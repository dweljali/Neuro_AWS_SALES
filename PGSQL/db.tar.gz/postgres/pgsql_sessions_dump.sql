--
-- Data for Name: activity; Type: TABLE DATA; Schema: sessions; Owner: postgres
--
COPY activity (id, severity, name, created_on, created_by, updated_on, updated_by) FROM stdin;
CHNGADDRES	NORMAL	Fund Transfer 2	2018-01-02 09:42:15.02+00	rbaadmin	2018-01-02 09:42:15.02+00	rbaadmin
CHNGPIN   	NORMAL	Fund Transfer 2	2018-01-02 09:42:22.503+00	rbaadmin	2018-01-02 09:42:22.503+00	rbaadmin
FUNDTRANS 	NORMAL	Fund Transfer 2	2018-01-02 09:42:01.319+00	rbaadmin	2018-01-02 09:44:12.27+00	rbaadmin
\.


--
-- Data for Name: method; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

COPY method (id, name, created_on, created_by, updated_on, updated_by) FROM stdin;
13	METHOD FUNDTRANS WEB	2018-01-02 09:42:01.31+00	rbaadmin	2018-01-02 09:42:01.31+00	rbaadmin
14	METHOD CHNGADDRES WEB	2018-01-02 09:42:15.014+00	rbaadmin	2018-01-02 09:42:15.014+00	rbaadmin
15	METHOD CHNGPIN WEB	2018-01-02 09:42:22.496+00	rbaadmin	2018-01-02 09:42:22.496+00	rbaadmin
\.


--
-- Data for Name: activity_by_channel; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

COPY activity_by_channel (activity_id, channel_id, user_type, score, status, created_on, created_by, updated_on, updated_by) FROM stdin;
CHNGADDRES	WEB            	USER	20	1	2018-01-02 09:42:15.025+00	rbaadmin	2018-01-02 09:42:15.025+00	rbaadmin
CHNGPIN   	WEB            	USER	20	1	2018-01-02 09:42:22.505+00	rbaadmin	2018-01-02 09:42:22.505+00	rbaadmin
FUNDTRANS 	WEB            	USER	20	1	2018-01-02 09:42:01.323+00	rbaadmin	2018-01-02 09:44:12.271+00	rbaadmin
\.


--
-- Data for Name: activity_method; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

COPY activity_method (activity_id, channel_id, user_type, method_id, created_on, created_by, updated_on, updated_by) FROM stdin;
FUNDTRANS 	WEB            	USER	13	2018-01-02 09:42:01.329+00	rbaadmin	2018-01-02 09:42:01.329+00	rbaadmin
CHNGADDRES	WEB            	USER	14	2018-01-02 09:42:15.035+00	rbaadmin	2018-01-02 09:42:15.035+00	rbaadmin
CHNGPIN   	WEB            	USER	15	2018-01-02 09:42:22.509+00	rbaadmin	2018-01-02 09:42:22.509+00	rbaadmin
\.


--
-- Data for Name: authenticator; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

COPY authenticator (id, name, fact_locator_id, status, created_on, created_by, updated_on, updated_by) FROM stdin;
ONLID     	ONLID	UserEnrollmentInfo	1	2018-01-02 09:39:37.998+00	rbaadmin	2018-01-02 09:39:37.998+00	rbaadmin
OTP       	One time Password	UserContactInfo	1	2018-01-02 09:39:38.001+00	rbaadmin	2018-01-02 09:40:15.648+00	rbaadmin
ZIP       	ZIP	UserInfo	1	2018-01-02 09:39:37.984+00	rbaadmin	2018-01-02 09:45:22.029+00	rbaadmin
\.


--
-- Data for Name: authenticator_method; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

COPY authenticator_method (authenticator_id, method_id, score, priority, mandatory_authentication, created_on, created_by, updated_on, updated_by) FROM stdin;
OTP       	14	20	1	N	2018-01-02 09:42:15.048+00	rbaadmin	2018-01-02 09:42:15.048+00	rbaadmin
ZIP       	14	50	2	N	2018-01-02 09:42:15.056+00	rbaadmin	2018-01-02 09:42:15.056+00	rbaadmin
OTP       	15	20	1	N	2018-01-02 09:42:22.526+00	rbaadmin	2018-01-02 09:42:22.526+00	rbaadmin
ZIP       	15	50	2	N	2018-01-02 09:42:22.538+00	rbaadmin	2018-01-02 09:42:22.538+00	rbaadmin
ZIP       	13	70	1	N	2018-01-02 09:44:12.279+00	rbaadmin	2018-01-02 09:44:12.279+00	rbaadmin
\.


--
-- Data for Name: configuration_audit; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

COPY configuration_audit (id, component, component_key, acted_by, data, acted_on, action, created_on, created_by) FROM stdin;
19	Authenticator	authId=ZIP	rbaadmin	"additions":[{"attributeName":"authName","newValueTxt":"ZIP"},{"attributeName":"factLocator","newValueTxt":"UserContactInfo"}]	2018-01-02 09:39:38.007+00	CREATED	2018-01-02 09:39:38.013+00	rbaadmin
20	Authenticator	authId=ONLID	rbaadmin	"additions":[{"attributeName":"authName","newValueTxt":"ONLID"},{"attributeName":"factLocator","newValueTxt":"UserEnrollmentInfo"}]	2018-01-02 09:39:38.045+00	CREATED	2018-01-02 09:39:38.049+00	rbaadmin
21	Authenticator	authId=OTP	rbaadmin	"additions":[{"attributeName":"authName","newValueTxt":"One time Password"},{"attributeName":"factLocator","newValueTxt":"One time Password"}]	2018-01-02 09:39:38.073+00	CREATED	2018-01-02 09:39:38.076+00	rbaadmin
22	Authenticator	authId=OTP	rbaadmin	"modifications":[{"attributeName":"factLocator","oldValueTxt":"None","newValueTxt":"UserContactInfo"}]	2018-01-02 09:40:15.655+00	MODIFIED	2018-01-02 09:40:15.658+00	rbaadmin
23	Activity	activityID=FUNDTRANS;channel=WEB;userType=User	rbaadmin	"additions":[{"attributeName":"activityAuthLevel","newValueTxt":"NORMAL"},{"attributeName":"activityName","newValueTxt":"Fund Transfer 2"},{"attributeName":"requiredScore","newValueTxt":"20"},{"attributeName":"riskAssessmentsAtActivityStart","newValueTxt":"[{riskAsmtId=TRAVEL},{riskAsmtId=DEVICE}]"},{"attributeName":"authenticators","newValueTxt":"[{id=OTP,score=20,priority=1},{id=ZIP,score=50,priority=2}]"}]	2018-01-02 09:42:01.416+00	CREATED	2018-01-02 09:42:01.418+00	rbaadmin
24	Activity	activityID=CHNGADDRES;channel=WEB;userType=User	rbaadmin	"additions":[{"attributeName":"activityAuthLevel","newValueTxt":"NORMAL"},{"attributeName":"activityName","newValueTxt":"Fund Transfer 2"},{"attributeName":"requiredScore","newValueTxt":"20"},{"attributeName":"riskAssessmentsAtActivityStart","newValueTxt":"[{riskAsmtId=TRAVEL},{riskAsmtId=DEVICE}]"},{"attributeName":"authenticators","newValueTxt":"[{id=OTP,score=20,priority=1},{id=ZIP,score=50,priority=2}]"}]	2018-01-02 09:42:15.075+00	CREATED	2018-01-02 09:42:15.077+00	rbaadmin
25	Activity	activityID=CHNGPIN;channel=WEB;userType=User	rbaadmin	"additions":[{"attributeName":"activityAuthLevel","newValueTxt":"NORMAL"},{"attributeName":"activityName","newValueTxt":"Fund Transfer 2"},{"attributeName":"requiredScore","newValueTxt":"20"},{"attributeName":"riskAssessmentsAtActivityStart","newValueTxt":"[{riskAsmtId=TRAVEL},{riskAsmtId=DEVICE}]"},{"attributeName":"authenticators","newValueTxt":"[{id=OTP,score=20,priority=1},{id=ZIP,score=50,priority=2}]"}]	2018-01-02 09:42:22.556+00	CREATED	2018-01-02 09:42:22.559+00	rbaadmin
26	Activity	activityID=FUNDTRANS;channel=WEB;userType=User	rbaadmin	"modifications":[{"attributeName":"authenticators","oldValueTxt":"[{id=ZIP,score=50,priority=2}]","newValueTxt":"[{id=ZIP,score=70,priority=1}]"}],"deletions":[{"attributeName":"authenticators","oldValueTxt":"[{id=OTP,score=20,priority=1}]"}]	2018-01-02 09:44:12.297+00	MODIFIED	2018-01-02 09:44:12.299+00	rbaadmin
27	Authenticator	authId=ZIP	rbaadmin	"modifications":[{"attributeName":"factLocator","oldValueTxt":"UserContactInfo","newValueTxt":"UserInfo"}]	2018-01-02 09:45:22.036+00	MODIFIED	2018-01-02 09:45:22.038+00	rbaadmin
\.
