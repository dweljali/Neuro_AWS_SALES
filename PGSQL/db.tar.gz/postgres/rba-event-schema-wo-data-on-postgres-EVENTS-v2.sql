--
-- PostgreSQL database dump
--

-- Dumped from database version 9.2.13
-- Dumped by pg_dump version 9.6.3

-- Started on 2017-08-04 18:39:00

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 7 (class 2615 OID 25168)
-- Name: events; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA events;

CREATE EXTENSION pgcrypto with SCHEMA events;


ALTER SCHEMA events OWNER TO postgres;

SET search_path = events, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 170 (class 1259 OID 25450)
-- Name: audit_event; Type: TABLE; Schema: events; Owner: postgres
--

CREATE TABLE audit_event (
    event_container_sk varchar(36) NOT NULL,
    activity_time timestamp with time zone NOT NULL,
    communication_date date NOT NULL,
    source varchar(50) DEFAULT NULL::character varying,
    channel character(15) DEFAULT NULL::bpchar,
    source_detail character(15) DEFAULT NULL::bpchar,
    initiated_by_user_id character(100) DEFAULT NULL::bpchar,
    initiated_by_user_type character(4) DEFAULT NULL::bpchar,
    server_id varchar(40) DEFAULT NULL::character varying,
    severity varchar(20) DEFAULT NULL::character varying,
    challenge varchar(100) DEFAULT NULL::character varying,
    event_type varchar(50) DEFAULT NULL::character varying,
    auth_outcome bigint,
    activity character(10) DEFAULT NULL::bpchar
);


ALTER TABLE audit_event OWNER TO postgres;

--
-- TOC entry 171 (class 1259 OID 25475)
-- Name: authentication_event; Type: TABLE; Schema: events; Owner: postgres
--

CREATE TABLE authentication_event (
    event_container_sk varchar(36) NOT NULL,
    activity_time timestamp with time zone NOT NULL,
    communication_date date NOT NULL,
    status character(1) NOT NULL,
    score smallint NOT NULL,
    activity character(10) DEFAULT NULL::bpchar
);


ALTER TABLE authentication_event OWNER TO postgres;

--
-- TOC entry 172 (class 1259 OID 25487)
-- Name: event_container; Type: TABLE; Schema: events; Owner: postgres
--

CREATE TABLE event_container (
    event_container_sk varchar(36) NOT NULL,
    communication_date date NOT NULL,
    session_id varchar(36) NOT NULL,
    com_with_user_id character(100) NOT NULL,
    com_with_user_type character(4) NOT NULL,
    record_time timestamp with time zone NOT NULL,
    communication_start_time timestamp with time zone
);


ALTER TABLE event_container OWNER TO postgres;


--
-- TOC entry 174 (class 1259 OID 25502)
-- Name: risk_assessment_event; Type: TABLE; Schema: events; Owner: postgres
--

CREATE TABLE risk_assessment_event (
    event_container_sk varchar(36) NOT NULL,
    communication_date date NOT NULL,
    risk_assessment_id varchar(10) NOT NULL,
    activity_time timestamp with time zone NOT NULL,
    score bigint,
    description varchar(255) DEFAULT NULL::character varying
);


ALTER TABLE risk_assessment_event OWNER TO postgres;

--
-- TOC entry 175 (class 1259 OID 25508)
-- Name: risk_factor_event; Type: TABLE; Schema: events; Owner: postgres
--

CREATE TABLE risk_factor_event (
    event_container_sk varchar(36) NOT NULL,
    communication_date date NOT NULL,
    activity_time timestamp with time zone NOT NULL,
    execution_time timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    risk_factor_id character(10) NOT NULL,
    status character(2) NOT NULL,
    value varchar(512) DEFAULT NULL::varchar
);


ALTER TABLE risk_factor_event OWNER TO postgres;

--
-- TOC entry 2768 (class 2606 OID 25469)
-- Name: audit_event audit_event_pkey; Type: CONSTRAINT; Schema: events; Owner: postgres
--

ALTER TABLE ONLY audit_event
    ADD CONSTRAINT audit_event_pkey PRIMARY KEY (event_container_sk, activity_time, communication_date);


--
-- TOC entry 2771 (class 2606 OID 25481)
-- Name: authentication_event authentication_event_pkey; Type: CONSTRAINT; Schema: events; Owner: postgres
--

ALTER TABLE ONLY authentication_event
    ADD CONSTRAINT authentication_event_pkey PRIMARY KEY (event_container_sk, activity_time, communication_date);


--
-- TOC entry 2773 (class 2606 OID 25491)
-- Name: event_container event_container_pkey; Type: CONSTRAINT; Schema: events; Owner: postgres
--

ALTER TABLE ONLY event_container
    ADD CONSTRAINT event_container_pkey PRIMARY KEY (event_container_sk, communication_date);



--
-- TOC entry 2779 (class 2606 OID 25507)
-- Name: risk_assessment_event risk_assessment_event_pkey; Type: CONSTRAINT; Schema: events; Owner: postgres
--

ALTER TABLE ONLY risk_assessment_event
    ADD CONSTRAINT risk_assessment_event_pkey PRIMARY KEY (event_container_sk, communication_date, risk_assessment_id, activity_time);


--
-- TOC entry 2782 (class 2606 OID 25517)
-- Name: risk_factor_event risk_factor_event_pkey; Type: CONSTRAINT; Schema: events; Owner: postgres
--

ALTER TABLE ONLY risk_factor_event
    ADD CONSTRAINT risk_factor_event_pkey PRIMARY KEY (event_container_sk, activity_time, communication_date, risk_factor_id);


--
-- TOC entry 2769 (class 1259 OID 25656)
-- Name: fk_audit_event; Type: INDEX; Schema: events; Owner: postgres
--

CREATE INDEX fk_audit_event ON audit_event USING btree (event_container_sk, communication_date);




--
-- TOC entry 2780 (class 1259 OID 25659)
-- Name: fk_risk_factor_event; Type: INDEX; Schema: events; Owner: postgres
--

CREATE INDEX fk_risk_factor_event ON risk_factor_event USING btree (event_container_sk, communication_date, activity_time);


--
-- TOC entry 2777 (class 1259 OID 25658)
-- Name: r_26; Type: INDEX; Schema: events; Owner: postgres
--

CREATE INDEX r_26 ON risk_assessment_event USING btree (event_container_sk, communication_date, activity_time);


--
-- TOC entry 2899 (class 0 OID 0)
-- Dependencies: 7
-- Name: events; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA events FROM PUBLIC;
REVOKE ALL ON SCHEMA events FROM postgres;
GRANT ALL ON SCHEMA events TO postgres;
GRANT USAGE ON SCHEMA events TO rba;


--
-- TOC entry 2900 (class 0 OID 0)
-- Dependencies: 170
-- Name: audit_event; Type: ACL; Schema: events; Owner: postgres
--

REVOKE ALL ON TABLE audit_event FROM PUBLIC;
REVOKE ALL ON TABLE audit_event FROM postgres;
GRANT ALL ON TABLE audit_event TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE audit_event TO rba;


--
-- TOC entry 2901 (class 0 OID 0)
-- Dependencies: 171
-- Name: authentication_event; Type: ACL; Schema: events; Owner: postgres
--

REVOKE ALL ON TABLE authentication_event FROM PUBLIC;
REVOKE ALL ON TABLE authentication_event FROM postgres;
GRANT ALL ON TABLE authentication_event TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE authentication_event TO rba;


--
-- TOC entry 2902 (class 0 OID 0)
-- Dependencies: 172
-- Name: event_container; Type: ACL; Schema: events; Owner: postgres
--

REVOKE ALL ON TABLE event_container FROM PUBLIC;
REVOKE ALL ON TABLE event_container FROM postgres;
GRANT ALL ON TABLE event_container TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE event_container TO rba;



--
-- TOC entry 2904 (class 0 OID 0)
-- Dependencies: 174
-- Name: risk_assessment_event; Type: ACL; Schema: events; Owner: postgres
--

REVOKE ALL ON TABLE risk_assessment_event FROM PUBLIC;
REVOKE ALL ON TABLE risk_assessment_event FROM postgres;
GRANT ALL ON TABLE risk_assessment_event TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_assessment_event TO rba;


--
-- TOC entry 2905 (class 0 OID 0)
-- Dependencies: 175
-- Name: risk_factor_event; Type: ACL; Schema: events; Owner: postgres
--

REVOKE ALL ON TABLE risk_factor_event FROM PUBLIC;
REVOKE ALL ON TABLE risk_factor_event FROM postgres;
GRANT ALL ON TABLE risk_factor_event TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_factor_event TO rba;


-- Completed on 2017-08-04 18:39:00

--
-- PostgreSQL database dump complete
--

