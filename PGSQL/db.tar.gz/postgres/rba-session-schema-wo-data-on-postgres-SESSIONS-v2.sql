
SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

DROP SCHEMA IF EXISTS sessions;
CREATE SCHEMA sessions;


DROP EXTENSION IF EXISTS pgcrypto;
CREATE EXTENSION pgcrypto with SCHEMA SESSIONS;

ALTER SCHEMA sessions OWNER TO postgres;

SET search_path = sessions, pg_catalog;


CREATE FUNCTION update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.EXPIRES_AT = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION sessions.update_timestamp() OWNER TO postgres;


CREATE FUNCTION update_timestamp_rba_users() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
    NEW.CREATED_ON = CURRENT_TIMESTAMP;
    RETURN NEW;
END;

$$;


ALTER FUNCTION sessions.update_timestamp_rba_users() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;


DROP TABLE IF EXISTS activity;
CREATE TABLE activity (
    id character(10) NOT NULL,
    severity varchar(20) NOT NULL,
    name varchar(50) NOT NULL,
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) NOT NULL
);

ALTER TABLE activity OWNER TO postgres;


DROP TABLE IF EXISTS channels;
CREATE TABLE channels (
    id character(15) NOT NULL,
    description varchar(50) NOT NULL,
	created_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	created_by varchar(20) NOT NULL DEFAULT 'rbaadmin',
    updated_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(20) NOT NULL DEFAULT 'rbaadmin'

);

ALTER TABLE channels OWNER TO postgres;


DROP TABLE IF EXISTS activity_by_channel;
CREATE TABLE activity_by_channel (
    activity_id character(10) NOT NULL,
    channel_id character(15) NOT NULL,
    user_type character(4) NOT NULL,
    score smallint NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_on timestamp with time zone NOT NULL,
	created_by varchar(20) not null,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) not null,
    CONSTRAINT activity_by_channel_status_check CHECK ((status >= 0))
);


ALTER TABLE activity_by_channel OWNER TO postgres;


DROP TABLE IF EXISTS activity_method;
CREATE TABLE activity_method (
    activity_id character(10) NOT NULL,
    channel_id character(15) NOT NULL,
    user_type character(4) NOT NULL,
    method_id bigint NOT NULL,
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) NOT NULL
);


ALTER TABLE activity_method OWNER TO postgres;


DROP TABLE IF EXISTS configuration_audit;
CREATE TABLE configuration_audit (
    id integer NOT NULL,
    component varchar(30) NOT NULL,
    component_key varchar(200) NOT NULL,
    acted_by varchar(20) NOT NULL,
    data varchar(4000) DEFAULT NULL::character varying,
    acted_on timestamp with time zone NOT NULL,
    action varchar(100) DEFAULT NULL::character varying,
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    CONSTRAINT change_audit_id_check CHECK ((id >= 0))
);

ALTER TABLE configuration_audit OWNER TO postgres;


DROP TABLE IF EXISTS configurations;
CREATE TABLE configurations (
    id varchar(100) NOT NULL,
    current_value varchar(100) NOT NULL,
    allowed_values varchar(1000) NOT NULL,
	created_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	created_by varchar(20) NOT NULL DEFAULT 'rbaadmin',
    updated_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(20) NOT NULL DEFAULT 'rbaadmin'
);

ALTER TABLE configurations OWNER TO postgres;


DROP SEQUENCE IF EXISTS config_audit_id_seq;
CREATE SEQUENCE config_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config_audit_id_seq OWNER TO postgres;


DROP TABLE IF EXISTS authenticator_method;
CREATE TABLE authenticator_method (
    authenticator_id character(10) NOT NULL,
    method_id bigint NOT NULL,
    score smallint NOT NULL,
    priority smallint NOT NULL,
    mandatory_authentication character(1) DEFAULT NULL::bpchar,
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) NOT NULL
);


ALTER TABLE authenticator_method OWNER TO postgres;


DROP TABLE IF EXISTS authenticator;
CREATE TABLE authenticator (
    id character(10) NOT NULL,
    name varchar(100) NOT NULL,
    fact_locator_id varchar(25) NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_on timestamp with time zone NOT NULL,
	created_by varchar(20) not null,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) not null,
    CONSTRAINT authenticator_status_check CHECK ((status >= 0))
);


ALTER TABLE authenticator OWNER TO postgres;


DROP SEQUENCE IF EXISTS id_seq;
CREATE SEQUENCE id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE id_seq OWNER TO postgres;

ALTER SEQUENCE id_seq OWNED BY configuration_audit.id;


DROP TABLE IF EXISTS login_sessions;
CREATE TABLE login_sessions (
    token varchar(45) NOT NULL,
    expires_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_id varchar(20) NOT NULL,
    generated_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status integer NOT NULL
);

ALTER TABLE login_sessions OWNER TO postgres;


DROP TABLE IF EXISTS method;
CREATE TABLE method (
    id bigint NOT NULL,
    name varchar(100) NOT NULL,
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) NOT NULL
);

ALTER TABLE method OWNER TO postgres;


DROP SEQUENCE IF EXISTS method_id_seq;
CREATE SEQUENCE method_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE method_id_seq OWNER TO postgres;


ALTER SEQUENCE method_id_seq OWNED BY method.id;


DROP SEQUENCE IF EXISTS method_method_id_seq;
CREATE SEQUENCE method_method_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE method_method_id_seq OWNER TO postgres;


DROP TABLE IF EXISTS user_auth_element;
CREATE TABLE user_auth_element (
    user_authentication_sk varchar(36) NOT NULL,
    response_time timestamp with time zone NOT NULL,
    authenticator_id character(10) NOT NULL,
    channel character(15) NOT NULL,
    status character(1) NOT NULL,
    score smallint NOT NULL,
    source varchar(50) NOT NULL,
    activity character(10) DEFAULT NULL::bpchar
);


ALTER TABLE user_auth_element OWNER TO postgres;


DROP TABLE IF EXISTS user_auth_in_com_session;
CREATE TABLE user_auth_in_com_session (
    user_authentication_sk varchar(36) NOT NULL,
    session_id varchar(36) NOT NULL,
    user_type character(4) NOT NULL,
    user_id character(100) NOT NULL,
    session_start_time timestamp with time zone NOT NULL,
    severity character(5) DEFAULT NULL::bpchar,
    session_score smallint,
    last_update_time timestamp with time zone NOT NULL,
    user_preference character(5) DEFAULT NULL::bpchar,
    risk_score smallint NOT NULL DEFAULT 0,
    current_activity character(10) DEFAULT NULL::bpchar
);


ALTER TABLE user_auth_in_com_session OWNER TO postgres;


DROP TABLE IF EXISTS user_auth_location_data;
CREATE TABLE user_auth_location_data (
    user_authentication_sk varchar(36) NOT NULL,
    user_id character(100) NOT NULL,
    last_authn_time timestamp with time zone NOT NULL,
    country_code character(3) DEFAULT NULL::bpchar,
    country_name varchar(30) DEFAULT NULL::character varying,
    continent varchar(15) DEFAULT NULL::character varying,
    sub_division_name varchar(50) DEFAULT NULL::character varying,
    sub_division_code character(3) DEFAULT NULL::bpchar,
    cityname varchar(100) DEFAULT NULL::character varying,
    postalcode varchar(10) DEFAULT NULL::character varying,
    latitude numeric(10,6) DEFAULT NULL::numeric,
    longitude numeric(10,6) DEFAULT NULL::numeric,
    timezone varchar(50) DEFAULT NULL::character varying,
    metrocode character(3) DEFAULT NULL::bpchar,
	ip_address character(16) NOT NULL
);


ALTER TABLE user_auth_location_data OWNER TO postgres;


DROP TABLE IF EXISTS user_risk_assessment;
CREATE TABLE user_risk_assessment (
    user_authentication_sk varchar(36) NOT NULL,
    execution_time timestamp with time zone NOT NULL,
    risk_asmt_id character(10) NOT NULL,
    activity_id character(10) DEFAULT NULL::bpchar,
    status character(2) NOT NULL,
    score smallint
);


ALTER TABLE user_risk_assessment OWNER TO postgres;


DROP TABLE IF EXISTS user_risk_factor;
CREATE TABLE user_risk_factor (
    user_authentication_sk varchar(36) NOT NULL,
    execution_time timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    risk_factor_id character(10) NOT NULL,
    status character(2) NOT NULL,
    value varchar(512) DEFAULT NULL::character varying
);


ALTER TABLE user_risk_factor OWNER TO postgres;


DROP TABLE IF EXISTS rba_users;
CREATE TABLE rba_users (
    id varchar(20) NOT NULL,
    password bytea NOT NULL,
    first_name varchar(45) DEFAULT 'FN'::character varying NOT NULL,
    last_name varchar(45) DEFAULT 'LN'::character varying NOT NULL,
    email varchar(45) DEFAULT NULL::character varying,
    address varchar(120) DEFAULT NULL::character varying,
    created_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by varchar(20) NOT NULL,
    role varchar(45) NOT NULL
);


ALTER TABLE rba_users OWNER TO postgres;

DROP TABLE IF EXISTS risk_assessment;
CREATE TABLE risk_assessment (
    id character(10) NOT NULL,
    name varchar(50) NOT NULL,
    invocation_code character(2) NOT NULL,
    rerun_on_failure character(1) DEFAULT 'F'::bpchar,
	created_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	created_by varchar(20) NOT NULL DEFAULT 'rbaadmin',
    updated_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(20) NOT NULL DEFAULT 'rbaadmin'
);


ALTER TABLE risk_assessment OWNER TO postgres;

DROP TABLE IF EXISTS risk_assessment_method;
CREATE TABLE risk_assessment_method (
    method_id bigint NOT NULL,
    risk_asmt_id character(10) NOT NULL,
    operation_mode character(1) NOT NULL,
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) NOT NULL
);


ALTER TABLE risk_assessment_method OWNER TO postgres;


DROP TABLE IF EXISTS risk_assessment_config;
CREATE TABLE risk_assessment_config (
    risk_asmt_id character(10) NOT NULL,
    id character(10) NOT NULL,
    name varchar(50) NOT NULL,
    description varchar(255) NOT NULL,
    type varchar(25) NOT NULL,
    data_type varchar(25) NOT NULL,
    value varchar(255) NOT NULL,
	created_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	created_by varchar(20) NOT NULL DEFAULT 'rbaadmin',
    updated_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(20) NOT NULL DEFAULT 'rbaadmin'
);


ALTER TABLE risk_assessment_config OWNER TO postgres;

DROP TABLE IF EXISTS risk_assessment_factor;
CREATE TABLE risk_assessment_factor (
    risk_factor_id character(10) NOT NULL,
    risk_asmt_id character(10) NOT NULL,
    rerun_on_factor_change character(1) DEFAULT 'F'::bpchar NOT NULL,
    risk_asmt_classname varchar(100) DEFAULT NULL::character varying,
    risk_factor_classname varchar(100) DEFAULT NULL::character varying,
    risk_factor_locator_classname varchar(100) DEFAULT NULL::character varying,
	created_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	created_by varchar(20) NOT NULL DEFAULT 'rbaadmin',
    updated_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(20) NOT NULL DEFAULT 'rbaadmin'
);


ALTER TABLE risk_assessment_factor OWNER TO postgres;

DROP TABLE IF EXISTS risk_factor;
CREATE TABLE risk_factor (
    id character(10) NOT NULL,
    name varchar(50) NOT NULL,
    data_type varchar(18) NOT NULL,
    invocation_code character(2) NOT NULL,
    provided_by_system varchar(25) NOT NULL,
    retry_collection_on_failure character(1) DEFAULT 'F'::bpchar NOT NULL,
	created_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	created_by varchar(20) NOT NULL DEFAULT 'rbaadmin',
    updated_on timestamp with time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_by varchar(20) NOT NULL DEFAULT 'rbaadmin'
);


ALTER TABLE risk_factor OWNER TO postgres;

DROP TABLE IF EXISTS  sessions.vw_activity;
CREATE VIEW sessions.vw_activity AS
SELECT act.id AS activity_id, act.severity AS activity_severity, act.name AS activity_name, actByChannel.channel_id AS channel, actByChannel.user_type AS user_type, actByChannel.score AS score, actByChannel.status AS status, actMethod.method_id AS method_id, method.name AS method_name, actByChannel.created_on AS created_on , actByChannel.updated_on AS updated_on FROM sessions.activity  AS act, sessions.activity_by_channel AS actByChannel, sessions.activity_method AS actMethod, sessions.method AS method WHERE act.id = actByChannel.activity_id AND actByChannel.activity_id = actMethod.activity_id AND actByChannel.channel_id = actMethod.channel_id AND actByChannel.user_type = actMethod.user_type AND actMethod.method_id = method.id;
ALTER TABLE sessions.vw_activity OWNER TO postgres;


DROP TABLE IF EXISTS sessions.vw_authenticator;
CREATE VIEW sessions.vw_authenticator AS
SELECT auth.id AS authenticator_id, auth.name AS authenticator_name, auth.status AS authenticator_status, actMethod.channel_id AS channel, authMethod.method_id AS method_id, authMethod.priority AS priority, auth.fact_locator_id AS fact_locator_id, authMethod.score AS score, method.name AS method_name, authMethod.mandatory_authentication AS mandatory_authentication, auth.created_on AS created_on, auth.updated_on AS updated_on FROM sessions.authenticator AS auth, sessions.authenticator_method AS authMethod, sessions.method AS method, sessions.activity_method AS actMethod WHERE auth.id=authMethod.authenticator_id AND authMethod.method_id=method.id AND method.id=actMethod.method_id;

ALTER TABLE sessions.vw_authenticator OWNER TO postgres;


DROP TABLE IF EXISTS sessions.vw_riskassessment;
CREATE VIEW sessions.vw_riskassessment AS
SELECT riskAssessment.id AS risk_asmt_id, riskAssessment.name AS risk_asmt_name, riskAssessment.invocation_code AS risk_asmt_invocation_code, riskAssessment.rerun_on_failure AS rerun_on_failure, riskAssessmentFactor.rerun_on_factor_change AS rerun_on_factor_change, riskAssessmentMethod.operation_mode AS operation_mode, riskFactor.id AS risk_factor_id, riskFactor.name AS risk_factor_name, riskFactor.data_type AS data_type, riskFactor.invocation_code AS risk_factor_invocation_code, riskFactor.provided_by_system  AS provided_by_system, riskFactor.retry_collection_on_failure AS retry_collection_on_failure,  actMethod.channel_id AS channel, riskAssessmentMethod.method_id AS method_id, method.name AS method_name, riskAssessmentConfig.id AS config_id, riskAssessmentConfig.name AS config_name, riskAssessmentConfig.description AS config_description, riskAssessmentConfig.type AS config_type, riskAssessmentConfig.data_type AS config_datatype, riskAssessmentConfig.value AS config_value FROM sessions.risk_assessment AS riskAssessment, sessions.risk_assessment_config AS riskAssessmentConfig, sessions.risk_assessment_factor riskAssessmentFactor, sessions.risk_factor riskFactor, sessions.risk_assessment_method riskAssessmentMethod, sessions.method method, sessions.activity_method actMethod WHERE riskAssessment.id=riskAssessmentConfig.risk_asmt_id AND riskAssessment.id=riskAssessmentFactor.risk_asmt_id AND riskAssessmentFactor.risk_factor_id=riskFactor.id AND riskAssessment.id=riskAssessmentMethod.risk_asmt_id AND riskAssessmentMethod.method_id=method.id AND method.id=actMethod.method_id;
ALTER TABLE sessions.vw_riskassessment OWNER TO postgres;

ALTER TABLE ONLY configuration_audit ALTER COLUMN id SET DEFAULT nextval('id_seq'::regclass);

ALTER TABLE ONLY method ALTER COLUMN id SET DEFAULT nextval('method_id_seq'::regclass);


SELECT pg_catalog.setval('config_audit_id_seq', 1, true);


SELECT pg_catalog.setval('id_seq', 18, true);


SELECT pg_catalog.setval('method_id_seq', 12, true);


SELECT pg_catalog.setval('method_method_id_seq', 1, false);


ALTER TABLE ONLY activity_by_channel
    ADD CONSTRAINT activity_by_channel_pkey PRIMARY KEY (activity_id, channel_id, user_type);


ALTER TABLE ONLY activity_method
    ADD CONSTRAINT activity_method_pkey PRIMARY KEY (activity_id, channel_id, user_type, method_id);


ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);
    
ALTER TABLE ONLY channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


ALTER TABLE ONLY configuration_audit
    ADD CONSTRAINT config_audit_pkey PRIMARY KEY (id);


ALTER TABLE ONLY configurations
    ADD CONSTRAINT configurations_pkey PRIMARY KEY (id);


ALTER TABLE ONLY authenticator_method
    ADD CONSTRAINT authenticator_by_channel_pkey PRIMARY KEY (authenticator_id, method_id);


ALTER TABLE ONLY authenticator
    ADD CONSTRAINT authenticator_pkey PRIMARY KEY (id);


ALTER TABLE ONLY login_sessions
    ADD CONSTRAINT login_sessions_pkey PRIMARY KEY (token);


ALTER TABLE ONLY method
    ADD CONSTRAINT method_pkey PRIMARY KEY (id);


ALTER TABLE ONLY user_auth_element
    ADD CONSTRAINT user_auth_element_pkey PRIMARY KEY (user_authentication_sk, response_time, authenticator_id);


ALTER TABLE ONLY user_auth_in_com_session
    ADD CONSTRAINT user_auth_in_com_session_pkey PRIMARY KEY (user_authentication_sk);


ALTER TABLE ONLY user_auth_location_data
    ADD CONSTRAINT user_auth_location_data_pkey PRIMARY KEY (user_authentication_sk);


ALTER TABLE ONLY user_risk_assessment
    ADD CONSTRAINT user_risk_assessment_pkey PRIMARY KEY (user_authentication_sk, execution_time, risk_asmt_id);


ALTER TABLE ONLY user_risk_factor
    ADD CONSTRAINT user_risk_factor_pkey PRIMARY KEY (user_authentication_sk, execution_time, risk_factor_id);


ALTER TABLE ONLY rba_users
    ADD CONSTRAINT rba_users_pkey PRIMARY KEY (id);


ALTER TABLE ONLY risk_assessment_method
    ADD CONSTRAINT risk_assessment_by_channel_pkey PRIMARY KEY (method_id, risk_asmt_id);


ALTER TABLE ONLY risk_assessment_config
    ADD CONSTRAINT risk_assessment_config_pkey PRIMARY KEY (risk_asmt_id, id);


ALTER TABLE ONLY risk_assessment_factor
    ADD CONSTRAINT risk_assessment_factor_pkey PRIMARY KEY (risk_factor_id, risk_asmt_id);


ALTER TABLE ONLY risk_assessment
    ADD CONSTRAINT risk_assessment_pkey PRIMARY KEY (id);


ALTER TABLE ONLY risk_factor
    ADD CONSTRAINT risk_factor_pkey PRIMARY KEY (id);


CREATE INDEX "USER_AUTH_ELEMENT_INDEX_1" ON user_auth_element USING btree (user_authentication_sk, authenticator_id, status);


CREATE INDEX "USER_AUTH_IN_COM_SESSION_INDEX_1" ON user_auth_in_com_session USING btree (session_id, user_type, user_id);


CREATE INDEX "USER_AUTH_LOCATION_DATA_INDEX_1" ON user_auth_location_data USING btree (user_id);


CREATE INDEX "USER_AUTH_LOCATION_DATA_INDEX_2" ON user_auth_location_data USING btree (last_authn_time);


CREATE INDEX "USER_AUTH_LOCATION_DATA_INDEX_3" ON user_auth_location_data USING btree (user_id, user_authentication_sk);


CREATE INDEX "USER_RISK_ASSESSMENT_INDEX_1" ON user_risk_assessment USING btree (user_authentication_sk);


CREATE INDEX "USER_RISK_ASSESSMENT_INDEX_2" ON user_risk_assessment USING btree (execution_time);


CREATE INDEX "USER_RISK_FACTOR_INDEX_1" ON user_risk_factor USING btree (user_authentication_sk);


CREATE INDEX "USER_RISK_FACTOR_INDEX_2" ON user_risk_factor USING btree (execution_time);


CREATE UNIQUE INDEX authen_name_unique ON authenticator USING btree (name);


CREATE INDEX fk_def_method ON authenticator_method USING btree (method_id);


CREATE INDEX fk_method_activity_method ON activity_method USING btree (method_id);


CREATE INDEX fki_fk_activity_activity_by_channel ON activity_by_channel USING btree (activity_id);


CREATE INDEX fki_fk_def_channel ON authenticator_method USING btree (authenticator_id);


CREATE INDEX fki_fk_risk_assessment_config_to_risk_assessment ON risk_assessment_config USING btree (risk_asmt_id);


CREATE INDEX fki_r_42 ON risk_assessment_method USING btree (method_id);


CREATE INDEX fki_r_53 ON user_risk_factor USING btree (user_authentication_sk);


CREATE INDEX fki_r_58 ON user_risk_assessment USING btree (user_authentication_sk);


CREATE UNIQUE INDEX id_unique ON configuration_audit USING btree (id);


CREATE INDEX r_60 ON risk_assessment_method USING btree (risk_asmt_id);


CREATE INDEX r_61 ON risk_assessment_factor USING btree (risk_asmt_id);


CREATE UNIQUE INDEX token_unique ON login_sessions USING btree (token);


CREATE INDEX user_id_fk_idx ON login_sessions USING btree (user_id);


CREATE UNIQUE INDEX user_id_unique ON rba_users USING btree (id);


ALTER TABLE ONLY activity_by_channel
    ADD CONSTRAINT fk_activity_activity_by_channel FOREIGN KEY (activity_id) REFERENCES activity(id);
	
	ALTER TABLE ONLY activity_by_channel
    ADD CONSTRAINT fk_channel_activity_by_channel FOREIGN KEY (channel_id) REFERENCES channels(id);


ALTER TABLE ONLY authenticator_method
    ADD CONSTRAINT fk_def_auth FOREIGN KEY (authenticator_id) REFERENCES authenticator(id);


ALTER TABLE ONLY authenticator_method
    ADD CONSTRAINT fk_def_method FOREIGN KEY (method_id) REFERENCES method(id);


ALTER TABLE ONLY activity_method
    ADD CONSTRAINT fk_method_activity_method FOREIGN KEY (method_id) REFERENCES method(id);



ALTER TABLE ONLY user_auth_location_data
    ADD CONSTRAINT fk_user_auth_location_data FOREIGN KEY (user_authentication_sk) REFERENCES user_auth_in_com_session(user_authentication_sk);


ALTER TABLE ONLY risk_assessment_config
    ADD CONSTRAINT fk_risk_assessment_config_to_risk_assessment FOREIGN KEY (risk_asmt_id) REFERENCES risk_assessment(id);


ALTER TABLE ONLY risk_assessment_method
    ADD CONSTRAINT r_42 FOREIGN KEY (method_id) REFERENCES method(id);


ALTER TABLE ONLY user_risk_factor
    ADD CONSTRAINT r_53 FOREIGN KEY (user_authentication_sk) REFERENCES user_auth_in_com_session(user_authentication_sk);


ALTER TABLE ONLY user_risk_assessment
    ADD CONSTRAINT r_58 FOREIGN KEY (user_authentication_sk) REFERENCES user_auth_in_com_session(user_authentication_sk);


ALTER TABLE ONLY risk_assessment_method
    ADD CONSTRAINT r_60 FOREIGN KEY (risk_asmt_id) REFERENCES risk_assessment(id);


ALTER TABLE ONLY risk_assessment_factor
    ADD CONSTRAINT fk_risk_fact FOREIGN KEY (risk_factor_id) REFERENCES risk_factor(id);


ALTER TABLE ONLY risk_assessment_factor
    ADD CONSTRAINT r_61 FOREIGN KEY (risk_asmt_id) REFERENCES risk_assessment(id);


ALTER TABLE ONLY rba_users
  ADD CONSTRAINT created_by_fk FOREIGN KEY (created_by) REFERENCES rba_users(id);
  
  
ALTER TABLE ONLY rba_users
  ADD CONSTRAINT updated_by_fk FOREIGN KEY (updated_by) REFERENCES rba_users(id);
  

REVOKE ALL ON SCHEMA sessions FROM PUBLIC;
REVOKE ALL ON SCHEMA sessions FROM postgres;
GRANT ALL ON SCHEMA sessions TO postgres;
GRANT USAGE ON SCHEMA sessions TO rba;


REVOKE ALL ON TABLE activity FROM PUBLIC;
REVOKE ALL ON TABLE activity FROM postgres;
GRANT ALL ON TABLE activity TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE activity TO rba;


REVOKE ALL ON TABLE channels FROM PUBLIC;
REVOKE ALL ON TABLE channels FROM postgres;
GRANT ALL ON TABLE channels TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE channels TO rba;


REVOKE ALL ON TABLE activity_by_channel FROM PUBLIC;
REVOKE ALL ON TABLE activity_by_channel FROM postgres;
GRANT ALL ON TABLE activity_by_channel TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE activity_by_channel TO rba;


REVOKE ALL ON TABLE activity_method FROM PUBLIC;
REVOKE ALL ON TABLE activity_method FROM postgres;
GRANT ALL ON TABLE activity_method TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE activity_method TO rba;


REVOKE ALL ON TABLE configuration_audit FROM PUBLIC;
REVOKE ALL ON TABLE configuration_audit FROM postgres;
GRANT ALL ON TABLE configuration_audit TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE configuration_audit TO rba;


REVOKE ALL ON TABLE configurations FROM PUBLIC;
REVOKE ALL ON TABLE configurations FROM postgres;
GRANT ALL ON TABLE configurations TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE configurations TO rba;


REVOKE ALL ON TABLE authenticator_method FROM PUBLIC;
REVOKE ALL ON TABLE authenticator_method FROM postgres;
GRANT ALL ON TABLE authenticator_method TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE authenticator_method TO rba;



REVOKE ALL ON TABLE authenticator FROM PUBLIC;
REVOKE ALL ON TABLE authenticator FROM postgres;
GRANT ALL ON TABLE authenticator TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE authenticator TO rba;


REVOKE ALL ON SEQUENCE id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE id_seq FROM postgres;
GRANT ALL ON SEQUENCE id_seq TO postgres;
GRANT USAGE ON SEQUENCE id_seq TO rba;


REVOKE ALL ON TABLE login_sessions FROM PUBLIC;
REVOKE ALL ON TABLE login_sessions FROM postgres;
GRANT ALL ON TABLE login_sessions TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE login_sessions TO rba;


REVOKE ALL ON TABLE method FROM PUBLIC;
REVOKE ALL ON TABLE method FROM postgres;
GRANT ALL ON TABLE method TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE method TO rba;


REVOKE ALL ON SEQUENCE method_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE method_id_seq FROM postgres;
GRANT ALL ON SEQUENCE method_id_seq TO postgres;
GRANT USAGE ON SEQUENCE method_id_seq TO rba;


REVOKE ALL ON TABLE user_auth_element FROM PUBLIC;
REVOKE ALL ON TABLE user_auth_element FROM postgres;
GRANT ALL ON TABLE user_auth_element TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE user_auth_element TO rba;


REVOKE ALL ON TABLE user_auth_in_com_session FROM PUBLIC;
REVOKE ALL ON TABLE user_auth_in_com_session FROM postgres;
GRANT ALL ON TABLE user_auth_in_com_session TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE user_auth_in_com_session TO rba;


REVOKE ALL ON TABLE user_auth_location_data FROM PUBLIC;
REVOKE ALL ON TABLE user_auth_location_data FROM postgres;
GRANT ALL ON TABLE user_auth_location_data TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE user_auth_location_data TO rba;


REVOKE ALL ON TABLE user_risk_assessment FROM PUBLIC;
REVOKE ALL ON TABLE user_risk_assessment FROM postgres;
GRANT ALL ON TABLE user_risk_assessment TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE user_risk_assessment TO rba;


REVOKE ALL ON TABLE user_risk_factor FROM PUBLIC;
REVOKE ALL ON TABLE user_risk_factor FROM postgres;
GRANT ALL ON TABLE user_risk_factor TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE user_risk_factor TO rba;


REVOKE ALL ON TABLE rba_users FROM PUBLIC;
REVOKE ALL ON TABLE rba_users FROM postgres;
GRANT ALL ON TABLE rba_users TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE rba_users TO rba;


REVOKE ALL ON TABLE risk_assessment FROM PUBLIC;
REVOKE ALL ON TABLE risk_assessment FROM postgres;
GRANT ALL ON TABLE risk_assessment TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_assessment TO rba;


REVOKE ALL ON TABLE risk_assessment_method FROM PUBLIC;
REVOKE ALL ON TABLE risk_assessment_method FROM postgres;
GRANT ALL ON TABLE risk_assessment_method TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_assessment_method TO rba;


REVOKE ALL ON TABLE risk_assessment_config FROM PUBLIC;
REVOKE ALL ON TABLE risk_assessment_config FROM postgres;
GRANT ALL ON TABLE risk_assessment_config TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_assessment_config TO rba;


REVOKE ALL ON TABLE risk_assessment_factor FROM PUBLIC;
REVOKE ALL ON TABLE risk_assessment_factor FROM postgres;
GRANT ALL ON TABLE risk_assessment_factor TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_assessment_factor TO rba;


REVOKE ALL ON TABLE risk_factor FROM PUBLIC;
REVOKE ALL ON TABLE risk_factor FROM postgres;
GRANT ALL ON TABLE risk_factor TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE risk_factor TO rba;


REVOKE ALL ON TABLE vw_activity FROM PUBLIC;
REVOKE ALL ON TABLE vw_activity FROM postgres;
GRANT ALL ON TABLE vw_activity TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE vw_activity TO rba;


REVOKE ALL ON TABLE vw_authenticator FROM PUBLIC;
REVOKE ALL ON TABLE vw_authenticator FROM postgres;
GRANT ALL ON TABLE vw_authenticator TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE vw_authenticator TO rba;


REVOKE ALL ON TABLE vw_riskassessment FROM PUBLIC;
REVOKE ALL ON TABLE vw_riskassessment FROM postgres;
GRANT ALL ON TABLE vw_riskassessment TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE vw_riskassessment TO rba;


ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON SEQUENCES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON SEQUENCES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT SELECT,USAGE ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT USAGE ON SEQUENCES  TO rba;


ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON TYPES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON TYPES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT ALL ON TYPES  TO postgres;


ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON FUNCTIONS  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON FUNCTIONS  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT ALL ON FUNCTIONS  TO rba;


ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sessions GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO rba;


INSERT INTO sessions.rba_users (id, password, created_by, updated_by, role) 
VALUES ('RBA_ADMIN', '\xa57007e8db803787034b784d8d476631', 'RBA_ADMIN', 'RBA_ADMIN', 'ADMIN');

INSERT INTO sessions.rba_users (id, password, first_name, last_name, email, address, created_on, created_by, updated_on, updated_by, role)
VALUES ('rbaadmin', '\xa57007e8db803787034b784d8d476631', 'Neuro', 'Admin', NULL, NULL, CURRENT_TIMESTAMP, 'RBA_ADMIN', CURRENT_TIMESTAMP, 'RBA_ADMIN', 'NEURO_ADMIN');

INSERT INTO sessions.rba_users (id, password, first_name, last_name, email, address, created_on, created_by, updated_on, updated_by, role)
VALUES ('chetan', '\xa57007e8db803787034b784d8d476631', 'Chetan', 'Desai', NULL, NULL, CURRENT_TIMESTAMP, 'RBA_ADMIN', CURRENT_TIMESTAMP, 'RBA_ADMIN', 'NEURO_ADMIN');

INSERT INTO sessions.rba_users (id, password, first_name, last_name, email, address, created_on, created_by, updated_on, updated_by, role)
VALUES ('sachin', '\xa57007e8db803787034b784d8d476631', 'Sachin', 'Patil', NULL, NULL, CURRENT_TIMESTAMP, 'RBA_ADMIN', CURRENT_TIMESTAMP, 'RBA_ADMIN', 'FRAUD_INVESTIGATOR');


INSERT INTO sessions.channels(id,description) VALUES('WEB', 'Internet Banking');
INSERT INTO sessions.channels(id,description) VALUES('MOBILE', 'Mobile Banking');

INSERT INTO sessions.configurations (id, current_value, allowed_values) VALUES ('RISK_AGGREGATION_POLICY', 'TOT', 'TOT:MAX:AVG');

DROP TABLE IF EXISTS sessions.RULES;
CREATE TABLE sessions.RULES (
  ID varchar(50),
  NAME varchar(50) NOT NULL UNIQUE,
  DESCRIPTION varchar(250),
  FACTSERVICE varchar(50) NOT NULL,
  FACTLOOKUPKEY varchar(50) NOT NULL,
  CREATED_ON timestamp with time zone,
  CREATED_BY varchar(20),
  UPDATED_ON timestamp with time zone,
  UPDATED_BY varchar(20),
  PRIMARY KEY (ID)
);

DROP TABLE IF EXISTS sessions.RULE_CONDITION;
CREATE TABLE sessions.RULE_CONDITION (
  ID varchar(50),
   RULEID varchar(50) NOT NULL,
   ATTRIBUTE varchar(50) NOT NULL,
   COND_OP varchar(20) NOT NULL,
  VALUE varchar(50) NOT NULL,
   RULE_OP varchar(20),
   COND_ORDER bigint NOT NULL,
  CREATED_ON timestamp with time zone,
  CREATED_BY varchar(20),
  UPDATED_ON timestamp with time zone,
  UPDATED_BY varchar(20),
  PRIMARY KEY (ID),
  CONSTRAINT FK_RULES FOREIGN KEY (RULEID) REFERENCES sessions.RULES (ID) ON DELETE NO ACTION ON UPDATE NO ACTION
);

DROP TABLE IF EXISTS sessions.CONDITION_OPERATORS;
CREATE TABLE sessions.CONDITION_OPERATORS (
  ID bigint NOT NULL,
  NAME varchar(50) NOT NULL,
  CODE varchar(20),
  CLASS_NAME varchar(250),
  CREATED_ON timestamp with time zone,
  CREATED_BY varchar(20),
  UPDATED_ON timestamp with time zone,
  UPDATED_BY varchar(20),
  PRIMARY KEY (ID)
);

	
	INSERT INTO sessions.condition_operators
(ID, NAME, CODE, CLASS_NAME,CREATED_ON, CREATED_BY,UPDATED_ON,UPDATED_BY) 
VALUES (1, 'Starts With', 'SW','com.persistent.rba.rule.operator.StartsWithOperation',  CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

INSERT INTO sessions.condition_operators
(ID, NAME, CODE,CLASS_NAME, CREATED_ON, CREATED_BY,UPDATED_ON,UPDATED_BY) 
VALUES (2, 'Contains', 'CO','com.persistent.rba.rule.operator.ContainsOperation', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

INSERT INTO sessions.condition_operators
(ID, NAME, CODE,CLASS_NAME, CREATED_ON, CREATED_BY,UPDATED_ON,UPDATED_BY) 
VALUES (3, 'Equals To', 'ET','com.persistent.rba.rule.operator.EqualsOperation',  CURRENT_TIMESTAMP, 'rbaadmin',CURRENT_TIMESTAMP, 'rbaadmin');

INSERT INTO sessions.condition_operators
(ID, NAME, CODE,CLASS_NAME, CREATED_ON, CREATED_BY,UPDATED_ON,UPDATED_BY) 
VALUES (4, 'Not Equals To', 'NE','com.persistent.rba.rule.operator.NotEqualsOperation', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

INSERT INTO sessions.condition_operators
(ID, NAME, CODE,CLASS_NAME, CREATED_ON, CREATED_BY,UPDATED_ON,UPDATED_BY) 
VALUES (5, 'Ends With' , 'EW', 'com.persistent.rba.rule.operator.EndsWithOperation',CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

CREATE UNIQUE INDEX activity_channel_id_unique ON sessions.activity_by_channel USING btree (activity_id,channel_id);

DROP TABLE IF EXISTS sessions.ACTIVITY_RULES;
CREATE TABLE sessions.ACTIVITY_RULES (
  ID varchar(50) NOT NULL,
  RULEID varchar(50) NOT NULL,
  RULE_TYPE varchar(50)NOT NULL,
  ACTIVITY char(10) NOT NULL,
  CHANNEL char(15) NOT NULL,
  CREATED_ON timestamp with time zone,
  CREATED_BY varchar(20),
  UPDATED_ON timestamp with time zone,
  UPDATED_BY varchar(20),
   PRIMARY KEY (ID),
   CONSTRAINT FK_ACTIVITY_BY_CHANNEL FOREIGN KEY (ACTIVITY,CHANNEL) REFERENCES sessions.ACTIVITY_BY_CHANNEL (ACTIVITY_ID,CHANNEL_ID) ON DELETE NO ACTION ON UPDATE NO ACTION,
   CONSTRAINT FK_RULE_ID FOREIGN KEY (RULEID) REFERENCES sessions.RULES (ID) ON DELETE NO ACTION ON UPDATE NO ACTION 
);

DROP TABLE IF EXISTS sessions.fact_config;
CREATE TABLE sessions.fact_config (
    factkey varchar(100) NOT NULL,
    name varchar(200) NOT NULL,
    factlocatorclass varchar(500),
	created_on timestamp with time zone NOT NULL,
	created_by varchar(20) NOT NULL,
    updated_on timestamp with time zone NOT NULL,
	updated_by varchar(20) NOT NULL
);

ALTER TABLE sessions.fact_config OWNER TO postgres;

ALTER TABLE ONLY sessions.fact_config
    ADD CONSTRAINT fact_config_pkey PRIMARY KEY (factkey);
	
CREATE TABLE sessions.servers_data(
    hostname varchar(100) NOT NULL,
    ipaddress varchar(100) NOT NULL,
    status varchar(100),
	fail_count integer,
    last_updated_on timestamp with time zone NOT NULL
);

ALTER TABLE sessions.servers_data OWNER TO postgres;

ALTER TABLE ONLY sessions.servers_data
    ADD CONSTRAINT servers_data_pkey PRIMARY KEY (hostname);
