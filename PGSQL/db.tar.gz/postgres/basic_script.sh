############################### Jenkins Continious Deployment Script ##############################################
#
#
## cpoy all file into /opt directory.
export JAVA_HOME=/usr/lib/jvm/java
export PATH=$JAVA_HOME/bin:$PATH

cd  /root/$(date +"%m-%d-%y")
cp -r * /opt

## Stop Apache Tomcat server
kill -9 $(ps -aux |grep tomcat | grep -v grep |awk '{print $2}')

ps -aux |grep tomcat
echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" 
cd $(find /opt -type d -name apache-tomcat-7.0.73 2>/dev/null)
cd webapps
rm -rf *

cd /opt
mv *.war /opt/apache-tomcat-7.0.73/webapps/

# Start Apache Tomcat server.
/opt/apache-tomcat-7.0.73/bin/startup.sh

# Steps for extracting all war files.
 war_files_count=$(find /opt/apache-tomcat-7.0.73/webapps/ -type f -name "*.war"|wc -l)

 extracted_all(){
         total_extracted_count=$(ls /opt/apache-tomcat-7.0.73/webapps/ |wc -l)
         files_in=$((war_files_count*2))
         if (( $files_in > $total_extracted_count ))
         then
                echo "-----------------------------------------------------------"
                echo $files_in
                echo $total_extracted_count
                echo "-------------------------------------------------------------"
                echo "All war files are not extrcted yet."
                sleep 5
                extracted_all
          else
                  echo "Successfuly extract all files "
          fi
  }
 extracted_all

# Touch web.xml file....
find ./ -type f -name web.xml -exec touch {} +
ps -aux |grep tomcat 
echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"

# Find PID of tomcat and restart tomcat server....
#PID=`ps -eaf | grep tomcat | grep -v grep | awk '{print $2}'`
#echo $PID
##    if [[ "" !=  "$PID" ]]; then
 #      sudo kill -9 $PID
  #  else
  #     echo "Killing running tomcat process...$PID"
  #     #sudo kill -9 $PID
  #  fi

#Start tomcat services.
#/opt/apache-tomcat-7.0.73/bin/startup.sh
#########################################Tomcat setup have done ######################################



##########################################Database setup for #########################################

cd /opt
mkdir -p new_db old_db
mv  old_db /root/$(date +"%m-%d-%y")/old_db
rm -rf old_db/*
mv new_db/* old_db/
tar -xzvf PostgreSQL.tar.gz -C new_db

# Check if there any changes occure in Database.
events_file_diff=$(diff new_db/PostgreSQL/rba-event-schema-wo-data-on-postgres-EVENTS-v2.sql old_db/PostgreSQL/rba-event-schema-wo-data-on-postgres-EVENTS-v2.sql )
sessions_file_diff=$(diff new_db/PostgreSQL/rba-session-schema-wo-data-on-postgres-SESSIONS-v2.sql old_db/PostgreSQL/rba-session-schema-wo-data-on-postgres-SESSIONS-v2.sql)
location_file_diff=$(diff new_db/PostgreSQL/location-risk-assessment-insert-on-postgres-SESSIONS-v2.sql old_db/PostgreSQL/location-risk-assessment-insert-on-postgres-SESSIONS-v2.sql)

if [ "$events_file_diff" != "" ] || [ "$sessions_file_diff" != "" ] || [ "$location_file_diff" != "" ]
then
pg_passwd="root123"
cd new_db/PostgreSQL
echo "File has modified so updating servers."
PGPASSWORD=$pg_passwd psql -U postgres << EVT
                DROP DATABASE IF EXISTS "SESSIONS";
                CREATE DATABASE "SESSIONS";
                \echo 'Connect with Sessions and upload Session Schema.......'
                \connect SESSIONS;
                \echo 'Uploading sessions schema......................'
                \i rba-session-schema-wo-data-on-postgres-SESSIONS-v2.sql;

                \echo 'Uploading Location Risk assessment............'
                \i location-risk-assessment-insert-on-postgres-SESSIONS-v2.sql;
                \echo '...............SESSIONS schema and location Risk Assessment have been updated............'
                \q
EVT
PGPASSWORD=$pg_passwd psql -U postgres << EVT
                DROP DATABASE IF EXISTS "EVENTS";
                CREATE DATABASE "EVENTS";
                \echo 'Connect with Events and upload EVENTS DB.......'
                \connect EVENTS;
                \i rba-event-schema-wo-data-on-postgres-EVENTS-v2.sql;
                \echo '...............EventsDB schema updated............'
                \q
EVT

else
echo "file has not modified"
fi
########################################### DB setup have done ########################################


########################################### RBAUI Setup ################################################
cd /opt
pm2 stop all
pm2 delete all
mv RBAUI RBAUI_OLD
mv RBAUI_OLD /root/$(date +"%m-%d-%y")/
tar -xzvf RBAUI.tar.gz
cd RBAUI

#Start node server......
pm2 start server.js
sleep 5
ps -aux |grep server.js
############################## Automatic Deployment have done now #######################################
