describe('Validation Routes', () => {
    it('Case: Determine Authentication Call...', (done) => {
        request
            .post('/admin/api/validate/determine')
            .send({})
            .expect(200)
            .expect((res) => {
                console.log('getRules', res.body);
            })
            .end(done);
    })

    it('Case: Send OTP Call...', (done) => {
        request
            .post('/admin/api/validate/sendOTP')
            .send({})
            .expect(200)
            .expect((res) => {
                console.log('getRules', res.body);
            })
            .end(done);
    })

    it('Case: Validate OTP (Success)...', (done) => {
        request
            .post('/admin/api/validate/validateOTP')
            .send({ "otp": "1234" })
            .expect(200)
            .expect((res) => {
                console.log('getRules', res.body);
            })
            .end(done);
    })

    it('Case: Validate OTP (Failure)...', (done) => {
        request
            .post('/admin/api/validate/validateOTP')
            .send({ "otp": "0" })
            .expect(200)
            .expect((res) => {
                console.log('getRules', res.body);
            })
            .end(done);
    })


});


