describe('Testing Authenticator Routes.', (done) => {
    it('Case: Get All Authenticators...', (done) => {

        request
            .get('/admin/api/authenticators/getAuthenticators')
            .expect(200)
            .expect((res) => {
                
            })
            .end(done)
    });

    it('Case: POST Authenticator Success...', (done) => {
        let data = {
            "AuthenticatorID": "FPRINT",
            "AuthenticatorDesc": "FINGERPRINT",
            "factid": "None",
            "activeStatus": 1
        }
        request
            .post('/admin/api/authenticators/authenticators')
            .send(data)
            .expect(200)
            .expect((res) => {
                
            })
            .end(done)
    });

    it('Case: POST Authenticator Failure...', (done) => {
        let data = {
            "AuthenticatorID": "ZIP",
            "AuthenticatorDesc": "Zip Code",
            "factid": "UserInfo",
            "activeStatus": 1
        }
        request
            .post('/admin/api/authenticators/authenticators')
            .send(data)
            .expect(200)
            .expect((res) => {
                
            })
            .end(done)
    });

    it('Case: PUT Authenticator Success..', (done) => {
        let data = {
            "AuthenticatorID": "ZIP",
            "AuthenticatorDesc": "Zip Code",
            "factid": "UserInfo",
            "activeStatus": 1
        }
        request
            .put('/admin/api/authenticators/updateAuthenticators')
            .send(data)
            .expect(200)
            .expect((res) => {
                
            })
            .end(done)
    });

     it('Case: PUT Authenticator Failure..', (done) => {
        let data = {
            "AuthenticatorID": "NotExists",
            "AuthenticatorDesc": "Zip Code",
            "factid": "UserInfo",
            "activeStatus": 1
        }
        request
            .put('/admin/api/authenticators/updateAuthenticators')
            .send(data)
            .expect(200)
            .expect((res) => {
                
            })
            .end(done)
    });
})