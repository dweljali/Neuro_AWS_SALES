/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var webPack = require('webpack');
var htmlWebPack = require('html-webpack-plugin');
var extractTextWebPackPlugin = require('extract-text-webpack-plugin');
var helpers=require('./helpers')
var path = require('path');
var OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');
var glob = require('glob');
var config = {
  entry:{
    'app':'./app/boot.ts',
    'libs':'./deps/stdpkgs.ts',
    'polyfills':'./deps/polyfills.ts',
  },
  resolve:{
      extensions:['','.ts','.js','css']
  },
  module:{
      loaders:[{
           test:/\.ts$/,
           loaders:['awesome-typescript-loader','angular2-template-loader']
      },
      {
        test: /\.html$/,
        loader: 'html'
      },
      {
        test: /\.(gif|png|jpe?g|svg)$/i,
        loaders: [
          'file-loader?hash=sha512&digest=hex&name=[hash].[ext]',
          'image-webpack-loader'
        ]
      },
      {
        test: /\.css$/,
        exclude: path.resolve('deps', 'app'),
       // loader: extractTextWebPackPlugin.extract('style', 'css?sourceMap')
      loader: 'css-loader',
      },
       { test: /\.scss$/, loaders: ['to-string-loader', 'css-loader', 'sass-loader','style', 'css', 'postcss', 'sass'],options:{includePaths: [
        path.resolve("./dist/pages/css")
      ]} },
      { test: /\.(woff2?|ttf|eot|svg)$/, loader: 'url?limit=10000' },
      { test: /bootstrap\/dist\/js\/umd\//, loader: 'imports?jQuery=jquery' }
      ]
  },
 plugins: [
    new webPack.optimize.CommonsChunkPlugin({
           name: ['app', 'libs', 'polyfills']
    }),
 
    new htmlWebPack({
      template: './index.html'
    }),
    new webPack.ProvidePlugin({
        jQuery: 'jquery',
        $: 'jquery',
        jquery: 'jquery'
    }),
       new webPack.optimize.UglifyJsPlugin({compress: {
        warnings: false 
       }}),
    new extractTextWebPackPlugin("customStyles.css"),
  ],
   output: {
    path: 'dist',
    publicPath: '/',
    filename: '[name].js',
    chunkFilename: '[id].[hash].chunk.js'
  },
};
module.exports = config;


