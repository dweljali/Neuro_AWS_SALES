/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from './../../services/MessageService';
import { GlobalService } from './../../services/globalFunctions.service';
import { DomSanitizer } from '@angular/platform-browser';
import { opsModel } from './opsmodal'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { RiskScoreIndex } from './models/riskScoreIndex.model';
import { AuthTrend } from './models/authTrend.model';
import { AuthFailure } from './models/authFailure.model';
import { APIService } from '../../services/APIService.service';
import { AuthService } from '../../services/auth.service';
import { DateRange } from './models/dateRange.model';
import { OpsWidgetComponent } from './opsWidget.coponent';
import { RISK_SCORE_INDEX_CARD_TITLE, AUTH_TREND_CARD_TITLE, AUTH_FAILURE_CARD_TITLE } from './opsDashboardMessages'
@Component({
    selector: 'opsDashboard',
    templateUrl: './OpsDashboard.html',
    providers: [Modal]
})
export class OpsDashboardComponent implements OnInit {

    initialCount: number = 10;
    private fromDate: string = '';
    private toDate: string = '';
    private fromDateObj: any = {};
    private toDateObj: any = {};
    private dateRangeRisk: string = '1M';
    private dateRangeAT: string = '1M';
    private daterangeAF: string = '1M';
    public testObj: any = {};
    public mode: Boolean = true;
    riskGraphData: any = {};
    ATGraphData: any = {};
    AFGraphData: any = {};
    riskscoreindexdata: RiskScoreIndex[] = [];
    riskscoreindexcardtitle: string = RISK_SCORE_INDEX_CARD_TITLE;
    authtrenddata: AuthTrend[] = [];
    authcardtitle: string = AUTH_TREND_CARD_TITLE;
    authfailuredata: AuthFailure[] = [];
    authfailurecardtitle: string = AUTH_FAILURE_CARD_TITLE;
    constructor(
        public objmodal: Modal,
        private sanitizer: DomSanitizer,
        private messageService: MessageService,
        private router: Router,
        private globalservice: GlobalService,
        private apiService: APIService,
        private auth: AuthService,
        vcRef: ViewContainerRef
    ) {
        objmodal.overlay.defaultViewContainer = vcRef;
        if (this.globalservice.mode == "demo") {
            this.mode = false;
        }
        this.toDateObj = new Date();
        this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Month');
        let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
        this.fromDate = formattedDates.fromDate;
        this.toDate = formattedDates.toDate;
        // this.riskscoreindexdata = this.dumyRiskScoreIndexData();
        // this.authtrenddata = this.dumbyAuthTrendData();
        // this.riskalertdata = this.dumbyRiskAlertData();
        this.getRiskScoreIndexData();
        this.getAuthenticatorTrendData();
        this.getAuthenticatorFailure();
    }
    ngOnInit() {
    }

    getRiskScoreIndexData(fromDate?: string, toDate?: string) {
        let from = fromDate ? fromDate : this.fromDate;
        let to = toDate ? toDate : this.toDate;
        this.apiService.getRSI(from, to).then((response) => {

            var objdata = JSON.parse(response._body);
            if (objdata.statusCode == 401) {
                this.auth.authInvalid = true;
                this.globalservice.redirectServerOrClient();
            }
            else if (objdata.statusCode == 402) {
                this.redir();
            }
            else if (objdata.userCards && objdata.userData) {
                let userCards: Object[] = objdata.userCards;
                let userData: Object[] = objdata.userData;

                let tempData: RiskScoreIndex[] = [];
                userCards.forEach((userCard: Object) => {
                    let temp: RiskScoreIndex = {
                        image: userData.find(user => user['userId'] == userCard['userId'])['userImage'],
                        name: userData.find(user => user['userId'] == userCard['userId'])['userName'],
                        activity: userCard['activity'],
                        channel: userCard['channel'],
                        riskScore: userCard['score'] ? userCard['score'] : 0,
                        time: userCard['activityTime']
                    }
                    tempData.push(temp)
                });
                this.riskscoreindexdata = tempData;
                //this.riskscoreindexdata = [];
            }

        }).catch(error => { console.log(error) });
    }
    getAuthenticatorTrendData(fromDate?: string, toDate?: string) {
        let from = fromDate ? fromDate : this.fromDate;
        let to = toDate ? toDate : this.toDate;

        this.apiService.getAT(from, to).then((response) => {

            var objdata = JSON.parse(response._body);

            if (objdata.statusCode == 401) {
                this.auth.authInvalid = true;
                this.globalservice.redirectServerOrClient();
            }
            else if (objdata.statusCode == 402) {
                this.redir();
            }
            else if (objdata.userCards && objdata.userData) {
                let userCards: Object[] = objdata.userCards;
                let userData: Object[] = objdata.userData;

                let tempData: AuthTrend[] = [];
                userCards.forEach((userCard: Object) => {
                    let temp: AuthTrend = {
                        image: userData.find(user => user['userId'] == userCard['userId'])['userImage'],
                        name: userData.find(user => user['userId'] == userCard['userId'])['userName'],
                        activity: userCard['activity'],
                        challenge: userCard['challenge'],
                        time: userCard['activityTime']
                    }
                    tempData.push(temp)
                });
                this.authtrenddata = tempData;
            }

        }).catch(error => { console.log(error) });
    }
    getAuthenticatorFailure(fromDate?: string, toDate?: string) {
        let from = fromDate ? fromDate : this.fromDate;
        let to = toDate ? toDate : this.toDate;
        this.apiService.getAF(from, to).then((response) => {

            var objdata = JSON.parse(response._body);

            if (objdata.statusCode == 401) {
                this.auth.authInvalid = true;
                this.globalservice.redirectServerOrClient();
            }
            else if (objdata.statusCode == 402) {
                this.redir();
            }
            else if (objdata.userCards && objdata.userData) {
                let userCards: Object[] = objdata.userCards;
                let userData: Object[] = objdata.userData;

                let tempData: AuthFailure[] = [];
                userCards.forEach((userCard: Object) => {
                    let userDetail = userData.find(user => user['userId'] == userCard['userId']);

                    let temp: AuthFailure = {
                        image: userData.find(user => user['userId'] == userCard['userId'])['userImage'],
                        name: userDetail['userName'],
                        activity: userCard['activity'],
                        risk: true,
                        time: userCard['activityTime'],
                        detail: {
                            userName: userDetail['userName'],
                            email: userDetail['emailId'],
                            channel: userCard['channel'],
                            authenticator: userCard['challenge'],
                            time: userCard['activityTime']
                        }
                    }
                    tempData.push(temp)
                });
                this.authfailuredata = tempData;
                //this.riskalertdata = [];
            }

        }).catch(error => { console.log(error) });
    }
    /* Function to redirect to dashboard on click of breadcrumb */
    redir() {
        this.messageService.highlightSidebar('dashboard');
        this.messageService.sendMessage('admin/dashboard');
        this.router.navigate(['admin/dashboard']);
    }

    save() {

    }

    clear() {
    }

    getURL(url: string) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }



    showalert(data: Object) {
        const dialog = this.objmodal.open(opsModel, overlayConfigFactory(
            data, BSModalContext));



        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    updateparent(event: any) {
        this.fromDate = event.fromDate;
        this.fromDateObj = new Date(this.fromDate);
        this.toDate = event.toDate;
        this.toDateObj = new Date(this.toDate)
        this.testObj = event;
        this.getRiskScoreIndexData();
        this.getAuthenticatorTrendData();
        this.getAuthenticatorFailure();
    }

    dateRangeUpdateRisk(dateRange: DateRange) {
        this.getRiskScoreIndexData(dateRange.fromDate, dateRange.toDate);
    }

    dateRangeUpdateAT(dateRange: DateRange) {
        this.getAuthenticatorTrendData(dateRange.fromDate, dateRange.toDate);
    }

    dateRangeUpdateRA(dateRange: DateRange) {
        this.getAuthenticatorFailure(dateRange.fromDate, dateRange.toDate);
    }

}