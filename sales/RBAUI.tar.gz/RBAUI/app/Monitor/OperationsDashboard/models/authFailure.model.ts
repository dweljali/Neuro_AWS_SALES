/*******************************************************************************
 * Copyright (c) 2017  Persistent Systems Ltd.
 * All rights reserved.
 *******************************************************************************/
import { OpsCardData } from './opsCardData.model';

export interface AuthFailure extends OpsCardData {
    activity: string;
    risk: Boolean;
    detail: AuthFailureDetail;
}

export interface AuthFailureDetail {
    userName: string;
    email: string;
    authenticator: string;
    channel: string;
    time: string;
}