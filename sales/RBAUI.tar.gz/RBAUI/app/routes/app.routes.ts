/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from '../Dashboard/dashboard.component';
import { ActivityWizardComponent } from '../ActivityWizard/activityWizard.component';
import { ActivitiesComponent } from '../Configuration/Activities/activities.component';
import { AuthenticatorsComponent } from '../Configuration/Authenticators/authenticators.component';
import { OpsDashboardComponent } from '../Monitor/OperationsDashboard/opsDashboard.component';
import { Admin } from '../admin.component';
import { Login } from '../Login/login.component'
import { riskassessmentsComponent } from '../Configuration/Riskassessments/riskassessments.component';
import { AuthGuard } from '../services/authguard.service';
import { ExportWizardComponent } from '../Configuration/Export/exportWizard.component';
import { ImportWizardComponent } from '../Configuration/Import/importWizard.component';
import { riskWizardComponent } from '../Configuration/Riskassessments/RiskWizard/riskWizard.component';
import { DiagnosticsComponent } from '../Monitor/Diagnostics/diagnostics.component';
import { channelsComponent } from '../Configuration/Channels/channels.component';
import { ruleconfigurationComponent } from '../Configuration/RuleConfiguration/ruleconfiguration.component';
import { rulewizardComponent } from '../Configuration/RuleConfiguration/RuleWizard/rulewizard.component';
import { factlocatorComponent } from '../Configuration/Factlocators/factlocator.component';
/* Route Configuration */
export const routes: Routes = [
	{ path: '', redirectTo: '/admin/dashboard', pathMatch: 'full' },
	{
		path: 'admin',
		component: Admin,
		canActivate: [AuthGuard],
		children: [
			{
				path: 'dashboard', component: DashboardComponent
			},
			{
				path: 'ActivityWizard',
				children: [
					{
						path: ':id', component: ActivityWizardComponent
					}]
			},
			{
				path: 'activities', component: ActivitiesComponent
			},
			{
				path: 'authenticators', component: AuthenticatorsComponent
			},
			{
				path: 'opsdash', component: OpsDashboardComponent
			},
			{
				path: 'diagnostics', component: DiagnosticsComponent
			},
			{
				path: 'riskassessments', component: riskassessmentsComponent
			},
			{
				path: 'export', component: ExportWizardComponent
			}
			,
			{
				path: 'import', component: ImportWizardComponent
			}
			,
			{
				path: 'channels', component: channelsComponent
			}
			,
			{
				path: 'ruleconfiguration', component: ruleconfigurationComponent
			}
			,
			{
				path: 'factlocators', component: factlocatorComponent
			}
			,
			{
				path: 'rulewizard',
				children: [
					{
						path: ':id',
						component: rulewizardComponent
					}]
			}
			,
			{
				path: 'RiskAssessmentWizard',
				children: [
					{
						path: ':id', component: riskWizardComponent
					}]
			}
		]
	}
];



export const routing: ModuleWithProviders = RouterModule.forRoot(routes);