/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from '../../services/tabsService'
import { AuthService } from '../../services/auth.service';
import { multiselectComponent } from './../../common/multiselect.component';

import { AlertModelData } from './../../common/alertModal.component';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import * as myGlobals from './../../common/appMessages';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'confirm-partial',
  template: `<span defaultOverlayTarget></span><div class="row row-same-height">
                    <div class="col-md-5 b-r b-dashed b-grey ">
                      <div class="padding-30 m-t-50">
                        <h2>Confirmation</h2>
                        <p>{{tabContent}}</p>
                      </div>
                    </div>
                    <div class="col-md-7">
                      <div>
                        <div class="panel panel-default hover-stroke">
                          <div class="panel-body no-padding">
                            <div class="container-sm-height">
                              <div class="row row-sm-height">
                                <div class="col-sm-12 padding-20 col-sm-height col-top"><span class="icon-thumbnail bg-info pull-left" style="color:white;">1</span>
                                  <p class="font-montserrat bold">ACTIVITY & CHANNEL</p><br/>
                                  <form role="form">
                                  <div class="form-group-attached">
                                    <div class="form-group form-group-default hidden">
                                      <label>Activity Name</label>
                                      <input type="text" class="form-control" value="{{activityName}}" disabled style="color:black;">
                                    </div>
                                    <div class="form-group form-group-default">
                                      <label>Activity ID</label>
                                      <input type="text" class="form-control" value="{{activityId}}" disabled style="color:black;">
                                    </div>
                                    <div class="form-group form-group-default">
                                      <label>Activity Description</label>
                                      <input type="text" class="form-control" value="{{activityDesc}}" disabled style="color:black;">
                                    </div>                                    
                                  </div>
                                  <div class="form-group-attached">
                                    <div class="row clearfix">
                                        <div class="col-sm-6 hidden">
                                        <div class="form-group form-group-default">
                                          <label>Auth Type</label>
                                            <input type="text" class="form-control" value="{{currentSelectedAuthType}}" disabled style="color:black;">
                                        </div>
                                        </div>
                                        <div class="col-sm-6">
                                        <div class="form-group form-group-default">
                                          <label>Channel</label>
                                            <input type="text" class="form-control" value="{{currentSelectedChannelName}}" disabled style="color:black;">
                                        </div>
                                        </div>
                                        <div class="form-group form-group-default">
                                          <label>Required Trust Score</label>
                                          <input type="text" value="{{score}}" disabled class="form-control" style="color:black;">
                                        </div>
                                    </div>
                                  </div>
                                </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>          
                      </div>
                      <div>
                        <div class="panel panel-default hover-stroke">
                          <div class="panel-body no-padding">
                            <div class="container-sm-height">
                              <div class="row row-sm-height">
                                <div class="col-sm-12 padding-20  col-sm-height col-top"><span class="icon-thumbnail bg-info pull-left" style="color:white;">2</span>
                                  <p class="font-montserrat bold">RISK ASSESSMENTS</p><br/>                       
                                    <form role="form">
                                      <div class="form-group-attached">
                                        <div class="row clearfix">
                                        <div *ngIf="activeea.length" class="col-sm-6">
                                                <div class="form-group form-group-default">
                                                  <label>Inclusion Rule</label>
                                                  <input class="form-control" value="{{inclusionRulename}}" disabled="" style="color:black;" type="text">
                                                </div>
                                            </div> 
                                         <div *ngIf="activeea.length" class="col-sm-6">
                                                <div class="form-group form-group-default " style="border-right-color:rgba(0, 0, 0, 0.07)">
                                                  <label>Exclusion rule</label>
                                                  <input class="form-control" value="{{exclusionRulename}}" disabled="" style="color:black;" type="text">
                                                </div>
                                            </div> 
                                            <div *ngIf="activeea.length">
                                              <br> 
                                              <br>
                                            </div>
                                            <p>Run At Activity Start</p>
                                          <div class="form-group form-group-default">
                                            <label>Risk Assessments</label>

                                            <div class="bootstrap-tagsinput">
                        <div *ngFor="let ea of activeea" style="display: inline"><span class="tag label label-info">{{ea}}</span> </div>
                                            </div>

                                          </div>
                                        </div>
                                      </div>
                                      <div class="form-group-attached">
                                        <div class="row clearfix">
                                            <br/>
                                            <p>Once Per Session</p>
                                            <div class="form-group form-group-default">
                                            <label>Risk Assessments</label>
                                          
                                            <div class="bootstrap-tagsinput">
<div *ngFor="let os of activeos" style="display: inline"><span class="tag label label-info">{{os}}</span> </div>
                                            </div> 
                                          </div>
                                        </div>
                                      </div>
                                    </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>          
                      </div>
                      <div>
                        <div class="panel panel-default hover-stroke">
                          <div class="panel-body no-padding">
                            <div class="container-sm-height">
                              <div class="row row-sm-height">
                                <div class="col-sm-12 padding-20  col-sm-height col-top"><span class="icon-thumbnail bg-info pull-left" style="color:white;">3</span>
                                  <p class="font-montserrat bold">AUTHENTICATORS</p><br/>                     
                                          <div class="form-group form-group-default">
                                            <div class="bootstrap-tagsinput">
<div *ngFor="let au of activeau" style="display: inline"><span class="tag label label-info">{{au}}</span> </div>
                                
                                            </div>
                                          </div>
                                </div>
                              </div>
                            </div>

                          </div>
                        </div>          
                      </div>
                    </div>
                  </div>
                  
                  <div class="padding-20 bg-white">
                  <ul class="pager wizard">
                    <li class="next hidden"  style="display: none;">
                      <button class="btn btn-primary btn-cons pull-right" type="button">
                        <span>Next</span>
                      </button>
                    </li>
                    <li class="next finish">
                      <button (click)="save()" class="btn btn-primary btn-cons from-left pull-right" type="button">
                        <span>Finish</span>
                      </button>
                    </li>
                    <li class="previous first hidden disabled">
                      <button class="btn btn-default btn-cons pull-right" type="button">
                        <span>First</span>
                      </button>
                    </li>
                    <li class="previous">
                      <button (click)="previous()" class="btn btn-default btn-cons pull-right from-left" type="button">
                        <span>Previous</span>
                      </button>
                    </li>
                  </ul>
                </div>
                  
                  `,
  providers: [APIService, Modal]
})
export class ConfirmWizardPartialComponent {
  activityName: string;
  activityDesc: string;
  activityId: string;
  score: string;
  riskScore: number;
  currentSelectedChannel: string;
  currentSelectedChannelName: string;
  currentSelectedAuthType: string;
  activeos: string[] = [];
  activeea: string[] = [];
  activeau: string[] = [];
  inclusionRuleId: string;
  exclusionRuleId: string;
  inclusionRulename: string;
  exclusionRulename: string;

  public balanceData: any;
  public activeChallenge: Object[] = [];
  public movetotab: number = 0;
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  private tabContent: string = myGlobals.ACITIVITY_WIZ_CONFIRM_CONTENT;
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(private service: APIService, private route: ActivatedRoute,
    private router: Router, private tabs: TabsService, vcRef: ViewContainerRef,
    public modal: Modal, private auth: AuthService, private globalService: GlobalService) {
    modal.overlay.defaultViewContainer = vcRef;
    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
      window.scrollTo(0, 0);
      if (message.text == "confirm") {
        this.loadData();
      }
      else if (message.text == "confirmAction" && message.next == "balance") {
        this.tabs.sendMessage("balance", "")
      }
    })

  }

  /* Function to load data incase of edit*/
  loadData() {
    this.service.getConfirm().then(response => {
      var data = response._body;
      data = JSON.parse(data);
      this.activityName = data.activityName;
      this.activityDesc = data.activityDesc;
      this.activityId = data.activityId;
      this.score = data.activityscore;
      this.currentSelectedChannel = data.currentSelectedChannel;
      this.currentSelectedChannelName = data.currentSelectedChannelName;
      this.currentSelectedAuthType = data.currentSelectedAuthType;
      if (data.balanceData) { this.balanceData = data.balanceData; }
      if (data.activechallenges) { this.activeChallenge = data.activechallenges; }
      if (data.exclusionRuleId) {
        this.exclusionRuleId = data.exclusionRuleId;
      }
      if (data.inclusionRuleId) {
        this.inclusionRuleId = data.inclusionRuleId;
      }
      if (data.inclusionRulename) {
        this.inclusionRulename = data.inclusionRulename;
      }
      if (data.exclusionRulename) {
        this.exclusionRulename = data.exclusionRulename;
      }


      this.activeos = [];
      if (data.activeRiskOS) {
        for (let i = 0; i < data.activeRiskOS.length; i++) {
          this.activeos.push(data.activeRiskOS[i]["text"]);
        }
      }

      this.activeea = [];
      if (data.activeRiskEA) {
        for (let i = 0; i < data.activeRiskEA.length; i++) {
          this.activeea.push(data.activeRiskEA[i]["text"]);
        }
      }

      this.activeau = [];
      if (this.activeChallenge) {
        for (let i = 0; i < this.activeChallenge.length; i++) {
          this.activeau.push(this.activeChallenge[i]["text"]);
        }
      }

      this.riskScore = 0;
      if (data.riskScore) { this.riskScore = data.riskScore; }
    }).catch(error => { console.log(error) });
  }

  /* Function to validate all the details on confirm tab*/
  validate() {

    var activityValid = true;
    if (!this.activityDesc.trim() || !this.activityId || !this.score || !this.currentSelectedChannel || !this.currentSelectedAuthType) {
      activityValid = false;
    }
    else {
      if (parseInt(this.score) < 0 || parseInt(this.score) > 100) {
        activityValid = false;
      }
    }

    if (!activityValid) {
      return 1;
    }

    if (!this.activeChallenge) {
      return 2;
    }

    if (this.activeChallenge.length <= 0) {
      return 2;
    }
    if (this.exclusionRuleId && this.exclusionRuleId != 'NA' && (!this.inclusionRuleId || this.inclusionRuleId == 'NA')) {
      return 5;
    }

    var balanceValid = false;
    /* If balance is set and balance data contains all active challenges only then enter loop to check further */
    if (this.balanceData && this.balanceData.name && this.activeChallenge.length <= this.balanceData.name.length) {
      var total: number = 0;
      for (var i = 0; i < this.balanceData.name.length; i++) {
        for (var j = 0; j < this.activeChallenge.length; j++) {
          if (this.balanceData.name[i].authname == this.activeChallenge[j]["text"]) {
            /* If any selected authenticator has a score less than equal to 0 then return error */
            if (this.balanceData.name[i].score <= 0) {
              return 3;
            }
            total = total + this.balanceData.name[i].score;
            break;
          }
        }
      }
      if (total >= (parseInt(this.score) + this.riskScore)) {
        balanceValid = true;
      }
    }

    if (!balanceValid) {
      return 3;
    }
    return 0;
  }

  ngOnInit() {
    if (this.router.url.indexOf('/edit') > -1) {
      if (this.globalService.actWizardAuthTab == true) {
        this.globalService.actWizardAuthTab = false;
        this.tabs.sendMessage("authenticator", ""); //redirect authenticator tab
      }
      else if (this.globalService.actWizardBalanceTab == true) {
        this.globalService.actWizardBalanceTab = false;
        this.tabs.sendMessage("balance", ""); //redirect balance tab
      }
    }
  }
  /* Function displays alert incase data is incomplete and navigates to the appropriate tab*/
  openModal(msg: string, headtext: string) {
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
      {
        isBlocking: true,
        message: msg,
        headtext: headtext
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
        switch (this.movetotab) {
          case 1:
            this.tabs.sendMessage("activity", "");
            break;
          case 2:
            this.tabs.sendMessage("authenticator", "");
            break;
          case 3:
            this.tabs.sendMessage("balance", "");
            break;
          case 4:
            this.router.navigate(['/admin/activities']);
            break;
          case 5:
            this.tabs.sendMessage("risk", "");
            break;
        }
      });
    });
  }

  /* Function triggered on click of save button that saves the activity*/
  save() {

    var objValidate: number = this.validate();
    if (objValidate == 0) {
      if (this.router.url.indexOf('/ActivityWizard/new') > -1) {
        this.service.postActivityWizard({}).then(response => {
          var resp = JSON.parse(response._body);
          if (resp.statusCode == 401) {
            this.auth.authInvalid = true;
            this.globalService.redirectServerOrClient();
          }
          else if (resp.error == 0) {
            this.movetotab = 4;
            this.openModal(resp.msg ? resp.msg : myGlobals.ADD_ACTIVITY_SUCCESS, "Success");
          }
          else { this.movetotab = 1; this.openModal(resp.msg, "Error"); }
        }).catch(error => { console.log(error) });
      }
      else {
        this.service.putActivityWizard({}).then(response => {
          var resp = JSON.parse(response._body);
          if (resp.statusCode == 401) {
            this.auth.authInvalid = true;
            this.globalService.redirectServerOrClient();
          }
          else if (resp.error == 0) {
            this.movetotab = 4;
            this.openModal(resp.msg ? resp.msg : myGlobals.UPDATE_ACTIVITY_SUCCESS, "Success");
          }
          else { this.movetotab = 1; this.openModal(resp.msg, "Error"); }
        }).catch(error => { console.log(error) });
      }
    }
    else {

      var errmsg: string;
      this.movetotab = 0;
      switch (objValidate) {
        case 1:
          errmsg = myGlobals.ACTIVITY_REVIEW;
          this.movetotab = 1;
          break;

        case 2:
          errmsg = myGlobals.AUTHENTICATOR_WIZ_REVIEW;
          this.movetotab = 2;
          break;

        case 3:
          errmsg = myGlobals.BALANCE_WIZ_REVIEW;
          this.movetotab = 3;
          break;
        case 5:
          errmsg = myGlobals.RISK_WIZ_REVIEW;
          this.movetotab = 5;
          break;
      }
      this.openModal(errmsg, "Validation error");
    }
  }

  /* Function to navigate to the previous tab*/
  previous() {
    this.tabs.sendMessage("balance", "");
  }
}