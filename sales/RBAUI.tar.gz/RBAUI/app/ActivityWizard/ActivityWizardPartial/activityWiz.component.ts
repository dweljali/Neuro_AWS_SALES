/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit,Output,EventEmitter,ViewContainerRef, AfterViewInit, ViewChildren } from '@angular/core';
import {APIService} from '../../services/APIService.service';
import { GlobalService } from '../../services/globalFunctions.service';
import { AuthService } from '../../services/auth.service';
import {FormsModule} from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from '../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../common/alertModal.component';
import * as myGlobals from './../../common/appMessages';
import { Subject } from 'rxjs/Subject'

import {ACTIVITY_ID_PC, ACTIVITY_DESCRIPTION_PC} from './../appActivityWizardMessage';

@Component({
    selector: 'activity-wizard-partial',
    template: require('./ActivityWiz.html'),
    providers: [APIService,Modal]
})
export class ActivityWizardPartialComponent{
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  private tabContent: string = myGlobals.ACTIVITY_CHANNEL_DISPLAY_CONTENT;
  public channel:Object[]=[];
  public authType:Object[]=[];
  public activityName:string='';
  public activityDesc:string='';
  public activityId:string='';
  public score:any="";
  public currentSelectedChannel:string;
  public currentSelectedAuthType:string;
  public activeAuthType:string[];
  public activeChannel:string[];
  public pcholder:string;
  public disableactid:boolean;
  public scorevalidate = true;

  public activityIdPc = ACTIVITY_ID_PC;
  public activityDescriptionPc= ACTIVITY_DESCRIPTION_PC;

  @Output() customclick = new EventEmitter();
  @ViewChildren('inputactid') vcActID:any;
  @ViewChildren('inputactchannel') vcActChannel: any;
  @ViewChildren('inputactscore') vcActScore: any;
  @ViewChildren('inputactauth') vcActAuth: any;
  @ViewChildren('inputactdesc') vcActDesc: any;

  @ViewChildren('dvactid') vcdvActIDc: any;
  @ViewChildren('dvactdesc') vcdvActDesc: any;
  @ViewChildren('dvactscore') vcdvActScore: any;

  ngAfterViewInit() { 
    this.vcActID.first.nativeElement.focus();        
  } 

  ngOnDestroy(){
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  /* Function to highlight fields that are blank upon validation*/
  loadDefault(){        
    if(!this.activityId){
      this.vcActID.first.nativeElement.focus();
    }
    else if(!this.activityDesc.trim()){
      this.vcActDesc.first.nativeElement.focus();
    }
    else if(!this.currentSelectedAuthType){
      this.vcActAuth.first.nativeElement.classList.add('focused');
    }
    else if(!this.currentSelectedChannel){
      this.vcActChannel.first.nativeElement.classList.add('focused');
    }
    else if(!this.score || parseInt(this.score) < 0|| parseInt(this.score) > 100){
      this.vcActScore.first.nativeElement.focus();
    }
  }

  /* Function to highlight fields that are blank upon validation when control comes from other tabs*/
  highlightControl(){
    if(!this.activityId){
      this.vcdvActIDc.first.nativeElement.classList.add('focused');
    }
    else if(!this.activityDesc.trim()){
      this.vcdvActDesc.first.nativeElement.classList.add('focused');
    }
    else if(!this.currentSelectedAuthType){
      this.vcActAuth.first.nativeElement.classList.add('focused');
    }
    else if(!this.currentSelectedChannel){
      this.vcActChannel.first.nativeElement.classList.add('focused');
    }
    else if(!this.score || parseInt(this.score) < 0|| parseInt(this.score) > 100 || isNaN(parseInt(this.score))){
      this.vcdvActScore.first.nativeElement.classList.add('focused');
    }
    else{
      this.vcdvActIDc.first.nativeElement.classList.add('focused');
    }
  }

  constructor(private service:APIService,  private route: ActivatedRoute,
              private router: Router,private tabs:TabsService,vcRef: ViewContainerRef, 
              public modal: Modal, private auth: AuthService,private globalService: GlobalService) {
    modal.overlay.defaultViewContainer = vcRef;
    window.scrollTo(0, 0);
    this.loadData();

    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => { 
      if(message.text=="postActivity"){
        window.scrollTo(0, 0);
        if(message.next == "confirm" || message.next == "balance"){
          this.postActivity(message.next);}
        else{
          window.scrollTo(0, 0);
          this.postActivity(null);
        }
      }
      else if(message.text=="activity"){
        window.scrollTo(0, 0);
        this.highlightControl();
      }
    })

  }

  /* Function to load data incase of edit*/
  loadData() {
    this.route.params.takeUntil(this.ngUnsubscribe).subscribe(params=>{                
      this.service.getWizardActivities(params["id"]).then(response=>{
        var data=response._body;
        data=JSON.parse(data);

        
        this.pcholder ="Select One";

        if(data.channel){this.channel=data.channel;}                        
        if(data.authType){this.authType=data.authType;}                
        if(data.activityDesc){this.activityDesc=data.activityDesc;}                    
        if(data.activityId){this.activityId=data.activityId;}                
        if(data.activityscore){this.score=data.activityscore;}

		if(data.activityscore){this.score=data.activityscore; }
		else if(parseInt(data.activityscore) == 0) 
		{this.score="0";}
		  
        if(data.currentSelectedChannel){
          this.currentSelectedChannel=data.currentSelectedChannel;
        }

        if(data.currentSelectedAuthType){
          this.currentSelectedAuthType=data.currentSelectedAuthType;
        }else{this.currentSelectedAuthType = "NORMAL";}

        if(data.currentSelectedAuthType && this.authType){
          for(let i=0; i< this.authType.length; i++){
            if(this.authType[i]["id"].toUpperCase() == data.currentSelectedAuthType.toUpperCase()){
              this.activeAuthType =[this.authType[i]["text"]];
            }
          }
        }

        if(data.currentSelectedChannel && this.channel){
          for(let i=0; i< this.channel.length; i++){
            if(this.channel[i]["id"].toUpperCase() == data.currentSelectedChannel.toUpperCase()){
              this.activeChannel =[this.channel[i]["text"]];
            }
          }
        }

        if(this.router.url.indexOf('/ActivityWizard/new') > -1){
          this.disableactid = false;}
        else{
          this.disableactid = true;
        }

      }).catch(error => {
            console.log(error);
        });

    })      
  }

  /* Function to check the trust score*/
  checkScore(){
    var s = (parseInt(this.score)); 
    if(s < 0|| s > 100 || isNaN(s) || s==null){
    }
  }

  /* Function to save activity & channel details*/
  postActivity(msg:string){
    this.checkScore();
    this.service.postWizardActivities({
      activityName:this.activityName,
      activityDesc:this.activityDesc,
      activityId:this.activityId,
      activityscore:this.score,
      currentSelectedChannel:this.currentSelectedChannel,
      currentSelectedAuthType:this.currentSelectedAuthType}).then(response=>{
        var data=response._body;
        data=JSON.parse(data);
        if(data.statusCode == 401){
            this.auth.authInvalid= true;
            this.globalService.redirectServerOrClient();
        }
        if(msg){
          this.tabs.sendMessage(msg, "")
        }
    }).catch(error => {
            console.log(error);
        });
  }

  /* Handler to highlight select boxes on focus*/
  onFocus(event: any, arg: number){
    let objbody1 = document.getElementById('auttype');
    let objbody2 = document.getElementById('activitychannel');

    if(arg==1){
      objbody2.classList.remove('focused');
      event.target.parentElement.parentElement.parentElement.parentElement.classList.add('focused');

    }
    else{
      objbody1.classList.remove('focused');
      event.target.parentElement.parentElement.parentElement.parentElement.classList.add('focused');
    }

  }

  /* Function triggered onclick of save button in activity & channel tab*/
  save(){
    if(this.validate()){
      this.postActivity("risk");
    }
    else{
      this.openModal();
    }
  }

  /* Function to validate all fields in activity and channel tab*/
  validate(){

    if(!this.activityDesc.trim() || !this.activityId || !this.score || !this.currentSelectedChannel || 
    !this.currentSelectedAuthType){          
      return false;
    }
    else{
      var s = (parseInt(this.score));
      if(s < 0|| s > 100 || isNaN(s) || s==null){
        this.scorevalidate = false;
        return false;
      }
      else{
        this.scorevalidate = true;                
      }
    }
    return true;
  }

  /* Function that displays modal upon validation error on activity & channel tab*/
  openModal(){
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
    {
      isBlocking: true,
      message: this.scorevalidate ? myGlobals.MANDATORY_FIELDS_VALIDATE :
      myGlobals.TRUST_SCORE_VALIDATE,
      headtext: "Validation error"
    }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {                    
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
        this.loadDefault();
      });
    });
  }

  selectedvalueauthtype(arg:any){         
    this.currentSelectedAuthType=arg.id;
  }

  selectedvaluechannel(arg:any){
    this.currentSelectedChannel=arg.id;
  } 

  /* Function that validates trust score on keypress*/
  _keyPress(event: any) {

    var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft','Home','Delete','Tab'];
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);

    if(arrint.indexOf(event.key) != -1 ){
      return;
    }
    else if (!pattern.test(inputChar)) {
    // invalid character, prevent input
      event.preventDefault();
    }


  }

  /* Function that validates activity ID on keypress*/
  _keyPressID(event: any) {
    var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft','Home','Delete','Tab'];
    const pattern = /^[a-zA-Z\d-_]+$/;
    let inputChar = String.fromCharCode(event.charCode);


    if(arrint.indexOf(event.key) != -1 ){
      return;
    }
    else if (!pattern.test(inputChar)) {
    // invalid character, prevent input
      event.preventDefault();
    }

  }

  /* Function that validates trust score on change*/
  onchangescore(){
    if(parseInt(this.score) > 100 || parseInt(this.score) < 0){
      this.score = "";
    }
  }
}