import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import {TabsService} from '../services/tabsService';
import {OrderByPipe} from './orderBy.component';
/**************************
 <div class="form-group form-group-default input-group" >
        <label class="inline" style="text-transform: uppercase;font-weight: 600;font-family: 
        Montserrat;font-size: 13px;vertical-align: middle;color: rgba(44,44,44,.35);float:left; left:40%">{{displayobjtype}}</label>
        <span class="input-group-addon" style="background-color:white">
            <ui-switch color="rgb(109, 92, 174)" (change)="onChange($event)" [(ngModel)]="defaultswitchstatus"></ui-switch>
        </span>
    </div>
    <div class="form-group form-group-default input-group"
            *ngFor="let item of data | paginate: {itemsPerPage: itemsperpage, currentPage:objectpage, id: '1'}; let i = index;">
        <label class="inline">{{item['name']}}</label>
        <span class="input-group-addon bg-transparent">
            <ui-switch color="rgb(109, 92, 174)" [(ngModel)]="item['status']" (change)="onChangeItem($event,item['id'])">
            </ui-switch>
        </span>
    </div>
**************************/
@Component({
    selector:'object-type-table',
    template: `
    
    <pagination-controls class="customPagination" (pageChange)="objectpage = $event" id="1"
        maxSize="{{maxpagesize}}" directionLinks="true" autoHide="true"> 
    </pagination-controls>
        <table class="table table-hover demo-table-search table-responsive-block" id="tableWithSearch">
            <thead>
                <tr> 
                    <th *ngFor="let heading of headings" 
                        [class.pointer_cursor]="(heading[1] == 1)" 
                        (click)="sort(heading[0])">{{heading[0]}}
                     <i class="fa" [ngClass]="{'fa-sort': column != heading[0], 
                        'fa-sort-asc': (column == heading[0] && isDesc), 
                        'fa-sort-desc': (column == heading[0] && !isDesc),
                        'hide-grid-sort': (heading[1] == 0)}" aria-hidden="true"> 
                    </i>
                </th> 
                    <th>
                        <ui-switch class="p-l-10" color="rgb(109, 92, 174)" 
                                (change)="onChange($event)" [(ngModel)]="defaultswitchstatus">
                        </ui-switch>
                    </th>
                </tr>
            </thead>
            <tbody> 
                <tr *ngFor="let item of data | orderBy: {property: column, direction: direction}  | paginate: {itemsPerPage: itemsperpage, currentPage:objectpage, id: '1'}; 
                let i = index;" >
                    <td *ngFor="let heading of headings" class="v-align-middle">
                        <p>{{item[heading[0]]}}</p>                   
                    </td>
                    <td><ui-switch color="rgb(109, 92, 174)" [(ngModel)]="item['status']"                
                            (change)="onChangeItem($event,item['id'])"></ui-switch>
                    </td>
                </tr>
            </tbody> 
        </table>
    <pagination-controls class="customPagination" (pageChange)="objectpage = $event" id="1"
        maxSize="{{maxpagesize}}" directionLinks="true" autoHide="true"> 
    </pagination-controls>`,
})
export class objectTypeTable{
    @Input() data:Object[];
    @Input() headings:Object[];
    public defaultswitchstatus:Boolean = false;
    @Input() displayobjtype:string;
    @Input() maxpagesize:number;
    @Input() itemsperpage:number;
    private ngUnsubscribe: Subject<void> = new Subject<void>();
     
    @Output() updateitemlist:EventEmitter<any> = new EventEmitter<any>();
    @Output() updateallitem:EventEmitter<any> = new EventEmitter<any>();

	isDesc: boolean = false;
    column: string = '';
    direction: number;
    ngOnDestroy(){
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }
     
     onChange(event:any){
          
         for(let i=0; i<this.data.length;i++){
             this.data[i]['status'] = event; 
         }
         this.updateallitem.emit(event);
     }
     
     onChangeItem(value:any, event:any){
         console.log(value);
         console.log(event);
         this.updateitemlist.emit({'status':value, 'id':event});
     }
     
    constructor(private objtservice:TabsService) {       
        this.objtservice.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
            if(message.text.toUpperCase().trim() == "OBJECTTYPE"){ 
                console.log(this.defaultswitchstatus);
                this.defaultswitchstatus = false;    
            }        
        });
    }
	 
	  sort(property:any){
        let proceedSorting: boolean = false;
        for(let i=0; i<this.headings.length;i++){
            if(this.headings[i][0] == property){
                if(this.headings[i][1] == 1){
                    proceedSorting = true;
                }
                break;
            }
        }
        
        if(proceedSorting){
            this.isDesc = !this.isDesc; //change the direction    
            this.column = property;
            this.direction = this.isDesc ? 1 : -1;
        }
    };
     
    isArray(val: any) {  return typeof val==='object'; }
}