import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { MessageService } from '../services/MessageService';
import { GlobalService } from '../services/globalFunctions.service';
import { APIService } from '../services/APIService.service';
/* Component for sidebar */
@Component({
  selector: 'sidebar',
  template: `<nav class="page-sidebar" data-pages="sidebar" style="transform: translate(210px, 0px)" (mouseleave)="sidenavref.close()">
      <!-- BEGIN SIDEBAR MENU HEADER-->
      <div class="sidebar-header">
        <img [src]='getURL("admin/assets/img/logo_white.png")' alt="logo" class="brand" height="22">
   
        <div class="sidebar-header-controls">
          <button type="button" class="btn btn-xs sidebar-slide-toggle btn-link m-l-20" data-pages-toggle="#appMenu">
          </button>
          <!--<button type="button" class="btn btn-link visible-lg-inline" data-toggle-pin="sidebar"><i class="fa fs-12"></i>
          </button>-->
        </div>
      </div>
      <!-- END SIDEBAR MENU HEADER-->
      <!-- START SIDEBAR MENU -->
      <div class="sidebar-menu">
        <!-- BEGIN SIDEBAR MENU ITEMS-->
        <div class="scroll-wrapper menu-items" style="position: relative;"><ul class="menu-items scroll-content scroll-scrolly_visible" style="height: auto; margin-bottom: 0px; margin-right: 0px; overflow:hidden !important">
          <li [class]="dashboard" id="dashboard">
            <a (click)="redir('dashboard'); hideInactiveSubMenus()" class="detailed">
              <span class="title">Dashboard</span>
            </a>
            <span class="icon-thumbnail"><i class="fa fa-dashboard"></i></span>
          </li>
          <li *ngIf="neuroadmin" [class]="wizard" id="wizard">
            <a (click)="reroute('ActivityWizard'); hideInactiveSubMenus()" class="detailed" >
              <span class="title">Wizard</span>
            </a>
            <span class="icon-thumbnail"><i class="pg-layouts"></i></span>
          </li>
          <li *ngIf="neuroadmin" [class]="configure" id="configure">
            <a href="javascript:;" id="btn-1" data-toggle="collapse" data-target="#submenu1" aria-expanded="false" (click)="clickedMenu($event,'submenu1')">
              <span class="title">Configure</span>
              <span class="arrow"></span>
            </a>
            <span class="icon-thumbnail"><i class="pg-settings"></i></span>
            <ul class="sub-menu nav collapse" id="submenu1" role="menu" aria-labelledby="btn-1">
              <li [class]="activities"  id="activities" (click)="redir('activities')">
                <a >Activites</a>
                <span class="icon-thumbnail"><i class="fa fa-bolt"></i></span>
              </li>
              <li [class]="authenticators" (click)="redir('authenticators')" id="authenticators">
                <a >Authenticators</a>
                <span class="icon-thumbnail"><i class="fa fa-key"></i></span>
              </li>			  
      			<li [class]="riskassessments" (click)="redir('riskassessments')" id="riskassessments">
                <a >Risk Assessments</a>
                <span class="icon-thumbnail"><i class="fa fa-exclamation"></i></span>
              </li>
				<li [class]="channels" (click)="redir('channels')" id="channels">
                <a >Channels</a>
                <span class="icon-thumbnail"><i class="fa fa-cubes"></i></span>
              </li>
				<li [class]="ruleconfiguration" (click)="redir('ruleconfiguration')" id="ruleconfiguration">
                <a >Rule Configuration</a>
                <span class="icon-thumbnail"><i class="fa pg-note"></i></span>
              </li>
        <li [class]="factlocator" (click)="redir('factlocators')" id="factlocator">
                <a >Fact Locators</a>
                <span class="icon-thumbnail"><i class="fa fa-database"></i></span>
              </li>
				<li [class]="export" (click)="redir('export')" id="export">
                <a >Export Configuration</a>
                <span class="icon-thumbnail"><i class="fa fa-download"></i></span>
              </li>
				<li [class]="import" (click)="redir('import')" id="import">
                <a >Import Configuration</a>
                <span class="icon-thumbnail"><i class="fa fa-upload"></i></span>
              </li>
            </ul>
          </li>
          <li [class]="monitor" id="monitor">
            <a href="javascript:;" id="btn-2" data-toggle="collapse" data-target="#submenu2" aria-expanded="false" (click)="clickedMenu($event,'submenu2')">
              <span class="title">Monitor</span>
              <span class="arrow"></span>
            </a>
            <span class="icon-thumbnail"><i class="fa fa-bar-chart"></i></span>
            <ul class="sub-menu nav collapse" id="submenu2" role="menu" aria-labelledby="btn-2">
              <li [class]="opsdash" (click)="redir('opsdash')"  id="opsdash" >
                <a >Ops Dashboard</a>
                <span class="icon-thumbnail"><i class="pg-charts"></i></span>
              </li>
      		  <li [class]="diagnostics" (click)="redir('diagnostics')"  id="diagnostics" >
                <a >Diagnostics</a>
                <span class="icon-thumbnail"><i class="fa fa-search"></i></span>
              </li>
            </ul>
          </li>
        </ul><div class="scroll-element scroll-x scroll-scrolly_visible"><div class="scroll-element_outer"><div class="scroll-element_size"></div><div class="scroll-element_track"></div><div class="scroll-bar" style="width: 89px;"></div></div></div><div class="scroll-element scroll-y scroll-scrolly_visible"><div class="scroll-element_outer"><div class="scroll-element_size"></div><div class="scroll-element_track"></div><div class="scroll-bar" style="height: 142px; top: 0px;"></div></div></div></div>
        <div class="clearfix"></div>
      </div>
      <!-- END SIDEBAR MENU -->
    </nav>`,

})
export class SideBar {
  @Input() sidenavref: any;
  dashboard: string;
  wizard: string;
  activities: string;
  authenticators: string;
  configure: string;
  monitor: string;
  opsdash: string;
  riskassessment: string;
  export: string;
  import: string;
  diagnostics: string;
  channels: string;
  ruleconfiguration: string;
  factlocator: string;
  private showDNClass: boolean = false;
  neuroadmin: boolean = true;

  constructor(
    private sanitizer: DomSanitizer,
    private router: Router,
    private messageService: MessageService,
    private globalService: GlobalService,
    private apiService: APIService,
  ) {
    this.dashboard = 'active';

    this.apiService.isLoggedIn().then((response: any) => {
      var apiData = JSON.parse(response._body);

      if (apiData && apiData.userole) {
        this.globalService.userRole = apiData.userole;
      }

      if (this.globalService.userRole == "neuroadmin") {
        this.neuroadmin = true;
      }
      else {
        this.neuroadmin = false;
      }
    }).catch(error => {
      console.log(error);
    });

    this.messageService.openSubmenu.subscribe((submenu: string) => {
      this.clickedMenu(null, submenu)
    })
  }

  getURL(url: string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  reroute(url: string) {
    this.apiService.clearWizardSession().then((response: any) => {
      this.redir(url);
    }).catch(error => {
      console.log(error);
    });
  }

  /* Function to redirect to pages */
  redir(refurl: string) {
    switch (refurl) {

      case 'dashboard':
        this.wizard = this.configure = this.activities = this.authenticators = this.opsdash =
          this.export = this.import = this.monitor = this.riskassessment = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator = "";
        this.messageService.highlightSidebar('dashboard');
        this.dashboard = 'active';
        break;
      case 'ActivityWizard':
        this.dashboard = this.configure = this.activities = this.authenticators = this.opsdash =
          this.export = this.import = this.monitor = this.riskassessment = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.wizard = 'active';
        this.messageService.highlightSidebar('ActivityWizard');
        refurl = refurl + '/new'
        break;
      case 'activities':
        this.dashboard = this.wizard = this.authenticators = this.opsdash =
          this.export = this.import = this.monitor = this.riskassessment = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('activities');
        this.activities = 'active';
        this.configure = 'active';
        break;
      case 'authenticators':
        this.dashboard = this.wizard = this.activities = this.opsdash =
          this.export = this.import = this.monitor = this.riskassessment = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('authenticators');
        this.authenticators = 'active';
        this.configure = 'active';
        break;
      case 'opsdash':
        this.dashboard = this.wizard = this.activities = this.authenticators =
          this.export = this.import = this.configure = this.riskassessment = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('opsdash');
        this.opsdash = 'active';
        this.monitor = 'active';
        break;
      case 'diagnostics':
        this.dashboard = this.wizard = this.activities = this.authenticators =
          this.export = this.import = this.configure = this.riskassessment = this.opsdash = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('diagnostics');
        this.diagnostics = 'active';
        this.monitor = 'active';
        break;
      case 'riskassessments':
        this.dashboard = this.wizard = this.activities = this.monitor =
          this.export = this.import = this.authenticators = this.opsdash = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('riskassessments');
        this.configure = 'active';
        this.riskassessment = 'active';
        break;
      case 'export':
        this.dashboard = this.wizard = this.activities = this.monitor =
          this.riskassessment = this.import = this.authenticators = this.opsdash = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('export');
        this.configure = 'active';
        this.export = 'active';
        break;
      case 'import':
        this.dashboard = this.wizard = this.activities = this.monitor =
          this.export = this.riskassessment = this.authenticators = this.opsdash = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('import');
        this.configure = 'active';
        this.import = 'active';
        break;
      case 'channels':
        this.dashboard = this.wizard = this.activities = this.monitor =
          this.export = this.riskassessment = this.authenticators = this.opsdash = this.diagnostics = this.import = this.ruleconfiguration = this.factlocator ="";
        this.messageService.highlightSidebar('channels');
        this.configure = 'active';
        this.channels = 'active';
        break;
      case 'ruleconfiguration':
        this.export = this.riskassessment = this.authenticators = this.opsdash = this.diagnostics = this.import = this.channels = this.factlocator ="";
        this.messageService.highlightSidebar('ruleconfiguration');
        this.configure = 'active';
        this.ruleconfiguration = 'active';
        break;
      case 'factlocator':
        this.export = this.riskassessment = this.authenticators = this.opsdash = this.diagnostics = this.import = this.channels = this.ruleconfiguration ="";
        this.messageService.highlightSidebar('factlocator');
        this.configure = 'active';
        this.factlocator = 'active';
        break;
      default:
        this.wizard = this.activities = this.authenticators = this.opsdash =
          this.export = this.import = this.monitor = this.riskassessment = this.diagnostics = this.channels = this.ruleconfiguration = this.factlocator ="";
        this.dashboard = 'active';
        break;

    }
    refurl = 'admin/' + refurl
    this.messageService.sendMessage(refurl);
    this.router.navigate([refurl]);

    //scroll to top of the page
    if (!location.href.includes(refurl)) {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }

  }

  /* Function for expanding and collapsing the sub menu of sidebar */
  clickedMenu(event: any, id: string) {
    let objbody = document.getElementById(id);
    let objParent = document.getElementById(id).parentElement; //get parent menu element to check if it's active
    let arrowIcon = document.getElementById(id).parentElement.getElementsByClassName('arrow')[0]; // get the element that has arrow icon for this sub-menu item

    // if menu item is not selected then proceed
    if ((objParent && objParent.classList && !objParent.classList.contains('active'))) {
      if (objbody && objbody.classList && objbody.classList.contains('in')) {
        objbody.classList.remove("in");
        objbody.style.display = 'none'
        arrowIcon.classList.remove('open');
        if (event) {
          event.stopPropagation();
        }
      } else {
        this.hideInactiveSubMenus()
        arrowIcon.classList.add('open')
        objbody.style.display = 'block'
        objbody.classList.add("in");
      }

    } else {
      if (objbody && objbody.classList && !objbody.classList.contains('in')) {
        this.hideInactiveSubMenus()
        objbody.style.display = 'block'
        arrowIcon.classList.add('open')
        objbody.classList.add("in");
      }
    }

  }
  hideInactiveSubMenus() {

    let subMenus = document.querySelectorAll('.sub-menu.in');

    for (let index in subMenus) {
      let subMenu = <HTMLElement>subMenus[index];

      if (subMenu && subMenu.classList) {
        subMenu.classList.remove('in')
        subMenu.style.display = 'none'
        let arrowIcon = subMenu.parentElement.getElementsByClassName('arrow')[0];
        arrowIcon.classList.remove('open');
      }
    }
  }
}


