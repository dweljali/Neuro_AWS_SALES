/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

/* Validations */
export const MANDATORY_FIELDS_VALIDATE: string="Please fill in all mandatory fields.";
export const TRUST_SCORE_VALIDATE: string="Required trust score should be between 0-100.";
export const AUTH_SCORE_VALIDATE: string="Your authenticator trust score falls within the acceptable threshold.";
export const AUTH_SCORE_INVALIDATE: string="Your authenticator trust score does not fall within the acceptable threshold.";
export const AUTH_TRUST_SCORE_VALIDATE: string="All selected authenticator(s) must have a trust score greater than zero.";
export const ACTIVITY_REVIEW: string="Please review activity & channel details.";
export const AUTHENTICATOR_WIZ_REVIEW: string="Please review authenticators details.";
export const BALANCE_WIZ_REVIEW: string="Please review balance risk and trust scores.";
export const RISK_WIZ_REVIEW: string="Exclusion rule exists, please select inclusion rule.";
export const AUTHENTICATOR_REVIEW: string="Please select at least one authenticator.";
export const AUTHENTICATOR_ITEMS_PER_PAGE: number = 10;
export const AUTHENTICATOR_LOCALSTORAGE_KEY: string = "authenticator-page-size";
export const AUTHENTICATOR_MAX_PAGE_SIZE: number = 5;
export const ACTIVITY_ITEMS_PER_PAGE: number = 10;
export const ACTIVITY_MAX_PAGE_SIZE: number = 5;
export const ACTIVITY_LOCALSTORAGE_KEY: string = "activity-page-size";
export const SELECT_EXPORT_TYPE: string="Please select an export type.";
export const SELECT_IMPORT_TYPE: string="Please select valid JSON file to import activities.";
export const EXPORT_MAX_PAGE_SIZE: number = 5;
export const EXPORT_ITEMS_PER_PAGE: number = 5;
export const EXPORT_CONFIRM_MAX_PAGE_SIZE: number = 5;
export const EXPORT_CONFIRM_ITEMS_PER_PAGE: number = 5;
export const RISKWIZARD_DETAILS_REVIEW: string="Please review risk assessment details.";
export const RISKWIZARD_CONFIG_REVIEW: string="Please review risk configuration(s).";
export const ADD_RISKWIZARD_SUCCESS: string="Risk assessment is successfully added.";


/* Risk assessment page variables */
/* Info */
export const ADD_AUTHENTICATOR_SUCCESS: string="Authenticator is successfully added.";
export const UPDATE_AUTHENTICATOR_SUCCESS: string="Authenticator is successfully edited.";
export const ADD_ACTIVITY_SUCCESS: string="Activity is successfully added to the activity list.";
export const UPDATE_ACTIVITY_SUCCESS: string="Activity is successfully edited.";
export const LOGIN_DISPLAY_CONTENT: string = "Neuro enables your enterprise to run risk assessments for every activity and channel combination.";

export const ACTIVITY_CHANNEL_DISPLAY_CONTENT: string = "An activity represents any digital transaction initiated by the user on any channel. In this step, you specify the activity that you want to protect using risk-based authentication. Neuro allows you to specify a required trust score that MUST be met in order for the user to proceed with the activity on the selected channel.";

export const ACTIVITY_WIZ_AUTH_CONTENT ="Authenticators represent challenges that you can present to the user to verify the identity claim submitted by the user. You can select from a list of pre-built authenticators or add an existing authenticator to the list. Neuro allows you to define a custom list of authenticators for every activity and channel combination.";

export const ACTIVITY_WIZ_BAL_CONTENT = "Authenticators enable the user to acquire trust points. Every successful authentication adds trust points to the user’s session. In this step, you can validate and check if the configured Authenticators will enable the user to meet the required Trust Score for the activity and offset the run-time Risk Score calculated by the risk assessment engine.";

export const ACTIVITY_WIZ_RISK_EA_CONTENT = "Neuro enables to run risk assessments for every activity and channel combinations. Use this option to specify risk assessments that you want to run when the user initiates the activity. Risk Scores returned by the risk assessments are then factored into the authentication decision.";

export const ACTIVITY_WIZ_RISK_OS_CONTENT = "Neuro enables to run risk assessments for every activity and channel combinations. Use this option to specify risk assessments that you want to run only once per session. Risk Scores returned by the risk assessments are then factored into the authentication decision.";

export const ACITIVITY_WIZ_CONFIRM_CONTENT = "Review and Save the configuration changes.";
export const RISKWIZARD_CONFIRM_CONTENT = "Review and Save the changes.";

/* Confirmation Messages */
export const DEACTIVATE_ACTIVITY_CONFIRM: string = "Are you sure you want to de-activate this activity?";
export const ACTIVATE_ACTIVITY_CONFIRM: string = "Are you sure you want to activate this activity?";
export const DEACTIVATE_AUTHENTICATOR_CONFIRM: string = "Are you sure you want to de-activate this authenticator?";
export const ACTIVATE_AUTHENTICATOR_CONFIRM: string = "Are you sure you want to activate this authenticator?";

/* Placeholders */
export const AUTHENTICATORS_SEARCH_PH: string = "Search Authenticators: ID, NAME";
export const ACTIVITIES_SEARCH_PH: string = "Search Activities: ID, DESCRIPTION, CHANNEL";
export const FACT_LOCATOR_PH: string = "None";
export const DIAGNOSTICS_SEARCH_TEXT_PH: string = "Enter User ID";
/* Error Messages */
export const AUTH_DEACTIVATE_ERROR: string = "Unable to de-activate authenticator.";
export const AUTH_ACTIVATE_ERROR: string = "Unable to activate authenticator.";
export const ACT_DEACTIVATE_ERROR: string = "Unable to de-activate activity.";
export const ACT_ACTIVATE_ERROR: string = "Unable to activate activity.";

/* Text/Content */
export const EXPORT_TAB_CONTENT = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. ";

export const EXPORT_OBJECT_TAB_CONTENT = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. ";

export const EXPORT_CONFIRM_TAB_CONTENT = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.";

export const RISKWIZARD_DETAILS_DISPLAY_CONTENT = "Neuro enables to run risk assessments for every activity and channel combinations. In this step, define risk assessment details and assign appropriate invocation code."

export const  toastThemes = [
  { name: 'Default Theme', code: 'default' }, 
  { name: 'Material Design', code: 'material' }, 
  { name: 'Bootstrap 3',code: 'bootstrap' }
];

export const toastTypes = [
  { name: 'Default', code: 'default' }, 
  { name: 'Info', code: 'info' }, 
  { name: 'Success', code: 'success' }, 
  { name: 'Wait', code: 'wait' }, 
  { name: 'Error', code: 'error' }, 
  { name: 'Warning', code: 'warning'}
];

export const  toastPositions = [
	{ name: 'Top Left', code: 'top-left' }, 
	{ name: 'Top Center', code: 'top-center' }, 
	{ name: 'Top Right', code: 'top-right' }, 
	{ name: 'Bottom Left', code: 'bottom-left' }, 
	{ name: 'Bottom Center', code: 'bottom-center' }, 
	{ name: 'Bottom Right', code: 'bottom-right' }, 
	{ name: 'Center Center', code: 'center-center'}
];

export const sessionTimeoutTitle: string= "Session timeout!";
export const sessionTimeoutMsg: string= "Your session expired due to inactivity";
export const selectDateMsg: string= "Please select valid dates";
export const invalidDateMsg: string = "End date should be greater than start date";
export const invalidDateRange: string= "The selected dates are out of range and the valid range is 30 days";

export const cardWizard: string= "Setup activities, risk assessments and authenticators.";
export const cardActivity: string= "Manage the types of activities that are monitored.";
export const cardAuthenticator: string= "Manage the allowed authenticators and global defaults.";
export const cardMonitor: string= "Monitor activities. View graphical representation.";
export const cardRiskConfiguration: string = "Configure risk assessments and aggregation policy.";
export const cardDiagonistics: string = "Monitor user's session performance.";
export const cardRuleConfiguration: string = "Setup inclusion, exclusion rules.";

export const REFRESH_CACHE_SUCCESS_MSG: string = "Refresh cache activity was successfully performed.";
export const REFRESH_CACHE_FAILURE_MSG: string = "Error encountered while trying to refresh cache.";

export const PERSISTENT_SYSTEM_HOME_LINK: string = "https://www.persistent.com/";