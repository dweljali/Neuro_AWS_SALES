/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
 import {DomSanitizer} from '@angular/platform-browser';
import { MessageService } from './services/MessageService';
@Component({
    selector:"app",
    template:` <router-outlet></router-outlet> `
})
export class App{


}