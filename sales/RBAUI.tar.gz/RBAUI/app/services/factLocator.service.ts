/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, URLSearchParams, QueryEncoder } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class FactLocatorService {

	constructor(private http: Http) { }

	/* Set header details*/
	
	setHttpHeaders() {
		let headers = new Headers();
		headers.append('Content-Type', 'application/json; charset=utf-8');
		headers.append("Cache-Control", "no-cache");
		headers.append("Cache-Control", "no-store");
		headers.append("If-Modified-Since", "Mon, 26 Jul 1997 05:00:00 GMT");
		return headers;
	}

    /* API call to get all fact locators */
	getFactLocators(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/factlocator/factlocators', { headers: headers }).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

    /* API call to add new channel */
	postFactLocators(data: Object): Promise<any> {
		return this.http.post('/admin/api/factlocator/factlocators', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to edit fact locator */
	putFactLocators(data: Object): Promise<any> {
		return this.http.put('/admin/api/factlocator/factlocators', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

    /* Handler incase of error */
	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}
}
