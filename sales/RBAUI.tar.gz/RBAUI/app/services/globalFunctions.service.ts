/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Injectable } from '@angular/core';
import {Router} from '@angular/router';

@Injectable()
export class GlobalService {

    /* Server Settings */
    public authMode:Boolean = false;
	public ActivityExportFileName:string = "";
	public AppendTimeStampExportFile:Boolean = false;
    public userRole:string = "neuroadmin";
	public mode:string = "";
	/* Application variables  */
	public actWizardAuthTab:Boolean = false;
	public actWizardBalanceTab:Boolean = false;
	public riskfactorids:any = [];
	
    constructor(private router: Router){
    }

    /* pass  selected toDate to the function along with the parameter to specify the range to be calculated 
    Possible values are 'Week', 'Month' , 'Year'
    */
    calcPastDays(yearTo:number, monthTo: number, dayTo: number, type: string){
        let fromDateObj = new Date(yearTo, monthTo, dayTo);
         
        if(type== 'Week'){
          fromDateObj.setDate(fromDateObj.getDate()-5);
        }
        else if(type== 'Month'){
          fromDateObj.setDate(fromDateObj.getDate()-29);
        }
        else if(type == 'Year'){
          fromDateObj.setFullYear(fromDateObj.getFullYear()-1);
        }
        else{
          fromDateObj.setDate(fromDateObj.getDate()+1);
        }
         
        return fromDateObj;
    }

    constructDateString(dateObjFrom: any, dateObjTo: any, isDay: Boolean){
      let formattedDates: any={};
      dateObjFrom.setUTCHours(0,0,0,0);
        if(isDay){
            dateObjTo.setUTCHours(dateObjTo.getHours(), dateObjTo.getMinutes(), dateObjTo.getSeconds(), 0);
            //dateObjTo.setUTCHours(23,59,59,999);
        }
        else{
            dateObjTo.setUTCHours(23,59,59,999);
        }
      //formattedDates.fromDate= this.formatDate(dateObjFrom)+ ' 00:00:00';
      //formattedDates.toDate =  this.formatDate(dateObjTo) + ' 23:59:59';

      /* replace above lines with these for timezone conversion*/
      formattedDates.fromDate= this.formatDate(dateObjFrom);
      formattedDates.toDate =  this.formatDate(dateObjTo);
      return formattedDates;
    }

    /* Formats date to MM/DD/YYYY*/
    formatDate(convertDate: any){
      let temp='', temp2='';
      //temp= convertDate.getFullYear()+ '-' + (parseInt(convertDate.getMonth())+1).toString() + '-' + convertDate.getDate();
      temp2 = convertDate.toISOString()+convertDate.getTimezoneOffset();
       /* Return temp2 instead of temp1 for timezone conversion*/
      return temp2;
    }
    
    /* Angualar/Node.js Redirect */
    redirectServerOrClient(){		
        if(this.authMode){
            window.location.href= '/login';
        }
        else{
            this.router.navigate(['/login']);
        }
    }
}