import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input } from '@angular/core';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import { MessageService } from './../../services/MessageService';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { channelModalData, ChannelModal  } from './channel-modal';
import {ConfirmModelData} from '../../common/confirmModal.component'
import { AlertModelData } from './../../common/alertModal.component';
import * as myGlobals from './appChannelMessages';

/* Trigger to add new channel modal */ 
@Component({
  selector: 'modal-channel',
  template: `<span defaultOverlayTarget></span>  
  			<button (click)="openCustom()" id="show-modal" class="btn btn-primary btn-cons">
				<i class="fa fa-plus"></i>{{btnAddRiskText}}</button>`,
  providers: [Modal]
})

export class channelModalComponent {
    @Output() custevent:EventEmitter<any> = new EventEmitter<any>();
	btnAddRiskText:string = myGlobals.CHANNEL_BTN_ADD_TEXT;
    constructor( public modal: Modal){
    }

    openCustom() {      
		const dialog = this.modal.open(ChannelModal, overlayConfigFactory(
			{
				isBlocking: true,
				channelID: "", 
				channelDescription: "",
				channelEdit: false,
				Add: myGlobals.CHANNEL_ADD_TEXT,
				channelHeadermsg: myGlobals.CHANNEL_ADD_HEADER_TEXT
			}, BSModalContext));

			dialog.then((resultPromise) => {
				resultPromise.result.then((result) => {
					this.custevent.emit(result);
					let objbody = document.getElementsByTagName('body')[0];
					objbody.classList.remove("modal-open");
				});
			});   
    }
}

@Component({
    selector: 'channels',
    template: require('./Channels.html'),
    providers: [Modal]
})
export class channelsComponent{
	titles:Object[]=[];
	data:Object[]=[];
	objDelete:Object;

	itemsperpage:number = myGlobals.CHANNEL_ITEMS_PER_PAGE;
	maxpagesize:number = myGlobals.CHANNEL_MAX_PAGE_SIZE;
	homePage:string = myGlobals.CHANNEL_REDIRECT_PAGE_NAME;
	headerText:string = myGlobals.CHANNEL_HEADER_TEXT;
	titleText:string = myGlobals.CHANNEL_TITLE_TEXT;
	blnHideDiv:Boolean = false;

	constructor(private apiService: APIService, public objmodal: Modal,
				vcRef: ViewContainerRef,private router: Router, 
				private messageService: MessageService, private auth: AuthService,
				private globalService:GlobalService) {	
					objmodal.overlay.defaultViewContainer = vcRef;  
		if(this.globalService.userRole != "neuroadmin"){
			this.redir();
		}
		else{
			this.titles=[
				['id', 
				myGlobals.CHANNEL_TABLE_DISPLAY_NAME.id, 
				myGlobals.CHANNEL_TABLE_SORT_INFO.id],

				['description', 
				myGlobals.CHANNEL_TABLE_DISPLAY_NAME.description, 
				myGlobals.CHANNEL_TABLE_SORT_INFO.description]
			];

			this.InitiateChallenge();
		}
	}

	modifytable(objData:any){
		if(objData){
			if(objData.type == 1){
				this.openModalError(myGlobals.ADD_CHANNEL_SUCCESS, "Success");
				this.InitiateChallenge();
			}
			else{
				this.openModalError(myGlobals.UPDATE_CHANNEL_SUCCESS, "Success");
				this.InitiateChallenge();
			}
		}
	}

	/* Function to redirect to dashboard on click of breadcrumb */ 
	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard']);
	}


	InitiateChallenge(): void {
		var factLocators:any;
		this.data=[];

		this.apiService.getAllChannels().then((response:any) => { 
			var data = JSON.parse(response._body);
			if(data.channel){
				if(data.channel.length > 4){
					this.blnHideDiv = true;
				}
				else{
					this.blnHideDiv = false;
				}
				for(var i = 0; i < data.channel.length; i++){
					this.data.push({
						'id': data.channel[i].id, 
						'description': data.channel[i].text,
						'editkey': 1
					});
				} 
			}
		}).catch(error => {
			console.log(error);
		});
	}

	/* Modal displayed incase of error in deleting channel */ 
	openModalError(msg:string, headtext: string){
		const dialog = this.objmodal.open(AlertModelData, overlayConfigFactory(
		{
			isBlocking: true,
			message: msg,
			headtext: headtext
		}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {                    
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
		});
	}

	/* Return channel object based on id */ 
	filterByID(d: Object): Object{
		var match = this.data.filter(function (el) {
			return el['id'] === d['id'];
		});
		return match[0];
	}

	/* Function triggered on click of edit channel */ 
	edit(obj:Object){
		var toEdit= this.filterByID(obj);
		var index:string = this.data.indexOf(toEdit).toString();


		const dialog = this.objmodal.open(ChannelModal, overlayConfigFactory(
		{
			isBlocking: true, 
			channelID: this.data[index].id, 
			channelDescription: this.data[index].description,
			channelEdit:true,
			Add: myGlobals.CHANNEL_EDIT_TEXT, 
			channelHeadermsg: myGlobals.CHANNEL_EDIT_HEADER_TEXT
		}, BSModalContext));
		
		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
				if(result){
					this.modifytable(result);
				} 
			});
		});
	}

	/* Confirmation modal for remove channel */ 
	openModal(displaymsg:string){
		const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
		{
			size: 'md',
			isBlocking: false,
			message: displaymsg
		}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {                   
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");

				if(result=="1"){
					this.deleteRow();
				}
			});
		});
	}

	/* Function triggered on click of remove button in channel list */ 
	remove(obj:Object){
		this.objDelete = obj;
		this.openModal(myGlobals.DELETE_CHANNEL_CONFIRM);
	}

	/* Function that deletes the row from channel table */ 
	deleteRow(){
		var toDelete= this.filterByID(this.objDelete);
		var index:string = this.data.indexOf(toDelete).toString();
		var objReqId = this.data[index].id;

		this.apiService.deleteChannel({reqId:objReqId} ).then((response:any) => {    
			var resp = JSON.parse(response._body);
			if(resp.statusCode == 401){              
				this.globalService.redirectServerOrClient();
			}
			else if(resp.error == 0){
				this.data.splice(parseInt(index), 1);
			}
			else{
				this.openModalError((resp.errorMsg ? resp.errorMsg : myGlobals.CHANNEL_DELETE_ERROR_MSG)
									, "Error");
			}
		}).catch(error => {
			console.log(error);
		});
	}
}