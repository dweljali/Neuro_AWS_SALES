/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from './../../services/APIService.service';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import * as myGlobals from './../../common/appRiskAssessmentConfiguration';
import { MessageService } from './../../services/MessageService';
import { RuleIDService } from './ruleID.service';
import { RULES_ITEMS_PER_PAGE, RULES_MAX_PAGE_SIZE,RULES_LOCALSTORAGE_KEY } from './appRuleMessages';
import { SettingsService } from '../../services/settings.service';
@Component({
	selector: 'rule-configuration',
	template: require('./ruleconfiguration.html')
})
export class ruleconfigurationComponent {
	tableTitles: Object[] = [];
	public rules: Object[] = [];
	itemsperpage: number;
	pagesizes: Object[];
	maxpagesize: number = RULES_MAX_PAGE_SIZE;
	defaultitemsperpage: number = RULES_ITEMS_PER_PAGE;
	localstoragekey: string=  RULES_LOCALSTORAGE_KEY;
	constructor(public objmodal: Modal,
		private router: Router,
		private apiService: APIService, private globalService: GlobalService, private auth: AuthService,
		private messageService: MessageService,
		private vcRef: ViewContainerRef,
		private ruleIdService: RuleIDService,
		private settings: SettingsService
	) {
		objmodal.overlay.defaultViewContainer = vcRef;
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
		if (this.globalService.userRole != "neuroadmin") {
			this.redir();
		}
		else {
			/*	this.rules = [
					{ Name: "For active Chicago users", Description: "Description For active Chicago users", editkey: 1 },
					{ Name: "For users with Premier Account", Description: "Description For users with Premier Account", editkey: 1 },
					{ Name: "For users outside US", Description: "Description For users outside US", editkey: 1 },
					{ Name: "For new customers only", Description: "For new customers only", editkey: 1 },
					{ Name: "For ACH transfer only", Description: "Description For ACH transfer only", editkey: 1 }
				];*/
			this.tableTitles = [['Name', 1], ['Description', 1]];
			this.getRules();
		}
	}

	getRules() {
		return this.apiService.getRules().then((response) => {
			var objdata = JSON.parse(response._body);


			if (objdata.statusCode == 401) {
				this.auth.authInvalid = true;
				this.globalService.redirectServerOrClient();
			}
			else if (objdata.statusCode == 402) {
				this.redir();
			}
			else {
				this.rules = objdata['rules'];
				this.rules.forEach((rule) => {
					rule['editkey'] = 1;
				});
				let totalItems = this.rules.length;
				this.pagesizes = []; //initialize so that it has atleast one value
				let page = RULES_ITEMS_PER_PAGE;
				while (page <= totalItems) {
					this.pagesizes.push({
						id: page.toString(),
						text: page.toString()
					})
					page += RULES_ITEMS_PER_PAGE;
				}
				if ((page - RULES_ITEMS_PER_PAGE) < totalItems || !this.pagesizes.length) {
					this.pagesizes.push({
						id: page.toString(),
						text: page.toString()
					});
				}
				this.itemsperpage = this.settings.getPageSize(this.rules.length, RULES_ITEMS_PER_PAGE,RULES_LOCALSTORAGE_KEY);
			}

		});
	}
	gotoWizard() {
		this.messageService.highlightSidebar('ruleconfiguration');
		this.ruleIdService.ruleID = null;
		this.router.navigate(['admin/rulewizard/add']);
	}

	editrule(rule: Object) {
		this.ruleIdService.ruleID = rule['id'];
		this.messageService.highlightSidebar('ruleconfiguration');
		this.router.navigate(['admin/rulewizard/edit']);
	}

	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}


}