import { Component, OnInit, EventEmitter, ViewContainerRef, AfterViewInit, Input, ViewChildren } from '@angular/core';
import { APIService } from './../../../services/APIService.service';
import { GlobalService } from './../../../services/globalFunctions.service';
import { AuthService } from './../../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from './../../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../../common/alertModal.component';
import * as myGlobals from './../../../common/appMessages';
import { Subject } from 'rxjs/Subject'
import { exportTable } from './../../../common/exportTable.component';
import { ActivityeModel, ActivityModelData } from './../../../Configuration/Activities/activities-modal';
@Component({
    selector: 'confirm-export-wizard',
    template: `<span defaultOverlayTarget></span>

<div class="tab-pane slide-left padding-20" id="tab4">
    <div class="row row-same-height">
        <div class="col-md-5 b-grey ">
          <div class="m-t-1">
            <h2>Confirmation</h2>             
          </div>
        </div>
        <div class="p-r-30" style="float:right"> <h5>EXPORT ACTIVITIES</h5> </div>
        <br/>
        <div class="col-md-12">             
            <div>
                <div class="panel panel-default hover-stroke" [hidden]="hideObjects">
                  <div class="panel-body no-padding">
                    <div class="container-sm-height">
                      <div class="row row-sm-height">
                        <div class="col-sm-12 padding-20  col-sm-height col-top">
                            <div>
                              <label class="font-montserrat bold">OBJECT</label>
                            </div>
                            <div class="form-group">
                              
                                <div class="bootstrap-tagsinput">
                                    <div *ngFor="let objct of activeObjects" style="display: inline">
                                        <span class="tag label label-info">{{objct}}</span>
                                    </div>
                                </div>                               
                                
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 
                
                 <div [hidden]="!hideObjects">
                    <custom-export-table [headings]="tableTitles" [data]="activityData" 
                                [maxpagesize]="maxpagesize" [itemsperpage]="itemsperpage"
                                [showalert]="showalert.bind(this)" >
                    </custom-export-table>
                </div> 
            </div>                      
        </div>
    </div>
</div>
<div class="padding-20 bg-white">
    <ul class="pager wizard">
        <li class="next finish">
          <button (click)="download()" class="btn btn-primary btn-cons from-left pull-right" type="button">
                <span><a style="text-decoration:none;color:white;">
                    <i class="fa fa-download"></i> Export</a>
                </span>
          </button>
        </li>

        <li class="previous">
          <button (click)="previous()" class="btn btn-default btn-cons from-left  pull-right" type="button">
            <span>Previous</span>
          </button>
        </li>
    </ul>
</div>
<div class="emptyDiv" style="height: 35vh;"></div>`,
    providers: [APIService, Modal]
})
export class ConfirmExportPartialComponent {
    private ngUnsubscribe: Subject<void> = new Subject<void>();
    @Input() objecttype: number; //1 - Activity, 2 - Risk, 3 - Authenticators
    @Input() activitylist: any;
    @Input() channels: any;

    private tabTextContent: string = myGlobals.EXPORT_CONFIRM_TAB_CONTENT;
    private activeObjects: string[] = [];
    private hideObjects = false;
    private exportType: string = "";
    tableTitles: Object[] = [];
    activityData: Object[] = [];
    maxpagesize: number;
    itemsperpage: number;

    @Input() activeitem: any;
    ngAfterViewInit() {

    }

    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    /*  Constructor */
    constructor(private service: APIService, private route: ActivatedRoute,
        private router: Router, private tabs: TabsService, vcRef: ViewContainerRef,
        public modal: Modal, private auth: AuthService, private globalService: GlobalService) {

        modal.overlay.defaultViewContainer = vcRef;
        window.scrollTo(0, 0);
        this.maxpagesize = myGlobals.EXPORT_CONFIRM_MAX_PAGE_SIZE;
        this.itemsperpage = myGlobals.EXPORT_CONFIRM_ITEMS_PER_PAGE;

        this.tableTitles = [['id', 0], ['Description', 0],
        ['Channel', 0], ['Required Trust Score', 0],
        ['Risk Assessments', 0], ['Authenticators', 0]];
        this.loadData();
        
        this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
            this.loadData();
            if (message.text.toUpperCase().trim() == "CONFIRMEXPORT") {
                window.scrollTo(0, 0);
            }
        });
    }

    /* Function that displays modal upon validation error on activity & channel tab*/
    openModal() {
        const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
            {
                isBlocking: true,
                message: myGlobals.SELECT_EXPORT_TYPE,
                headtext: "Validation error"
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    validate() {
     
        if (this.objecttype == 0) {
            return false;
        }
        return true;
    }

    /* Function to navigate to the previous tab*/
    previous() {
        this.tabs.sendMessage("objectType", "");
    }

    /* Download function */
    download() {
        if (this.validate()) {
            var objJSON = this.exportActivities();
            if (objJSON && objJSON.ActivityList && objJSON.ActivityList.length > 0) {

                let blob = new Blob([JSON.stringify(objJSON)], { type: "application/json;charset=utf-8" });

                let filename = this.getJSONFileName();
                require('file-saver').saveAs(blob, filename);
            }
            else {
                this.openModalError("Please select activites to import.", "Error");
            }
        }
        else {
            this.openModal();
            this.tabs.sendMessage("exportType", "");
        }
    }

    getJSONFileName() {
        let filename: string = "";

        if (this.objecttype == 1) {
            filename = this.globalService.ActivityExportFileName + ".json";

            if (this.globalService.AppendTimeStampExportFile) {
                var dt = new Date();
                //dt.getFullYear() + "/" + (dt.getMonth() + 1) + "/" + dt.getDate();
                filename = this.globalService.ActivityExportFileName + '_'
                    + dt.getFullYear() + '_' + (dt.getMonth() + 1) + '_'
                    + dt.getDate() + '_' + dt.getHours()
                    + dt.getMinutes() + dt.getSeconds()
                    + ".json";
            }
        }

        if (!filename) { filename = this.createFileName() };
        return filename;
    }

    createFileName() {
        let filename: string = "Exported_";
        if (this.objecttype == 1) { filename + "Activities"; }
        else if (this.objecttype == 2) { filename + "RiskAssessments"; }
        else { filename + "Authenticators"; }

        var dt = new Date();
        dt.getFullYear() + "/" + (dt.getMonth() + 1) + "/" + dt.getDate();
        filename = filename + dt.getFullYear() + dt.getMonth() + dt.getDate() + dt.getHours() +
            dt.getMinutes() + dt.getSeconds() + ".json";

        return filename;
    }

    exportActivities() {
        var objActivities: any[] = [];
        let cnl: any[] = [];
        if (this.activeitem && this.activeitem.length > 0 && this.activitylist && this.activitylist.length > 0) {
            for (var i = 0; i < this.activeitem.length; i++) {
                if (this.activeitem[i]['status'] == true) {
                    for (var k = 0; k < this.activitylist.length; k++) {
                        if (this.activitylist[k].activity.activityID.value == this.activeitem[i]['id'] &&
                            this.activitylist[k].activity.channel == this.activeitem[i]['channelid']) {
                            if (cnl.indexOf(this.activeitem[i]['channelid']) == -1) {
                                cnl.push(this.activeitem[i]['channelid']);
                            }
                            objActivities.push(this.activitylist[k]);
                       
                            break;
                        }
                    }
                }
            }
        }

        var objchannels: Object[] = [];
       
        if (this.channels) {
            for (var key in this.channels) {
                if (cnl.indexOf(key) > -1) {
                    objchannels.push({ "id": key, "text": this.channels[key] });
                }

            }
        }
       
        var objJSON = { 'objectType': 'ACTIVITIES', 'ActivityList': objActivities, 'Channels': objchannels };

        return objJSON;
    }

    exportRiskAssessments() {
    }

    exportAuthenticators() {
    }

    /* Function to load data incase of edit*/
    loadData() {
        switch (this.objecttype) {
            case 1:
                this.exportType = "ACTIVITIES";
                this.hideObjects = true;
                this.loadActivities();
                break;
            case 2:
                this.exportType = "RISK ASSESSMENTS";
                this.hideObjects = false;
                this.loadAuthRisk();
                break;
            case 3:
                this.exportType = "AUTHENTICATROS";
                this.hideObjects = false;
                this.loadAuthRisk();
                break;
        }
    }

    loadAuthRisk() {
   
        this.activeObjects.splice(0, this.activeObjects.length);
        if (this.activeitem && this.activeitem.length > 0) {
            for (var i = 0; i < this.activeitem.length; i++) {
                if (this.activeitem[i]['status'] == true) {
                    this.activeObjects.push(this.activeitem[i]['name']);
                }
            }
        }
    }

    openModalError(msg: string, headtext: string) {
        const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
            {
                isBlocking: true,
                message: msg,
                headtext: headtext
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    loadActivities() {
        this.activityData.splice(0, this.activityData.length);
        if (this.activeitem && this.activeitem.length > 0 && this.activitylist && this.activitylist.length > 0 && this.channels) {

            for (var i = 0; i < this.activeitem.length; i++) {
                if (this.activeitem[i]['status'] == true) {
                    var authList: any[] = [];
                    var riskList: any[] = [];

                    for (var k = 0; k < this.activitylist.length; k++) {
                        if (this.activitylist[k].activity.activityID.value == this.activeitem[i]['id']
                            && this.activitylist[k].activity.channel == this.activeitem[i]['channelid']) {
                            if (this.activitylist[k].authenticationChallengeList) {
                                for (var j = 0; j < this.activitylist[k].authenticationChallengeList.length; j++) {
                                    authList.push(this.activitylist[k].authenticationChallengeList[j].description);
                                }
                            }

                            if (this.activitylist[k].riskAssessmentList) {
                                for (var j = 0; j < this.activitylist[k].riskAssessmentList.length; j++) {
                                    riskList.push(this.activitylist[k].riskAssessmentList[j].riskAssessmentName);
                                }
                            }

                            this.activityData.push({
                                'id': this.activitylist[k].activity.activityID.value,
                                'Description': this.activitylist[k].activity.description,
                                'Channel': this.channels[this.activitylist[k].activity.channel],
                                'Required Trust Score': this.activitylist[k].activity.requiredScore,
                                'Risk Assessments': riskList,
                                'Authenticators': authList
                            });
                            break;
                        }
                    }
                }
            }
        }
    }


    /* Modal to display all authenticators and risk assessments for a row in activity list */
    showalert(data: Object, heading: string) {
        const dialog = this.modal.open(ActivityeModel, overlayConfigFactory(
            {
                Add: heading,
                actArr: data
            }, BSModalContext));



        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }
}