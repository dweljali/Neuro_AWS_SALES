/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import {OrderByPipe} from '../../common/orderBy.component';
import {SearchPipe} from '../../common/searchFilter.component';
import * as myGlobals from './../../common/appRiskAssessmentConfiguration';
import {RISK_BTN_EDIT_DETAILS} from './riskassessmentsMessages';
import { SettingsService } from '../../services/settings.service';
/* Reusable component for tables */ 
@Component({
    selector:'risk-table',
    template: `
    <div class="row">
        <div class="col-xs-12" style="margin-left:-15px;">
                            <input id="search-table" style="width:300px;" [(ngModel)]="searchText" class="form-control" placeholder="{{pcSearchText}}" type="text" (input)="inpchanged($event.target.value);">
        </div>
        <div  *ngIf="itemsperpage && data.length > defaultitemsperpage" class="col-md-2  col-sm-6 form-group pull-right">
        <label>Records per page</label>
        <custom-select [dataobject]="pagesizes"   [activemember]="[{'text': itemsperpage}]" (selectvaluechange)="selectedvaluecode($event)">
        </custom-select>
        </div>
    </div>    
                <div class="clearfix"></div>
<pagination-controls class="customPagination" (pageChange)="page = $event" id="1"

                                    maxSize="{{maxpagesize}}"

                                    directionLinks="true"

                                    autoHide="true">

                </pagination-controls>
<span defaultOverlayTarget></span>
<table class="table table-hover demo-table-search table-responsive-block" id="tblRisk">
               <thead> 
               <tr> 
               <th *ngFor="let heading of headings" 
                        [class.pointer_cursor]="(heading[1] == 1)" 
                        (click)="sort(heading[0])">{{heading[2]}}
                     <i class="fa" [ngClass]="{'fa-sort': column != heading[0], 
                        'fa-sort-asc': (column == heading[0] && isDesc), 
                        'fa-sort-desc': (column == heading[0] && !isDesc),
                        'hide-grid-sort': (heading[1] == 0)}" aria-hidden="true"> 
                    </i>
                </th> 
               <th></th>
               <th></th> 
               </tr>
               </thead>
               <tbody> 
               <tr *ngFor="let item of data | searchcriteria: searchText | orderBy: {property: column, direction: direction} | paginate: {itemsPerPage: itemsperpage, currentPage:page, id: '1'}; 
					let i = index;" >
                <td *ngFor="let heading of headings" class="v-align-middle">
               <p *ngIf='!isArray(item[heading[0]])'>{{item[heading[0]]}}</p> 
               
               </td> 
               
               <td class="v-align-middle"> 
               <p><a class="btn" [ngClass]="{'btn-primary': (item['editkey'] == 1),
                                    'btn-disable-grid-button': (item['editkey'] == 0)}"  (click)="editrisk(item)">{{btnEditText}}</a></p>
                </td> 
                
               <td class="v-align-middle"> 
               <p><a class="btn" [ngClass]="{'btn-primary': (item['editkey'] == 1),
                                    'btn-disable-grid-button': (item['editkey'] == 0)}"  data-toggle="modal" (click)="showalert(item)">{{btnDetailsText}}</a></p>
                </td> 
                
               
               </tr>
               </tbody> 
               </table>
               <pagination-controls class="customPagination" (pageChange)="page = $event" id="1"

                                    maxSize="{{maxpagesize}}"

                                    directionLinks="true"

                                    autoHide="true">

                </pagination-controls>`,
})
export class risktable{

    @Input() headings:Object[];
    @Input() data:Object[];
    @Input() showalert: Object;
    @Input() editrisk : Object;
    @Input() maxpagesize:number;
    @Input() itemsperpage:number;
    @Input() pagesizes: Object[];
    @Input() defaultitemsperpage: number;
    @Input() localstoragekey: string;
  	@Output() changedtext:EventEmitter<number> = new EventEmitter<number>();
    isDesc: boolean = false;
    column: string = '';
    direction: number;
    btnEditText: string = RISK_BTN_EDIT_DETAILS;
	btnDetailsText: string = myGlobals.RISK_BTN_DISPLAY_DETAILS;
    pcSearchText:string = myGlobals.RISK_SEARCH_TEXT_PC;
	
    constructor(
        private settings: SettingsService
    ) {       
        
    }    
   
   sort(property:any){
        let proceedSorting: boolean = false;
        for(let i=0; i<this.headings.length;i++){
            if(this.headings[i][0] == property){
                if(this.headings[i][1] == 1){
                    proceedSorting = true;
                }
                break;
            }
        }
        
        if(proceedSorting){
            this.isDesc = !this.isDesc; //change the direction    
            this.column = property;
            this.direction = this.isDesc ? 1 : -1;
        }
    };
     
    isArray(val: any) {  return typeof val==='object'; }
	 
	inpchanged(val:any){
		let emitval:number = 0;
		if(val){
			if(val.length > 0){
				emitval=1;
			}
		}		
		this.changedtext.emit(emitval);
    }
    selectedvaluecode(data: any) {
        this.itemsperpage = parseInt(data['id']);
        this.settings.setPageSize(this.localstoragekey,this.itemsperpage);
    }
}