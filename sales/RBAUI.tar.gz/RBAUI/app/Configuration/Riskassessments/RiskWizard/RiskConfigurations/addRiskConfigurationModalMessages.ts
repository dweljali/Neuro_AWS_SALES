/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

// placeholders
export const RISK_CONFIGURATION_ID_PC : string = "Alphanumeric only, max length 10";
export const RISK_CONFIGURATION_NAME_PC : string = "Enter risk configuration name, max length 50";
export const RISK_CONFIGuRATION_DESCRIPTION_PC : string = "Describe risk configuration, max length 255";
export const RISK_CONFIGURATION_VALUE_PC : string = "Enter risk configuration value, max length 255";