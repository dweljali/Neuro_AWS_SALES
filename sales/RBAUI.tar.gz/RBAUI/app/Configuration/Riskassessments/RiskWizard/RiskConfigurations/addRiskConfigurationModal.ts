import { Component,Input,AfterViewInit, ViewChildren } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { selectComponent } from './../../../../common/select.component';
import * as myGlobals from './../../../../common/appMessages';
import {RISK_CONFIGURATION_ID_PC, RISK_CONFIGURATION_NAME_PC, RISK_CONFIGuRATION_DESCRIPTION_PC, RISK_CONFIGURATION_VALUE_PC} from './addRiskConfigurationModalMessages'
import { RISK_ASSESSMENT_NAME_PC } from '../../riskassessmentsMessages';
export class riskConfigurationModalData extends BSModalContext {
  public configID: string; 
  public configName: string;
  public configDescription: string;
  public configValue : string;
  public configEdit: boolean;
  public Add:string;
  public datatype:Object[];
  public activedatatype:Object[];
  public selecteddatatype:string;
  public selectedConfType: string;
  public configtypedata:Object[];
  public iddata:any;
  public formData: any;
   
  public authHeadermsg:string;
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-content', 
  template: `
    <style>.ui-select-choices {left: auto; position: fixed;    top: auto;    width: 88% !important;} .small-text-red {font-size: 14px !important;color: red;text-align: center;} .hide-text{display: none;}</style>
        <div class="modal-dialog" [class.customfade]="isFade">
             
                <div class="modal-header clearfix ">
        <button type="button" (click)='closebox()' class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                  </button>
                  <h4 class="p-b-5"><span class="semi-bold">{{context.Add}}</span> Risk Configuration</h4>
                </div>
                <div class="modal-body">
                  <p class="small-text-red" [class.hide-text]="hideerrormsg">{{errormessage}}</p>
                  <p class="small-text">{{context.authHeadermsg}}</p>                   
                  <form role="form">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>Risk Configuration ID</label>
                          <input maxlength="10" id="appID" #appID (focus)="oninputfocus()"  (input)="configID = $event.target.value" [disabled]="context.configEdit" class="form-control" placeholder="{{riskConfigIdPc}}" type="text" value="{{context.configID}}" (keypress)="_keyPressID($event)">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>Risk Configuration Name</label>
                          <input maxlength="50" id="appName" #appName (input)="configName = $event.target.value" (focus)="oninputfocus()" class="form-control" placeholder="{{riskConfigNamePc}}" type="text" value="{{context.configName}}">
                        </div>
                      </div>
                    </div>
					<div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>Risk Configuration Description</label>
                          <input maxlength="255" id="appDescription" #appDesc (input)="configDescritption = $event.target.value" (focus)="oninputfocus()" class="form-control" placeholder="{{riskConfigDescriptionPc}}" type="text" value="{{context.configDescription}}">
                        </div>
                      </div>
                    </div>

					<div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required custFormgrp">
                          <label>Risk Configuration Type</label>
                              <custom-select [dataobject]="context.configtypedata" [placeholder]="pcholder" (selectvaluechange)="selectedvalueconfig($event)"     [activemember]="context.activedatatype"></custom-select>
                        </div>
                      </div>
                    </div> 
					<div class="row">
                        <div class="col-sm-12 ">                            
                            <div class="form-group form-group-default custFormgrp" hidden>
                    <label>Risk Configuration Datatype</label>
                    <custom-select [dataobject]="context.datatype" [placeholder]="pcholder" (selectvaluechange)="selectedvalue($event)" [activemember]="context.activedatatype" ></custom-select>
                               
                            </div> 
                        </div> 
                      </div>
					<div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>Risk Configuration Value</label>
                          <input maxlength="255" id="appValue" #appValue (input)="configValue = $event.target.value" (focus)="oninputfocus()" class="form-control" placeholder="{{riskConfigValuePc}}" type="text" value="{{context.configValue}}">
                        </div>
                      </div>
                    </div>

                  </form>
                </div>
                <div class="modal-footer">
                  <button id="add-app" data-dismiss="modal" type="button" (click)='saveAuthenticators(appID.value, appName.value, appDesc.value, isEdit.value,datattype.value,appValue.value, iddata.value)' class="btn btn-primary  btn-cons">Add</button>
                  <button type="button" data-dismiss="modal" (click)='closebox()' class="btn btn-cons">Close</button>
<input type="hidden" #isEdit value="{{context.configEdit}}" >
<input type="hidden" #datattype value="{{context.selecteddatatype}}" > 
<input type="hidden" #iddata value="{{context.iddata}}">
                </div>
            </div>`
})
export class riskConfigurationModal implements CloseGuard, ModalComponent<riskConfigurationModalData> {
	context: riskConfigurationModalData;
	@ViewChildren('appID') vcappid:any;
	@ViewChildren('appName') vcappname:any;
	@ViewChildren('appDesc') vcappdesc:any;
	
	 
	@ViewChildren('appValue') vcappvalue:any;

  ngAfterViewInit() {
    this.configID = this.context.configID;
    this.configName = this.context.configName;
    this.configDescritption = this.context.configDescription;
    this.configValue = this.context.configValue;
    this.selectedconfigtype = this.context.selectedConfType;
    this.selecteddatatype = this.context.selecteddatatype;
   
    /*for(let type of this.context.configtypedata){
      console.log("Selected config value ", type['id']);
        if(type['text'] == this.context.activedatatype[0]['text']){
          this.selectedvalueconfig(type);
          console.log("selectedconfigtype", this.selectedconfigtype);
          console.log("selecteddatatype", this.selecteddatatype);          
        }
    }*/
	try{
		if(this.vcappid){
			this.vcappid.first.nativeElement.focus();
		}
	}
	catch(e){
	}
  }

  public isFade = false;
  public configID:string;
 public configName:string;
  public configDescritption:string;
   
  public configValue:string;
  public selecteddatatype:string;
public selectedconfigtype:string;
  public returndata:any;
  public pcholder:string;
  public authFact:string;
  public selecteddatakey:string;
   
  public hideerrormsg = true;
  public errormessage:string;

  public riskConfigIdPc =RISK_CONFIGURATION_ID_PC;
  public riskConfigNamePc = RISK_CONFIGURATION_NAME_PC;
  public riskConfigDescriptionPc = RISK_CONFIGuRATION_DESCRIPTION_PC;
  public riskConfigValuePc = RISK_CONFIGURATION_VALUE_PC;
  oninputfocus(){
    this.errormessage = "";
    this.hideerrormsg = true;
  }

  constructor(private apiService: APIService, public dialog: DialogRef<riskConfigurationModalData>,private globalService: GlobalService) {
    this.context = dialog.context;
    dialog.setCloseGuard(this);
    this.pcholder = myGlobals.FACT_LOCATOR_PH;    
  }

  closebox(){
    this.isFade = true;
    this.dialog.close(this.returndata);
  }

  selectedvalue(objValue:any){    
    this.selecteddatatype = objValue.id;
     this.configValue = "";
  }

selectedvalueconfig(val:any){
	this.selectedconfigtype = val.id;
	if(val.id == "OUTPUT_POINTS"){
		this.selecteddatatype = "INTEGER"
	}else{
		this.selecteddatatype = "STRING"
	}
}

  beforeDismiss(): boolean {
    this.dialog.close(this.returndata);
    this.isFade = true;
    return false;
  }

  /* Function to validate authenticator id */ 
  _keyPressID(event: any) {
    var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft','Home','Delete','Tab'];
    const pattern = /^[a-zA-Z\d-_]+$/;
    let inputChar = String.fromCharCode(event.charCode);


    if(arrint.indexOf(event.key) != -1 ){
      return;
    }
    else if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }

  }

  /* Function to save the new/edited authenticator */ 
  saveAuthenticators(objAppid: string, objAppname:string, objAppDesc:string,
					 objEdit:string, objdatattype:string ,objappValue:string, idData:any)
  {  
	 
	  
    if(!objAppid || !objAppname || !objAppDesc || !this.selectedconfigtype || !objappValue){
      this.errormessage = myGlobals.MANDATORY_FIELDS_VALIDATE;
      this.hideerrormsg = false;
      return;   
    }
	 if(idData){
		 var res = idData.split(",");
		 if(res && res.length > 0){
			 var validstate = 1;
			 for(var i=0; i<res.length; i++){
				 if(res[i] == this.configID){
					 validstate = 0;
					 break;
				 }
			 }
				 
			 if(validstate == 0){
				 this.errormessage = "Risk configuration ID already exists. Please enter some other ID.";
				  this.hideerrormsg = false;
				  return;
			 }
		 }
	 }
		this.returndata = {'id': this.configID, 'name':this.configName, 'desc': this.configDescritption ,
						   'configtype': this.selectedconfigtype, 'value':this.configValue,
						  'datatype':this.selecteddatatype, 'type':1};
		this.closebox();            
    }
    
  
}
