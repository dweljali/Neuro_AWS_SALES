/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewContainerRef, Input, SimpleChange } from '@angular/core';
import { APIService } from './../../../../services/APIService.service';
import { GlobalService } from './../../../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from '../../../../services/tabsService'
import { AuthService } from '../../../../services/auth.service';
import { multiselectComponent } from './../../../../common/multiselect.component';

import { AlertModelData } from './../../../../common/alertModal.component';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import * as myGlobals from './../../../../common/appMessages';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'risk-confirm-tab',
  template: `<span defaultOverlayTarget></span><div class="row row-same-height">
                    <div class="col-md-5 b-r b-dashed b-grey ">
                      <div class="padding-30 m-t-50">
                        <h2>Confirmation</h2>
                        <p>{{tabContent}}</p>
                      </div>
                    </div>
                    <div class="col-md-7">
                      <div>
                        <div class="panel panel-default hover-stroke">
                          <div class="panel-body no-padding">
                            <div class="container-sm-height">
                              <div class="row row-sm-height">
                                <div class="col-sm-12 padding-20 col-sm-height col-top">
								<span class="icon-thumbnail bg-info pull-left" style="color:white;">1</span>
                                  <p class="font-montserrat bold">RISK ASSESSMENT</p><br/>
                                  <form role="form">
                                  <div class="form-group-attached">
                                    <div class="form-group form-group-default">
                                      <label>Risk Assessment ID</label>
                                      <input type="text" class="form-control" value="{{riskcode}}"
											disabled style="color:black;">
                                    </div>
								</div>
							<div class="form-group-attached">
								<div class="row clearfix">
									<div class="col-sm-6">
										<div class="form-group form-group-default">
										  <label>Risk Assessment Name</label>
										  <input type="text" class="form-control" value="{{riskname}}" 
													disabled style="color:black;">
										</div>
									  </div>
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											  <label>Invocation Code</label>
											  <input type="text" class="form-control" value="{{invocationcodename}}" 
												disabled style="color:black;">
										 </div>
									</div>
								</div>
							</div>

                                </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>          
                      </div>
                      <div>
                        <div class="panel panel-default hover-stroke">
                          <div class="panel-body no-padding">
                            <div class="container-sm-height">
                              <div class="row row-sm-height">
                                <div class="col-sm-12 padding-20  col-sm-height col-top"><span class="icon-thumbnail bg-info pull-left" style="color:white;">2</span>
                                  <p class="font-montserrat bold">RISK CONFIGURATION</p><br/>                       
                                    <form role="form">
                                       
                                      <div class="form-group-attached">
                                         <div class="row clearfix">
								<risk-score-table [headings]="configtitles" [data]="riskconfiguration"   
										[itemsperpage]="5" [maxpagesize]="5" >
									</risk-score-table>
							</div>
                                      </div>
                                    </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>          
                      </div>
                      <div>
                        <div class="panel panel-default hover-stroke">
                          <div class="panel-body no-padding">
                            <div class="container-sm-height">
                              <div class="row row-sm-height">
                                <div class="col-sm-12 padding-20  col-sm-height col-top"><span class="icon-thumbnail bg-info pull-left" style="color:white;">3</span>
                                  <p class="font-montserrat bold">RISK FACTOR</p><br/>                     
										<form role="form">

										<div class="form-group-attached">
											<div class="row clearfix">
											<risk-factor-table [headings]="factortitles" [data]="riskfactors"   
											[itemsperpage]="5" [maxpagesize]="5" >
											</risk-factor-table>
										</div>
										</div>
										</form>
                                </div>
                              </div>
                            </div>

                          </div>
                        </div>          
                      </div>
                    </div>
                  </div>
                  
                  <div class="padding-20 bg-white">
                  <ul class="pager wizard">
                    <li class="next finish">
                      <button (click)="save()" class="btn btn-primary btn-cons from-left pull-right" type="button">
                        <span>Finish</span>
                      </button>
                    </li>
                    <li class="previous">
                      <button (click)="previous()" class="btn btn-default btn-cons pull-right from-left" type="button">
                        <span>Previous</span>
                      </button>
                    </li>
                  </ul>
                </div>
                  
                  `,
  providers: [APIService, Modal]
})
export class riskConfirmComponent {
  /* Risk Details tab */
  @Input() riskcode: string;
  @Input() riskname: string;
  @Input() invocationcode: string;
  @Input() invocationcodename: string;

  /* Risk Configuration tab */
  @Input() riskconfiguration: any = [];

  /* Risk factors tab */
  @Input() riskfactors: any = [];

  //to check if edit
  @Input() isedit: boolean;
  public movetotab: number = 0;
  public configtitles: Object[] = [];
  public factortitles: Object[] = [];
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  private tabContent: string = myGlobals.RISKWIZARD_CONFIRM_CONTENT;
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(private service: APIService, private route: ActivatedRoute,
    private router: Router, private tabs: TabsService, vcRef: ViewContainerRef,
    public modal: Modal, private auth: AuthService, private globalService: GlobalService) {
    modal.overlay.defaultViewContainer = vcRef;
    window.scrollTo(0, 0);
    this.configtitles = [['id', 1, 'id'], ['Name', 1, 'Name'], ['Type', 1, 'Type']];
    this.factortitles = [['id', 1, 'id'], ['Name', 1, 'Name'], ['Provided System', 1, 'Provided System']];
    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
      if (message.text == "confirmriskwizard") {
        window.scrollTo(0, 0);

      }
    });

  }
  ngOnChanges(changes: SimpleChange) {
  }
  /* Function to load data incase of edit*/
  loadData() {
  }

  /* Function to validate all the details on confirm tab*/
  validate() {
    if (!this.riskcode || !this.riskname || !this.invocationcode) {
      return 1;
    }
    else if (!this.riskconfiguration || this.riskconfiguration.length <= 0) {
      return 2;
    }
    return 0;
  }


  /* Function displays alert incase data is incomplete and navigates to the appropriate tab*/
  openModal(msg: string, headtext: string) {
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
      {
        isBlocking: true,
        message: msg,
        headtext: headtext
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
        switch (this.movetotab) {
          case 1:
            this.tabs.sendMessage("detailsriskswizard", "");
            break;
          case 2:
            this.tabs.sendMessage("riskconfigriskwizard", "");
            break;
          case 3:
            this.router.navigate(['/admin/riskassessments']);
            break;
        }
      });
    });
  }

  /* Function triggered on click of save button that saves the activity*/
  save() {
    var objValidate: number = this.validate();
    if (objValidate == 0) {
      if (this.isedit) {
        this.putRiskAssessment();
      } else {
        this.postRiskAssessment();
      }

    }
    else {
      var errmsg: string;
      this.movetotab = 0;
      switch (objValidate) {
        case 1:
          errmsg = myGlobals.RISKWIZARD_DETAILS_REVIEW;
          this.movetotab = 1;
          break;

        case 2:
          errmsg = myGlobals.RISKWIZARD_CONFIG_REVIEW;
          this.movetotab = 2;
          break;
      }
      this.openModal(errmsg, "Validation error");
    }
  }

  postRiskAssessment() {

    let risk: Object[] = [];
    let riskCongifData: Object[] = [];
    let riskFactorsData: Object[] = [];

    for (var i = 0; i < this.riskconfiguration.length; i++) {
      riskCongifData.push({
        "riskAssessmentConfigID": this.riskconfiguration[i].id,
        "riskAssessmentConfigName": this.riskconfiguration[i].Name,
        "riskAssessmentConfigDesc": this.riskconfiguration[i].Desc,
        "riskAssessmentConfigType": this.riskconfiguration[i].Type,
        "riskAssessmentConfigDatatype": this.riskconfiguration[i].datatype,
        "riskAssessmentConfigValue": this.riskconfiguration[i].Value
      });
    }

    risk.push({
      "riskAssessmentCD": this.riskcode,
      "riskAssessmentName": this.riskname,
      "riskAssessmentInvocationCD": this.invocationcode,
      "riskAssessmentConfigurations": riskCongifData
    });


    if (this.riskfactors && this.riskfactors.length > 0) {
      for (var i = 0; i < this.riskfactors.length; i++) {
        riskFactorsData.push({
          "riskFactorCode": this.riskfactors[i].id,
          "riskFactorName": this.riskfactors[i].Name,
          "risk_asmt_classname": this.riskfactors[i].risk_asmt_classname,
          "risk_factor_classname": this.riskfactors[i].risk_factor_classname,
          "risk_factor_locator_classname": this.riskfactors[i].risk_factor_locator_classname,
          "riskFactorDataTypeName": this.riskfactors[i].datatype,
          "providedBySourceSystemName": this.riskfactors[i]['Provided System'],
          "retryCollectionOnFailureIndicator": false,
          "rerunOnFactorChange": false,
          "riskFactorInvocationCode": this.invocationcode == "EA"
            ? "EVERY_ACTIVITY_START" : "ONCE_PER_SESSION"
        });
      }
    }

    this.service.postRiskAssessmentsWithFactors({ "riskassessments": risk, "riskFactors": riskFactorsData }).then(response => {
      var resp = JSON.parse(response._body);
      if (resp.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
      else if (resp.error == 0) {
        this.movetotab = 3;
        this.openModal(myGlobals.ADD_RISKWIZARD_SUCCESS, "Success");
      }
      else { this.movetotab = 0; this.openModal(resp.errmsg, "Error"); }
    }).catch(error => { console.log(error) });


  }
  putRiskAssessment() {


    let riskCongifData: Object[] = [];
    let riskFactorsData: Object[] = [];
    let riskAssessmentCD = this.riskcode;
    let riskAssessmentName = this.riskname;
    let riskAssessmentInvocationCD = this.invocationcode;
    let rerunAssessmentOnFailure = false;

    for (var i = 0; i < this.riskconfiguration.length; i++) {
      console.log("Risk configs: ", this.riskconfiguration[i]);
      riskCongifData.push({
        "assessmentCode": riskAssessmentCD,
        "riskAssessmentConfigID": this.riskconfiguration[i].id,
        "riskAssessmentConfigName": this.riskconfiguration[i].Name,
        "riskAssessmentConfigDesc": this.riskconfiguration[i].Desc,
        "riskAssessmentConfigType": this.riskconfiguration[i].Type,
        "riskAssessmentConfigDatatype": this.riskconfiguration[i].datatype,
        "riskAssessmentConfigValue": this.riskconfiguration[i].Value
      });
    }



    if (this.riskfactors && this.riskfactors.length > 0) {
      for (var i = 0; i < this.riskfactors.length; i++) {
        riskFactorsData.push({
          "riskFactorCode": this.riskfactors[i].id,
          "riskFactorName": this.riskfactors[i].Name,
          "risk_asmt_classname": this.riskfactors[i].risk_asmt_classname,
          "risk_factor_classname": this.riskfactors[i].risk_factor_classname,
          "risk_factor_locator_classname": this.riskfactors[i].risk_factor_locator_classname,
          "riskFactorDataTypeName": this.riskfactors[i].datatype.toUpperCase(),
          "providedBySourceSystemName": this.riskfactors[i]['Provided System'],
          "retryCollectionOnFailureIndicator": false,
          "rerunOnFactorChange": false,
          "riskFactorInvocationCode": this.invocationcode == "EA"
            ? "EVERY_ACTIVITY_START" : "ONCE_PER_SESSION"
        });
      }
    }

    this.service.editRiskAssessment(riskAssessmentCD, {
      riskAssessmentCD,
      riskAssessmentName,
      riskAssessmentInvocationCD,
      rerunAssessmentOnFailure,
      "riskAssessmentConfigurations": riskCongifData,
      "riskFactorVOs": riskFactorsData
    }).then(response => {
      var resp = JSON.parse(response._body);
      if (resp.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
      else if (resp.error == 0) {
        this.movetotab = 3;
        this.openModal("Risk assessment edited successfully", "Success");
      }
      else { this.movetotab = 1; this.openModal(resp.errmsg, "Error"); }
    }).catch(error => { console.log(error) });


  }
  checkLoggedIn() {
    this.service.isLoggedIn().then((response: any) => {
      var apiData = JSON.parse(response._body);
      if (apiData && !apiData.login) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
    });
  }
  /* Function to navigate to the previous tab*/
  previous() {
    this.checkLoggedIn();
    this.tabs.sendMessage("riskfactorriskwizard", "");
  }
}