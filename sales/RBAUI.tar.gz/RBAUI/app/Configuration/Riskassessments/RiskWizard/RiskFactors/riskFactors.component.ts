/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input } from '@angular/core';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from '../../../../services/tabsService';
import { AuthService } from '../../../../services/auth.service';
import { Subject } from 'rxjs/Subject';
import * as myGlobals from './../../../../common/appMessages';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { riskFactorModal, riskFactorModalData } from './addRiskFactorModal';
import { ConfirmModelData } from './../../../../common/confirmModal.component'
import { AlertModelData } from './../../../../common/alertModal.component';
import { SimpleChange, ViewChild } from '@angular/core';
import { riskFactorEditModalComponent } from './riskFactorsEdit.component'
@Component({
  selector: 'add-risk-factor',
  template: `<span defaultOverlayTarget></span>  
  <button (click)="openCustom()" id="show-modal" class="btn btn-primary btn-cons"><i class="fa fa-plus"></i> Add Risk Factor</button>
`,
  providers: [Modal]
})

export class riskFactorModalComponent {
  @Output() custevent: EventEmitter<any> = new EventEmitter<any>();
  public datatypeobj: Object[] = [];
  public providedsystems: Object[] = [];
  @Input() iddata: Object[] = [];
  constructor(public modal: Modal) {
    this.datatypeobj.push({ 'id': "STRING", 'text': "STRING" });
    this.datatypeobj.push({ 'id': "INTEGER", 'text': "INTEGER" });

    this.providedsystems.push({ 'id': 'CLIENT', 'text': 'CLIENT' });
    this.providedsystems.push({ 'id': 'RBA_INTERNAL', 'text': 'RBA_INTERNAL' });
    this.providedsystems.push({ 'id': 'EXTERNAL', 'text': 'EXTERNAL' });
  }
  openCustom() {

    const dialog = this.modal.open(riskFactorModal, overlayConfigFactory(
      {
        isBlocking: true,
        factorID: "",
        factorName: "",
        riskClass: "",
        factorClass: "",
        factorLocator: "",
        factorEdit: false,
        Add: "Add",
        activedatatype: [{ 'text': "STRING" }],
        selecteddatatype: "STRING",
        datatype: this.datatypeobj,
        providedsystems: this.providedsystems,
        iddata: this.iddata,
        authHeadermsg: "Create a new risk factor using this form"
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        this.custevent.emit(result);
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
      });
    });
  }
}

@Component({
  selector: 'risk-factors-tab',
  template: require('./RiskFactors.html'),
  providers: [APIService, Modal]
})
export class riskFactorsComponent {

  @Output() updateriskfactors: EventEmitter<any> = new EventEmitter<any>();
  @Input() riskfactdatafromparent: any = [];
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  public riskfactordata: any = [];
  public titles: Object[] = [];
  public iddata: Object[] = [];
  @ViewChild('child')
  private editComponent: riskFactorEditModalComponent;
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(private service: APIService, private route: ActivatedRoute,
    private tabs: TabsService, private auth: AuthService, private globalService: GlobalService,
    private objmodal: Modal) {
    this.loadData();
    this.titles = [['id', 1], ['Name', 1]];
    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
      if (message.text == "riskfactorriskwizard") {


      }
    });
  }
  ngOnInit() {
    //this.loadData();
  }
  ngOnChanges(changes: SimpleChange) {

    if (changes['riskfactdatafromparent']) {
      //this.riskfactordata = this.riskfactdatafromparent;
      for (let value of this.riskfactdatafromparent) {
        // console.log(`value is `, value);
        this.pushData(value);
      }
      // console.log("Iddata is", this.iddata);
      this.updateriskfactors.emit(this.riskfactordata);
    }
  }
  pushData(value: any) {

    this.riskfactordata.push({
      'id': value.id.trim(),
      'Name': value.name,
      'Provided System': value.providedsystem,
      'datatype': value.dataType,
      'risk_asmt_classname': value.risk_asmt_classname,
      'risk_factor_classname': value.risk_factor_classname,
      'risk_factor_locator_classname': value.risk_factor_locator_classname
    });
    this.iddata.push(value.id.trim());
  }
  modifytable(value: any) {
    if (value) {
      this.riskfactordata.push({
        'id': value.id,
        'Name': value.name,
        'Provided System': value.providedsystem,
        'datatype': value.datattype,
        'risk_asmt_classname': value.risk_asmt_classname,
        'risk_factor_classname': value.risk_factor_classname,
        'risk_factor_locator_classname': value.risk_factor_locator_classname
      });
      this.iddata.push(value.id.trim());
    }
    this.updateriskfactors.emit(this.riskfactordata);
  }

  /* Function to load data incase of edit */
  loadData() {
    this.riskfactordata = this.riskfactdatafromparent;
  }
  editriskfactor(data: any) {
    if (data) {
      var index = this.riskfactordata.map(function (item: any) {
        return item.id;
      }).indexOf(data.id);
      this.riskfactordata[index].Name = data.name;
      this.riskfactordata[index]['Provided System'] = data.providedsystem;
      this.riskfactordata[index].datatype = data.datattype;
      this.riskfactordata[index].risk_asmt_classname = data.risk_asmt_classname;
      this.riskfactordata[index].risk_factor_classname = data.risk_factor_classname;
      this.riskfactordata[index].risk_factor_locator_classname = data.risk_factor_locator_classname;
    }

  }
  edit(data: any) {
    this.editComponent.openCustom(data);
  }

  remove(data: any) {
    const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
      {
        size: 'md',
        isBlocking: false,
        message: "Are you sure you want to delete this risk factor?"
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");

        if (result == "1") {
          var index = this.riskfactordata.map(function (item: any) {
            return item.id
          }).indexOf(data);
          this.riskfactordata.splice(index, 1);

          // get index of data in iddata
          index = this.iddata.indexOf(data);
          this.iddata.splice(index, 1); // remove it

          this.updateriskfactors.emit(this.riskfactordata);
        }
      });
    });

  }

  checkLoggedIn() {
    this.service.isLoggedIn().then((response: any) => {
      var apiData = JSON.parse(response._body);
      if (apiData && !apiData.login) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
    });
  }
  /* Function triggered on click of save button*/
  save() {
    this.checkLoggedIn();
    this.tabs.sendMessage("confirmriskwizard", "");
  }

  /* Function to navigate to the previous tab*/
  previous() {
    this.checkLoggedIn();
    this.tabs.sendMessage("riskconfigriskwizard", "");
  }

}