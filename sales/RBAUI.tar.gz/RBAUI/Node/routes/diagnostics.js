/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var dgController=require('../controllers/diagnosticsController');
var loginController=require('../controllers/loginController');

router.get('/getDiagnostics/:userid/:channel',loginController.authenticateAuthorzation, function(req,res,next){
    runner(dgController.getDiagnostics(req,res,next));
});

router.get('/getChannels', loginController.authenticateAuthorzation, function(req,res,next){
    runner(dgController.getChannels(req,res,next));
});

module.exports=router;