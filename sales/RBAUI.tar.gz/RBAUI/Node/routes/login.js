/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var loginController=require('../controllers/loginController');

router.get('/',function(req,res,next){
    runner(loginController.verifyLogin(req,res,next));
});

router.post('/',function(req,res,next){
    runner(loginController.login(req,res,next));
});

router.get('/refreshCache',loginController.authenticate ,function(req,res,next){
    runner(loginController.refreshCache(req,res,next));
});

router.get('/getLoggedInUserDetails',function(req,res,next){
    runner(loginController.getLoggedInUserDetails(req,res,next));
});

module.exports=router;