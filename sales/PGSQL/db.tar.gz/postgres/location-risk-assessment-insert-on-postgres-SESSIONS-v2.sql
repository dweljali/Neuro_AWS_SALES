--
-- PostgreSQL database dump
--

-- Dumped from database version 9.2.13
-- Dumped by pg_dump version 9.6.3

-- Started on 2017-08-07 14:40:45

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = sessions, pg_catalog;

--
-- TOC entry 3114 (class 0 OID 25369)
-- Dependencies: 185
-- Data for Name: risk_assessment; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

INSERT INTO SESSIONS.AUTHENTICATOR(ID, NAME, FACT_LOCATOR_ID, STATUS, CREATED_ON, CREATED_BY, UPDATED_ON, UPDATED_BY) VALUES ('OTP','One Time Password','UserContactInfo',1,CURRENT_TIMESTAMP,'rbaadmin',CURRENT_TIMESTAMP,'rbaadmin');

INSERT INTO SESSIONS.ACTIVITY(ID, SEVERITY, NAME,CREATED_ON,CREATED_BY,UPDATED_ON,UPDATED_BY) VALUES('REFCACHE','Normal','Refresh Cache',CURRENT_TIMESTAMP,'rbaadmin',CURRENT_TIMESTAMP,'rbaadmin');

INSERT INTO SESSIONS.METHOD(ID,NAME,CREATED_ON,CREATED_BY,UPDATED_ON,UPDATED_BY) VALUES(1,'METHOD REFCACHE WEB',CURRENT_TIMESTAMP,'rbaadmin',CURRENT_TIMESTAMP,'rbaadmin');

INSERT INTO SESSIONS.ACTIVITY_BY_CHANNEL(ACTIVITY_ID,CHANNEL_ID,USER_TYPE,SCORE,STATUS,CREATED_BY,CREATED_ON,UPDATED_BY,UPDATED_ON) VALUES ('REFCACHE','WEB','USER',50,1,'rbaadmin',CURRENT_TIMESTAMP,'rbaadmin',CURRENT_TIMESTAMP);

INSERT INTO SESSIONS.ACTIVITY_METHOD(ACTIVITY_ID, CHANNEL_ID, USER_TYPE, METHOD_ID,CREATED_ON,CREATED_BY,UPDATED_ON,UPDATED_BY) VALUES('REFCACHE','WEB','USER',1,CURRENT_TIMESTAMP,'rbaadmin',CURRENT_TIMESTAMP,'rbaadmin');

INSERT INTO SESSIONS.AUTHENTICATOR_METHOD(AUTHENTICATOR_ID, METHOD_ID, SCORE, PRIORITY, MANDATORY_AUTHENTICATION,CREATED_ON,CREATED_BY,UPDATED_ON,UPDATED_BY) VALUES('OTP',1,50,1,'N',CURRENT_TIMESTAMP,'rbaadmin',CURRENT_TIMESTAMP,'rbaadmin');

INSERT INTO risk_assessment (id, name, invocation_code, rerun_on_failure) VALUES ('LOCATION', 'Geo Location', 'EA', 'F');
INSERT INTO risk_assessment (id, name, invocation_code, rerun_on_failure) VALUES ('TRAVEL', 'Travel Speed', 'EA', 'F');
INSERT INTO risk_assessment (id, name, invocation_code, rerun_on_failure) VALUES ('DEVICE', 'Device Risk Assessment', 'EA', 'F');
INSERT INTO risk_assessment (id, name, invocation_code, rerun_on_failure) VALUES ('HIGHVALTRN', 'High Value Transaction', 'EA', 'F');
INSERT INTO risk_assessment (id, name, invocation_code, rerun_on_failure) VALUES ('MAXMINDIP', 'MaxMind IP Risk Assessment', 'EA', 'F');
INSERT INTO risk_assessment (id, name, invocation_code, rerun_on_failure) VALUES ('EXTERNALIP', 'External IP Risk Assessment', 'EA', 'F');


--
-- TOC entry 3116 (class 0 OID 25376)
-- Dependencies: 187
-- Data for Name: risk_assessment_config; Type: TABLE DATA; Schema: sessions; Owner: postgres
--

INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CITYLIST', 'Black listed city name list', 'Comma separated list of black listed cities.', 'INPUT_THRESHOLD', 'STRING', 'bangalore,Sandy');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CNTYNAMSG', 'Country unavailable Message', 'Outcome description for country name unavailable', 'OUTCOME_DESC', 'STRING', 'Could not determine country for  ($(ipaddress))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CNTRYLIST', 'Black listed country name list', 'Comma separated list of black listed countries.', 'INPUT_THRESHOLD', 'STRING', 'India');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CNTYRSKMSG', 'Black Listed Country Message', 'Outcome description for black listed country', 'OUTCOME_DESC', 'STRING', 'Country ($(country)) is found in black listed countries');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CNTYRSKPTS', 'Country Risk Score Points', 'Number of points to add to the required trust score for black listed country', 'OUTPUT_POINTS', 'INTEGER', '20');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CNTYVLDMSG', 'Allowed Country Message', 'Outcome description for no risk', 'OUTCOME_DESC', 'STRING', 'No risk for country ($(country))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CTYNAMSG', 'City unavailable Message', 'Outcome description for city name unavailable', 'OUTCOME_DESC', 'STRING', 'Could not determine city for  ($(ipaddress))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CTYNRSKMSG', 'Allowed City Message', 'Outcome description for no risk', 'OUTCOME_DESC', 'STRING', 'No risk for city ($(city))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CTYRISKMSG', 'Black Listed City Message', 'Outcome description for black listed City', 'OUTCOME_DESC', 'STRING', 'City ($(city)) is found in black listed cities');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'CTYRISKPTS', 'City Risk Score Points', 'Number of points to add to the required trust score for black listed city', 'OUTPUT_POINTS', 'INTEGER', '10');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'IPRANGE', 'Black listed IP address range', 'Comma separated list of black listed IP address ranges. ''*'' wild card is supported in the range.', 'INPUT_THRESHOLD', 'STRING', '107.10.103.*-107.20.103.244, 107.10.104.12-107.20.*.*, 107.10.103.*-107.20.*.*');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'IPRISKMSG', 'Black Listed IP Address Message', 'Outcome description for black listed IP address', 'OUTCOME_DESC', 'STRING', 'IP Address ($(ipaddress)) is found in black listed IP Address range');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'IPRISKPTS', 'IP Address Risk Score Points', 'Number of points to add to the required trust score for black listed IP address', 'OUTPUT_POINTS', 'INTEGER', '15');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'IPVALIDMSG', 'Allowed IP Address Message', 'Outcome description for no risk', 'OUTCOME_DESC', 'STRING', 'No risk for IP Address ($(ipaddress))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'NOIPMSG', 'No IP Address Message', 'Outcome description for no IP address available', 'OUTCOME_DESC', 'STRING', 'IP Address ($(ipaddress)) could not determined or validated');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('LOCATION', 'LOCHISTSTS', 'Location history check status flag', 'Location history check status flag', 'INPUT_THRESHOLD', 'STRING', 'ACTIVE');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('TRAVEL', 'VLCTNAMSG', 'Velocity unavailable Message', 'Outcome description for velocity unavailable', 'OUTCOME_DESC', 'STRING', 'Could not determine velocity for  ($(geolocationprev)) and ($(geolocationcurr))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('TRAVEL', 'VLCTREFVAL', 'Allowed maximum velocity', 'Velocity in Miles per hour', 'INPUT_THRESHOLD', 'INTEGER', '1000');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('TRAVEL', 'VLCTRSKMSG', 'High Velicty Risk Message', 'Outcome description for high velocity', 'OUTCOME_DESC', 'STRING', 'Velocity ($(velocity)) is high. Risk score will be topped up.');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('TRAVEL', 'VLCTRSKPTS', 'Velocity Risk Score Points', 'Number of points to add to the required trust score for high velocity case.', 'OUTPUT_POINTS', 'INTEGER', '25');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('TRAVEL', 'VLCTVLDMSG', 'Acceptable velocity Message', 'Outcome description for no risk', 'OUTCOME_DESC', 'STRING', 'No risk for velocity ($(velocity))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('DEVICE', 'DEVNAMSG', 'Device details unavailable', 'Outcome description for device details unavailable', 'OUTCOME_DESC', 'STRING', 'Could not identity device for fingerprint.');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('DEVICE', 'DEVTREFVAL', 'High risk device status', 'High risk device status', 'INPUT_THRESHOLD', 'STRING', 'NOT_REGISTERED,BLACK_LISTED,JAILBROKEN,REVOKED,UNREGISTERED, UNSAFE');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('DEVICE', 'DEVRSKMSG', 'Unknown/unsafe Device Risk Message', 'Outcome description for unknown/unsafe device', 'OUTCOME_DESC', 'STRING', 'Device bears high risk. Derived status of device is ($(deviceStatus)).');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('DEVICE', 'DEVRSKPTS', 'High risk device risk points', 'Number of points to add to the required trust score for high risk device.', 'OUTPUT_POINTS', 'INTEGER', '25');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('DEVICE', 'DEVVLDMSG', 'Safe device message', 'Outcome description for no risk', 'OUTCOME_DESC', 'STRING', 'No risk related to the device. Derived status of device is ($(deviceStatus)).');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('HIGHVALTRN',' THRESHOLD', 'The Threshold Value', 'The high transaction reference value','INPUT_THRESHOLD','INTEGER','5000');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('HIGHVALTRN', 'TRNRSKMSG', 'High Value Transaction Message', 'Outcome description for high value transaction', 'OUTCOME_DESC', 'STRING', 'Transaction value ($(transactionValue)) is above threshold $(threshold)');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('HIGHVALTRN', 'NOTRRSKMSG', 'No High Value Transaction Message', 'Outcome description for low value transaction', 'OUTCOME_DESC', 'STRING',  'Transaction value is ($(transactionValue)) is below threshold $(threshold)');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('HIGHVALTRN', 'TRNRSKPTS', 'High Value Transaction Score Points', 'Number of points to add to the required trust score for high value transaction','OUTPUT_POINTS','INTEGER','20');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','LOWRISKMSG', 'Low Risk','Outcome description for low risk IP','OUTCOME_DESC','STRING','IP address ($(ipaddress)) falls in low risk category');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','MODRISKMSG', 'Moderate Risk','Outcome description for moderate risk IP address','OUTCOME_DESC','STRING','IP address ($(ipaddress)) falls in moderate risk category');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','HIRISKMSG', 'High Risk','Outcome description for high risk IP address','OUTCOME_DESC','STRING','IP address ($(ipaddress)) falls in high risk category');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','XHIRISKMSG', 'Extremely High Risk','Outcome description for extremely high risk IP address','OUTCOME_DESC','STRING','IP address ($(ipaddress)) falls in extremely high risk category');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','IPERRORMSG', 'IP Error Message', 'Outcome description for invalid IP address','OUTCOME_DESC','STRING','IP address provided  ($(ipaddress)) is invalid or reserved');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','ERRORMSG', 'Generic Error Message', 'Outcome description for generic error message','OUTCOME_DESC','STRING','Could not determine Maxmind IP Risk score: $(errormsg)');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('MAXMINDIP','IPRISKPTS', 'IP Address Risk Score Points','Number of points to add to the required trust score for black listed IP address','OUTPUT_POINTS','INTEGER','20');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('EXTERNALIP','IPRANGE','External IP range','Comma separated list of external IP ranges. ''*'' wild card is supported in the range.','INPUT_THRESHOLD','STRING','107.10.103.*-107.20.103.244, 107.10.104.12-107.20.*.*, 107.10.103.*-107.20.*.*');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('EXTERNALIP','IPRISKMSG','Restricted External IP Message','Outcome description for external IP','OUTCOME_DESC','STRING','IP ($(ip)) is not found in allowed external IP range');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('EXTERNALIP','IPRISKPTS','IP Risk Score Points','Number of points to add to the required trust score for external IP','OUTPUT_POINTS','INTEGER','15');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('EXTERNALIP','IPVALIDMSG','Allowed IP Address Message','Outcome description for no risk','OUTCOME_DESC','STRING','No risk for IP ($(ip))');
INSERT INTO risk_assessment_config (risk_asmt_id, id, name, description, type, data_type, value) VALUES ('EXTERNALIP','NOEXTIPMSG','No IP Message','Outcome description for no IP available','OUTCOME_DESC','STRING','IP ($(ip)) could not determined or validated');
--
-- TOC entry 3118 (class 0 OID 25386)
-- Dependencies: 189
-- Data for Name: risk_factor; Type: TABLE DATA; Schema: sessions; Owner: postgres
--
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('CITY','Black Listed City','STRING','EA','RBA_INTERNAL','F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('COUNTRY','Black Listed Country','STRING','EA','RBA_INTERNAL','F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('IPADDRESS','Black listed IP Address','STRING','EA','RBA_INTERNAL','F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('VELOCITY','Travel Speed Indicator','STRING','EA','RBA_INTERNAL','F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('DEVICE','Unknown/Unsafe Device Risk','STRING','EA','RBA_INTERNAL','F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('TRANSVAL', 'Transaction Value', 'INTEGER', 'EA', 'CLIENT', 'F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('MAXMNDIPAD','MaxMind Black listed IP Address','STRING','EA','RBA_INTERNAL','F');
INSERT INTO risk_factor (id, name, data_type, invocation_code, provided_by_system,retry_collection_on_failure) VALUES ('EXTIP','External IP','STRING','EA','RBA_INTERNAL','F');

--
-- TOC entry 3117 (class 0 OID 25382)
-- Dependencies: 188
-- Data for Name: risk_assessment_factor; Type: TABLE DATA; Schema: sessions; wner: postgres
--

INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('CITY', 'LOCATION', 'F','com.persistent.rba.riskassessment.GeoLocationRiskAssessment','com.persistent.rba.riskfactor.CityRiskFactor','com.persistent.rba.riskfactor.locator.LocationRiskFactorsLocator');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('COUNTRY', 'LOCATION', 'F','com.persistent.rba.riskassessment.GeoLocationRiskAssessment','com.persistent.rba.riskfactor.CountryRiskFactor','com.persistent.rba.riskfactor.locator.LocationRiskFactorsLocator');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('IPADDRESS', 'LOCATION', 'F','com.persistent.rba.riskassessment.GeoLocationRiskAssessment','com.persistent.rba.riskfactor.IPAddressRiskFactor','com.persistent.rba.riskfactor.locator.LocationRiskFactorsLocator');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('VELOCITY', 'TRAVEL', 'F','com.persistent.rba.riskassessment.TravelSpeedRiskAssessment','com.persistent.rba.riskfactor.VelocityRiskFactor','com.persistent.rba.riskfactor.locator.VelocityRiskFactorLocator');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('DEVICE', 'DEVICE', 'F','com.persistent.rba.riskassessment.DeviceRiskAssessment','com.persistent.rba.riskfactor.DeviceRiskFactor','com.persistent.rba.riskfactor.locator.DeviceRiskFactorLocator');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname) VALUES ('TRANSVAL', 'HIGHVALTRN', 'F','com.persistent.rba.riskassessment.HighValueTransactionRiskAssessment','com.persistent.rba.riskfactor.HighValueTransactionRiskFactor');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('MAXMNDIPAD', 'MAXMINDIP', 'F','com.persistent.rba.riskassessment.MaxMindIPRiskAssessment','com.persistent.rba.riskfactor.MaxMindIPRiskFactor','com.persistent.rba.riskfactor.locator.MaxMindIPRiskFactorLocator');
INSERT INTO risk_assessment_factor (risk_factor_id, risk_asmt_id, rerun_on_factor_change,risk_asmt_classname,risk_factor_classname,risk_factor_locator_classname) VALUES ('EXTIP', 'EXTERNALIP', 'F','com.persistent.rba.riskassessment.ExternalIPRiskAssessment','com.persistent.rba.riskfactor.ExternalIPRiskFactor','com.persistent.rba.riskfactor.locator.ExternalIPRiskFactorLocator');

Insert into sessions.fact_config (factkey, name, factlocatorclass, created_on, created_by, updated_on, updated_by) values('UserEnrollmentInfo', 'UserEnrollmentFactLocator', 'com.persistent.rba.factlocators.EnrollmentDataFactLocator', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

Insert into sessions.fact_config (factkey, name, factlocatorclass, created_on, created_by, updated_on, updated_by) values('UserContactInfo', 'UserContactInfoFactLocator', 'com.persistent.rba.factlocators.UserContactInfoFactLocator', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

Insert into sessions.fact_config (factkey, name, factlocatorclass, created_on, created_by, updated_on, updated_by) values('UserFamilyInfo', 'UserFamilyInfoFactLocator', 'com.persistent.rba.factlocators.UserFamilyInfoFactLocator', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

Insert into sessions.fact_config (factkey, name, factlocatorclass, created_on, created_by, updated_on, updated_by) values('IdProof', 'IdProofingFactLocator', 'com.persistent.rba.factlocators.IdProofingFactLocator', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

Insert into sessions.fact_config (factkey, name, factlocatorclass, created_on, created_by, updated_on, updated_by) values('UserInfo', 'UserInfoFactLocator', 'com.persistent.rba.factlocators.UserInfoFactLocator', CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');

Insert into sessions.fact_config (factkey, name, factlocatorclass, created_on, created_by, updated_on, updated_by) values('None', 'None', null, CURRENT_TIMESTAMP, 'rbaadmin', CURRENT_TIMESTAMP, 'rbaadmin');


-- Completed on 2017-08-07 14:40:47

--
-- PostgreSQL database dump complete
--

