set -e
set -u
echo "Install PostgreSQL DB with repository...."

if [[ -f  $(which postgres 2>/dev/null) ]]
then
 echo "PostgreSQL $(postgres --version) is installed"
  postgres_version=$(postgres --version | awk '{print $3}'| cut -d "." -f1,2)
  if [[ $postgres_version < 9.2 ]]
  then
 	echo "Minimum requirement of PostgreSQL for Neuro 9.2."
  	exit 1
  else
  	echo "Reusing existing PostgreSQL version."
  fi
else
  echo "Started Installing PostgreSQL...."
  #sudo yum -y update 
  sudo yum install -y postgresql-server postgresql-contrib
  echo "Setup Postgresql for initialize DB."
  sudo postgresql-setup initdb 2>/dev/null
  sudo service postgresql start

  echo "By default, PostgreSQL does not allow password authentication. We will change that by editing it's host-based authentication (HBA)"
	
  echo "Set password PostgreSQL:"
  read -s  newpassword
  sudo -u postgres psql -c "ALTER USER postgres WITH PASSWORD '${newpassword}';"
  sudo sed -i.bak -e 's/ident$/md5/' -e 's/peer$/md5/' /var/lib/pgsql/data/pg_hba.conf
  sudo sed -i '81i host  all    all 0.0.0.0/0 md5'  /var/lib/pgsql/data/pg_hba.conf
  sudo sed -i "58i listen_addresses = '*'" /var/lib/pgsql/data/postgresql.conf
  echo "PostgreSQL password have created"
fi

echo "********************Restart PostgreSQL******************"
sudo sed -i "s/\btimezone\b/#timezone/g" /var/lib/pgsql/data/postgresql.conf
sudo sed -i "59i timezone = 'UTC'" /var/lib/pgsql/data/postgresql.conf
#sudo sed -i "s/Asia\/Kolkata/UTC/g" /var/lib/pgsql/data/postgresql.conf
sudo service postgresql stop
sudo service postgresql start


echo "********************RBA User*****************************"
echo "Enter postgres user password"
read -s pg_passwd
rba_user=$(PGPASSWORD=$pg_passwd psql -U postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='rba'")
if [[ $rba_user =~ "1" ]]
then
	echo "RBA User have already created. Do you want to update RBA password? [yes or no]" 
	while read  rba_ur
	do
	case $rba_ur in 
		[yY]|[Yy][Ee][Ss])
			echo "Password:"
			read -s rba_password
			rba_pass="${rba_password:-rba}"
			PGPASSWORD=$pg_passwd psql -U postgres -tAc "ALTER ROLE rba WITH PASSWORD '${rba_pass}'"
			echo "RBA password is updated."
			break ;;
		[nN] | [nN][Oo])
			echo "RBA password has not changed."
			break ;;
		*) 
			echo "Invalid Arguments. Please enter correct option.";;
	esac
	done
else
	echo "Creating RBA user.... "
	echo "Please provide password for rba_user:"
	read -s rba_user
	PGPASSWORD=$pg_passwd psql -U postgres -c "CREATE USER rba WITH PASSWORD '${rba_user}';"
	echo "RBA USer is created with password."
fi



echo "*******************SESSIONS Schema***************************"

echo "Check sessions tables "
 if [[ $(PGPASSWORD=$pg_passwd psql -U postgres -lqt|cut -d \| -f 1 |grep SESSIONS ) =~ SESSIONS ]]
 then
        echo "SESSIONS Schema is avaliable. Do you want to delete it? [yes or no]"
        while read event_opt
	do
        case $event_opt in
        [yY] | [yY][eE][sS] )

PGPASSWORD=$pg_passwd psql -U postgres << EVT
                DROP DATABASE IF EXISTS "SESSIONS";
                CREATE DATABASE "SESSIONS";
                \echo 'Connect with Sessions and upload Session Schema.......'
                \connect SESSIONS;
		\echo 'Uploading sessions schema......................'
		\i rba-session-schema-wo-data-on-postgres-SESSIONS-v2.sql;
		DROP SCHEMA public;
		\echo 'Uploading Location Risk assessment............'
		\i location-risk-assessment-insert-on-postgres-SESSIONS-v2.sql;
                \echo '...............SESSIONS schema and location Risk Assessment have been updated............'
                \q
EVT
       	break ;;
        [nN] | [nN][oO])
		echo "Sessions schema has not updated."
                break
		;;
        *)
	 echo "Invalid options. Please enter correct value."
	 ;;
        esac
	done

 else
        echo "There is no Sessions DB. Creating Sessions DB with schema."
PGPASSWORD=$pg_passwd psql -U postgres  << EVN
                CREATE DATABASE "SESSIONS";
                \echo 'Connect with SESSIONS and upload SESSIONS Schema.......'
                \connect SESSIONS;
		\i rba-session-schema-wo-data-on-postgres-SESSIONS-v2.sql;
		DROP SCHEMA public;
		\echo 'Uploading Location Risk assessment............'
		\i location-risk-assessment-insert-on-postgres-SESSIONS-v2.sql;
                \echo '...............EventsDB schemea updated............'
                \q
EVN
 fi

echo "*******************Events Schema*****************************"

 if [[ $(PGPASSWORD=$pg_passwd psql -U postgres -lqt|cut -d \| -f 1 |grep EVENTS ) =~ EVENTS ]]
 then 
	echo "Events DB & schema are avaliable. Do you want to delete it? [yes or no]"
	while read event_opt
	do
	case $event_opt in
	[yY] | [yY][eE][sS] )
PGPASSWORD=$pg_passwd psql -U postgres << EVT
		DROP DATABASE IF EXISTS "EVENTS";
		CREATE DATABASE "EVENTS";
		\echo 'Connect with Events and upload EVENTS DB.......'
		\connect EVENTS;
		\i rba-event-schema-wo-data-on-postgres-EVENTS-v2.sql;
		DROP SCHEMA public;
		\echo '...............EventsDB schema updated............'
		\q
EVT
	echo "EVENTS table successfully drop and recreated."
	break ;;
	[nN] | [nN][oO])
		echo "EVENTS schema had not updated."
	break ;;
	*) echo "Invalid options. Please enter correct value." ;; 
	esac
	done 
 else  
	echo "There is no EVENTS DB. Creating EVENTS DB with Schema."
PGPASSWORD=$pg_passwd psql -U postgres  << EVN
                CREATE DATABASE "EVENTS";
                \echo 'Connect with Events and upload EVENTS DB.......'
                \connect EVENTS;
                \i rba-event-schema-wo-data-on-postgres-EVENTS-v2.sql;
				DROP SCHEMA public;
                \echo '...............EventsDB schemea have updated............'
                \q
EVN
 fi

echo "******** RBA EVENTS and SESSIONS have completed *************"
