/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, AfterViewInit, ViewChildren } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { APIService } from '../services/APIService.service';
import { AuthService } from '../services/auth.service';
import * as myGlobals from '../common/appMessages';
import { GlobalService } from '../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastyService, ToastyConfig, ToastOptions, ToastData } from 'ng2-toasty';
import { SettingsService } from '../services/settings.service';
@Component({
  selector: 'login',
  templateUrl: `
       <div class="login-wrapper ">
      <!-- START Login Background Pic Wrapper-->
      <div class="bg-pic">
        <!-- START Background Pic-->
        <img [src]='getURL("admin/wallpaper.png")' alt="" class="lazy">
        <!-- END Background Pic-->
        <!-- START Background Caption-->
        <div class="bg-caption pull-bottom sm-pull-bottom text-white p-l-20 m-b-20">
          <h2 class="semi-bold text-white">{{logincontent}}</h2>
          <p class="small">
            © 2017 PERSISTENT SYSTEMS.
          </p>
        </div>
        <!-- END Background Caption-->
      </div>
      <!-- END Login Background Pic Wrapper-->
      <!-- START Login Right Container-->
      <div class="login-container bg-white">
       <ng2-toasty [position]="toastyComponentPosition"></ng2-toasty>
        <div class="p-l-50 m-l-20 p-r-50 m-r-20 p-t-50 m-t-30 sm-p-l-15 sm-p-r-15 sm-p-t-40">
          <img [src]='getURL("admin/assets/img/logo.png")' alt="logo" width="78" height="22">
          <p class="p-t-35">Sign in to your account</p>
          <!-- START Login Form -->
          <form id="form-login" [class.p-t-15]="!authMode" role="form" action="rba-admin.html">
            <!-- START Form Control-->
            <div class="form-group form-group-default" [hidden]="authMode">
              <label>Login</label>
              <div class="controls">
                <input type="text" #inputuser name="username" placeholder="User Name" class="form-control" [(ngModel)]="username" required>
              </div>
            </div>
            <!-- END Form Control-->
            <!-- START Form Control-->
            <div class="form-group form-group-default" [hidden]="authMode">
              <label>Password</label>
              <div class="controls">
                <input type="password" class="form-control" name="password" placeholder="Password" [(ngModel)]="password" required>
              </div>
            </div>
            <!-- START Form Control-->
            <div class="row" [hidden]="authMode">
              <div class="col-md-6 no-padding" >
                <span id="lblMessage" style="color: red;" *ngIf="message">{{errmsg}}</span>
              </div>
              <div class="col-md-6 text-right">
               
              </div>
            </div>
            <!-- END Form Control-->
            <button class="btn btn-info btn-cons m-t-10" type="submit" (click)="login();">Sign in</button>
          </form>
          <!--END Login Form-->
          <div class="pull-bottom sm-pull-bottom">
            <div class="m-b-30 p-r-80 sm-m-t-20 sm-p-r-15 sm-p-b-20 clearfix">
              <div class="col-sm-3 col-md-2 no-padding">
                
              </div>
              <div class="col-sm-9 no-padding m-t-10">
                <p>
                  <small></small>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- END Login Right Container-->
    </div>`
})
export class Login implements AfterViewInit {
  @ViewChildren('inputuser') vc: any;
  toastyComponentPosition: string = myGlobals.toastPositions[2].code;
  logincontent: string = myGlobals.LOGIN_DISPLAY_CONTENT;

  options = {
    title: myGlobals.sessionTimeoutTitle,
    msg: myGlobals.sessionTimeoutMsg,
    showClose: true,
    timeout: 5000,
    theme: myGlobals.toastThemes[2].code,
    type: myGlobals.toastTypes[4].code
  };

  ngAfterViewInit() {
    if (this.auth.authInvalid) {
      this.newToast();
    }
    this.vc.first.nativeElement.focus();
    this.service.isLoggedIn()
      .then((resp: any) => {
        var apiData = JSON.parse(resp._body);
        if (apiData && apiData.login == true) {
          console.log(apiData);
          this.router.navigate(['/admin/dashboard'])
        }
      })
      .catch(err => console.log(err))
  }

  username: string = '';
  password: string = '';
  message: boolean = false;
  errmsg: string = "Oops! Your username and password do not match. Please try again.";
  authMode = this.globalService.authMode;

  constructor(
    private sanitizer: DomSanitizer,
    private service: APIService,
    private auth: AuthService,
    private router: Router,
    private toastyService: ToastyService,
    private toastyConfig: ToastyConfig,
    private globalService: GlobalService,
    private settings: SettingsService) {     

  }

  getURL(url: string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  /* Function triggered on click of login button */
  login() {
    if (this.authMode) {
      window.location.href = '/login';
    }
    else {
      var data = {};
      data["username"] = this.username;
      data["password"] = this.password;
      this.service.login(data).then(response => {    
        var data = response._body;
        var data = JSON.parse(data);
             
        if (data.login == 1) {
          if (data.userrole) { this.globalService.userRole = data.userrole }
          this.auth.authInvalid = false;
          var url = '/admin/dashboard';
          this.message = false;
          this.router.navigate([url])
          this.settings.clearPageSize();
        }
        else {
          this.message = true;
          if(data.message){
            this.errmsg = data.message;
          }
          if(data.resolve){
            this.errmsg = this.errmsg + ' ' + data.resolve;
          }
          this.password = "";
          this.username = "";
          this.vc.first.nativeElement.focus();
        }
      }).catch(response => {
        this.message = true;
        this.password = "";
        this.username = "";
        this.vc.first.nativeElement.focus();
      })
    }
  }

  /* Function to display message on session timeout */
  newToast() {
    let toastOptions: ToastOptions = {
      title: this.options.title,
      msg: this.options.msg,
      showClose: this.options.showClose,
      timeout: this.options.timeout,
      theme: this.options.theme,
      onAdd: (toast: ToastData) => {
      },
      onRemove: function (toast: ToastData) {
      }
    };

    switch (this.options.type) {
      case 'default': this.toastyService.default(toastOptions); break;
      case 'info': this.toastyService.info(toastOptions); break;
      case 'success': this.toastyService.success(toastOptions); break;
      case 'wait': this.toastyService.wait(toastOptions); break;
      case 'error': this.toastyService.error(toastOptions); break;
      case 'warning': this.toastyService.warning(toastOptions); break;
    }
  }
}