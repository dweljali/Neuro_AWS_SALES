/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

// placeholders
export const RESEND_OTP_CONFIRMATION : string = "OTP was successfully sent to your device."
export const RESEND_OTP_ERROR : string = "There was an error while trying to resend OTP."
export const INVALID_OTP_ERROR: string = "Invalid input."