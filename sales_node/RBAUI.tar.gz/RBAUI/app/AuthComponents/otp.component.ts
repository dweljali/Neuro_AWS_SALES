import { Component, Input, AfterViewInit, ViewChildren } from '@angular/core';
import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { APIService } from './../services/APIService.service';
import { AuthService } from './../services/auth.service';
import { GlobalService } from './../services/globalFunctions.service';
import { RESEND_OTP_CONFIRMATION, RESEND_OTP_ERROR, INVALID_OTP_ERROR } from './appAuthComponentMessages';
export class OTPCustomModal extends BSModalContext {
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-content',
  template: `<style>
  .ui-select-choices {
    left: auto;
    position: fixed;
    top: auto;
    width: 88% !important;
  }

  .small-text-red {
    font-size: 14px !important;
    color: red;
    text-align: center;
  }

  .hide-text {
    display: none;
  }
</style>
<div class="modal-dialog" style="margin:15px auto !important;" [class.customfade]="isFade">
  <div class="modal-header clearfix" style="padding: 0 25px 0 !important">
    <button (click)='closebox()' aria-hidden="true" class="close" data-dismiss="modal" type="button">
    <i class="pg-close fs-14"></i>
    </button>
    <h4 class="p-b-5"><span class="semi-bold">OTP</span></h4>
  </div>

  <div class="modal-body">
    <p class="small-text-red" [class.hide-text]="hideerrormsg">{{errormessage}}</p>
    <p class="small-text">Please enter your one time password</p>
    <form role="form">
      <div class="row">
        <div class="form-group form-group-default required">
          <label>OTP</label>
          <input class="form-control" #appName (keyup.enter)="verifyOTP()"  (focus)="oninputfocus()" id="appName" 
          maxlength="10" placeholder="Enter your OTP" type="password" name="otp" [(ngModel)]="otp">
        </div>
      </div>
    </form>
  </div>

  <div class="row p-l-25">
    <div class="col-md-3">
      <button data-dismiss="modal" id="add-app" type="button" class="btn btn-primary btn-cons" 
      (click)='resendOTP()'>Resend OTP</button>
    </div>
    <div class="col-md-1">
    </div>

    <div class="col-md-8">
      <div class="p-l-100">
        <button data-dismiss="modal" id="add-app" type="button" class="btn btn-primary btn-md"
        (click)='verifyOTP()' [disabled]="(otp) ? false : true">Submit</button>
        <button data-dismiss="modal" type="button" class="btn btn-md" (click)='closebox()'>Cancel</button>
      </div>
    </div>
  </div>  
</div>`
})
export class OTPComponentModal implements CloseGuard, ModalComponent<OTPCustomModal> {
  context: OTPCustomModal;

  @ViewChildren('appName') vcappname: any;

  ngAfterViewInit() {
    this.vcappname.first.nativeElement.focus();
  }

  public isFade = false;
  public returndata: any = {};
  public pcholder: string;
  public authFact: string;
  public hideerrormsg = true;
  public errormessage: string;
  public otp: string;

  oninputfocus() {
    this.errormessage = "";
    this.hideerrormsg = true;
  }

  constructor(private apiService: APIService, public dialog: DialogRef<OTPCustomModal>,
    private globalService: GlobalService,   private authService: AuthService,) {
    this.context = dialog.context;
    dialog.setCloseGuard(this);
  }

  closebox() {
    this.isFade = true;
    this.dialog.close(this.returndata);
  }

  resendOTP() {
    this.apiService.sendOTP({}).then(data1 => {
      var data = data1._body;
      var resp = JSON.parse(data);
      this.hideerrormsg = false;
      if (resp.statusCode == 401) {
        this.closebox();
        this.authService.isLoggedIn=false;
        this.authService.authInvalid= true;
        this.globalService.redirectServerOrClient();
      }
      else if (resp.statusCode == 200 && resp.status == "CHALLENGE" && resp.auth == "OTP") {
        this.errormessage = RESEND_OTP_CONFIRMATION;
      }
      else {
        this.errormessage = RESEND_OTP_ERROR;
      }
    }).catch(error => {
      console.log(error);
    });
  }

  verifyOTP() {
    if (this.otp) {
      this.apiService.validateOTP({ 'otp': this.otp }).then(data1 => {
        var data = data1._body;
        var resp = JSON.parse(data);
        this.hideerrormsg = false;
        if (resp.statusCode == 401) {
          this.closebox();
          this.authService.isLoggedIn=false;
        this.authService.authInvalid= true;
          this.globalService.redirectServerOrClient();
        }
        else if (resp.statusCode == 200 && resp.status == "SUCCESS" && resp.auth == "OTP") {
          this.returndata = { 'status': 'SUCCESS' };
          this.closebox();
        }
        else {
          this.errormessage = INVALID_OTP_ERROR;
        }
      }).catch(error => {
        console.log(error);
      });
    }
  }

  beforeDismiss(): boolean {
    this.dialog.close(this.returndata);
    this.isFade = true;
    return false;
  }

  /* Function to validate authenticator id */
  _keyPressID(event: any) {
    var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft', 'Home', 'Delete', 'Tab'];
    const pattern = /^[a-zA-Z\d-_]+$/;
    let inputChar = String.fromCharCode(event.charCode);


    if (arrint.indexOf(event.key) != -1) {
      return;
    }
    else if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }

  }


}
