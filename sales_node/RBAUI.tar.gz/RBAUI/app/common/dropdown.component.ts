import { Component, OnInit,Input,Output,EventEmitter,ElementRef} from '@angular/core';


@Component({
  selector: 'dropdown',
  template: `
    <label>{{label}}</label>
    <select [(ngModel)]="selected" class="cs-select cs-skin-slide cs-transparent form-control" data-init-plugin="cs-select" style="height: 50px;background: white;" (change)="select($event.target.value)">
       <option>Select One</option>
     <option *ngFor="let value  of values let i = index;" [value]="value">{{value}}</option>
    </select>
  `
})
export class DropdownComponent {
  @Input()
  values: string[];
  @Input()
  label: string;
  @Input() selected:string;
  @Output() customchange=new EventEmitter();

  constructor(private elementRef:ElementRef) {
  }

  select(value:any) {
    this.customchange.emit(value);
  }
}