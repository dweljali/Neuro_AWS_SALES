/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

export const RISK_REDIRECT_PAGE_NAME: string= "Dashboard";
export const RISK_HEADER_TEXT: string= "Configure Risk Assessments";
export const RISK_TITLE_TEXT: string= "Risk Assessments";
export const RISK_BTN_ADD_TEXT: string = "Add a Risk Assessment";
export const RISK_POLICY_DETAILS_TEXT: string = "Select Risk Aggregation Method:";
export const RISK_OPT_TOTAL_TEXT: string = "Total";
export const RISK_OPT_MAX_TEXT: string = "Max";
export const RISK_OPT_AVG_TEXT: string = "Average";
export const RISK_TABLE_DISPLAY_NAME: any = {'id': 'id','name': 'name'};
export const RISK_TABLE_SORT_INFO: any = {'id': 1,'name': 1};
export const RISK_ITEMS_PER_PAGE: number = 10;
export const RISK_MAX_PAGE_SIZE: number = 5;
export const RISK_LOCALSTORAGE_KEY: string = "risk-page-size";
export const RISK_BTN_DISPLAY_DETAILS: string = "Details";

export const RISK_SEARCH_TEXT_PC: string = "Search Assessment ID, NAME";
export const RISK_CONFIG_HEADER_TEXT: string = "CONFIGURATION";
export const RISK_CONFIG_TABLE_DISPLAY_NAME: any = {'id': 'id','name': 'name', 'value': 'value', 'type': 'type'};
export const RISK_CONFIG_TABLE_SORT_INFO: any = {'id': 1,'name': 1, 'value': 1, 'type': 1};
export const RISK_CONFIG_ITEMS_PER_PAGE: number = 6;
export const RISK_CONFIG_MAX_PAGE_SIZE: number = 4;

export const RISK_FACTOR_HEADER_TEXT: string = "RISK FACTORS";
export const RISK_FACTOR_TABLE_DISPLAY_NAME: any = {'id': 'id','name': 'name', 'provided_system': 'provided system'};
export const RISK_FACTOR_TABLE_SORT_INFO: any = {'id': 1,'name': 1, 'provided_system': 1};
export const RISK_FACTOR_ITEMS_PER_PAGE: number = 4;
export const RISK_FACTOR_MAX_PAGE_SIZE: number = 4;
export const RISK_MODAL_CLOSE_TEXT: string = "Close";