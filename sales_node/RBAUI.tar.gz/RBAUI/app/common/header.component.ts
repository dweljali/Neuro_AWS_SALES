import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { APIService } from './../services/APIService.service';
import { AuthService } from './../services/auth.service';
import { GlobalService } from '../services/globalFunctions.service';
import { AlertModelData } from './alertModal.component';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { OTPComponentModal, OTPCustomModal } from '../AuthComponents/otp.component';
import { REFRESH_CACHE_SUCCESS_MSG, REFRESH_CACHE_FAILURE_MSG } from './appMessages';
import {
    CanActivate, Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';

@Component({
    selector: 'header',
    template: `<span defaultOverlayTarget></span><div class=" pull-left sm-table hidden-xs hidden-sm">
      <div class="header-inner">
        <div class="brand inline">
          <img [src]='getURL("admin/assets/img/logo.png")' alt="logo" height="22">
        </div>
      </div>
</div>

<div class="pull-right"> <div class="header-inner">  </div> </div> 
 	<div class=" pull-right">
	  <!-- START User Info-->
	  <div class="visible-lg visible-md m-t-10">
		<div class="pull-left p-r-20 fs-16 font-heading">
			<span class="semi-bold">{{loggedIndata.firstName}}</span>
			<span class="text-master">{{loggedIndata.lastName}}</span>
			<br>
			<span style="font-weight:bold!important">{{loggedIndata.userroleDisplayName}}</span>
		</div>
		<div class="dropdown pull-right logoutBtn p-t-10">
		  <a class="btn btn-primary btn-sm" (click)="logout()">
			<span class="fa fa-sign-out"></span> Logout
		  </a>
		</div>
	  </div>
	  <!-- END User Info-->
	</div>
   <div class="pull-right"><div class="header-inner">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
</div> 
<div *ngIf="neuroadmin" class="pull-right">
	<div class="visible-lg visible-md m-t-20">
		<div title="Refresh cache" class="small no-margin pull-right sm-pull-reset">
			<a (click)="refreshCache()" href="javascript:void(0)" style="color:#337ab7;">
				<i class="fa fa-refresh fa-2x" aria-hidden="true"></i>
			</a>
		</div>
	</div>
</div>`,

})
export class Header {
    neuroadmin: boolean = true;
    loggedIndata: any = {};
    callref: boolean = true;
    constructor(private sanitizer: DomSanitizer, private apiService: APIService,
        private authService: AuthService, private vcRef: ViewContainerRef, public modal: Modal,
        private globalService: GlobalService, private router: Router) {
        modal.overlay.defaultViewContainer = vcRef;
        //this.loggedIndata= this.authService.getLoggedDetails();
        this.loggedIndata.firstName = "";
        this.loggedIndata.lastName = "";
        this.loggedIndata.userroleDisplayName = "";
        this.apiService.getLoggedInUserDetails().then(response => {

            var data = response._body;
            var data = JSON.parse(data);
            if (data.firstName) { this.loggedIndata.firstName = data.firstName; }
            if (data.lastName) { this.loggedIndata.lastName = data.lastName; }
            if (data.userrole) {
                if (data.userrole != "neuroadmin") {
                    this.neuroadmin = false;
                }
                else {
                    this.neuroadmin = true;
                }
            }
            if (data.userroleDisplayName) { this.loggedIndata.userroleDisplayName = data.userroleDisplayName; }
            if (data.ActivityExportFileName) { this.globalService.ActivityExportFileName = data.ActivityExportFileName; }
            if (data.AppendTimeStamp) { this.globalService.AppendTimeStampExportFile = data.AppendTimeStamp; }

            if (data.mode) {
                this.globalService.mode = data.mode;
            }
            if (data.authMode) {
                this.globalService.authMode = data.authMode;
            }
        }).catch(error => {

        });
    }

    openModal(msg: string, headtext: string) {
        this.modal.overlay.defaultViewContainer = this.vcRef;
        const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
            {
                isBlocking: true,
                message: msg,
                headtext: headtext
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    getURL(url: string) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }

    /* Function triggered on click of logout button*/
    logout() {

        this.apiService.logout({}).then(response => {
            var resp = JSON.parse(response._body);
            this.authService.logout();
            this.router.navigate(['/login']);
        }).catch(error => {
            this.router.navigate(['/login']);
        });
    }

    /* Function triggered on click of refresh link */
    refreshCache() {
        console.log(this.callref);
        if (this.callref) {
            this.callref = false;
            this.apiService.determineAuthentication({}).then(data1 => {
                var data = data1._body;
                var resp = JSON.parse(data);
                if (resp.statusCode == 401) {
                    this.authService.isLoggedIn = false;
                    this.authService.authInvalid = true;
                    this.globalService.redirectServerOrClient();
                }
                else if (resp.statusCode == 200 && resp.status == "APPROVE") {
                    this.refreshCacheCall();
                }
                else if (resp.statusCode == 200 && resp.status == "CHALLENGE" && resp.auth == "OTP") {
                    this.modal.overlay.defaultViewContainer = this.vcRef;
                    const dialog = this.modal.open(OTPComponentModal, overlayConfigFactory(
                        {}, BSModalContext));

                    dialog.then((resultPromise) => {
                        resultPromise.result.then((result) => {
                            let objbody = document.getElementsByTagName('body')[0];
                            objbody.classList.remove("modal-open");
                            console.log(result);
                            if (result && result.status == "SUCCESS") {
                                this.refreshCacheCall();
                            }
                        });
                    });
                    this.callref = true;
                }
                else {
                    this.openModal(REFRESH_CACHE_FAILURE_MSG, "");
                    this.callref = true;
                }                
            }).catch(error => {
                console.log(error);
                this.callref = true;
            });
        }
    }

    refreshCacheCall() {
        this.callref = false;
        this.apiService.refreshCache().then(response => {
            console.log(response);
            this.openModal(REFRESH_CACHE_SUCCESS_MSG, "");
            this.callref = true;
        }).catch(error => {
            console.log(error);
            this.callref = true;
        });
    }
}