/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, Input, Output, EventEmitter, ViewChildren} from '@angular/core';
import {IMyDpOptions} from 'mydatepicker';
import * as myGlobals from './appMessages';
import { GlobalService } from '../services/globalFunctions.service';

@Component({
  selector: 'custom-datepicker',
  template: `
  <div class="customDate">
   <div class="height-20">
      <p class="error" [class.hide-text]="hideerrormsg">{{errorMsg}}</p>
    </div>
   <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
        <div class="form-group">
          <label>Start Date&nbsp;</label>
           <my-date-picker name="fromDate" [options]="fromDatePickerOptions"
        [(ngModel)]="fromDate" required></my-date-picker>
        </div>
      </div>
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
        <div class="form-group">
          <label>End Date&nbsp;&nbsp;&nbsp;&nbsp;     </label>
         <my-date-picker name="toDate" [options]="toDatePickerOptions"
                        [(ngModel)]="toDate" required></my-date-picker>
        </div>
      </div>
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
        <div class="form-group">
          <div class="panelbtns">
          <a class="btn btn-primary"  data-toggle="modal" (click)="apply()">Apply</a>&nbsp;
          <button class="btn btn-info"  (click)="clear()">Clear</button>
          </div>
        </div>
      </div>
    </div>
    </div>
  `,
})
export class DateTimePickerComponent {
  
    /* Get format of date and time to be passed and append time to the date
       start.setHours(0,0,0,0);
       end.setHours(23,59,59,999);
       create 2 input objects from date and end date and pass to the component for initial set up
    */
    @Input()
    count: number = 0;
    @Output() update= new EventEmitter<any>(); 

    today: any =  new Date();
    private fromDatePickerOptions: IMyDpOptions = {
        // other options...
        dateFormat:'dd/mm/yyyy',
        height: '34px',
        width: '210px',
        disableUntil: {year: 0, month: 0, day: 0},
        disableSince:  {year: this.today.getFullYear(), month: this.today.getMonth()+ 1, day: this.today.getDate()+1},
        editableDateField: false
    };

    
    selectDate: any = {};
    public hideerrormsg = true;
    public errorMsg= '';
    private toDatePickerOptions: IMyDpOptions = {
      dateFormat:'dd/mm/yyyy',
      height: '34px',
      width: '210px',
      disableUntil: {year: 0, month: 0, day: 0},
      disableSince:  {year: this.today.getFullYear(), month: this.today.getMonth()+ 1, day: this.today.getDate()+1},
      editableDateField: false
    };
    private fromDate: any={};
    private toDate: any= {};
   
    constructor(private globalservice: GlobalService) {
        this.selectDate= this.globalservice.calcPastDays(this.today.getFullYear(),this.today.getMonth(),this.today.getDate(), 'Month');
        this.fromDate = { date: { year: this.selectDate.getFullYear(), month: this.selectDate.getMonth()+1, day: this.selectDate.getDate() } };
        this.toDate = { date: { year: this.today.getFullYear(), month: this.today.getMonth()+1, day: this.today.getDate()}};
     }

    apply(){
        this.hideerrormsg= true;
        this.errorMsg='';
        if(!this.fromDate || !this.toDate){
          this.hideerrormsg= false;
          this.errorMsg=myGlobals.selectDateMsg;
          return false;
        }
        if(!this.compareDates(this.fromDate.date, this.toDate.date)){
          this.hideerrormsg= false;
          return false;
        }
        if(!this.checkDateRange(this.fromDate.date, this.toDate.date)){
          this.hideerrormsg= false;
          return false;
        }
       /* this.update.emit({
            fromDate: this.formatDate(this.fromDate.date,'from')+ ' 00:00:00',
            toDate: this.formatDate(this.toDate.date, 'to') + ' 23:59:59',
            locale: window.navigator.language
        });

         replace this with the above emit for timezone conversion*/
         this.update.emit({
             fromDate: this.formatDate(this.fromDate.date, 'from'),
            toDate: this.formatDate(this.toDate.date, 'to'),
            locale: window.navigator.language
         });
    }

    clear(){
      this.fromDate = null;
      this.toDate = null;
    }

    /* Formats date to MM/DD/YYYY*/
    formatDate(convertDate: any, type: string){
        let temp='', temp2='';
        let dateObj = new Date(convertDate.year, convertDate.month-1, convertDate.day+1);
        if(type=='from'){
          dateObj.setUTCHours(0,0,0,0);
        }
        else{
          dateObj.setUTCHours(23,59,59,999);
        }
       // temp=  convertDate.year + '-'+ convertDate.month + '-' + convertDate.day;
        temp2 = dateObj.toISOString()+dateObj.getTimezoneOffset();
       /* Return temp2 instead of temp1 for timezone conversion*/
        return temp2;
    }

    compareDates(fromDate: any, toDate: any){
        if(toDate.year> fromDate.year){
          return true;
        }
        else if(toDate.year == fromDate.year){
          if(toDate.month> fromDate.month){
            return true;
          }
          else if(toDate.month == fromDate.month){
            if(toDate.day> fromDate.day || toDate.day == fromDate.day){
              return true;
            }
            else{
              this.errorMsg= myGlobals.invalidDateMsg;
              return false;
            }
          }
          else{
            this.errorMsg= myGlobals.invalidDateMsg;
            return false;
          }
        }
        else{
          this.errorMsg= myGlobals.invalidDateMsg;
          return false;
        }
    }

    checkDateRange(fromdateObj: any, todateObj: any){
        let fromDateTemp= new Date(fromdateObj.month+'/'+ fromdateObj.day + '/' + fromdateObj.year);
        let toDateTemp= new Date(todateObj.month+'/'+ todateObj.day + '/' + todateObj.year);
        var numDaysBetween = function(dt1:any, dt2: any) {
          return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24));
        };
        if(numDaysBetween(fromDateTemp, toDateTemp)> 29){
            this.errorMsg=myGlobals.invalidDateRange;
            return false;
        }
        else{
          return true;
        }

    }
  }