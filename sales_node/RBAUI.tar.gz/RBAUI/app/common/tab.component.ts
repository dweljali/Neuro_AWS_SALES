import { Component, OnInit,Input,EventEmitter,Output } from '@angular/core';
import {Tabs} from './tabs.component'
@Component({
    selector:'tab',
    templateUrl: './tab.html',

})
export class Tab{
   @Input() objtitle:string;
   active=false;
   @Input() icon:string;
   @Input() name:string;
   @Output() tabclick= new EventEmitter();
    constructor(tabs: Tabs) {
      tabs.addTab(this)
    }

   
  
 
}