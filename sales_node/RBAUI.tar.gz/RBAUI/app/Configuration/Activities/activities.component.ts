import { Component, OnInit, ViewEncapsulation, ViewContainerRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from '../../common/table.component';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import { MessageService } from './../../services/MessageService';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ActivityeModel, ActivityModelData } from './activities-modal';
import { ConfirmModelData } from '../../common/confirmModal.component'
import { AlertModelData } from './../../common/alertModal.component';
import * as myGlobals from './../../common/appMessages';
import { SettingsService } from '../../services/settings.service';

@Component({
    selector: 'modal-activity',
    template: `<span defaultOverlayTarget></span>`,
    providers: [Modal]
})
export class ActivityModalComponent {
    constructor(public modal: Modal) {

    }

}

@Component({
    selector: 'activities',
    templateUrl: './Activities.html',
    providers: [Modal]
})
export class ActivitiesComponent {
    titles: string[] = [];
    data: Object[] = [];
    APIdata: any[] = [];
    activityData: Object[] = [];
    tableTitles: Object[] = [];
    authListData: Object[] = [];
    riskData: Object[] = [];
    placeholder: string = myGlobals.ACTIVITIES_SEARCH_PH;
    itemsperpage: number;
    maxpagesize: number = myGlobals.ACTIVITY_MAX_PAGE_SIZE;
    pagesizes: Object[];
    defaultitemsperpage: number = myGlobals.ACTIVITY_ITEMS_PER_PAGE;
    localstoragekey: string = myGlobals.ACTIVITY_LOCALSTORAGE_KEY;
    public cnls: any = {};
    @ViewChild(Table)
    private objtblcmp: Table;
    /*{ "INTERNET": "Internet", "ATM" :"ATM Kiosk","WEB":"Internet Banking", 
                        "RETAIL": "Retail Banking",
                        "COMMERCIAL":"Commercial Banking",
                        "MOBILE":"Mobile Banking",
                        "CHAT":"Chat",
                        "FACEBOOK":"Facebook", "MWALLET":"Mobile Wallet"
                        ,"CALLCENTER":"Call Center"};*/

    constructor(
        private messageService: MessageService,
        private apiService: APIService,
        private router: Router,
        public objmodal: Modal,
        private auth: AuthService,
        private globalService: GlobalService,
        vcRef: ViewContainerRef,
        private settings: SettingsService
    ) {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        objmodal.overlay.defaultViewContainer = vcRef;
        if (this.globalService.userRole != "neuroadmin") {
            this.redir();
        }
        else {
            this.getActivities();
            this.tableTitles = [['ID', 1], ['Description', 1], ['Channel', 1],
            ['Required Trust Score', 1], ['Risk Assessments', 0], ['Authenticators', 0]];
        }
    }

    /* Function to redirect to dashboard on click of breadcrumb */
    redir() {
        this.messageService.highlightSidebar('dashboard');
        this.messageService.sendMessage('admin/dashboard');
        this.router.navigate(['admin/dashboard']);
    }

    /* Function triggered on click of remove button in activities list */
    remove(obj: Object) {
        this.openModal(obj);
    }

    /* Confirmation modal for remove activity */
    openModal(obj: Object) {
        let displaymsg: string = "";
        if (obj["editkey"] && obj["editkey"] == 1) {
            displaymsg = myGlobals.DEACTIVATE_ACTIVITY_CONFIRM;
        }
        else {
            displaymsg = myGlobals.ACTIVATE_ACTIVITY_CONFIRM;
        }

        const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
            {
                size: 'md',
                isBlocking: false,
                message: displaymsg
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
                if (result == "1") {
                    this.deleteRow(obj);
                }
            });
        });
    }

    /* Modal displayed incase of error in deleting activity */
    openModalError(msg: string, headtext: string) {
        const dialog = this.objmodal.open(AlertModelData, overlayConfigFactory(
            {
                isBlocking: true,
                message: msg,
                headtext: headtext
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    /* Function that deletes the row from activity table */
    deleteRow(obj: Object) {
        this.activateDeactivateActivity(this.filterByID(obj), obj);
    }

    /* function triggered on activate/deactivate button */
    activateDeactivateActivity(activityData: any, obj: Object) {
        var objdata = {};
        var objAuth: any[] = [];
        var riskList: any[] = [];
        var activityStatus = 0;

        if (activityData.authenticationChallengeList) {
            for (var j = 0; j < activityData.authenticationChallengeList.length; j++) {
                if (activityData.authenticationChallengeList[j].activeStatus == 1) {
                    objAuth.push({
                        'id': activityData.authenticationChallengeList[j].id.value,
                        'desc': activityData.authenticationChallengeList[j].description,
                        'score': activityData.authenticationChallengeList[j].score,
                        'priority': activityData.authenticationChallengeList[j].priority
                    });
                }
            }

            objAuth = this.sortByKey(objAuth, 'priority');
        }


        if (activityData.riskAssessmentList) {
            for (var j = 0; j < activityData.riskAssessmentList.length; j++) {
                riskList.push(activityData.riskAssessmentList[j].riskAssessmentCD);
            }
        }

        if (activityData.activity) {
            if (activityData.activity.activeStatus == 0) {
                activityStatus = 1;
            }

            //If Authenticators exists and balance risk trust score is valid only then re-activate 
            if (activityStatus == 0) {
                objdata = {
                    'activityId': activityData.activity.activityID.value,
                    'activityName': activityData.activity.activityName,
                    'activityDesc': activityData.activity.description,
                    'currentSelectedChannel': activityData.activity.channel,
                    'activityscore': activityData.activity.requiredScore,
                    'authLevel': activityData.activity.activityAuthLevel,
                    'activeStatus': activityStatus,
                    'authList': objAuth,
                    'risk': riskList
                }

                var object = {}
                object["data"] = objdata;
                this.apiService.changeActivityStatus(object).then((response: any) => {
                    var resp = JSON.parse(response._body);
                    if (resp.statusCode == 401) {
                        this.auth.authInvalid = true;
                        this.globalService.redirectServerOrClient();
                    }
                    else if (resp.error == 0) {
                        this.getActivities();//Refresh Grid                        
                    }
                    else {
                        var objError = activityStatus == 1 ? (myGlobals.ACT_ACTIVATE_ERROR + ' ' + resp.msg) :
                            (myGlobals.ACT_DEACTIVATE_ERROR + ' ' + resp.msg);
                        this.openModalError(objError, "Error");
                    }
                }).catch(error => {
                    console.log(error);
                });
            }
            else {
                if (objAuth.length <= 0) {
                    this.globalService.actWizardAuthTab = true;
                    this.globalService.actWizardBalanceTab = false;
                    this.edit(obj, 0);
                }
                else {
                    let apiData: any = {};
                    apiData.ID = activityData.activity.activityID.value;
                    apiData.Channel = activityData.activity.channel;
                    this.apiService.validateActivityScore(apiData).then(res => {
                        var dataAPI = JSON.parse(res._body);
                        if (dataAPI.statusCode == 200) {
                            if (parseInt(dataAPI.validated) == 1) {
                                objdata = {
                                    'activityId': activityData.activity.activityID.value,
                                    'activityName': activityData.activity.activityName,
                                    'activityDesc': activityData.activity.description,
                                    'currentSelectedChannel': activityData.activity.channel,
                                    'activityscore': activityData.activity.requiredScore,
                                    'authLevel': activityData.activity.activityAuthLevel,
                                    'activeStatus': activityStatus,
                                    'authList': objAuth,
                                    'risk': riskList
                                }

                                var object = {}
                                object["data"] = objdata;
                                this.apiService.changeActivityStatus(object).then((response: any) => {
                                    var resp = JSON.parse(response._body);
                                    if (resp.statusCode == 401) {
                                        this.auth.authInvalid = true;
                                        this.globalService.redirectServerOrClient();
                                    }
                                    else if (resp.error == 0) {
                                        this.getActivities();//Refresh Grid                        
                                    }
                                    else {
                                        var objError = activityStatus == 1 ? (myGlobals.ACT_ACTIVATE_ERROR + ' ' + resp.msg) :
                                            (myGlobals.ACT_DEACTIVATE_ERROR + ' ' + resp.msg);
                                        this.openModalError(objError, "Error");
                                    }
                                }).catch(error => {
                                    console.log(error);
                                });
                            }
                            else {
                                this.globalService.actWizardAuthTab = false;
                                this.globalService.actWizardBalanceTab = true;
                                this.edit(obj, 0);
                            }
                        }
                        else if (dataAPI.statusCode == 401) {
                            this.auth.authInvalid = true;
                            this.globalService.redirectServerOrClient();
                        }
                    }).catch(error => { console.log(error) });
                }
            }
        }
    }

    /* Validate Activity state before Re-activating an Activity */
    validateActivity(activityID: string, ChannelID: string) {
        //Re-activating an Activity



    }

    /* Function to fetch activity list */
    getActivities(): void {
        this.activityData = [];
        this.authListData = [];
        this.riskData = [];
        this.riskData = [];
        this.apiService.getActivities().then((response) => {
            var objdata = JSON.parse(response._body);


            if (objdata.statusCode == 401) {
                this.auth.authInvalid = true;
                this.globalService.redirectServerOrClient();
            }
            else if (objdata.statusCode == 402) {
                this.redir();
            }
            else {
                this.APIdata = objdata.activities;
                if (objdata.channels) {
                    this.cnls = objdata.channels;
                }

                for (var i = 0; i < this.APIdata.length; i++) {
                    var authList: any[] = [];
                    var riskList: any[] = [];
                    var objAuth: any[] = [];
                    var riskOS: any[] = [];
                    var riskScore: any[] = [];
                    var riskEA: any[] = [];

                    if (this.APIdata[i].authenticationChallengeList) {
                        for (var j = 0; j < this.APIdata[i].authenticationChallengeList.length; j++) {
                            if (this.APIdata[i].authenticationChallengeList[j].activeStatus == 1) {
                                objAuth.push({
                                    'id': this.APIdata[i].authenticationChallengeList[j].id.value,
                                    'desc': this.APIdata[i].authenticationChallengeList[j].description,
                                    'score': this.APIdata[i].authenticationChallengeList[j].score,
                                    'priority': this.APIdata[i].authenticationChallengeList[j].priority
                                });
                            }
                        }

                        objAuth = this.sortByKey(objAuth, 'priority');
                        for (let i = 0; i < objAuth.length; i++) {
                            authList.push(objAuth[i]['desc']);
                        }

                        this.authListData.push({
                            'actid': this.APIdata[i].activity.activityID.value,
                            'authlist': objAuth,
                            'authLevel': this.APIdata[i].activity.activityAuthLevel,
                            'channel': this.cnls[this.APIdata[i].activity.channel]
                        });
                    }

                    if (this.APIdata[i].riskAssessmentList) {
                        for (var j = 0; j < this.APIdata[i].riskAssessmentList.length; j++) {
                            riskList.push(this.APIdata[i].riskAssessmentList[j].riskAssessmentName);
                            if (this.APIdata[i].riskAssessmentList[j].riskAssessmentInvocationCD == "OS") {
                                riskOS.push({
                                    'code': this.APIdata[i].riskAssessmentList[j].riskAssessmentCD,
                                    'name': this.APIdata[i].riskAssessmentList[j].riskAssessmentName
                                });
                            }
                            else {
                                riskEA.push({
                                    'code': this.APIdata[i].riskAssessmentList[j].riskAssessmentCD,
                                    'name': this.APIdata[i].riskAssessmentList[j].riskAssessmentName,
                                    'outputpoint': this.APIdata[i].riskAssessmentList[j].outputPoint
                                });

                            }
                            riskScore.push({
                                'code': this.APIdata[i].riskAssessmentList[j].riskAssessmentCD,
                                'outputpoint': this.APIdata[i].riskAssessmentList[j].outputPoint
                            });
                        }

                        this.riskData.push({
                            'actid': this.APIdata[i].activity.activityID.value,
                            'ea': riskEA, 'os': riskOS, 'riskScore': riskScore, 'channel': this.cnls[this.APIdata[i].activity.channel]
                        }
                        );
                    }


                    this.activityData.push({
                        'ID': this.APIdata[i].activity.activityID.value,
                        'Description': this.APIdata[i].activity.description,
                        'Channel': this.cnls[this.APIdata[i].activity.channel],
                        'Required Trust Score': this.APIdata[i].activity.requiredScore,
                        'Risk Assessments': riskList,
                        'Authenticators': authList,
                        'activekey': this.APIdata[i].activity.activeStatus == 1 ? "De-Activate" : "Activate",
                        'editkey': this.APIdata[i].activity.activeStatus,
                        'authL': this.APIdata[i].activity.activityAuthLevel,
                        'Chnl': this.APIdata[i].activity.channel
                    })
                }
                let totalItems = this.activityData.length;
                this.pagesizes = [];
                let page = myGlobals.ACTIVITY_ITEMS_PER_PAGE;
                while (page <= totalItems) {
                    this.pagesizes.push({
                        id: page.toString(),
                        text: page.toString()
                    })
                    page += myGlobals.ACTIVITY_ITEMS_PER_PAGE;
                }
                if ((page - myGlobals.ACTIVITY_ITEMS_PER_PAGE) < totalItems || this.pagesizes.length) {
                    this.pagesizes.push({
                        id: page.toString(),
                        text: page.toString()
                    });
                }
                this.itemsperpage = this.settings.getPageSize(totalItems, myGlobals.ACTIVITY_ITEMS_PER_PAGE, myGlobals.ACTIVITY_LOCALSTORAGE_KEY);
                this.objtblcmp.checkText();
            }
        }).catch(error => {
            console.log(error);
        });
    }

    sortByKey(array: any, key: string) {
        return array.sort(function (a: any, b: any) {
            var x = a[key]; var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    /* Function triggered on click of edit activity */
    edit(data: Object, index: number) {
        var object = {}
        object["data"] = data;
        object["index"] = this.APIdata[index];

        var toEdit = this.filterAuthList(data['ID'], data['Channel']);




        var inx: string = this.authListData.indexOf(toEdit).toString();
        object["authlist"] = this.authListData[inx].authlist;
        object["authlevel"] = this.authListData[inx].authLevel;


        toEdit = this.filterRiskList(data['ID'], data['Channel']);
        inx = this.riskData.indexOf(toEdit).toString();
        object["riskdataea"] = this.riskData[inx].ea;
        object["riskdataos"] = this.riskData[inx].os;
        object["riskscore"] = this.riskData[inx].riskScore;


        object["inclusionRuleId"] = 'ALL'
        object["exclusionRuleId"] = 'NA'
        if (this.APIdata[index].rules) {
            for (let rule of this.APIdata[index].rules) {
                if (rule['rule_type'] == "INC") {
                    object["inclusionRuleId"] = rule['ruleId']
                } else if (rule['rule_type'] == "EXC") {
                    object["exclusionRuleId"] = rule['ruleId']
                }
            }
        }
        this.apiService.editActivity(object).then(response => {
            var refurl = "admin/ActivityWizard/edit";
            this.router.navigate([refurl])

        }).catch(error => {
            console.log(error);
        });
    }

    /* Modal to display all authenticators and risk assessments for a row in activity list */
    showalert(data: Object, heading: string) {
        const dialog = this.objmodal.open(ActivityeModel, overlayConfigFactory(
            {
                Add: heading,
                actArr: data
            }, BSModalContext));



        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    /* Return activity object based on activity id */
    filterByID(data: Object): Object {
        var match = this.APIdata.filter(function (el) {
            return el.activity.activityID.value === data['ID'] && el.activity.channel === data['Chnl'];
        });
        return match[0];
    }

    /* Return Authenticator list object based on activity id */
    filterAuthList(data: string, cn: string): Object {
        var match = this.authListData.filter(function (el) {
            return el['actid'] === data && el['channel'] === cn;
        });
        return match[0];
    }

    /* Return risk list object based on activity id */
    filterRiskList(data: string, cn: string): Object {
        var match = this.riskData.filter(function (el) {
            return el['actid'] === data && el['channel'] === cn;
        });
        return match[0];
    }

    /* Function to navigate to wizard */
    gotoWizard() {
        this.apiService.clearWizardSession().then((response: any) => {
            var refurl = "admin/ActivityWizard/new";
            this.router.navigate([refurl])
        }).catch(error => {
            console.log(error);
        });
    }
}