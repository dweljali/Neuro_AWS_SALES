import { Component, Input, AfterViewInit, ViewChildren } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { FactLocatorService } from './../../services/factLocator.service';
import { GlobalService } from './../../services/globalFunctions.service';
import * as myGlobals from './appFactLocMsg';

export class flModalData extends BSModalContext {
	public factKey: string;
	public factName: string;
	public factClass: string;
	public factEdit: boolean;
	public Add: string;
	public factHeadermsg: string;
}

/**
 * Create fact locator modal popup
 */
@Component({
	selector: 'modal-content',
	template: `<style>
  .ui-select-choices {
    left: auto;
    position: fixed;
    top: auto;
    width: 88% !important;
  }

  .small-text-red {
    font-size: 14px !important;
    color: red;
    text-align: center;
  }

  .hide-text {
    display: none;
  }
</style>
<div class="modal-dialog" [class.customfade]="isFade">

  <div class="modal-header clearfix ">
    <button type="button" (click)='closebox()' class="close" data-dismiss="modal" aria-hidden="true">
<i class="pg-close fs-14"></i>
                  </button>
    <h4 class="p-b-5"><span class="semi-bold">{{context.Add}}</span> {{titleText}}</h4>
  </div>
  <div class="modal-body">
    <p class="small-text-red" [class.hide-text]="hideerrormsg">{{errormessage}}</p>
    <p class="small-text">{{context.factHeadermsg}}</p>
    <form role="form">
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group form-group-default required">
            <label>{{lblFactKey}}</label>
            <input maxlength="25" id="appKey" #appKey (focus)="oninputfocus()" [disabled]="context.factEdit" class="form-control" placeholder="{{pcFactKey}}"
              type="text" value="{{context.factKey}}" (keypress)="_keyPressID($event)" (paste)="false">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group form-group-default required">
            <label>{{lblFactName}}</label>
            <input maxlength="50" id="appName" #appName (focus)="oninputfocus()" class="form-control" placeholder="{{pcFactName}}" value="{{context.factName}}">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group form-group-default required">
            <label>{{lblFactClass}}</label>
            <input maxlength="250" id="appClass" #appClass (focus)="oninputfocus()" class="form-control" placeholder="{{pcFactClass}}"
              value="{{context.factClass}}">
          </div>
        </div>
      </div>
    </form>
  </div>
  <div class="modal-footer">
    <button id="add-app" data-dismiss="modal" type="button" (click)='saveFactLocators(appKey.value, appName.value, appClass.value, isEdit.value)'
      class="btn btn-primary  btn-cons">{{btnSaveText}}</button>
    <button type="button" data-dismiss="modal" (click)='closebox()' class="btn btn-cons">{{btnCloseText}}</button>
    <input type="hidden" #isEdit value="{{context.factEdit}}">
  </div>
</div>`
})
export class flModal implements CloseGuard, ModalComponent<flModalData> {
	context: flModalData;

	@ViewChildren('appKey') vcappKey: any;
	@ViewChildren('appName') vcappName: any;

	ngAfterViewInit() {
		if (this.vcappKey.first.nativeElement.value) {
			this.vcappName.first.nativeElement.focus();
		}
		else {
			this.vcappKey.first.nativeElement.focus();
		}
	}

	constructor(private apiService: FactLocatorService, public dialog: DialogRef<flModalData>,
		private globalService: GlobalService) {
		this.context = dialog.context;
		dialog.setCloseGuard(this);
	}

	public isFade = false;
	public returndata: any;
	public pcholder: string;
	public hideerrormsg = true;
	public errormessage: string;
	titleText: string = myGlobals.FACT_LOCATOR_ADD_TITLE_TEXT;
	lblFactKey: string = myGlobals.FACT_LOCATOR_LBL_FACT_KEY;
	lblFactName: string = myGlobals.FACT_LOCATOR_LBL_FACT_NAME;
	lblFactClass: string = myGlobals.FACT_LOCATOR_LBL_FACT_CLASS;

	pcFactKey: string = myGlobals.FACT_PC_KEY;
	pcFactName: string = myGlobals.FACT_PC_NAME;
	pcFactClass: string = myGlobals.FACT_PC_CLASS;

	factKeyMaxLength: number = myGlobals.FACT_KEY_MAX_LENGTH;
	factNameMaxLength: number = myGlobals.FACT_NAME_MAX_LENGTH;
	factClassMaxLength: number = myGlobals.FACT_CLASS_MAX_LENGTH;

	btnCloseText: string = myGlobals.FACT_BTN_CLOSE;
	btnSaveText: string = myGlobals.FACT_BTN_SAVE;

	oninputfocus() {
		this.errormessage = "";
		this.hideerrormsg = true;
	}



	closebox() {
		this.isFade = true;
		this.dialog.close(this.returndata);
	}

	beforeDismiss(): boolean {
		this.dialog.close(this.returndata);
		this.isFade = true;
		return false;
	}


	_keyPressID(event: any) {
		var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft', 'Home', 'Delete', 'Tab'];
		const pattern = /^[a-zA-Z\d-_]+$/;
		let inputChar = String.fromCharCode(event.charCode);

		if (arrint.indexOf(event.key) != -1) {
			return;
		}
		else if (!pattern.test(inputChar)) {
			// invalid character, prevent input
			event.preventDefault();
		}
	}

	processResponse(obj: any, objkey: string, objname: string, objclass: string, isEdit: number) {
		if (obj && obj.status && obj._body) {
			var resp = JSON.parse(obj._body);
			if (obj.status == 401 || (resp && resp.statusCode && resp.statusCode == 401)) {
				this.closebox();
				this.globalService.redirectServerOrClient();
			}
			else if (resp.error == 0) {
				this.returndata = { 'key': objkey, 'name': objname, 'class': objclass, 'type': isEdit };
				this.closebox();
			}
			else {
				this.errormessage =
					resp.msg ? resp.msg : (isEdit == 0 ? myGlobals.FACT_UPDATE_ERROR_MSG : myGlobals.FACT_ADD_ERROR_MSG)
				this.hideerrormsg = false;
			}
		}
	}

	saveFactLocators(objAppKey: string, objAppName: string, objClass: string, objEdit: string) {
		if (!objAppKey || !objAppName || !objClass) {
			this.errormessage = myGlobals.MANDATORY_FIELDS_VALIDATION;
			this.hideerrormsg = false;
			return;
		}

		if (objEdit == "true") {
			this.apiService.putFactLocators({
				factKey: objAppKey,
				factName: objAppName,
				factClass: objClass
			}).then(response => {
				this.processResponse(response, objAppKey, objAppName, objClass, 0);
			}).catch(error => {
				console.log(error);
				this.processResponse(error, objAppKey, objAppName, objClass, 0);
			});
		}
		else {
			this.apiService.postFactLocators({
				factKey: objAppKey,
				factName: objAppName,
				factClass: objClass
			}).then(response => {
				this.processResponse(response, objAppKey, objAppName, objClass, 1);
			}).catch(error => {
				console.log(error);
				this.processResponse(error, objAppKey, objAppName, objClass, 1);
			});
		}
	}
}