import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { FactLocatorService } from './../../services/factLocator.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import { MessageService } from './../../services/MessageService';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { flModalData, flModal } from './flModalPopup';
import { ConfirmModelData } from '../../common/confirmModal.component'
import { AlertModelData } from './../../common/alertModal.component';
import * as myGlobals from './appFactLocMsg';
import { factlocatorTable } from './factlocator-table.component';
import { SettingsService } from '../../services/settings.service';
import {FACT_TABLE_SEARCH_PH} from './appFactLocMsg';

/* Trigger to add new fact modal */
@Component({
	selector: 'modal-factlocator',
	template: `<span defaultOverlayTarget></span>  
  			<button (click)="openCustom()" id="show-modal" class="btn btn-primary btn-cons">
				<i class="fa fa-plus"></i>{{btnAddFactLocator}}</button>`,
	providers: [Modal]
})

export class factlocatorModalComponent {
	@Output() custevent: EventEmitter<any> = new EventEmitter<any>();
	btnAddFactLocator: string = myGlobals.FACT_LOCATOR_BTN_ADD_TEXT;
	constructor(public modal: Modal) {
	}

	openCustom() {
		const dialog = this.modal.open(flModal, overlayConfigFactory(
			{
				isBlocking: true,
				factKey: "",
				factName: "",
				factClass: "",
				factEdit: false,
				Add: myGlobals.FACT_LOCATOR_ADD_TEXT,
				factHeadermsg: myGlobals.FACT_LOCATOR_ADD_HEADER_TEXT
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				this.custevent.emit(result);
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
		});
	}
}

@Component({
	selector: 'factlocators',
	template: require('./Factlocators.html'),
	providers: [Modal]
})
export class factlocatorComponent {
	titles: Object[] = [];
	data: Object[] = [];
	objDelete: Object;

	itemsperpage: number;
	maxpagesize: number = myGlobals.FACT_LOCATOR_MAX_PAGE_SIZE;
	defaultitemsperpage: number = myGlobals.FACT_LOCATOR_ITEMS_PER_PAGE;
	localstoragekey: string = myGlobals.FACT_LOCATOR_LOCALSTORAGE_KEY;
	pagesizes: Object[];

	homePage: string = myGlobals.FACT_LOCATOR_REDIRECT_PAGE_NAME;
	headerText: string = myGlobals.FACT_LOCATOR_HEADER_TEXT;
	titleText: string = myGlobals.FACT_LOCATOR_TITLE_TEXT;
	blnHideDiv: Boolean = false;
	@ViewChild(factlocatorTable)
	private objtblcmp: factlocatorTable;
	placeholder: string = FACT_TABLE_SEARCH_PH;
	constructor(private apiService: FactLocatorService, public objmodal: Modal,
		vcRef: ViewContainerRef, private router: Router,
		private messageService: MessageService, private auth: AuthService,
		private globalService: GlobalService,
		private settings: SettingsService) {
		objmodal.overlay.defaultViewContainer = vcRef;
		if (this.globalService.userRole != "neuroadmin") {
			this.redir();
		}
		else {
			this.titles = [
				['key', myGlobals.FACT_LOCATOR_TABLE_SORT_INFO.key,
					myGlobals.FACT_LOCATOR_TABLE_DISPLAY_NAME.key],

				['name', myGlobals.FACT_LOCATOR_TABLE_SORT_INFO.name,
					myGlobals.FACT_LOCATOR_TABLE_DISPLAY_NAME.name]
			];

			this.InitiateChallenge();
		}
	}

	modifytable(objData: any) {
		if (objData) {
			if (objData.type == 1) {
				this.openModalError(myGlobals.ADD_FACT_LOCATOR_SUCCESS, "Success");
				this.InitiateChallenge();
			}
			else {
				this.openModalError(myGlobals.UPDATE_FACT_LOCATOR_SUCCESS, "Success");
				this.InitiateChallenge();
			}
		}
	}

	/* Function to redirect to dashboard on click of breadcrumb */
	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard']);
	}


	InitiateChallenge(): void {
		var factLocators: any;
		this.data = [];

		this.apiService.getFactLocators().then((response: any) => {
			if (response.status == 401) {
				this.logout();
			}
			else {
				var apiData = JSON.parse(response._body);
				if (apiData.statusCode && apiData.statusCode == 401) {
					this.logout();
				}
				else if (apiData.factLocators) {
					if (apiData.factLocators.length > 4) {
						this.blnHideDiv = true;
					}
					else {
						this.blnHideDiv = false;
					}
					for (var i = 0; i < apiData.factLocators.length; i++) {
						this.data.push({
							'key': apiData.factLocators[i].key,
							'name': apiData.factLocators[i].name,
							'class': apiData.factLocators[i].class,
							'editkey': 1,
							'activekey': "Delete"
						});
					}

					let totalItems = this.data.length;
					this.pagesizes = [];
					let page = myGlobals.FACT_LOCATOR_ITEMS_PER_PAGE;
					while (page <= totalItems) {
						this.pagesizes.push({
							id: page.toString(),
							text: page.toString()
						})
						page += myGlobals.FACT_LOCATOR_ITEMS_PER_PAGE;
					}
					if ((page - myGlobals.FACT_LOCATOR_ITEMS_PER_PAGE) < totalItems || !this.pagesizes.length) {
						this.pagesizes.push({
							id: page.toString(),
							text: page.toString()
						});
					}
					this.itemsperpage = this.settings.getPageSize(this.data.length, myGlobals.FACT_LOCATOR_ITEMS_PER_PAGE,
						myGlobals.FACT_LOCATOR_LOCALSTORAGE_KEY);
					this.objtblcmp.checkText();

				}
			}
		}).catch(error => {
			console.log(error);
			if (error.status == 401) {
				this.logout();
			}
		});
	}

	logout() {
		this.auth.authInvalid = true;
		this.globalService.redirectServerOrClient();
	}

	/* Modal displayed incase of error in deleting channel */
	openModalError(msg: string, headtext: string) {
		const dialog = this.objmodal.open(AlertModelData, overlayConfigFactory(
			{
				isBlocking: true,
				message: msg,
				headtext: headtext
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
		});
	}

	/* Return channel object based on id */
	filterByID(d: Object): Object {
		var match = this.data.filter(function (el) {
			return el['key'] === d['key'];
		});
		return match[0];
	}

	/* Function triggered on click of edit channel */
	edit(obj: Object) {
		var toEdit = this.filterByID(obj);
		var index: string = this.data.indexOf(toEdit).toString();

		const dialog = this.objmodal.open(flModal, overlayConfigFactory(
			{
				isBlocking: true,
				factKey: this.data[index].key,
				factName: this.data[index].name,
				factClass: this.data[index].class,
				factEdit: true,
				Add: myGlobals.FACT_LOCATOR_EDIT_TEXT,
				factHeadermsg: myGlobals.FACT_LOCATOR_EDIT_HEADER_TEXT
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
				if (result) {
					this.modifytable(result);
				}
			});
		});
	}

	/* Confirmation modal for remove channel */
	openModal(displaymsg: string) {
		const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
			{
				size: 'md',
				isBlocking: false,
				message: displaymsg
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");

				if (result == "1") {
					this.deleteRow();
				}
			});
		});
	}

	/* Function triggered on click of remove button in channel list */
	remove(obj: Object) {
		this.objDelete = obj;
		this.openModal(myGlobals.DELETE_FACT_LOCATOR_CONFIRM);
	}

	/* Function that deletes the row from channel table */
	deleteRow() {
		/*var toDelete = this.filterByID(this.objDelete);
		var index: string = this.data.indexOf(toDelete).toString();
		var objReqId = this.data[index].id;

		this.apiService.deleteChannel({ reqId: objReqId }).then((response: any) => {
			var resp = JSON.parse(response._body);
			if (resp.statusCode == 401) {
				this.globalService.redirectServerOrClient();
			}
			else if (resp.error == 0) {
				this.data.splice(parseInt(index), 1);
			}
			else {
				this.openModalError((resp.msg ? resp.msg : myGlobals.FACT_LOCATOR_DELETE_ERROR_MSG)
					, "Error");
			}
		}).catch(error => {
			console.log(error);
		});*/
	}
}