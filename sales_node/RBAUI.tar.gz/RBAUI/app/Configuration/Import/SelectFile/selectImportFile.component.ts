import { Component, OnInit, Output, EventEmitter, ViewContainerRef, AfterViewInit, ViewChildren, Input } from '@angular/core';
import { GlobalService } from './../../../services/globalFunctions.service';
import { AuthService } from './../../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from './../../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../../common/alertModal.component';
import * as myGlobals from './../../../common/appMessages';
import { Subject } from 'rxjs/Subject'

@Component({
	selector: 'import-select-file',
	template: require('./selectImportFile.html'),
	providers: [Modal]
})
export class selectImportFileComponent {
	private ngUnsubscribe: Subject<void> = new Subject<void>();
	@Input() objecttype: number; //1 - Activity, 2 - Risk, 3 - Authenticators
	private tabTextContent: string = myGlobals.EXPORT_TAB_CONTENT;
	filename: string = "No file selected.";
	@Output() updateriskfactorlist: EventEmitter<any> = new EventEmitter<any>();
	@Output() updaterisklist: EventEmitter<any> = new EventEmitter<any>();
	@Output() updateauthlist: EventEmitter<any> = new EventEmitter<any>();
	@Output() updateactivitylist: EventEmitter<any> = new EventEmitter<any>();
	@Output() updatechannellist:  EventEmitter<any> = new EventEmitter<any>();
	activityDetails: Object[] = [];
	ngAfterViewInit() {

	}


	ngOnDestroy() {
		this.ngUnsubscribe.next();
		this.ngUnsubscribe.complete();
	}

	/* Function to navigate to the previous tab*/
	previous() {
		this.tabs.sendMessage("importType", "");
	}

	/* Function to navigate to the next tab*/
	next() {
		if (this.validate()) {
			this.tabs.sendMessage("confirmImport", "");
		}
	}

	fileChangeListener($event: any): void {
		try {

			if ($event && $event.target && $event.target.files && $event.target.files[0]) {
				this.activityDetails = [];
				this.updateactivitylist.emit(this.activityDetails);
				this.filename = "No file selected.";

				var reader = new FileReader();
				reader.readAsText($event.target.files[0]);

				this.filename = $event.target.files[0].name;
				reader.onload = (data: any) => {

					try {
						var actJSONData = JSON.parse(data.target.result);
					}
					catch (e) {
						console.log("error");
						console.log(e);
						this.openModal();
					}
					if (actJSONData && actJSONData.ActivityList) {
						let activityList: Object[] = []; //POST ACTIVITY PAYLOAD OBJECT
						let authenticatorList: Object[] = [];  //POST AUTHENTICATOR PAYLOAD OBJECT
						let riskList: Object[] = []; //POST RISK ASSESSMENT PAYLOAD OBJECT
						let riskFactorsList: Object[] = []; //POST RISK FACTOR BY ID PAYLOAD OBJECT

						let activityID: Object[] = []; //Distinct Activity ID Object
						let authenticatorID: Object[] = []; //Distinct Authenticator ID Object
						let riskID: Object[] = []; //Distinct Risk ID Object
						let risk: Object[] = []; let auth: Object[] = [];
						let riskCongif: Object[] = [];
						let riskFactors: Object[] = [];

						//loop through all activities from the JSON file
						for (let i = 0; i < actJSONData.ActivityList.length; i++) {
							risk = []; auth = [];

							//loop risk assessments assoicated with Activities
							for (let j = 0; j < actJSONData.ActivityList[i].riskAssessmentList.length; j++) {
								//Risk assessment object to be passed in POST Activity payload
								risk.push({
									"riskAssessmentCD": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentCD,
									"description": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentName
								});

								//Check if risk assessments already exists in the POST object
								if (riskID.filter(function (el) {
									return el['id'] === actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentCD;
								}).length <= 0) {
									riskCongif = [];
									riskFactors = [];

									//Add to authenticator ID object
									riskID.push({ "id": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentCD });

									//Form risk-config object for POST Risk assessement
									if (actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations) {
										for (let k = 0;
											k < actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations.length;
											k++) {
											riskCongif.push(
												{
													"riskAssessmentConfigID": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations[k].riskAssessmentConfigID,
													"riskAssessmentConfigName": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations[k].riskAssessmentConfigName,
													"riskAssessmentConfigDesc": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations[k].riskAssessmentConfigDesc,
													"riskAssessmentConfigType": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations[k].riskAssessmentConfigType,
													"riskAssessmentConfigDatatype": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations[k].riskAssessmentConfigDatatype,
													"riskAssessmentConfigValue": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentConfigurations[k].riskAssessmentConfigValue
												});
										}
									}

									//Form risk-factor object for POST Risk factor by ID
									if (actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs) {
										for (let k = 0; k < actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs.length; k++) {
											riskFactors.push({
												"riskFactorCode":
												actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].riskFactorCode,
												"riskFactorName":
												actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].riskFactorName,
												"riskFactorDataTypeName": actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].riskFactorDataTypeName,
												"riskFactorInvocationCode": actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].riskFactorInvocationCode,
												"providedBySourceSystemName": actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].providedBySourceSystemName,
												"retryCollectionOnFailureIndicator":
												actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].retryCollectionOnFailureIndicator,
												// "rerunOnFactorChange"://actJSONData.ActivityList[i].riskAssessmentList[j].riskFactorVOs[k].rerunOnFactorChange
											});
										}
									}

									riskFactorsList.push({
										"id": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentCD,
										"riskFactors": riskFactors
									})

									//POST Authenticator payload
									riskList.push({
										"riskAssessmentCD": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentCD,
										"riskAssessmentName": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentName,
										"riskAssessmentInvocationCD": actJSONData.ActivityList[i].riskAssessmentList[j].riskAssessmentInvocationCD,
										"riskAssessmentConfigurations": riskCongif
									});
								}
							}

							//loop authenticators assoicated with Activities
							for (let j = 0; j < actJSONData.ActivityList[i].authenticationChallengeList.length; j++) {
								//Authenticators object to be passed in POST Activity payload
								auth.push({
									"id": actJSONData.ActivityList[i].authenticationChallengeList[j].id.value,
									"score": actJSONData.ActivityList[i].authenticationChallengeList[j].score,
									"priority": actJSONData.ActivityList[i].authenticationChallengeList[j].priority,
									"description": actJSONData.ActivityList[i].authenticationChallengeList[j].description
								});

								//Check if Authenticator is already exists in the POST object
								if (authenticatorID.filter(function (el) {
									return el['id'] === actJSONData.ActivityList[i].authenticationChallengeList[j].id.value;
								}).length <= 0) {
									//Add to authenticator ID object
									authenticatorID.push({ "id": actJSONData.ActivityList[i].authenticationChallengeList[j].id.value });

									//POST Authenticator payload
									authenticatorList.push({
										"id": actJSONData.ActivityList[i].authenticationChallengeList[j].id.value,
										"description": actJSONData.ActivityList[i].authenticationChallengeList[j].description,
										"factKey": actJSONData.ActivityList[i].authenticationChallengeList[j].factKey,
										"activeStatus": actJSONData.ActivityList[i].authenticationChallengeList[j].activeStatus
									});
								}
							}

							//form POST Activity Payload
							activityList.push(
								{
									"activity": {
										"activityID": actJSONData.ActivityList[i].activity.activityID.value,
										"description": actJSONData.ActivityList[i].activity.description,
										"activityAuthLevel": actJSONData.ActivityList[i].activity.activityAuthLevel,
										"requiredScore": actJSONData.ActivityList[i].activity.requiredScore,
										"channel": actJSONData.ActivityList[i].activity.channel,
										"activeStatus": actJSONData.ActivityList[i].activity.activeStatus
									},
									"riskAssessmentList": risk,
									"authenticationChallengeList": auth
								});
						}//for loop Activity ends


						this.activityDetails = activityList;
						this.updateriskfactorlist.emit(riskFactorsList);
						this.updaterisklist.emit(riskList);
						this.updateauthlist.emit(authenticatorList);
						this.updateactivitylist.emit(activityList);

					}

					if (actJSONData && actJSONData.Channels) {
						console.log(actJSONData.Channels);
						this.updatechannellist.emit(actJSONData.Channels);
					}
				}
			}
		}
		catch (e) {
			console.log("main error");
			console.log(e);
			this.openModal();
		}
		$event.target.value = null;
	}

	constructor(private route: ActivatedRoute,
		private router: Router, private tabs: TabsService, vcRef: ViewContainerRef,
		public modal: Modal, private auth: AuthService, private globalService: GlobalService) {
		modal.overlay.defaultViewContainer = vcRef;
		window.scrollTo(0, 0);
		this.loadData();

		this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
			if (message.text.toUpperCase().trim() == "SELECTIMPORT") {
				window.scrollTo(0, 0);

			}
		});

	}

	/* Function that displays modal upon validation error on activity & channel tab*/
	openModal() {
		const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
			{
				isBlocking: true,
				message: myGlobals.SELECT_IMPORT_TYPE,
				headtext: "Validation error"
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
		});
	}


	/* Validate component */
	validate() {
		if (this.activityDetails && this.activityDetails.length > 0) {
			return true;
		}
		else {
			this.openModal();
			return false;
		}
	}

	/* Function to load data incase of edit*/
	loadData() {
	}
}