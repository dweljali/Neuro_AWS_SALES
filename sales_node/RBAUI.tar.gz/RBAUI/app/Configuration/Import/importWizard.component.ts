import { Component, OnInit, ViewEncapsulation,ContentChild } from '@angular/core';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {ExportTypePartialComponent} from '../Export/ExportType/exportType.component';
import { exportTable } from './../../common/exportTable.component';
import {TabsService} from './../../services/tabsService';
import { GlobalService } from './../../services/globalFunctions.service';
import { MessageService } from './../../services/MessageService';
import { APIService } from './../../services/APIService.service';
@Component({  
        template: require('./ImportWizard.html')
})
export class ImportWizardComponent{
    public objectType:number = 1; //Default Activities
    public activityList:any;
    public authList:any;
    public riskList:any;
    public riskFactorList:any;
	public channelList:any;
     
    tableTitles:Object[]=[];
    activityData:Object[]=[];
 
     public activeItem:Object[]=[];
    constructor(private tabservice:TabsService, private globalService:GlobalService, private messageService:MessageService,
			   private router:Router,private apiService: APIService) {
		if(this.globalService.userRole != "neuroadmin"){
			this.redir();
		}
		else{
			this.validateAccess();
		}
    }

	validateAccess(){
		this.apiService.getLoggedInUserDetails().then(response=>{
			var data=response._body;
			var data=JSON.parse(data);
			if(data.userrole){
				this.globalService.userRole = data.userrole;
				if(data.userrole != "neuroadmin"){
					this.redir();
				}
			}
		}).catch(error => {
			console.log(error);
		});
	}
	
	redir(){
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}

    save(){

    }

    clear(){
    }


    changeTabs(arg:any){
      
    }

    changeobjecttype(value:number){
        this.objectType = value; 
    }
    
	updaterisklist(val:any){
        this.riskList = val;
    } 
	
	updateauthlist(val:any){
        this.authList = val;
    } 

	updateriskfactorlist(val:any){
        this.riskFactorList = val;
    } 

	updateactivitylist(val:any){
        this.activityList = val;
    } 

    updatechannellist(val:any){  
           console.log("set val");
         this.channelList = val;
               console.log(this.channelList);
    }

    tabclicked(arg:any){
       
       switch(arg){
                
       }
    }
}

