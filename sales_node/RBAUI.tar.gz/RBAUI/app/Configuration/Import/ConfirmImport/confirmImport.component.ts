import { Component, OnInit, EventEmitter,ViewContainerRef, AfterViewInit,Input, ViewChildren } from '@angular/core';
import {APIService} from './../../../services/APIService.service';
import { GlobalService } from './../../../services/globalFunctions.service';
import { AuthService } from './../../../services/auth.service';
import {FormsModule} from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from './../../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../../common/alertModal.component';
import * as myGlobals from './../../../common/appMessages';
import { Subject } from 'rxjs/Subject'
import { exportTable } from './../../../common/exportTable.component';
import { ActivityeModel, ActivityModelData  } from './../../../Configuration/Activities/activities-modal';
@Component({
    selector: 'confirm-import-wizard',
    template: `<span defaultOverlayTarget></span>

<div class="tab-pane slide-left padding-20" id="tab4">
    <div class="row row-same-height">
        <div class="col-md-5 b-grey ">
          <div class="m-t-1">
            <h2>Confirmation</h2>             
          </div>
        </div>
        <div class="p-r-30" style="float:right"> <h5>IMPORT ACTIVITIES</h5> </div>
        <br/>
        <div class="col-md-12">             
            <div>
				<custom-export-table [headings]="tableTitles" [data]="activityData" 
							[maxpagesize]="maxpagesize" [itemsperpage]="itemsperpage"
							[showalert]="showalert.bind(this)" >
				</custom-export-table>
            </div>                      
        </div>
    </div>
</div>
<div class="padding-20 bg-white">
    <ul class="pager wizard">
        <li class="next finish">
          <button (click)="import()" class="btn btn-primary btn-cons from-left pull-right" type="button">
                <span><a style="text-decoration:none;color:white;">
                    <i class="fa fa-upload"></i> Import</a>
                </span>
          </button>
        </li>

        <li class="previous">
          <button (click)="previous()" class="btn btn-default btn-cons from-left  pull-right" type="button">
            <span>Previous</span>
          </button>
        </li>
    </ul>
</div>
<div class="emptyDiv" style="height: 35vh;"></div>`,
    providers: [APIService,Modal]
})
export class ConfirmImportComponent{
    private ngUnsubscribe: Subject<void> = new Subject<void>();
    @Input() objecttype:number; //1 - Activity, 2 - Risk, 3 - Authenticators
 

    private tabTextContent:string = myGlobals.EXPORT_CONFIRM_TAB_CONTENT;
    private activeObjects:string[]=[];
    private hideObjects = false;
    private exportType:string = "";
    tableTitles:Object[]=[];
    activityData:Object[]=[];
    maxpagesize:number;
    itemsperpage:number;

    @Input() activitylist:any;
    @Input() authlist:any;
    @Input() risklist:any;
    @Input() riskfactorlist:any;
    @Input() channellist:any;

	/*public cnls: any = { "INTERNET": "Internet", "ATM" :"ATM Kiosk","WEB":"Internet Banking", 
					"RETAIL": "Retail Banking",
					"COMMERCIAL":"Commercial Banking",
					"MOBILE":"Mobile Banking",
					"CHAT":"Chat",
					"FACEBOOK":"Facebook", "MWALLET":"Mobile Wallet"
					,"CALLCENTER":"Call Center"};*/

    ngAfterViewInit() { 

    }

    ngOnDestroy(){
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    /*  Constructor */
    constructor(private service:APIService,  private route: ActivatedRoute,
                private router: Router,private tabs:TabsService,vcRef: ViewContainerRef, 
                public modal: Modal, private auth: AuthService,private globalService: GlobalService) {
        
        modal.overlay.defaultViewContainer = vcRef;
        window.scrollTo(0, 0);
        this.maxpagesize =  myGlobals.EXPORT_CONFIRM_MAX_PAGE_SIZE;
        this.itemsperpage = myGlobals.EXPORT_CONFIRM_ITEMS_PER_PAGE;
        
        this.tableTitles=[['id',0], ['Description',0],
						  ['Channel',0],['Required Trust Score',0],
						  ['Risk Assessments',0],['Authenticators',0]];
        this.loadData();
     
        this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
            this.loadData();
            if(message.text.toUpperCase().trim() == "CONFIRMIMPORT"){
                window.scrollTo(0, 0);
            }        
        });
    }

    /* Function that displays modal upon validation error on activity & channel tab*/
    openModal(){
        const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
        {
          isBlocking: true,
          message: myGlobals.SELECT_IMPORT_TYPE,
          headtext: "Validation error"
        }, BSModalContext));

        dialog.then((resultPromise) => {
          resultPromise.result.then((result) => {                    
            let objbody = document.getElementsByTagName('body')[0];
            objbody.classList.remove("modal-open");        
          });
        });
    }

    validate(){
        if(this.activitylist.length > 0){
            
        }
        return true;
    }

    /* Function to navigate to the previous tab*/
    previous(){
        this.tabs.sendMessage("selectImport","");
    }

    /* Download function */
    import(){
 
        if(this.activitylist && this.activitylist.length > 0){
            this.service.importActivities({
			  "activities":{
				  "risk":this.risklist,
				  "riskFactorsVO":this.riskfactorlist,
				  "authenticators":this.authlist,
				  "activity":this.activitylist,
                  "channels":this.channellist
			  }
			}).then(response=>{   
				var resp = JSON.parse(response._body);
			 
				if(resp.statusCode == 401){              
				  this.globalService.redirectServerOrClient();
				}
				else if(resp.error == 0){
				 
					this.openModalError("Import process completed successfully.", "");
				}
				else{
					this.openModalError(resp.errmsg, "Error");
				}
			  }).catch(error => {
				console.log(error);
			});
        }
        else{
            this.openModal();
            this.tabs.sendMessage("selectImport", "");
        }
    }
    
    

    exportRiskAssessments(){
    }

    exportAuthenticators(){
    }

    /* Function to load data incase of edit*/
    loadData() {
       
              this.loadActivities();
                 
    }

     
    loadActivities(){
        this.activityData.splice(0,this.activityData.length);
 
		let authList:any;
		let riskList:any;
        if(this.activitylist && this.activitylist.length > 0){
			for(var k=0; k<this.activitylist.length; k++){
				authList =[];
				riskList = [];
				if(this.activitylist[k].authenticationChallengeList){
					for (var j=0; j < this.activitylist[k].authenticationChallengeList.length ; j++) {
						authList.push(this.activitylist[k].authenticationChallengeList[j].description);
					}
				}

				if(this.activitylist[k].riskAssessmentList){
					for (var j=0; j < this.activitylist[k].riskAssessmentList.length ; j++) {
						riskList.push(this.activitylist[k].riskAssessmentList[j].description);
					} 
				}
                var cnl = "";             
                if(this.channellist){
                for(let i=0; i<this.channellist.length;i++){
                    if(this.channellist[i]['id'] == this.activitylist[k].activity.channel){
                        cnl = this.channellist[i]['text'] 
                        break;
                    }
                }
                }
         
				this.activityData.push({
					'id': this.activitylist[k].activity.activityID,
					'Description': this.activitylist[k].activity.description,
					'Channel': cnl ? cnl : "",
					'Required Trust Score': this.activitylist[k].activity.requiredScore,
					'Risk Assessments': riskList,
					'Authenticators': authList  
				});
			}              
        }
    }



 /* Modal displayed incase of error in deleting authenticator */ 
  openModalError(msg:string, headtext: string){ 
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
      {
      isBlocking: true,
      message: msg,
      headtext: headtext
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {                    
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
      });
    });
  }

    /* Modal to display all authenticators and risk assessments for a row in activity list */ 
    showalert(data: Object, heading: string){
 
        const dialog = this.modal.open(ActivityeModel, overlayConfigFactory(
            {
            Add:heading,
            actArr:data
            }, BSModalContext));



        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }
}