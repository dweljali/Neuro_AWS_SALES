/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { riskDetailsComponent } from './RiskDetails/riskDetails.component';
import { riskConfigurationComponent } from './RiskConfigurations/riskConfigurations.component';
import { riskFactorsComponent } from './RiskFactors/riskFactors.component';
import { riskConfirmComponent } from './Confirm/riskConfirm.component';
import { TabsService } from '../../../services/tabsService';
import { GlobalService } from '../../../services/globalFunctions.service';
import { MessageService } from '../../../services/MessageService';
import { APIService } from '../../../services/APIService.service';
import { AuthService } from '../../../services/auth.service';

@Component({
	template: require('./riskWizard.html')
})
export class riskWizardComponent {
	/* Risk Details tab */
	public riskcode: string;
	public riskname: string;
	public invocationcode: string = "";
	public invocationcodename: string = "";

	/* Risk Configuration tab */
	public riskconfiguration: any = [];
	public riskconfigurationEdit: any = [];

	/* Risk factors tab */
	public riskfactors: any = [];
	public riskfactorsEdit: any = [];
	private editID: string;
	public isedit: boolean;
	constructor(private tabservice: TabsService, private globalService: GlobalService, private messageService: MessageService,
		private router: Router,
		private route: ActivatedRoute,
		private apiService: APIService,
		private auth: AuthService
	) {
		this.checkLoggedIn();
		if (this.globalService.userRole != "neuroadmin") {
			this.redir();
		}
		else {
			this.validateAccess();
		}
	}
	ngOnInit() {
		this.route.params.subscribe(params => {
			this.editID = params['id'];
			if (this.editID != 'new') {
				this.isedit = true;
				this.apiService.getRiskAssesmentById(this.editID).then(
					response => {
						var objdata = JSON.parse(response._body);


						if (objdata.statusCode == 401) {
							this.auth.authInvalid = true;
							this.globalService.redirectServerOrClient();
						}
						else if (objdata.statusCode == 402) {
							this.redir();
						}
						else {
							this.riskcode = objdata.riskAssessmentCD;
							this.riskname = objdata.riskAssessmentName;
							this.invocationcode = objdata.riskAssessmentInvocationCD;
							this.invocationcodename = objdata.riskAssessmentInvocationDesc;
							this.riskconfigurationEdit = objdata.riskconfig;
							this.riskfactorsEdit = objdata.riskFactors;
						}

					});
			}
		});
	}
	validateAccess() {
		this.apiService.getLoggedInUserDetails().then(response => {
			var data = response._body;
			var data = JSON.parse(data);
			if (data.userrole) {
				this.globalService.userRole = data.userrole;
				if (data.userrole != "neuroadmin") {
					this.redir();
				}
			}
		}).catch(error => {
			console.log(error);
		});
	}

	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}
	/* Risk details tab function(s) */
	updateriskcode(value: string) {
		this.riskcode = value;
	}

	updateriskname(value: string) {
		this.riskname = value;
	}

	updateinvocationcode(value: string) {
		this.invocationcode = value;
	}

	updateinvocationcodename(value: string) {
		this.invocationcodename = value;
	}

	/* Risk configuration tab function(s) */
	updateriskconfiguration(value: any) {
		this.riskconfiguration = value;
	}

	/* Risk factors tab function(s) */
	updateriskfactors(value: any) {
		this.riskfactors = value;
	}

	save() {

	}

	clear() {
	}

	changeTabs(arg: any) {
	}
	checkLoggedIn() {
		this.apiService.isLoggedIn().then((response: any) => {
			var apiData = JSON.parse(response._body);
			if (apiData && !apiData.login) {
				this.auth.authInvalid = true;
				this.globalService.redirectServerOrClient();
			}
		});
	}
	tabclicked(arg: any) {
		this.checkLoggedIn();
	}
}

