/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

// placeholders
export const RISK_FACTOR_ID_PC : string = "Alphanumeric only, max length 10";
export const RISK_FACTOR_NAME_PC : string = "Enter risk factor name, max length 50";
export const RISK_CLASS_NAME_PC = "Enter risk assessment class, max length 100";
export const RISK_FACTOR_CLASS_NAME_PC = "Enter risk factor class, max length 100";
export const RISK_FACTOR_LOCATOR_CLASS_NAME_PC = "Enter risk factor locator class, max length 100";
export const RISK_FACTOR_INVALID_ID_MSG = "Please enter valid risk factor id";
export const RISK_FACTOR_ID_EXISTS_MSG : string = "Risk factor id already exists. Please enter some other id.";