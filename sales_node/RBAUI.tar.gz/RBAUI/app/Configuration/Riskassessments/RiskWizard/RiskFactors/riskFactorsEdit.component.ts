/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input } from '@angular/core';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from '../../../../services/tabsService';
import { AuthService } from '../../../../services/auth.service';
import { Subject } from 'rxjs/Subject';
import * as myGlobals from './../../../../common/appMessages';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { riskFactorModal, riskFactorModalData } from './addRiskFactorModal';
import { ConfirmModelData } from './../../../../common/confirmModal.component'
import { AlertModelData } from './../../../../common/alertModal.component';
import { SimpleChange } from '@angular/core';
@Component({
    selector: 'edit-risk-factor',
    template: `<span defaultOverlayTarget></span>`,
    providers: [Modal]
})

export class riskFactorEditModalComponent {
    @Output() custevent: EventEmitter<any> = new EventEmitter<any>();
    public datatypeobj: Object[] = [];
    public providedsystems: Object[] = [];
    @Input() iddata: Object[] = [];
    constructor(public modal: Modal) {
        this.datatypeobj.push({ 'id': "STRING", 'text': "STRING" });
        this.datatypeobj.push({ 'id': "INTEGER", 'text': "INTEGER" });

        this.providedsystems.push({ 'id': 'CLIENT', 'text': 'CLIENT' });
        this.providedsystems.push({ 'id': 'RBA_INTERNAL', 'text': 'RBA_INTERNAL' });
        this.providedsystems.push({ 'id': 'EXTERNAL', 'text': 'EXTERNAL' });
    }
    openCustom(data: any) {

        const dialog = this.modal.open(riskFactorModal, overlayConfigFactory(
            {
                isBlocking: true,
                factorID: data['id'],
                factorName: data['Name'],
                riskClass: data['risk_asmt_classname'],
                factorClass: data['risk_factor_classname'],
                factorLocator: data['risk_factor_locator_classname'],
                factorEdit: true,
                Add: "Edit",
                activedatatype: [{ 'text': data['datatype'] }],
                selecteddatatype: data['datatype'],
                datatype: this.datatypeobj,
                providedsystems: this.providedsystems,
                selectedps: [{ 'text': data['Provided System'] }],
                ediddata: data,
                authHeadermsg: "Edit a new risk factor using this form"
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                this.custevent.emit(result);
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }
}
