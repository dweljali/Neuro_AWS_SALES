/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input } from '@angular/core';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from '../../../../services/tabsService';
import {AuthService} from '../../../../services/auth.service';
import { Subject } from 'rxjs/Subject';
import * as myGlobals from './../../../../common/appMessages';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { riskConfigurationModal, riskConfigurationModalData  } from './addRiskConfigurationModal';
import {ConfirmModelData} from './../../../../common/confirmModal.component'
import { AlertModelData } from './../../../../common/alertModal.component';
import { SimpleChange, ViewChild } from '@angular/core';
import {riskConfigEditModalComponent } from './riskConfigurationsEdit.component';
@Component({
  selector: 'add-risk-configuration',
  template: `<span defaultOverlayTarget></span>  
  <button (click)="openCustom()" id="show-modal" class="btn btn-primary btn-cons"><i class="fa fa-plus"></i> Add Risk Configuration</button>
`,
  providers: [Modal]
})

export class riskConfigModalComponent {
    @Output() custevent:EventEmitter<any> = new EventEmitter<any>();
	 public datatypeobj:Object[]=[];
     public configtypedata:Object[]=[];
	 @Input() iddata:Object[]=[];
    constructor( public modal: Modal) {
			   this.datatypeobj.push({'id':"STRING",'text':"STRING"});
		this.datatypeobj.push({'id':"INTEGER",'text':"INTEGER"});
		
		this.configtypedata.push({'id':"INPUT_THRESHOLD",'text':"Input threshold or value"});
		this.configtypedata.push({'id':"OUTPUT_POINTS",'text':"Output in points"});
		this.configtypedata.push({'id':"OUTCOME_DESC",'text':"Outcome description"});
    }
    openCustom() {
      
    const dialog = this.modal.open(riskConfigurationModal, overlayConfigFactory(
        {
            isBlocking: true,
            authID: "", 
            authDescription: "",
            authEdit:false,
            Add:"Add", 
          /*  activedatatype:[{'text': "STRING"}],*/               
      selecteddatatype:"STRING",
			datatype:this.datatypeobj,	
			 configtypedata:this.configtypedata,
			iddata:this.iddata,
            authHeadermsg:"Create a new risk configuration using this form"
        }, BSModalContext));
         
        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                this.custevent.emit(result);
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });   
    }
}


@Component({
    selector: 'risk-configurations-tab',
    template: require('./RiskConfigurations.html'),
    providers: [APIService,Modal]
})
export class riskConfigurationComponent{
  public riskconfiguration:any = [];
  @Output() updateriskconfiguration:EventEmitter<any> = new EventEmitter<any>();
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  public riskconfigdata:any=[];
  @Input() riskconfigdatafromparent: any = [];
  public titles:Object[]=[];
  public iddata:Object[]=[];
  private configtypedata = [
  {'id':"INPUT_THRESHOLD",'text':"Input threshold or value"},
  {'id':"OUTPUT_POINTS",'text':"Output in points"},
  {'id':"OUTCOME_DESC",'text':"Outcome description"}
];

  @ViewChild('child')
  private editComponent: riskConfigEditModalComponent;
  ngOnDestroy(){
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(private service:APIService,  private route: ActivatedRoute,
              private tabs:TabsService, private auth: AuthService, private globalService:GlobalService,
			 private objmodal: Modal) {
    this.loadData();
	  this.titles=[['id',1],['Name',1]];
    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {             
      if(message.text=="riskconfigriskwizard"){
        	window.scrollTo(0, 0);
      }            
    })
  }
ngOnInit(){
 // this.loadData();
}
ngOnChanges(changes: SimpleChange){
  if(changes['riskconfigdatafromparent']){
    //console.log("Child comp getting changed RiskConfig, ", this.riskconfigdatafromparent);
    //this.riskfactordata = this.riskfactdatafromparent;
     for(let value of this.riskconfigdatafromparent){
     // console.log(`value is `, value);
       this.pushData(value);
     }
     //console.log("Iddata is", this.iddata);
     this.updateriskconfiguration.emit(this.riskconfigdata);
  }
}
pushData(value: any){
  let type: string;

  for(let configType of this.configtypedata){
      if(configType['text'] == value.type){
        type = configType['id'];
      }
  }
  if(value){
    this.riskconfigdata.push({
      'id':value.id.trim(),
      'Name':value.name,
      'Value': value.value,
      'Type': type,
      'Desc':value.description,
      'datatype':value.dataType 
    });
    this.iddata.push(value.id.trim());
  }
}
 modifytable(value:any){
	 if(value){
		 this.riskconfigdata.push({
			 'id':value.id,
			 'Name':value.name,
			 'Value': value.value,
			 'Type':value.configtype,
			 'Desc':value.desc,
       'datatype':value.dataType || value.datatype,
       'allowDelete': value.allowDelete
		 });
		 this.iddata.push(value.id);
	 }
	 this.updateriskconfiguration.emit(this.riskconfigdata);
 }
 editrisk(data: any){
   if(data){
    var index = this.riskconfigdata.map(function(item:any) {
      return item.id;
      }).indexOf(data.id);
      this.riskconfigdata[index].Name = data.name;
      this.riskconfigdata[index].Value = data.value;
      this.riskconfigdata[index].Type = data.configtype;
      this.riskconfigdata[index].Desc = data.desc;
      this.riskconfigdata[index].datatype = data.datatype;
   }
   
 }
  /* Function to load data incase of edit */
  loadData(){
    this.riskconfigdata = this.riskconfigdatafromparent;
  }

   edit(data:any){
     this.editComponent.openCustom(data);
   }

	/* Confirmation modal for remove channel */ 
	openModal(displaymsg:string){
		
	}

   remove(data:any){
	   const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
		{
			size: 'md',
			isBlocking: false,
			message: "Are you sure you want to delete this risk configuration?"
		}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {                   
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");

				if(result=="1"){					
					var index = this.riskconfigdata.map(function(item:any) {
					return item.id;
					}).indexOf(data);

					this.riskconfigdata.splice(index, 1);
					// get index of data in iddata
					index = this.iddata.indexOf(data);  
					this.iddata.splice(index, 1); // remove it

					this.updateriskconfiguration.emit(this.riskconfigdata);
				}
			});
		});
   }

   checkLoggedIn(){
    this.service.isLoggedIn().then((response: any) => {
      var apiData = JSON.parse(response._body);
      if (apiData && !apiData.login) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
    });
  }
  /* Function triggered on click of save button*/
  save(){ 
    this.checkLoggedIn();           
   this.tabs.sendMessage("riskfactorriskwizard","");
  }

  /* Function to navigate to the previous tab*/
  previous(){
    this.checkLoggedIn();  
    this.tabs.sendMessage("detailsriskswizard","");
  }

}