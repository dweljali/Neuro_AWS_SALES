/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef, AfterViewInit, ViewChildren, SimpleChange } from '@angular/core';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { AuthService } from '../../../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from '../../../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../../../common/alertModal.component';
import * as myGlobals from './../../../../common/appMessages';
import { Subject } from 'rxjs/Subject'
import { RISK_ASSESSMENT_ID_PC, RISK_ASSESSMENT_NAME_PC } from './../../riskassessmentsMessages';
import { riskassessmentsComponent } from '../../riskassessments.component';
@Component({
	selector: 'risk-details-tab',
	template: require('./RiskDetails.html'),
	providers: [APIService, Modal]
})
export class riskDetailsComponent {
	private ngUnsubscribe: Subject<void> = new Subject<void>();
	private tabContent: string = myGlobals.RISKWIZARD_DETAILS_DISPLAY_CONTENT;
	public riskId: string = '';
	public riskDesc: string = '';

	@Input() riskassessmentscode: string;
	@Input() riskassessmentsname: string;
	@Input() riskassessmentsactcode: string;
	public riskassessmentsactcodeSel: any[];
	@Input() riskassessmentsactname: string;

	@Output() updateriskcode: EventEmitter<string> = new EventEmitter<string>();
	@Output() updateriskname: EventEmitter<string> = new EventEmitter<string>();
	@Output() updateinvocationcode: EventEmitter<string> = new EventEmitter<string>();
	@Output() updateinvocationcodename: EventEmitter<string> = new EventEmitter<string>();

	public riskAssessmentIdPc = RISK_ASSESSMENT_ID_PC;
	public riskAssesmentNamePc = RISK_ASSESSMENT_NAME_PC;
	public pcholder: string;
	public disableriskid: boolean;
	public selectedinvcode: string = "";
	public selectedinvcodename: string = "";
	public invocationcodes: Object[] = [{ 'id': "EA", 'text': "Every Activity Start" }, { 'id': "OS", 'text': "Once Per Session" }];


	@ViewChildren('inputriskid') vcRiskID: any;
	@ViewChildren('inputactcode') vcinvcode: any;
	@ViewChildren('inputriskdesc') vcriskDesc: any;
	@ViewChildren('dvriskid') vcdvriskIDc: any;
	@ViewChildren('dvriskdesc') vcdvriskDesc: any;

	ngAfterViewInit() {
		this.vcRiskID.first.nativeElement.focus();
	}

	ngOnDestroy() {
		this.ngUnsubscribe.next();
		this.ngUnsubscribe.complete();
	}
	ngOnChanges(changes: SimpleChange) {
		if (changes['riskassessmentscode'] || changes['riskassessmentsname'] || changes['riskassessmentsactcode'] || changes['riskassessmentsactname']) {
			for (let code of this.invocationcodes) {
				if (code['id'] == this.riskassessmentsactcode) {
					this.riskassessmentsactcodeSel = [{ 'text': code['text'] }];
					break;
				}
			}
			if (this.riskassessmentscode) {
				this.riskId = this.riskassessmentscode;
				this.riskDesc = this.riskassessmentsname;
				this.selectedinvcode = this.riskassessmentsactcode;
				this.selectedinvcodename = this.riskassessmentsactname
				this.updateRiskWizard("");
			}
		}


		//	this.riskassessmentsactcodeSel = [ this.riskassessmentsactcode]
	}
	/* Function to highlight fields that are blank upon validation*/
	loadDefault() {
		if (!this.riskId) {
			this.vcRiskID.first.nativeElement.focus();
		}
		else if (!this.riskDesc.trim()) {
			this.vcriskDesc.first.nativeElement.focus();
		}
		else if (!this.selectedinvcode) {
			this.vcinvcode.first.nativeElement.classList.add('focused');
		}
	}

	/* Function to highlight fields that are blank upon validation when control comes from other tabs*/
	highlightControl() {
		if (!this.riskId) {
			this.vcdvriskIDc.first.nativeElement.classList.add('focused');
		}
		else if (!this.riskDesc.trim()) {
			this.vcdvriskDesc.first.nativeElement.classList.add('focused');
		}
		else if (!this.selectedinvcode) {
			this.vcinvcode.first.nativeElement.classList.add('focused');
		}
		else {
			this.vcdvriskIDc.first.nativeElement.classList.add('focused');
		}
	}

	constructor(private service: APIService, private route: ActivatedRoute,
		private router: Router, private tabs: TabsService, vcRef: ViewContainerRef,
		public modal: Modal, private auth: AuthService, private globalService: GlobalService) {
		modal.overlay.defaultViewContainer = vcRef;
		window.scrollTo(0, 0);
		this.loadData();

		this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
			if (message.text == "updateRiskWizard") {
				this.updateRiskWizard(message.next);
			}
			else if (message.text == "detailsriskswizard") {
				window.scrollTo(0, 0);
				this.highlightControl();
			}
		});
	}


	updateRiskWizard(msg: string) {
		this.updateriskcode.emit(this.riskId);
		this.updateriskname.emit(this.riskDesc);
		this.updateinvocationcode.emit(this.selectedinvcode);
		this.updateinvocationcodename.emit(this.selectedinvcodename);
		if (msg) {
			this.tabs.sendMessage(msg, "");
		}
	}
	/* Function to load data incase of edit*/
	loadData() {
		this.pcholder = "Select One";
		if (this.router.url.indexOf('/RiskAssessmentWizard/new') > -1) {
			this.disableriskid = false;
		}
		else {
			this.disableriskid = true;
		}
	}


	/* Handler to highlight select boxes on focus*/
	onFocus(event: any, arg: number) {

		let objbody2 = document.getElementById('inputactcode');



	}

	/* Function triggered onclick of save button in activity & channel tab*/
	save() {
		this.service.isLoggedIn().then((response: any) => {
			var apiData = JSON.parse(response._body);
			if (apiData && !apiData.login) {
				this.auth.authInvalid = true;
				this.globalService.redirectServerOrClient();
			} else {
				if (this.validate()) {
					this.updateRiskWizard("riskconfigriskwizard");
				}
				else {
					this.openModal();
				}
			}
		});
	}

	/* Function to validate all fields in activity and channel tab*/
	validate() {
		if (!this.riskDesc.trim() || !this.riskId || !this.selectedinvcode) {
			return false;
		}
		return true;
	}

	/* Function that displays modal upon validation error on activity & channel tab*/
	openModal() {
		const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
			{
				isBlocking: true,
				message: myGlobals.MANDATORY_FIELDS_VALIDATE,
				headtext: "Validation error"
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
				this.loadDefault();
			});
		});
	}



	selectedvaluecode(arg: any) {
		this.selectedinvcode = arg.id;
		this.selectedinvcodename = arg.text;
	}

	/* Function that validates trust score on keypress*/
	_keyPress(event: any) {

		var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft', 'Home', 'Delete', 'Tab'];
		const pattern = /[0-9]/;
		let inputChar = String.fromCharCode(event.charCode);

		if (arrint.indexOf(event.key) != -1) {
			return;
		}
		else if (!pattern.test(inputChar)) {
			// invalid character, prevent input
			event.preventDefault();
		}
	}

	/* Function that validates activity ID on keypress*/
	_keyPressID(event: any) {
		var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft', 'Home', 'Delete', 'Tab'];
		const pattern = /^[a-zA-Z\d-_]+$/;
		let inputChar = String.fromCharCode(event.charCode);


		if (arrint.indexOf(event.key) != -1) {
			return;
		}
		else if (!pattern.test(inputChar)) {
			// invalid character, prevent input
			event.preventDefault();
		}
	}
}