/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component,Input } from '@angular/core';
import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import * as myGlobals from './../../common/appRiskAssessmentConfiguration';

/* Component to display all authenticators and risk assessments for a row in activity table. */ 
export class RiskModelData extends BSModalContext {
	titles:Object[]=[];
	data:Object[]=[];
	titlesFactor:Object[]=[];
	dataFactor:Object[]=[];
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'risk-modal-content',
  template: `
	   <div class="custRiskModal">
		<div class="modal-dialog" [class.customfade]="isFade">

			<div class="container-fluid container-fixed-lg bg-white">
			<!-- START PANEL -->
				<div class="panel panel-transparent">
				<!--<div class="panel-heading"><div class="clearfix"></div></div>-->

					<div class="panel-body">
						<div class="row">
						<button  aria-hidden="true" class="close" (click)='closebox()' data-dismiss="modal" type="button">
						<i  class="pg-close fs-14"></i></button>
							<div class="col-sm-12">
								<div class="panel-heading" style="padding: 1px 1px 1px; min-height: 10px">
									<div class="panel-title">{{rcheaderText}}</div>
								</div>
								<risk-score-table [headings]="context.titles" [data]="context.data"   
								[itemsperpage]="itemsperpageconfig" [maxpagesize]="maxpagesizeconfig" ></risk-score-table>		 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="panel-heading" style="padding: 1px 1px 1px; min-height: 10px">
									<div class="panel-title">{{rfheaderText}}</div>
								</div>
								<risk-factor-table [headings]="context.titlesFactor" [data]="context.dataFactor"   
								[itemsperpage]="itemsperpagefactor" [maxpagesize]="maxpagesizefactor" ></risk-factor-table>
							</div>
						</div>
						<div><button type="button" data-dismiss="modal" (click)='closebox()' 
						class="btn btn-cons from-left pull-right">{{btnCloseText}}</button>
						</div>
					</div>
				</div>
			</div>	
		</div>
	</div>`
})

export class RiskeModel implements CloseGuard, ModalComponent<RiskModelData> {
	context: RiskModelData;
	public isFade = false;
	titles:Object[]=[];
	data:Object[]=[];
	titlesFactor:Object[]=[];
	dataFactor:Object[]=[];
	rcheaderText:string = myGlobals.RISK_CONFIG_HEADER_TEXT;
	rfheaderText:string = myGlobals.RISK_FACTOR_HEADER_TEXT;
	btnCloseText:string = myGlobals.RISK_MODAL_CLOSE_TEXT;
	
	itemsperpageconfig:number = myGlobals.RISK_CONFIG_ITEMS_PER_PAGE;
	maxpagesizeconfig:number = myGlobals.RISK_CONFIG_MAX_PAGE_SIZE;
	
	itemsperpagefactor:number = myGlobals.RISK_FACTOR_ITEMS_PER_PAGE;
	maxpagesizefactor:number = myGlobals.RISK_FACTOR_MAX_PAGE_SIZE;
 
	constructor(public dialog: DialogRef<RiskModelData>) { 
		this.context = dialog.context;		 
		dialog.setCloseGuard(this);
	}

	closebox(){
		this.isFade = true;
		this.dialog.close(this.isFade);
	}
}

