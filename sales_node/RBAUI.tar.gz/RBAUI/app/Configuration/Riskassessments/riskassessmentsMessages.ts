/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

// placeholders
export const RISK_ASSESSMENT_ID_PC : string= "Alphanumeric only, max length 10";
export const RISK_ASSESSMENT_NAME_PC: string ="Name your risk assessment, max length 50";
export const RISK_BTN_EDIT_DETAILS: string ="Edit";
export const RISK_BTN_DELETE_DETAILS: string ="Delete";
export const DELETE_RA_CONFIRM: string =  "Are you sure you want to delete this risk assessment?";
export const DELETE_RA_ERROR_MSG: string = "Error encountered while deleting risk assessment.";