/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component} from '@angular/core';
import {Router} from '@angular/router';
import { APIService } from './../../services/APIService.service';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ConfirmModelData } from '../../common/confirmModal.component';
import { AlertModelData } from './../../common/alertModal.component';
import {RiskeModel} from './risk-modal';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import * as myGlobals from './../../common/appRiskAssessmentConfiguration';
import { MessageService } from './../../services/MessageService';
import { SettingsService } from '../../services/settings.service';
import {DELETE_RA_CONFIRM, DELETE_RA_ERROR_MSG} from './riskassessmentsMessages';
@Component({
    selector: 'risk-config',
    template: require('./riskassessments.html') ,
	 providers: [Modal]
})
export class riskassessmentsComponent{
	objRiskType:any = "Total";
	blnHideDiv:Boolean = false;

	titles:Object[]=[];
	data:Object[]=[];
	titlesConfig:Object[]=[];
	dataConfig:Object[]=[];
	titlesFactor:Object[]=[];
	dataFactor:Object[]=[];

	pagesizes: Object[];
	itemsperpage:number;
	maxpagesize:number = myGlobals.RISK_MAX_PAGE_SIZE;
	defaultitemsperpage: number = myGlobals.RISK_ITEMS_PER_PAGE;
	localstoragekey: string = myGlobals.RISK_LOCALSTORAGE_KEY;
	homePage:string = myGlobals.RISK_REDIRECT_PAGE_NAME;
	headerText:string = myGlobals.RISK_HEADER_TEXT;
	titleText:string = myGlobals.RISK_TITLE_TEXT;
	btnAddRiskText:string = myGlobals.RISK_BTN_ADD_TEXT;
	policyDetailsText:string = myGlobals.RISK_POLICY_DETAILS_TEXT;
	optionTotalText:string = myGlobals.RISK_OPT_TOTAL_TEXT;
	optionMaxText:string = myGlobals.RISK_OPT_MAX_TEXT;
	optionAvgText:string = myGlobals.RISK_OPT_AVG_TEXT;

	constructor(
		public objmodal: Modal, 
		private router: Router,
		private apiService: APIService,
		private globalService:GlobalService,
		private auth: AuthService,
		private messageService: MessageService,
		private settings: SettingsService
	){
		if(this.globalService.userRole != "neuroadmin"){
			this.redir();
		}
		else{		
			this.titles=[
							['id', 
							 myGlobals.RISK_TABLE_SORT_INFO.id, 
							 myGlobals.RISK_TABLE_DISPLAY_NAME.id],

							['name', 
							 myGlobals.RISK_TABLE_SORT_INFO.name, 
							 myGlobals.RISK_TABLE_DISPLAY_NAME.name]
						];
			this.getRiskAssessments();
		}
	}

	gotoWizard(){
		var refurl="admin/RiskAssessmentWizard/new";
        this.router.navigate([refurl])
	}
	
	changedtext(val:number){
		if(val && val > 0){
			this.blnHideDiv = false;
		}
		else if(this.data && this.data.length > 2){
			this.blnHideDiv = true;
		}
	}

	/* Function to fetch activity list */ 
    getRiskAssessments(): void {
		this.data = [];
        this.apiService.getRiskAssessments().then((response) => { 
            var APIdata=JSON.parse(response._body);
            
			if(APIdata.statusCode == 402){
				this.redir();
			}
            else if(APIdata.statusCode == 401){
                this.auth.authInvalid= true;
                this.globalService.redirectServerOrClient();
            }
            else if (APIdata.riskassessments){
                for(var i = 0; i < APIdata.riskassessments.length; i++){
					this.data.push({
						'id': APIdata.riskassessments[i].id, 
						'name':  APIdata.riskassessments[i].name,
						'Provider' : 'None',
						'editkey':1
					});
                }
				
				if(APIdata.riskScorePolicy){
					switch(APIdata.riskScorePolicy){
						case "TOT":
							this.objRiskType = "Total";
							break;
						
						case "AVG":
							this.objRiskType = "Avg";
							break;
							
						case "MAX":
							this.objRiskType = "Max";
							break;
					}
				}
				
				if(APIdata.riskfactorids){
					this.globalService.riskfactorids = APIdata.riskfactorids;
				}
				
				if(APIdata.riskassessments.length > 2){
					this.blnHideDiv = true;
				}
				else{
					this.blnHideDiv = false;
				}

				let totalItems = this.data.length;
			   
				this.pagesizes = []; 
				let page= myGlobals.RISK_ITEMS_PER_PAGE;
				while (page <= totalItems) {
				  this.pagesizes.push({
						id: page.toString(),
						text: page.toString()
					})
					page +=  myGlobals.RISK_ITEMS_PER_PAGE;   
				}
				if( (page -  myGlobals.RISK_ITEMS_PER_PAGE) < totalItems || !this.pagesizes.length){
				  this.pagesizes.push({
						id: page.toString(),
						text: page.toString()
					});
				}
			   this.itemsperpage =  this.settings.getPageSize(this.data.length, myGlobals.RISK_ITEMS_PER_PAGE, myGlobals.RISK_LOCALSTORAGE_KEY);
            }
        }).catch(error => {
            console.log(error);
        });
    }

	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}

	showalert(d: Object){
		this.titlesConfig=	[
								['type',
								 myGlobals.RISK_CONFIG_TABLE_SORT_INFO.type,
								 myGlobals.RISK_CONFIG_TABLE_DISPLAY_NAME.type],
			
								['id',
								 myGlobals.RISK_CONFIG_TABLE_SORT_INFO.id,
								 myGlobals.RISK_CONFIG_TABLE_DISPLAY_NAME.id],
			
								['name',
								 myGlobals.RISK_CONFIG_TABLE_SORT_INFO.name,
								 myGlobals.RISK_CONFIG_TABLE_DISPLAY_NAME.name],
			
								['value',
								 myGlobals.RISK_CONFIG_TABLE_SORT_INFO.value,
								 myGlobals.RISK_CONFIG_TABLE_DISPLAY_NAME.value]
							];
		this.dataConfig =[];
		this.titlesFactor=[['id',
							myGlobals.RISK_FACTOR_TABLE_SORT_INFO.id,
							myGlobals.RISK_FACTOR_TABLE_DISPLAY_NAME.id],
						   
						   ['name',
							myGlobals.RISK_FACTOR_TABLE_SORT_INFO.name,
							myGlobals.RISK_FACTOR_TABLE_DISPLAY_NAME.name], 
						   
						   ['provided system',
							myGlobals.RISK_FACTOR_TABLE_SORT_INFO.provided_system,
							myGlobals.RISK_FACTOR_TABLE_DISPLAY_NAME.provided_system]
						  ];	  
		this.dataFactor =[];

		this.apiService.getRiskAssessmentDetails({'ID': d['id']}).then((response) => { 
			var APIdata=JSON.parse(response._body);

			if(APIdata.statusCode == 401){
				this.auth.authInvalid= true;
				this.globalService.redirectServerOrClient();
			}
			else{
				if (APIdata.riskconfig){
					for(var i = 0; i < APIdata.riskconfig.length; i++){
						this.dataConfig.push({
							'id': APIdata.riskconfig[i].id, 
							'name':  APIdata.riskconfig[i].name,
							'value' : APIdata.riskconfig[i].value,
							'type' : APIdata.riskconfig[i].type,
							'editkey':1
						});
					}
				}				
				if (APIdata.riskFactors){
					for(var i = 0; i < APIdata.riskFactors.length; i++){
						this.dataFactor.push({
							'id': APIdata.riskFactors[i].id, 
							'name':  APIdata.riskFactors[i].name,
							'provided system' : APIdata.riskFactors[i].providedsystem,
							'editkey':1
						});
					}
				}
				
			const dialog = this.objmodal.open(RiskeModel, overlayConfigFactory(
			{
				titles: this.titlesConfig,
				data: this.dataConfig,				
				titlesFactor: this.titlesFactor,
				dataFactor: this.dataFactor
			}, BSModalContext));



			dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
			});
		}
		}).catch(error => {
			console.log(error);
		});
	 }
	 editrisk(data: Object){
		const editUrl ="admin/RiskAssessmentWizard/";
		this.router.navigate([editUrl, data['id']]);
	}
    opendeletemodal(item: Object,){
		let displaymsg = DELETE_RA_CONFIRM;
		const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
			{
			  size: 'md',
			  isBlocking: false,
			  message: displaymsg
			}, BSModalContext));
	  
		  dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
			  let objbody = document.getElementsByTagName('body')[0];
			  objbody.classList.remove("modal-open");
	  
			  if (result == "1") {
	  
				this.deleterisk(item);
			  }
			});
		  });
	}
	deleterisk(item: Object){
		this.apiService.deleteRiskAssesment(item['id'])
			.then((res) => {
				this.processResponse(res);
			})
			.catch((err) => {
				this.processResponse(err)
			});
	}
	processResponse(obj: any){
		if(obj && obj.status && obj._body){
			let response = JSON.parse(obj._body);
			if(obj.status == 401){
				this.auth.authInvalid = true;
				this.globalService.redirectServerOrClient();
			} else if(response.error == 0){
				this.getRiskAssessments();
			} else{
				this.openModalError(response.msg || DELETE_RA_ERROR_MSG, 'Error');
			}
		}
	}
	  /* Modal displayed incase of error in deleting risk assessment */
	  openModalError(msg: string, headtext: string) {
		const dialog = this.objmodal.open(AlertModelData, overlayConfigFactory(
		  {
			isBlocking: true,
			message: msg,
			headtext: headtext
		  }, BSModalContext));
	
		dialog.then((resultPromise) => {
		  resultPromise.result.then((result) => {
			let objbody = document.getElementsByTagName('body')[0];
			objbody.classList.remove("modal-open");
		  });
		});
	  }
}