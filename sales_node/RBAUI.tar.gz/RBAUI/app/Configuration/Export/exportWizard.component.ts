import { Component, OnInit, ViewEncapsulation,ContentChild } from '@angular/core';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {ExportTypePartialComponent} from './ExportType/exportType.component';
import {ObjectTypePartialComponent} from './ObjectType/objectType.component';
import {ConfirmExportPartialComponent} from './ConfirmExport/confirmExport.component';
import {TabsService} from './../../services/tabsService';
import { GlobalService } from './../../services/globalFunctions.service';
import { MessageService } from './../../services/MessageService';
import { APIService } from './../../services/APIService.service';
@Component({  
        template: require('./ExportWizard.html')
})
export class ExportWizardComponent{
    public objectType:number = 1; //Default Activities
    public acitivityList:any;
    public authenticatorList:any;
    public riskList:any;
    public exps: string = "Export";
    public activeItem:Object[]=[];
    public channels:any;
    constructor(private tabservice:TabsService, private globalService:GlobalService, private messageService:MessageService,
			   private router:Router,private apiService: APIService) {
        if(this.globalService.userRole != "neuroadmin"){
			this.redir();
		}
		else{
			this.validateAccess();
		}
    }

	validateAccess(){
		this.apiService.getLoggedInUserDetails().then(response=>{
			var data=response._body;
			var data=JSON.parse(data);
			if(data.userrole){
				this.globalService.userRole = data.userrole;
				if(data.userrole != "neuroadmin"){
					this.redir();
				}
			}
		}).catch(error => {
			console.log(error);
		});
	}
	
	redir(){
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}

    save(){

    }

    clear(){
    }

    changeTabs(arg:any){
      
    }

    changeobjecttype(value:number){
        this.objectType = value;
        this.activeItem = [];
    }
 
    fillactivitylist(val:any){
        this.acitivityList = val;
    }

    fillauthlist(val:any){
        this.authenticatorList = val;    
    }

    fillrisklist(val:any){
        this.riskList = val;
    }

    updateactiveitem(val:any){
        this.activeItem = val;
    }

    updatechannels(val:any){
        this.channels = val;
    }

    tabclicked(arg:any){
       
       switch(arg){
                
       }
    }
}

