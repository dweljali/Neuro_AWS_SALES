import { Component, OnInit,Output,EventEmitter,ViewContainerRef, AfterViewInit, ViewChildren, Input } from '@angular/core';
import { GlobalService } from './../../../services/globalFunctions.service';
import { AuthService } from './../../../services/auth.service';
import {FormsModule} from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from './../../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../../common/alertModal.component';
import * as myGlobals from './../../../common/appMessages';
import { Subject } from 'rxjs/Subject'

@Component({
    selector: 'export-type-wizard',
    template: require('./ExportType.html'),
    providers: [Modal]
})
export class ExportTypePartialComponent{
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  @Input() objecttype: number; //1 - Activity, 2 - Risk, 3 - Authenticators
  private tabTextContent:string = myGlobals.EXPORT_TAB_CONTENT;
    @Input() exps: string;
  @Output() objecttypechange:EventEmitter<number> = new EventEmitter<number>();
 
  ngAfterViewInit() { 
    
  }

  setObjectType(value:number){
      this.objecttypechange.emit(value);
      
  }

  ngOnDestroy(){
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(private route: ActivatedRoute,
              private router: Router,private tabs:TabsService,vcRef: ViewContainerRef, 
              public modal: Modal, private auth: AuthService,private globalService: GlobalService) {
    modal.overlay.defaultViewContainer = vcRef;
    window.scrollTo(0, 0);
    this.loadData();
      console.log("constructor export");
    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => { 
        if(message.text.toUpperCase().trim() == "EXPORTTYPE"){
            window.scrollTo(0, 0);
            console.log(message);
            console.log(message.text);
            console.log("export type");
        }
    });

  }

  /* Function that displays modal upon validation error on activity & channel tab*/
  openModal(){
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
    {
      isBlocking: true,
      message: myGlobals.SELECT_EXPORT_TYPE,
      headtext: "Validation error"
    }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {                    
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");        
      });
    });
  }


  /* Validate component */
    validate(){
        if(this.objecttype == 0){
            this.openModal();
            return false;
        }
        return true;
    }

  /* Function to load data incase of edit*/
  loadData() {
  }

   /* Function to navigate to the previous tab*/
    next(){
        if(this.validate()){
            this.tabs.sendMessage("objectType","");
        }
    }
}