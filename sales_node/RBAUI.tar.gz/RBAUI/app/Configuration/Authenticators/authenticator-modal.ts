import { Component, Input, AfterViewInit, ViewChildren } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { selectComponent } from './../../common/select.component';
import * as myGlobals from './../../common/appMessages';
import { AUTHENTICATOR_ID_PC, AUTHENTICATOR_DESCRIPTION_PC } from './appAuthenticatorMessages'
export class CustomModelData extends BSModalContext {
  public authID: string;
  public authDescription: string;
  public authEdit: boolean;
  public Add: string;
  public factLocator: Object[];
  public activefact: Object[];
  public selectedfactkey: string;
  public selectedfactvalue: string;
  public authHeadermsg: string;

}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-content',
  template: `
    <style>.ui-select-choices {left: auto; position: fixed;    top: auto;    width: 88% !important;} .small-text-red {font-size: 14px !important;color: red;text-align: center;} .hide-text{display: none;}</style>
        <div class="modal-dialog" [class.customfade]="isFade">
             
                <div class="modal-header clearfix ">
        <button type="button" (click)='closebox()' class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                  </button>
                  <h4 class="p-b-5"><span class="semi-bold">{{context.Add}}</span> Authenticator</h4>
                </div>
                <div class="modal-body">
                  <p class="small-text-red" [class.hide-text]="hideerrormsg">{{errormessage}}</p>
                  <p class="small-text">{{context.authHeadermsg}}</p>                   
                  <form role="form">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>Authenticator ID</label>
                          <input maxlength="10" id="appName" #appName (focus)="oninputfocus()"  (input)="authenicatorCode = $event.target.value" [disabled]="context.authEdit" class="form-control" placeholder="{{authenticationIdPc}}" type="text" value="{{context.authID}}" (keypress)="_keyPressID($event)" (paste)="false">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>Authenticator Name</label>
                          <input maxlength="50" id="appDescription" #appDesc (input)="authenicatorDesc = $event.target.value" (focus)="oninputfocus()" class="form-control" placeholder="{{authenticationDescriptionPc}}" type="text" value="{{context.authDescription}}">
                        </div>
                      </div>
                    </div>                    
                    <div class="row">
                        <div class="col-sm-12 ">                            
                            <div class="form-group form-group-default custFormgrp">
                    <label>Fact Locator Module</label>
                    <custom-select [dataobject]="context.factLocator" [placeholder]="pcholder" (selectvaluechange)="selectedvalue($event)" [activemember]="context.activefact" ></custom-select>
                               
                            </div> 
                        </div> 
                      </div>                    
                  </form>
                </div>
                <div class="modal-footer">
                  <button id="add-app" data-dismiss="modal" type="button" (click)='saveAuthenticators(appName.value, appDesc.value, isEdit.value,factid.value,factvalue.value)' class="btn btn-primary  btn-cons">Save</button>
                  <button type="button" data-dismiss="modal" (click)='closebox()' class="btn btn-cons">Close</button>
<input type="hidden" #isEdit value="{{context.authEdit}}" >
<input type="hidden" #factid value="{{context.selectedfactkey}}" >
<input type="hidden" #factvalue value="{{context.selectedfactvalue}}" >
                </div>
            </div>`
})
export class ChallengeModel implements CloseGuard, ModalComponent<CustomModelData> {
  context: CustomModelData;

  @ViewChildren('appName') vcappname: any;
  @ViewChildren('appDesc') vcappdesc: any;

  ngAfterViewInit() {
    if (this.vcappname.first.nativeElement.value) {
      this.vcappdesc.first.nativeElement.focus();
    }
    else {
      this.vcappname.first.nativeElement.focus();
    }
  }

  public isFade = false;
  public authenicatorCode: string;
  public authenicatorDesc: string;
  public returndata: any;
  public pcholder: string;
  public authFact: string;
  public selectedfactKey: string;
  public selectedfactValue: string;
  public hideerrormsg = true;
  public errormessage: string;

  public authenticationIdPc = AUTHENTICATOR_ID_PC;
  public authenticationDescriptionPc = AUTHENTICATOR_DESCRIPTION_PC;
  oninputfocus() {
    this.errormessage = "";
    this.hideerrormsg = true;
  }

  constructor(private apiService: APIService, public dialog: DialogRef<CustomModelData>, private globalService: GlobalService) {
    this.context = dialog.context;
    dialog.setCloseGuard(this);
    this.pcholder = myGlobals.FACT_LOCATOR_PH;
  }

  closebox() {
    this.isFade = true;
    this.dialog.close(this.returndata);
  }

  selectedvalue(objValue: any) {
    this.selectedfactKey = objValue.id;
    this.selectedfactValue = objValue.text;
  }

  beforeDismiss(): boolean {
    this.dialog.close(this.returndata);
    this.isFade = true;
    return false;
  }

  /* Function to validate authenticator id */
  _keyPressID(event: any) {
    var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft', 'Home', 'Delete', 'Tab'];
    const pattern = /^[a-zA-Z\d-_]+$/;
    let inputChar = String.fromCharCode(event.charCode);


    if (arrint.indexOf(event.key) != -1) {
      return;
    }
    else if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }

  }

  /* Function to save the new/edited authenticator */
  saveAuthenticators(objAppname: string, objAppDesc: string, objEdit: string, objfactid: string, objfactvalue: string) {
    if (!objAppname || !objAppDesc) {
      this.errormessage = myGlobals.MANDATORY_FIELDS_VALIDATE;
      this.hideerrormsg = false;
      return;
    }

    if (!this.selectedfactKey) {
      this.selectedfactKey = objfactid;
    }
    if (!this.selectedfactValue) {
      this.selectedfactValue = objfactvalue;
    }

    if (objEdit == "true") {
      this.apiService.updateAuthenticators({
        AuthenticatorID: objAppname,
        AuthenticatorDesc: objAppDesc,
        factid: this.selectedfactKey,
        activeStatus: 1
      }).then(response => {
        var resp = JSON.parse(response._body);
        if (resp.statusCode == 401) {
          this.closebox();
          this.globalService.redirectServerOrClient();
        }
        else if (resp.error == 0) {
          this.returndata = {
            'name': objAppname, 'desc': objAppDesc, 'fact': this.selectedfactValue, 'msg': resp.msg,
            'factid': this.selectedfactKey, 'type': 0
          };
          this.closebox();

        }
        else {
          this.errormessage = resp.msg ? resp.msg : "There was an error while updating authenticator details.";
          this.hideerrormsg = false;
        }
      }).catch(error => {

      });
    }
    else {
      this.apiService.postAuthenticators({
        AuthenticatorID: this.authenicatorCode,
        AuthenticatorDesc: objAppDesc,
        factid: this.selectedfactKey,
        activeStatus: 1
      }).then(response => {
        var resp = JSON.parse(response._body);
        if (resp.statusCode == 401) {
          this.closebox();
          this.globalService.redirectServerOrClient();
        }
        else if (resp.error == 0) {
          this.returndata = {
            'name': this.authenicatorCode, 'desc': this.authenicatorDesc, 'msg': resp.msg,
            'fact': this.selectedfactValue, 'factid': this.selectedfactKey, 'type': 1
          };
          this.closebox();
        }
        else {
          this.errormessage = resp.msg ? resp.msg : "There was an error while adding a new authenticator.";
          this.hideerrormsg = false;
        }
      }).catch(error => {

      });
    }
  }

}
