/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import { APIService } from '../services/APIService.service';
import { GlobalService } from '../services/globalFunctions.service';
import {AuthService} from '../services/auth.service';
import * as myGlobals from '../common/appMessages';
import {Router} from '@angular/router';
import { CommonModule } from '@angular/common'; 
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
@Component({
    selector:'dashboard',
    template: `<div class="content sm-gutter">
  <!-- START CONTAINER FLUID -->
  <div class="container-fluid padding-25 sm-padding-10">
    <!-- START ROW -->
    <div *ngIf="neuroadmin" class="row">
      <div class="col-md-12">
         <div class="col-md-3">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <!-- START WIDGET widget_imageWidgetBasic-->
              <card name="WIZARD" description="{{cardWizard}}" [config]="1" refurl="ActivityWizard" refcss="bg-complete"></card>
              <!--<button md-button (click)="sidenav.open()">Open sidenav </button>-->
              <!-- END WIDGET -->
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <!-- START WIDGET widget_imageWidgetBasic-->
              <card name="ACTIVITIES" description="{{cardActivity}}" refurl="activities" [config]="1" [total]="totalActivity" refcss="bg-info"></card>
              <!-- END WIDGET -->
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <card name="AUTHENTICATORS" description="{{cardAuthenticator}}" refurl="authenticators" [config]="1" [total]="totalAuth" refcss="bg-primary"></card>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <!-- START WIDGET widget_imageWidgetBasic-->
              <card name="RISK ASSESSMENTS" description="{{cardRiskConfiguration}}" refurl="riskassessments" [config]="1" [total]="totalRisk" refcss="bg-success"></card>
            </div>
          </div>
        </div>        
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
       <div class="col-md-3" *ngIf="neuroadmin">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <!-- START WIDGET widget_imageWidgetBasic-->
              <card name="MANAGE RULES" description="{{cardRuleConfiguration}}" refurl="ruleconfiguration" [config]="1" [total]="totalRule" refcss="bg-success"></card>
            </div>
          </div>
        </div>
        <div [class.col-md-3]="neuroadmin" [class.col-md-4]="!neuroadmin">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <card name="OPS DASHBOARD" description="{{cardMonitor}}" [config]="0" refurl="opsdash" refcss="bg-primary"></card>
            </div>
          </div>
        </div>
        <div [class.col-md-3]="neuroadmin" [class.col-md-4]="!neuroadmin">
          <div class="row">
            <div class="col-sm-12 m-b-10">
              <card name="DIAGNOSTICS" description="{{cardDiagonistics}}" [config]="0" refurl="diagnostics" refcss="bg-complete"></card>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- END CONTAINER FLUID -->
</div>
<div class="emptyDiv" style="height: 50vh;"></div>`,

})
export class DashboardComponent {

  totalActivity: number;
  totalAuth: number;
  totalRisk: number;
  totalRule: number;
  cardWizard: string;
  cardActivity: string;
  cardAuthenticator: string;
  cardMonitor: string;
  cardRiskConfiguration: string;
  cardDiagonistics: string;
  neuroadmin: boolean = true;
  cardRuleConfiguration: string;


  constructor(public objmodal: Modal, private service: APIService, private globalService: GlobalService, private auth: AuthService,
    private router: Router, vcRef: ViewContainerRef) {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    this.service.isLoggedIn().then((response: any) => {
      var apiData = JSON.parse(response._body);

      if (apiData.statusCode == 401) {
        this.auth.authInvalid = true;
        this.router.navigate(['/login']);
      }
      else {
        if (apiData && apiData.userole) {
          this.globalService.userRole = apiData.userole;
        }

        if (this.globalService.userRole == "neuroadmin") {
          this.neuroadmin = true;
        }
        else {
          this.neuroadmin = false;
        }
        this.cardWizard = myGlobals.cardWizard;
        this.cardAuthenticator = myGlobals.cardAuthenticator;
        this.cardMonitor = myGlobals.cardMonitor;
        this.cardActivity = myGlobals.cardActivity;
        this.cardRiskConfiguration = myGlobals.cardRiskConfiguration;
        this.cardDiagonistics = myGlobals.cardDiagonistics;
        this.cardRuleConfiguration = myGlobals.cardRuleConfiguration;
      }
    }).catch(err => console.log(err));


  }

  ngAfterViewInit() {
    if (this.globalService.userRole == "neuroadmin") {
      let activities = this.service.getActivitiesCount()
        .then(res => this.processResponse(res))
        .catch(err => this.processResponse(err));

      let authenticators = this.service.getAuthenticatorsCount()
        .then(res => this.processResponse(res))
        .catch(err => this.processResponse(err));

      let risks = this.service.getRiskCount().then(res => res.json()).catch(err => console.log(err));
      let rule = this.service.getRuleCount().then(res => res.json()).catch(err => console.log(err));

      Observable.forkJoin([activities, authenticators, risks, rule]).subscribe(results => {
        if ((results[0] && results[0].statusCode == 401) || (results[1] && results[1].statusCode == 401) ||
          (results[2] && results[2].statusCode == 401) || (results[3] && results[3].statusCode == 401)) {
          this.auth.authInvalid = true;
          this.router.navigate(['/login']);
        }
        this.totalActivity = results[0].noOfRecordsFound;
        this.totalAuth = results[1].noOfRecordsFound;
        this.totalRisk = results[2].noOfRecordsFound;
        this.totalRule = results[3].noOfRecordsFound;
      });
    }
  }

  processResponse(resp: any) {
    let r: any = {};
    r.statusCode = 400;
    r.noOfRecordsFound = 0;

    if (resp && resp.status && resp._body) {
      r.statusCode = resp.status;
      let _body: any = JSON.parse(resp._body);
      if (_body.noOfRecordsFound) { r.noOfRecordsFound = _body.noOfRecordsFound }
    }
    return r;
  }
}