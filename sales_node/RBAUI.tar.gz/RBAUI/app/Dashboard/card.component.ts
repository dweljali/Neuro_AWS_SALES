/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SideBar } from '../common/sidebar.component';
import { MessageService } from '../services/MessageService';
import { APIService } from '../services/APIService.service';

@Component({
  selector: 'card',
  template: `<div class="ar-1-1">
  <div class="widget-2 panel no-border {{refcss}} widget widget-loader-circle-lg no-margin">
    <div class="panel-heading">
      <div class="panel-controls">
        <ul>
          <li>
          </li>
        </ul>
      </div>
    </div>
    <div class="panel-body">
      <a (click)="redir()" href="javascript:void(0)">
        <div class="padding-25 bottom-right custCard">
          <span class="label font-montserrat fs-11">{{name}}</span>
          <span class="badge badge-important">{{totalNos}}</span>
          <br>
          <h3 class="text-white">{{description}}</h3>
          <p *ngIf='config == 1' class="text-white hint-text hidden-md">Configure</p>
        </div>
      </a>
    </div>
  </div>
</div>`,

})
export class Card {
  @Input() name: string;
  @Input() description: string;
  @Input() refurl: string;
  @Input() refcss: string;
  @Input('total') totalNos: number;
  @Input() authNos: number;
  @Input() config: number;
  constructor(private router: Router, private messageService: MessageService, private apiService: APIService) {

  }

  /* navigation to pages on click of cards on dashboard */
  redir() {
    switch (this.refurl) {
      case 'dashboard':
        this.messageService.highlightSidebar('dashboard');
        break;
      case 'ActivityWizard':
        this.messageService.highlightSidebar('ActivityWizard');
        break;
      case 'activities':
        this.messageService.highlightSidebar('activities');
        break;
      case 'authenticators':
        this.messageService.highlightSidebar('authenticators');
        break;
      case 'opsdash':
        this.messageService.highlightSidebar('opsdash');
        break;
      case 'diagnostics': this.messageService.highlightSidebar('diagnostics');
        break;
      case 'ruleconfiguration': this.messageService.highlightSidebar('ruleconfiguration');
        break;
      case 'riskassessments':
        this.messageService.highlightSidebar('riskassessments');
        break;
      default:
        break;

    }
    this.refurl = 'admin/' + this.refurl
    if (this.refurl == "admin/ActivityWizard") {
      this.apiService.clearWizardSession().then((response: any) => {
        this.refurl = this.refurl + '/new';
        this.route();
      }).catch(error => {
        console.log(error);
      });
    }
    else {
      this.route();
    }
  }

  route() {
    this.messageService.sendMessage(this.refurl);
    this.router.navigate([this.refurl]);
  }
}
