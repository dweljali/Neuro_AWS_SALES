/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
*******************************************************************************/
import { Component, OnInit, ViewEncapsulation, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import { MessageService } from './../../services/MessageService';
import * as myGlobals from './../../common/appMessages';
import { AlertModelData } from './../../common/alertModal.component';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ActivityeModel, ActivityModelData } from './../../Configuration/Activities/activities-modal';
@Component({
	selector: 'diagnostics',
	templateUrl: './Diagnostics.html',
	providers: [APIService, Modal]
})
export class DiagnosticsComponent {
	titlesession: Object[] = [];
	sessiondata: Object[] = [];

	titleactivity: Object[] = [];
	activitydata: Object[] = [];

	titlerisk: Object[] = [];
	riskdata: Object[] = [];

	titlefactor: Object[] = [];
	factordata: Object[] = [];

	pcDiagnosticSearch: string;
	searchText: string = "";
	channel: Object[] = [];
	selectedchannel: string = "DEFAULT";
	pcholder: string = "";
	activeChannel: string[];

	selectedvaluechannel(arg: any) {
		this.selectedchannel = arg.id;
		this.getDiagnostics();
	}

	constructor(private service: APIService, private auth: AuthService, private globalService: GlobalService,
		private router: Router, public modal: Modal, vcRef: ViewContainerRef, private messageService: MessageService) {
		modal.overlay.defaultViewContainer = vcRef;
		this.titlesession = [['user', 0], ['session id', 0], ['start time', 0],
		['session score', 0]];

		this.titleactivity = [['id', 1], ['time', 1], ['authenticators', 0], ['trust score', 1]];

		this.titlerisk = [['id', 1], ['activity id', 1], ['time', 1], ['description', 1], ['score', 1]];

		this.titlefactor = [['id', 1], ['risk assessment id', 1], ['activity id', 1], ['time', 1], ['value', 1], ['status', 1]];
		this.pcDiagnosticSearch = myGlobals.DIAGNOSTICS_SEARCH_TEXT_PH;
		this.pcholder = "Select One";

		this.service.getChannels().then((response: any) => {
			var data = JSON.parse(response._body);
			if (data.channel) { this.channel = data.channel; }
		}).catch(error => {
			console.log(error);
		});
	}

	getDiagnostics() {
		this.sessiondata = [];
		this.activitydata = [];
		this.riskdata = [];
		this.factordata = [];

		if (this.searchText) {
			this.service.getDiagnostics({ 'userid': this.searchText, 'channel': this.selectedchannel }).then((response: any) => {

				var objBody = JSON.parse(response._body);
				if (objBody.statusCode && objBody.statusCode == 401 || objBody.statusCode == 401) {
					this.auth.authInvalid = true;
					this.globalService.redirectServerOrClient();
				}
				else {
					if (objBody.user && objBody.sessions && objBody.sessions.length > 0) {
						for (var i = 0; i < objBody.sessions.length; i++) {
							this.sessiondata.push({
								'user': objBody.user,
								'session id': objBody.sessions[i]["session id"],
								'start time': objBody.sessions[i]["start time"],
								'session score': objBody.sessions[i]["session score"],
								'risk score': objBody.sessions[i]["risk score"]
							});

							if (objBody.sessions[i].activities) {
								for (var j = 0; j < objBody.sessions[i].activities.length; j++) {
									this.activitydata.push({
										'id': objBody.sessions[i].activities[j].id,
										'time': objBody.sessions[i].activities[j].time,
										'authenticators': objBody.sessions[i].activities[j].authenticators,
										'channel': objBody.sessions[i].activities[j].channel,
										'trust score': objBody.sessions[i].activities[j].trustscore,
										'lastact': ((j == 0) ? 1 : 0)
									});
								}
							}

							if (objBody.sessions[i].riskassessments) {
								for (var j = 0; j < objBody.sessions[i].riskassessments.length; j++) {
									this.riskdata.push({
										'id': objBody.sessions[i].riskassessments[j].id,
										'score': objBody.sessions[i].riskassessments[j].score,
										'description': objBody.sessions[i].riskassessments[j].description,
										'activity id': objBody.sessions[i].riskassessments[j].activityid,
										'time': objBody.sessions[i].riskassessments[j].activityTime
									});
								}
							}

							if (objBody.sessions[i].riskfactors) {
								for (var j = 0; j < objBody.sessions[i].riskfactors.length; j++) {
									this.factordata.push({
										'id': objBody.sessions[i].riskfactors[j].id,
										'status': objBody.sessions[i].riskfactors[j].status,
										'value': objBody.sessions[i].riskfactors[j].value,
										'risk assessment id': objBody.sessions[i].riskfactors[j].riskid,
										'activity id': objBody.sessions[i].riskfactors[j].activityid,
										'time': objBody.sessions[i].riskfactors[j].executionTime
									});
								}
							}
						}

						if (this.selectedchannel == "DEFAULT") {
							if (objBody.sessions[0]["channel"]) {
								if (objBody.sessions[0]["channel"] != "DEFAULT") {
									for (let i = 0; i < this.channel.length; i++) {
										if (this.channel[i]["id"].toUpperCase() == objBody.sessions[0]["channel"].toUpperCase()) {
											this.activeChannel = [this.channel[i]["text"]];
											this.selectedchannel = this.channel[i]["id"];
											break;
										}
									}
								}
							}
						}
					}
					else {
						this.openModalError("No data available for the user.", "Error");
					}
				}
			}).catch(error => {
				console.log(error);
			});
		}
	}

	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard']);
	}

	showalert(data: any, heading: string) {
		let authdata: any = [];
		for (let i = 0; i < data.length; i++) {
			authdata.push(data[i][1]);
		}
		const dialog = this.modal.open(ActivityeModel, overlayConfigFactory(
			{
				Add: heading,
				actArr: authdata
			}, BSModalContext));



		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
		});
	}

	/* Modal displayed incase of error in deleting authenticator */
	openModalError(msg: string, headtext: string) {
		const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
			{
				isBlocking: true,
				message: msg,
				headtext: headtext
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
			});
		});
	}

}