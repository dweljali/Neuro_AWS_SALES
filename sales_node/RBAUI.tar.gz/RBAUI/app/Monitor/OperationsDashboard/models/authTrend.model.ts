
/*******************************************************************************
 * Copyright (c) 2017  Persistent Systems Ltd.
 * All rights reserved.
 *******************************************************************************/
import { OpsCardData } from './opsCardData.model';

export interface AuthTrend extends OpsCardData {
    activity: string;
    challenge: string;
}