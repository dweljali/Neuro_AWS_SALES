/*******************************************************************************
 * Copyright (c) 2017  Persistent Systems Ltd.
 * All rights reserved.
 *******************************************************************************/
import { OpsCardData } from './opsCardData.model';

export class RiskScoreIndex implements OpsCardData{
    image: string;
    name: string;
    time: string;
    activity: string;
    riskScore: number;
    channel: string;
}