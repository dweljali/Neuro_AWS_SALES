export interface DateRange{
    fromDate: string;
    toDate: string;
}