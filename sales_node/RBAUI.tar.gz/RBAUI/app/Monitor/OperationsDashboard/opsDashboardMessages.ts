/*******************************************************************************
 * Copyright (c) 2017  Persistent Systems Ltd.
 * All rights reserved.
 *******************************************************************************/
export const RISK_SCORE_INDEX_GRAPH_TITLE: string = "Risk Score Index";
export const AUTH_TREND_CARD_GRAPH_TITLE: string = "Authenticator Adaption Trend";
export const  AUTH_FAILURE_GRAPH_TITLE: string = "Authenticator Failure";

export const RISK_SCORE_INDEX_CARD_TITLE: string = "RISK SCORE INDEX";
export const AUTH_TREND_CARD_TITLE: string = "AUTHENTICATOR ADAPTION TREND";
export const  AUTH_FAILURE_CARD_TITLE: string = "AUTHENTICATOR FAILURE";