/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, Input, Output, EventEmitter, SimpleChange, AfterViewInit } from '@angular/core';

/* Component for select */
@Component({
    selector: 'ops-widget',
    template: `
  <div class="widget-1-wrapper">
  <div class="panel pending-comments-widget">
      <div class="widget-header p-r-20 p-l-20" style="background-color:#3B4753">
          <!-- BEGIN Widget title -->
          <h5 class="text-uppercase font-montserrat m-t-0 p-t-20 p-l-10" style="color:#C1C3C6">
          <span style="font-size: 17px;"> {{title}} </span>
          </h5>
          <ul class="nav nav-tabs nav-tabs-simple font-montserrat text-uppercase" style="background-color:#3b4753"> </ul>
          <!-- END Widget title -->
          <!-- BEGIN Refresh button -->
          <div class="panel-heading top-right">
          </div>
          <!-- END Refresh button -->
      </div>
      <div class="tab-content panel-body no-padding scrollable" style="position: relative;min-height: 637px;max-height: 637px !important;">
          <div class="tab-content panel-body no-padding scrollable scroll-content" style="margin-bottom: 0px; margin-right: 0px;max-height: 637px !important;">
              <div class="p-t-35 p-b-20">
                  <!-- BEGIN Comment -->
                  <div *ngFor="let item of data | limit: itemstodisplay; let i= index; let isLast = last" class="row p-l-25 p-r-25 p-b-30">
                      <!-- BEGIN Profile Picture -->
                      <div class="thumbnail-wrapper d32 circular b-white m-r-10 b-a b-white">
                           <img width="30" height="30" [src]="item.image">
                      </div>
                      <!-- BEGIN END Picture -->
                      <!-- BEGIN Comment text -->
                      <div class="comment-wrapper pull-left no-padding" style="width: calc(100% - 45px);">
                          <!-- BEGIN Username -->
                          <span class="comment-username text-black m-r-10" style="font-weight: 500;">{{item.name}}</span>
                          <!-- END Username -->
                          <!-- BEGIN Comment timestamp -->
                          <div class="pull-right small hint-text text-black">{{item.time}}</div>
                          <!-- END Comment timestamp -->
                          <!-- BEGIN Comment -->
                          <p class="hint-text">{{item.activity}}</p>
                          <!-- END Comment -->
                          <!-- If item is  Risk Factor Index -->
                          <span *ngIf="item.channel" class="label label-success ">{{item.channel}}</span>
                          <!-- If item is Authenticator Trend -->
                          <span *ngIf="item.challenge" class="label label-info ">{{item.challenge}}</span>
                          <!-- If item is Risk Alert -->
                           <!-- <button  *ngIf="item.risk" class="btn btn-xs btn-{{item.severity}}" id="show-modal" (click)="showalert(item.details)">{{item.risk}}</button> -->
                           <button  *ngIf="item.risk" class="btn btn-xs btn-success" id="show-modal" (click)="showalert(item.detail)">View Details</button>
                          <br>
                          <!-- BEGIN Controls -->
                          <!-- If item is  Risk Factor Index -->
                          <a   *ngIf="item.riskScore != undefined" class="btn btn-link font-montserrat text-uppercase text-complete fs-12 p-l-0 p-r-0 m-r-15 comment-button ">Risk Score:</a>
                          <span *ngIf="item.riskScore != undefined" class="badge badge-danger">{{item.riskScore}}</span>
                          <!-- END Controls -->
                      </div>
                      <!-- END Comment text -->
                      <div class="row" *ngIf="isLast && i != data.length -1">
                          <div class="col-sm-12 m-t-10 sm-m-t-10">
                              <button type="button" class="btn btn-primary btn-block m-t-5" (click)="showMore()">SHOW MORE</button>
                          </div>
                      </div>
                  </div>
                  <!-- END Comment -->

              </div>
          </div>

          <!-- <div class="scroll-element scroll-x">
              <div class="scroll-element_outer">
                  <div class="scroll-element_size"></div>
                  <div class="scroll-element_track"></div>
                  <div class="scroll-bar" style="width: 96px;"></div>
              </div>
          </div> -->
          <div class="scroll-element scroll-y">
              <div class="scroll-element_outer">
                  <div class="scroll-element_size"></div>
                  <div class="scroll-element_track"></div>
                  <div class="scroll-bar" style="height: 96px;"></div>
              </div>
          </div>
      </div>
  </div>

</div>
  `
})
export class OpsWidgetComponent {
    @Input() title: string;
    @Input() data: Object[];
    @Input() showalert: Object;
    itemstodisplay: number = 5;
    constructor() {

    }

    ngOnInit() {
        this.loadDisplayData();
    }
    ngOnChanges(changes: SimpleChange) {
        if (changes['data']) {
            this.resetItems();
        }
    }
    ngAfterViewInit() {
       // this.setMaxHeight();
    }
    loadDisplayData() {
    }
    showMore() {
        this.itemstodisplay += 5;
    }

    resetItems() {
        this.itemstodisplay = 5;
    }
}