import { Component, Input } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AuthFailureDetail } from './models/authFailure.model';



/* Component to display all authenticators and risk assessments for a row in activity table. */
export class opsModelData extends BSModalContext implements AuthFailureDetail {
    userName: string;
    email: string;
    authenticator: string;
    time: string;
    channel: string;
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
    selector: 'modal-content',
    template: `
    <div class="custOPSModal">
    <div class="modal-dialog" [class.customfade]="isFade">
        <div class="container-fluid container-fixed-lg bg-white">
            <div class="modal-content">
                <div class="modal-header clearfix ">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" (click)='closebox()'>
                        <i class="pg-close fs-14"></i>
                    </button>
                    <h4 style="text-align:center" class="p-b-5">
                        <span class="semi-bold">Authenticator</span> Failure</h4>
                </div>
                <div class="modal-body">
                    <form role="form">
                        <!--  <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group form-group-default">
                                <label>First Name</label>
                                <label>{{context.firstName}}</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group form-group-default">
                                <label>Last Name</label>
                                <label>{{context.lastName}}</label>
                            </div>
                        </div>
                    </div>
                    -->
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Username</label>
                                    <label>{{context.userName}}</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group form-group-default">
                                    <label>Email</label>
                                    <label>{{context.email}}</label>
                                </div>
                            </div>
                        </div>
                    </form>

                    <div class="panel-body">
                        <table class="table table-hover table-responsive-block">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <!--    <th>App</th> -->
                                    <th>Location</th>
                                    <th>CHANNEL</th>
                                    <th>Authenticators</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="v-align-middle">
                                        <p>{{context.time}}</p>
                                    </td>
                                    <!--     <td class="v-align-middle">
                                    <p>{{context.app}}</p>
                                </td> -->
                                    <td class="v-align-middle">
                                        <p>{{context.location}}</p>
                                    </td>
                                    <td class="v-align-middle">
                                        <p>
                                            <span class="label label-success">{{context.channel}}</span>
                                        </p>
                                    </td>
                                    <td class="v-align-middle">
                                        <p>
                                            <span class="label label-info">{{context.authenticator}}</span>
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn btn-cons" (click)='closebox()'>Close</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
    </div>
</div>
  `
})

export class opsModel implements CloseGuard, ModalComponent<opsModelData> {
    context: opsModelData;
    public isFade = false;
    public returndata: any;
    titles: Object[] = [];
    data: Object[] = [];
    titles2: Object[] = [];
    data2: Object[] = [];


    constructor(
        public dialog: DialogRef<opsModelData>
    ) {
        this.context = dialog.context;
        console.log("Context is", this.context)
        dialog.setCloseGuard(this);
    }

    closebox() {
        this.isFade = true;
        this.dialog.close(this.isFade);
    }

}