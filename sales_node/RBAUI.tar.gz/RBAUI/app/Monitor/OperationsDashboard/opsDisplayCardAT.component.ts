/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input, OnChanges, Renderer, ElementRef, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import { APIService } from '../../services/APIService.service';
import { Subject } from 'rxjs/Subject';
import { GlobalService } from '../../services/globalFunctions.service';
import { AuthService } from '../../services/auth.service';
import { DateRange } from './models/dateRange.model';
import { AUTH_TREND_CARD_GRAPH_TITLE } from './opsDashboardMessages';

@Component({
  selector: 'chart-card-at',
  template: `<div class="col-sm-4 m-b-10">
  <div class="widget-12 panel no-border widget-loader-circle no-margin">
  <div class="row">
  <div class="col-xlg-12">
  <div class="panel-heading pull-up top-right ">
  <div class="panel-controls">

  </div>
  </div>
  </div>
  </div>
  <div class="panel-body" style="height:550px">
  <div class="row">
  <div class="col-xlg-12">
  <div class="p-l-10">
  <h2 class="pull-left">
    <span class="icon-thumbnail bg-master-light pull-left text-master">{{cardcode}}</span>
    <span style="font-size: 24px;"> {{cardname}}</span>
  </h2>
  <div class="clearfix"></div>
  <h2 class="pull-left m-l-50 text-danger">
  <span class="bold">{{totalcount}}</span>
  <span class="text-danger fs-12"></span>
  </h2>
  <div class="clearfix"></div>
  <div class="full-width">
  <ul class="list-inline">
  <li [class.active]="isDay">
  <a href="javascript:void(0)" (click)="dayView()" class="font-montserrat text-master" 
  [class.bg-master-light]="isDay">1D</a>
  </li>
  <li [class.active]="isWeek">
  <a href="javascript:void(0)" (click)="weekView()" class="font-montserrat text-master"
  [class.bg-master-light]="isWeek">7D</a>
  </li>
  <li [class.active]="isMonth">
  <a  href="javascript:void(0)" (click)="monthView()" class="font-montserrat text-master"
  [class.bg-master-light]="isMonth">1M</a>
  </li>                              
  </ul>
  </div>
  <div class="nvd3-line5 line-chart text-center" data-x-grid="false">
  <div style="display: block">
  <canvas baseChart class="chart" height="250"
  [data]="pieChartData"
  [labels]="pieChartLabels"
  [chartType]="pieChartType"
  [colors]="pieChartColor"
  (chartHover)="chartHovered($event)"
  (chartClick)="chartClicked($event)"></canvas>
  </div>
  </div>

  </div>
  </div>
  </div>
  </div>
  </div>                  
  </div>`
})
export class ChartCardComponentAT {
  @Input() changeddatevalues: any;
  // Pie
  public pieChartLabels: string[] = [];
  public pieChartData: number[] = [];
  public pieChartType: string = 'pie';

  private fromDate: string = '';
  private toDate: string = '';
  private fromDateObj: any = {};
  private toDateObj: any = {};
  public isDay: boolean = false;
  public isWeek: boolean = false;
  public isMonth: boolean = false;
  @Output() datechange = new EventEmitter<DateRange>();
  private options: any = {
    responsive: true
  }
  private totalcount: number = 0;
  private cardcode: string = 'AT';
  private cardname: string = AUTH_TREND_CARD_GRAPH_TITLE;

  public dynlinedata: any = [];
  public pieChartColor: any = [
    { // blue
      backgroundColor: ['#00285e', '#f4be41', '#b4108b', '#89ba17', '#7FB5FF', '#f44141', '#ff8000', '#ffff00', '#00ffbf', '#bf00ff', '#ccff33']
    }];
  ngOnChanges(changes: any) {
    if (changes.changeddatevalues.currentValue) {
      if (changes.changeddatevalues.currentValue.fromDate && changes.changeddatevalues.currentValue.toDate) {
        this.setActiveClass(false, false, false);
        this.fromDate = changes.changeddatevalues.currentValue.fromDate;
        this.toDate = changes.changeddatevalues.currentValue.toDate;
        this.callGraphAPI('NA');
        this.changeLabels();
      }
    }
  }
  ngOnInit() {
    this.pieChartData = [0];
    this.pieChartLabels = [''];
    this.dynlinedata = [];

  }
  ngAfterViewInit() {
    this.changeLabels();
  }
  constructor(private apiService: APIService, private globalservice: GlobalService, private auth: AuthService) {
    this.setActiveClass(false, false, true);
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Month');
    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;
    this.callGraphAPI('1M');
  }

  setActiveClass(day: boolean, week: boolean, month: boolean) {
    this.isDay = day;
    this.isWeek = week;
    this.isMonth = month;

  }

  emitDates() {
    this.datechange.emit({
      fromDate: this.fromDate,
      toDate: this.toDate
    })
  }

  dayView() {
    this.setActiveClass(true, false, false);
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Day');

    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, true);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;

    this.callGraphAPI('1D');
    this.changeLabels();
    this.emitDates();
  }

  weekView() {
    this.setActiveClass(false, true, false);
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Week');

    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;

    this.callGraphAPI('7D');
    this.changeLabels();
    this.emitDates();
  }

  monthView() {
    this.setActiveClass(false, false, true);
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Month');

    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;

    this.callGraphAPI('1M');
    this.changeLabels();
    this.emitDates();

  }


  callGraphAPI(duration: string) {
    let apiData: any = {};
    //this.lineChartLabels=['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    let pieChartDataA: any = [];
    this.dynlinedata = [];
    apiData.startDate = this.fromDate;
    apiData.endDate = this.toDate;
    apiData.locale = window.navigator.language;
    apiData.duration = duration;
    this.apiService.getChartData(apiData, 'AT').then(res => {


      var dataAPI = res._body;
      dataAPI = JSON.parse(dataAPI);
      this.totalcount = 0;

      if (dataAPI.statusCode == 200) {

        let data: any = [];
        if (dataAPI.data) {
          this.totalcount = dataAPI.data.cumulativeValue;

          if (Object.keys(dataAPI.data.graphData).length > 0) {
            for (let key in dataAPI.data.graphData) {

              this.dynlinedata.push(key);
              pieChartDataA.push(dataAPI.data.graphData[key]);
            }
          } else {
            pieChartDataA = [0];
            this.dynlinedata = [''];
          }
        }
        this.pieChartData = pieChartDataA;

        this.pieChartLabels = this.dynlinedata;
      }
      else if (dataAPI.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalservice.redirectServerOrClient();
      }


    }).catch(error => { console.log(error) });
  }

  // events
  public chartClicked(e: any): void {
    //console.log(e);

  }

  public chartHovered(e: any): void {
    // console.log(e);
  }

  changeLabels(): void {
    this.pieChartLabels = this.dynlinedata;
  }
}