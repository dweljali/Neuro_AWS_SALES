/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
 import {DomSanitizer} from '@angular/platform-browser';
import { MessageService } from './services/MessageService';
import { AuthGuard } from './services/authguard.service';
import { Subject } from 'rxjs/Subject';
import { GlobalService } from './services/globalFunctions.service';
import { APIService } from './services/APIService.service';
@Component({
    template:`<md-sidenav-container class="example-container" style="height:auto; min-height: 100%" >
     <md-sidenav #sidenav class="example-sidenav" style="width: 284px;position:fixed; z-index: 1020">
   <sidebar [sidenavref]= "sidenav"></sidebar>
  </md-sidenav>
<nav class="page-sidebar admin-sidebar" data-pages="sidebar" style="transform: translate3d(0px, 0px, 0px);height: 100%; position:fixed; z-index: 1010" (mouseover)="sidenav.open()" >
      <!-- BEGIN SIDEBAR MENU HEADER-->
      <div class="sidebar-header">
        
        <div class="sidebar-header-controls">
          <button type="button" class="btn btn-xs sidebar-slide-toggle btn-link m-l-20" data-pages-toggle="#appMenu">
          </button>
          <button type="button" class="btn btn-link visible-lg-inline" data-toggle-pin="sidebar"><i class="fa fs-12"></i>
          </button>
        </div>
      </div>
      <!-- END SIDEBAR MENU HEADER-->
      <!-- START SIDEBAR MENU -->
      <div class="sidebar-menu">
        <!-- BEGIN SIDEBAR MENU ITEMS-->
        <div class="scroll-wrapper menu-items" style="position: relative;"><ul class="menu-items scroll-content scroll-scrolly_visible" style="height: inherit; margin-bottom: 0px; margin-right: 0px; overflow:hidden !important">
          <li [class]="dashboard">
            <a href="dashboard" class="detailed">
              <span class="title">Dashboard</span>
            </a>
            <span class="icon-thumbnail"><i class="fa fa-dashboard"></i></span>
          </li>
          <li *ngIf="neuroadmin" [class]="wizard">
            <a href="ActivityWizard" class="detailed">
              <span class="title">Wizard</span>
            </a>
            <span class="icon-thumbnail"><i class="pg-layouts"></i></span>
          </li>
          <li *ngIf="neuroadmin" [class]="configure">
            <a href="javascript:;">
              <span class="title">Configure</span>
              <span class=" open  arrow"></span>
            </a>
            <span class="icon-thumbnail"><i class="pg-settings"></i></span>
            <ul class="sub-menu nav collapse" role="menu" aria-labelledby="btn-1">
              <li [class]="activities" >
                <a >Activites</a>
                <span class="icon-thumbnail"><i class="fa fa-bolt"></i></span>
              </li>
              <li [class]="authenticators">
                <a >Authenticators</a>
                <span class="icon-thumbnail"><i class="fa fa-key"></i></span>
              </li>			  
      		  <li [class]="riskassessments">
                <a >Risk Assessments</a>
                <span class="icon-thumbnail"><i class="fa fa-exclamation"></i></span>
              </li>
			   <li [class]="channels">
                <a >Channels</a>
                <span class="icon-thumbnail"><i class="fa fa-cubes"></i></span>
              </li>
				<li [class]="ruleconfiguration">
                <a >Rule Configuration</a>
                <span class="icon-thumbnail"><i class="fa pg-note"></i></span>
              </li>
            <li [class]="factlocator">
                <a >Fact Locators</a>
                <span class="icon-thumbnail"><i class="fa fa-database"></i></span>
              </li>
				<li [class]="export">
                <a >Export Configuration</a>
                <span class="icon-thumbnail"><i class="fa fa-download"></i></span>
              </li>
				<li [class]="import">
                <a >Import Configuration</a>
                <span class="icon-thumbnail"><i class="fa fa-upload"></i></span>
              </li>
				
            </ul>  
          </li>
          <li [class]="monitor" >
            <a href="javascript:;">
              <span class="title">Monitor</span>
              <span class=" open  arrow"></span>
            </a>
            <span class="icon-thumbnail"><i class="fa fa-bar-chart"></i></span>
            <ul class="sub-menu nav collapse" role="menu" aria-labelledby="btn-1">
              <li [class]="opsdash" >
                <a >Ops Dashboard</a>
                <span class="icon-thumbnail"><i class="pg-charts"></i></span>
              </li>
			  <li [class]="diagnostics" >
                <a >Diagnostics</a>
                <span class="icon-thumbnail"><i class="fa fa-search"></i></span>
              </li>
            </ul>  
          </li>
        </ul><div class="scroll-element scroll-x scroll-scrolly_visible"><div class="scroll-element_outer"><div class="scroll-element_size"></div><div class="scroll-element_track"></div><div class="scroll-bar" style="width: 89px;"></div></div></div><div class="scroll-element scroll-y scroll-scrolly_visible"><div class="scroll-element_outer"><div class="scroll-element_size"></div><div class="scroll-element_track"></div><div class="scroll-bar" style="height: 142px; top: 0px;"></div></div></div></div>
        <div class="clearfix"></div>
      </div>
      <!-- END SIDEBAR MENU -->
    </nav>
        <div class="page-container ">
            <!-- START HEADER -->
            <span defaultOverlayTarget></span>
            <div class="header"> 
              <div class="container-fluid relative"> 
                <div class="pull-left full-height visible-sm visible-xs"> 
                  <div class="header-inner"> 
                    <a class="btn-link visible-sm-inline-block visible-xs-inline-block padding-5" href="javascript:;" (click)="sidenav.open()"> 
                      <span class="icon-set menu-hambuger"></span> 
                    </a>
                  </div> 
                </div> 
                <div class="pull-center hidden-md hidden-lg"> 
                  <div class="header-inner"> 
                    <div class="brand inline"> 
                      <img [src]='getURL("admin/assets/img/logo.png")' alt="logo" height="22">
                    </div> 
                  </div> 
                </div> 
                <div class="pull-right full-height visible-sm visible-xs"> 
                  <!-- <div class="header-inner"> 
                  <a class="btn-link visible-sm-inline-block visible-xs-inline-block" data-toggle="quickview" data-toggle-element="#quickview" href="#"> 
                    <span class="icon-set menu-hambuger-plus">
                    </span> 
                  </a> 
                  </div>  -->
                </div> 
              </div>
            <header></header>
            </div>
                <div class="page-content-wrapper ">
                  <router-outlet></router-outlet>   
               
                </div>
        </div>
</md-sidenav-container>
  
 <footer></footer>`
})
export class Admin{
    dashboard:string;
    wizard:string;
    activities:string;
    authenticators:string;
    configure:string;
    monitor: string;
    opsdash: string;
	riskassessments: string;
    export:string;
    import:string;
    diagnostics:string;
    subscription: Subscription;
    message:string;
    redirURL: string;
	channels: string;
	ruleconfiguration:string; 
  factlocator:string;
	neuroadmin:boolean = true;
    private ngUnsubscribe: Subject<void> = new Subject<void>();

    ngOnDestroy(){
      this.ngUnsubscribe.next();
      this.ngUnsubscribe.complete();
    }

    constructor(private route: ActivatedRoute,private router:Router,
				private messageService: MessageService,private sanitizer:DomSanitizer, 
				private authGuard: AuthGuard, private globalService: GlobalService, private apiService: APIService){
		this.dashboard='active';
      	 
	  	this.apiService.isLoggedIn().then((response:any) => {
				var apiData = JSON.parse(response._body);

				if(apiData && apiData.userole){
					this.globalService.userRole = apiData.userole;
				}

				if(this.globalService.userRole == "neuroadmin"){
					this.neuroadmin = true;
				}
				else{
					this.neuroadmin = false;
				}	
			}).catch(error => {
				console.log(error);
		});	 
		
        this.subscription = this.messageService.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => { 
            this.message = message; 
            this.authGuard.checkAuth(message.text);
            this.redirURL= message.text.split('/')[1];
            /* setting the sidebar option active based on the navigation link */ 
            switch(this.redirURL){
                case 'dashboard': 
                        this.wizard=this.configure=this.activities=this.authenticators=this.opsdash=
							this.riskassessments=this.export=this.import=this.monitor=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.dashboard='active';
                        break;
                case 'ActivityWizard': 
                        this.dashboard=this.configure=this.activities=this.authenticators=this.opsdash=
							this.riskassessments=this.export=this.import=this.monitor=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.wizard='active';
                        break;
                case 'activities': 
                        this.dashboard=this.wizard=this.authenticators=this.opsdash=this.riskassessments=
							this.export=this.import=this.monitor=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.configure='active';
                        this.activities= 'active';
                        break;
                case 'authenticators':
                        this.dashboard=this.wizard=this.activities=this.opsdash=
							this.export=this.import=this.riskassessments=this.monitor=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.configure='active';
                        this.authenticators='active';
                        break;
                case 'opsdash':
                        this.dashboard=this.wizard=this.activities=this.configure=
						this.export=this.import=this.riskassessments=this.authenticators=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.opsdash='active';
                        this.monitor='active';
                        break;
				case 'diagnostics':
                        this.dashboard=this.wizard=this.activities=this.configure=
						this.export=this.import=this.riskassessments=this.authenticators=this.opsdash=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.diagnostics='active';
                        this.monitor='active';
                        break;
				case 'riskassessments':
					this.dashboard=this.wizard=this.activities=this.monitor=
						this.export=this.import=this.authenticators=this.opsdash=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.configure='active';
                        this.riskassessments='active';
                        break;
				case 'export':
					this.dashboard=this.wizard=this.activities=this.monitor=
						this.riskassessments=this.import=this.authenticators=this.opsdash=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.configure='active';
                        this.export='active';
                        break;
				case 'import':
					this.dashboard=this.wizard=this.activities=this.monitor=
						this.export=this.riskassessments=this.authenticators=this.opsdash=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.configure='active';
                        this.import='active';
                        break;
				case 'channels':
					this.dashboard=this.wizard=this.activities=this.monitor=
						this.export=this.riskassessments=this.authenticators=this.opsdash=this.diagnostics=this.import=this.ruleconfiguration=this.factlocator="";
                        this.configure='active';
                        this.channels='active';
                        break;
				case 'ruleconfiguration':
					this.dashboard=this.wizard=this.activities=this.monitor=
						this.export=this.riskassessments=this.authenticators=this.opsdash=this.diagnostics=this.import=this.channels=this.factlocator="";
                        this.configure='active';
                        this.ruleconfiguration='active';
                        break;
        	case 'factlocator':
					this.dashboard=this.wizard=this.activities=this.monitor=
						this.export=this.riskassessments=this.authenticators=this.opsdash=this.diagnostics=this.import=this.ruleconfiguration=this.channels="";
                        this.configure='active';
                        this.factlocator='active';
                        break;
                default:
                        this.wizard=this.activities=this.authenticators=this.opsdash=
							this.export=this.import=this.monitor=this.riskassessments=this.diagnostics=this.channels=this.ruleconfiguration=this.factlocator="";
                        this.dashboard='active';
                        break;
            }
        });
   }


  getURL(url:string) {
     
      return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
 
     
}