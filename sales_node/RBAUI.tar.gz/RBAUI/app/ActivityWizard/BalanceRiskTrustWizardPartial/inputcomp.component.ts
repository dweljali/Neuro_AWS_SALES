/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import{ BalanceRiskAuthenticatorsComponent} from './balanceRiskAuthenticators.component';

import { APIService } from './../../services/APIService.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from '../../services/tabsService'
import {BalanceRiskTrustWizardPartialComponent} from './balanceRiskTrustWiz.component'
@Component({
    selector: 'listauthn',
    template: ` <label>{{authname}}</label>
    <input type="text" class="form-control" (keypress)="_keyPress($event)" maxlength="3" required (change)="changeData($event.target.value,authname)" (paste)="false" value={{authscore}}>`,
    providers: [APIService]
})

export class AuthenticatorList{
    @Input() authname:string;
    @Input() authscore:number;
    @Output() callparent:EventEmitter<any>=new EventEmitter<any>();
    name:string;
     
    constructor(private balance:BalanceRiskAuthenticatorsComponent){
       
        if(this.authscore){
            this.authscore = 0
        }
        
        balance.addToList(this);
    }
  
    ngOninit(){
        this.name=this.authname;
         
    }
    
    /* Function to validate score on keypress*/ 
    _keyPress(event: any) {
         var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft','Home','Delete','Tab'];

        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(event.charCode);

        if(arrint.indexOf(event.key) != -1 ){
        return;
        }
        else if (!pattern.test(inputChar)) {
        // invalid character, prevent input
        event.preventDefault();
        }
    }

    /* Function to trigger calculate total score on change of scores*/     
    changeData(score:number,name:string){

        var arg={}
        arg["name"]=name;
        arg["score"]=score;
        this.callparent.emit(arg);
    }
}