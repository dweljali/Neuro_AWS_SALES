/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component,Input } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';

export class CustomAlertModelData extends BSModalContext {
  public message: string;
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-alert-content',
  template: `
   <div class="custModal">
        <div class="modal-dialog" [class.customfade]="isFade">             
                  <div class="modal-header clearfix text-left">
                    <h5>{{context.message}}</h5>
                    <!--<p class="p-b-10">Nullam leo nisl, posuere non ligula vel, tempor fringilla turpis. Integer suscipit risus neque, in interdum tellus mollis ac. Vivamus eu nunc a lectus commodo iaculis ut in massa.</p>-->
                  </div>
            <div class="modal-footer">
                  <button id="add-app" data-dismiss="modal" type="button" (click)='closebox()' class="btn btn-primary  btn-cons">Ok</button>
            </div>                              
            </div>
            </div>`
})
export class RiskAlertModelData implements CloseGuard, ModalComponent<CustomAlertModelData> {
  context: CustomAlertModelData;
  public isFade = false;
  public returndata:any; 

  constructor(public dialog: DialogRef<CustomAlertModelData>) {
    this.context = dialog.context;
    dialog.setCloseGuard(this);
  }
  
  closebox(){
    this.isFade = true;
    this.dialog.close(this.returndata);
  }

  beforeDismiss(): boolean {
    this.dialog.close(this.returndata);
    this.isFade = true;
    return false;
  }
}
