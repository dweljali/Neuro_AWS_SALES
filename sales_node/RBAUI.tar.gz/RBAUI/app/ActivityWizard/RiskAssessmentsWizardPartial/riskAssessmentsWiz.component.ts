/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from '../../services/tabsService';
import { AuthService } from '../../services/auth.service';
import { Subject } from 'rxjs/Subject';
import * as myGlobals from './../../common/appMessages';
import { AlertModelData } from './../../common/alertModal.component';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { RULES_MSG } from './../appActivityWizardMessage';

const defaultIR: Object[] = [{ 'id': "ALL", 'text': "All Users" }];
const defaultER: Object[] = [{ 'id': "NA", 'text': "None" }];

@Component({
  selector: 'risk-assessments-partial',
  template: require('./RiskAssessmentsWiz.html'),
  providers: [APIService]
})
export class RiskAssessmentsWizardPartialComponent {

  public pcholder: string;
  public pcholder2: string;
  public pcholder3: string;
  public disablegrid: boolean = false;
  public mode: boolean = true;
  public riskos: Object[] = [];
  public riskea: Object[] = [];
  public selectedIRID: string = 'ALL';
  public selectedERID: string = 'NA';
  public activeIR: Object[] = defaultIR.slice();
  public activeER: Object[] = defaultER.slice();
  public activeRiskOS: Object[] = [];
  public activeRiskEA: Object[] = [];
  public activeRiskscore: Object[] = [];
  public riskScore: number = 0;
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  public riskMethodType: string = "Total";
  private tabContentEA: string = myGlobals.ACTIVITY_WIZ_RISK_EA_CONTENT;
  private tabContentOS: string = myGlobals.ACTIVITY_WIZ_RISK_OS_CONTENT;
  public IR: any = [];
  public ER: any = [];

  public hideerrormsg: boolean = true;
  public rulesErrormessage: string = RULES_MSG;
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(
    private service: APIService,
    private route: ActivatedRoute,
    private tabs: TabsService,
    private auth: AuthService,
    private globalService: GlobalService,
    public modal: Modal,
    vcRef: ViewContainerRef,
  ) {
    this.loadData();
    if (this.globalService.mode == "demo") {
      this.mode = false;
    }
    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
      if (message.text == "postRisk") {
        if (message.next == "confirm" || message.next == "balance") { this.postRisk(message.next); }
        else { this.postRisk(null); }

      }
    })
  }

  /* Function to save risk assesments tab details*/
  postRisk(msg: string) {
    var objscore: any;
    this.riskScore = 0;
    var riskfactorlength = 0;
    for (let i = 0; i < this.activeRiskscore.length; i++) {
      objscore = parseInt(this.activeRiskscore[i]["outputpoint"]);
      riskfactorlength = riskfactorlength +
        (parseInt(this.activeRiskscore[i]["riskfactorcount"]) > 0 ?
          parseInt(this.activeRiskscore[i]["riskfactorcount"]) : 1)

      if (this.riskMethodType.toUpperCase().trim() == "MAX") {
        if (this.riskScore < objscore) {
          this.riskScore = objscore;
        }
      }
      else {

        //Total by default
        this.riskScore = this.riskScore + objscore;
      }
    }

    //Calculate Average risk score
    if (this.riskMethodType.toUpperCase().trim() == "AVG") {
      if (riskfactorlength > 0) {
        this.riskScore = Math.ceil(this.riskScore / riskfactorlength);
      }
    }
    if (!this.activeRiskEA.length) {
      this.activeIR = defaultIR.slice();
      this.selectedIRID = defaultIR[0]['id'];

      this.activeER = defaultER.slice();
      this.selectedERID = defaultER[0]['id'];
    }

    let incRuleName = this.IR.find((val: Object) => { return val['id'] == this.selectedIRID });
    let excRuleName = this.ER.find((val: Object) => { return val['id'] == this.selectedERID });
    this.service.postRiskAssesment({
      activeRiskOS: this.activeRiskOS,
      activeRiskEA: this.activeRiskEA,
      activeRiskscore: this.activeRiskscore,
      riskScore: this.riskScore,
      inclusionRuleId: this.selectedIRID,
      inclusionRulename: incRuleName ? incRuleName['text'] : '',
      exclusionRuleId: this.selectedERID,
      exclusionRulename: excRuleName ? excRuleName['text'] : ''
    }).then(response => {
      var data = response._body;
      data = JSON.parse(data);
      if (data.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
      if (msg) {
        this.tabs.sendMessage(msg, "")
      }
    }).catch(error => { console.log(error) });

    this.toggleRulesErrorMsg();
  }

  /* Function to load data incase of edit */
  loadData() {
    this.pcholder = "Select Risk Assessment";
    this.pcholder2 = "Select One";
    this.pcholder3 = "For all users";
    this.service.getRiskAssesment().then(response => {
      var data = response._body;
      data = JSON.parse(data);

      this.riskos = [];
      if (data.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
      else {
        if (data.os) {
          for (let i = 0; i < data.os.length; i++) {
            this.riskos.push({
              id: data.os[i].riskAssessmentCD.toString(),
              text: data.os[i].riskAssessmentName.toString(),
              outputpoint: data.os[i].outputPoint,
              riskfactorcount: data.os[i].riskfactorcount
            });
          }
          this.riskos.sort((rea1: Object, rea2: Object) => rea1['text'].localeCompare(rea2['text']));
        }

        this.riskea = [];
        if (data.ea) {
          for (let i = 0; i < data.ea.length; i++) {
            this.riskea.push({
              id: data.ea[i].riskAssessmentCD.toString(),
              text: data.ea[i].riskAssessmentName.toString(),
              outputpoint: data.ea[i].outputPoint,
              riskfactorcount: data.ea[i].riskfactorcount
            });
          }
          this.riskea.sort((rea1: Object, rea2: Object) => rea1['text'].localeCompare(rea2['text']));
        }

        if (data.activeRiskOS) {
          this.activeRiskOS = data.activeRiskOS
        }
        if (data.activeRiskEA) {
          this.activeRiskEA = data.activeRiskEA
        }
        if (data.activeRiskscore) {
          this.activeRiskscore = data.activeRiskscore;
        }
        if (data.riskMethodType) {
          this.riskMethodType = data.riskMethodType;
        }
        if (data.riskInclusionExclusion) {
          this.IR = defaultIR.slice();
          this.ER = defaultER.slice();
          data.riskInclusionExclusion.forEach((rule: Object) => {
            this.IR.push(rule);
            this.ER.push(rule);
          });


        }
        if (data.inclusionRuleId) {
          let rule = this.IR.filter((rule: Object) => { return rule['id'] == data.inclusionRuleId });
          this.activeIR = rule.length ? rule : defaultIR.slice();
          this.selectedIRID = this.activeIR[0]['id'];

        }

        if (data.exclusionRuleId) {
          let rule = this.ER.filter((rule: Object) => { return rule['id'] == data.exclusionRuleId });
          this.activeER = rule.length ? rule : defaultER.slice();
          this.selectedERID = this.activeER[0]['id'];
        }

      }
    }).catch(error => { console.log(error) });
  }

  /* Function triggered when risk assessments of once per session are selected*/
  selectedvaluelistos(arg: any) {
    this.activeRiskOS.push(arg);
    for (let i = 0; i < this.riskos.length; i++) {
      if (this.riskos[i]["id"] == arg.id) {
        this.activeRiskscore.push({
          id: arg.id,
          outputpoint: this.riskos[i]["outputpoint"],
          riskfactorcount: this.riskos[i]["riskfactorcount"]
        });
        break;
      }
    }
  }
  selectedvaluelistIR(data: any) {

    if (this.selectedERID) {
      if (this.selectedERID != data['id']) {
        this.selectedIRID = data['id']
      } else {
        this.activeIR = this.IR.filter((rule: Object) => rule['id'] == this.selectedIRID);
        this.openModal('Inclusion rule cannot be same as exclusion rule.');
      }
    } else {
      this.selectedIRID = data['id']
    }
    this.toggleRulesErrorMsg();
  }
  selectedvaluelistER(data: any) {
    if (this.selectedIRID && (data['id'] != 'NA')) {
      if (this.selectedIRID != data['id']) {
        this.selectedERID = data['id']
      } else {
        this.activeER = this.ER.filter((rule: Object) => rule['id'] == this.selectedERID);
        this.openModal('Exclusion rule cannot be same as inclusion rule.');
      }

    } else {
      this.selectedERID = data['id']
    }
    this.toggleRulesErrorMsg();
  }
  /* Function that displays modal upon validation error on authenticators tab*/
  openModal(msg: string) {
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
      {
        isBlocking: true,
        message: msg,
        headtext: "Validation error"
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
      });
    });
  }
  /* Function triggered when risk assessments of once per session are removed*/
  removelistos(arg: any) {
    for (let i = 0; i < this.activeRiskOS.length; i++) {
      if (this.activeRiskOS[i]["id"] == arg.id) {
        delete this.activeRiskOS.splice(i, 1);
        break;
      }
    }

    for (let i = 0; i < this.activeRiskscore.length; i++) {
      if (this.activeRiskscore[i]["id"] == arg.id) {
        delete this.activeRiskscore.splice(i, 1);
        break;
      }
    }
  }

  /* Function triggered when risk assessments of activity start are selected*/
  selectedvaluelistea(arg: any) {
    this.activeRiskEA.push(arg);
    for (let i = 0; i < this.riskea.length; i++) {
      if (this.riskea[i]["id"] == arg.id) {
        this.activeRiskscore.push({
          id: arg.id,
          outputpoint: this.riskea[i]["outputpoint"],
          riskfactorcount: this.riskea[i]["riskfactorcount"]
        });
        break;
      }
    }
    this.toggleRulesErrorMsg();
  }

  /* Function triggered when risk assessments of activity start are removed*/
  removelistea(arg: any) {
    for (let i = 0; i < this.activeRiskEA.length; i++) {
      if (this.activeRiskEA[i]["id"] == arg.id) {
        delete this.activeRiskEA.splice(i, 1);
        break;
      }
    }
    //if zero risk assessment, then set IR, ER to default values
    if (!this.activeRiskEA.length) {
      this.activeIR = defaultIR.slice();
      this.selectedIRID = this.activeIR[0]['id'];

      this.activeER = defaultER.slice();
      this.selectedERID = this.activeER[0]['id'];
    }
    this.toggleRulesErrorMsg();
    for (let i = 0; i < this.activeRiskscore.length; i++) {
      if (this.activeRiskscore[i]["id"] == arg.id) {
        delete this.activeRiskscore.splice(i, 1);
        break;
      }
    }
  }
  toggleRulesErrorMsg() {

    if (((this.selectedIRID && this.selectedIRID != 'ALL') || (this.selectedERID && this.selectedERID != 'NA')) && !this.activeRiskEA.length) {
      this.hideerrormsg = false;
    } else {
      this.hideerrormsg = true;
    }
  }
  /* Function triggered on click of save button*/
  save() {
    if (this.selectedERID && this.selectedERID != 'NA' && (!this.selectedIRID || this.selectedIRID == 'NA')) {
      this.openModal("Exclusion rule exists, please select inclusion rule.");
    }
    else {
      this.postRisk("authenticator");
    }
  }

  /* Function to navigate to the previous tab*/
  previous() {
    this.postRisk(null);
    this.tabs.sendMessage("activity", "");
  }

}