/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Ng2PaginationModule } from 'ng2-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
// import { NgDateRangePickerModule } from 'ng-daterangepicker';
import { MyDatePickerModule } from 'mydatepicker';
import { HttpModule, XSRFStrategy, CookieXSRFStrategy } from '@angular/http';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { DashboardComponent } from './Dashboard/dashboard.component';
import { ActivitiesComponent, ActivityModalComponent } from './Configuration/Activities/activities.component';
import { AuthenticatorsComponent } from './Configuration/Authenticators/authenticators.component';
import { authenticatorModalComponent } from './Configuration/Authenticators/authenticators.component';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Header } from './common/header.component';
import { Footer } from './common/footer.component';
import { SideBar } from './common/sidebar.component';
import { Card } from './Dashboard/card.component';
import { MaterialModule } from '@angular/material';
import { ToastyModule } from 'ng2-toasty';
import 'hammerjs';
import { ActivityWizardComponent } from './ActivityWizard/activityWizard.component';
import { ActivityWizardPartialComponent } from './ActivityWizard/ActivityWizardPartial/activityWiz.component';
import { AuthenticatorsWizardPartialComponent } from './ActivityWizard/AuthenticatorsWizardPartial/authenticatorsWiz.component'
import { BalanceRiskTrustWizardPartialComponent } from './ActivityWizard/BalanceRiskTrustWizardPartial/balanceriskTrustWiz.component'
import { ConfirmWizardPartialComponent } from './ActivityWizard/ConfirmWizardPartial/confirmWiz.component'
import { RiskAssessmentsWizardPartialComponent } from './ActivityWizard/RiskAssessmentsWizardPartial/riskAssessmentsWiz.component'
import { APIService } from './services/APIService.service';
import { routing } from './routes/app.routes';
import { MessageService } from './services/MessageService';
import { GlobalService } from './services/globalFunctions.service';
import { SettingsService } from './services/settings.service';
import { Tab } from './common/tab.component';
import { Tabs } from './common/tabs.component';
import { Table } from './common/table.component';
import { DropdownComponent } from './common/dropdown.component';
import { selectComponent } from './common/select.component';
import { multiselectComponent } from './common/multiselect.component';
import { DateTimePickerComponent } from './common/dateTImePicker.component';
import { ChartCardComponentAT } from './Monitor/OperationsDashboard/opsDisplayCardAT.component';
import { ChartCardComponentRSI } from './Monitor/OperationsDashboard/opsDisplayCardRSI.component';
import { ChartCardComponentAF } from './Monitor/OperationsDashboard/opsDisplayCardAF.component';
import { ChallengeModel } from './Configuration/Authenticators/authenticator-modal';
import { ActivityeModel } from './Configuration/Activities/activities-modal';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
import { TabsService } from './services/tabsService';
import { BalanceRiskAuthenticatorsComponent } from './ActivityWizard/BalanceRiskTrustWizardPartial/balanceRiskAuthenticators.component';
import { AuthenticatorList } from './ActivityWizard/BalanceRiskTrustWizardPartial/inputcomp.component';
import { Login } from './Login/login.component';
import { Admin } from './admin.component';
import { App } from './app.component';
import { loginrouting } from './routes/login.routes';
import { AuthGuard } from './services/authguard.service';
import { AuthService } from './services/auth.service';
import { RiskAlertModelData } from './ActivityWizard/BalanceRiskTrustWizardPartial/riskAlertModal.component';
import { RiskeModel } from './Configuration/Riskassessments/risk-modal';
import { SelectModule } from 'ng2-select';
import { ConfirmModelData } from './common/confirmModal.component';
import { AlertModelData } from './common/alertModal.component';
import { OpsDashboardComponent } from './Monitor/OperationsDashboard/opsDashboard.component';
import { OrderByPipe } from './common/orderBy.component';
import { SearchPipe } from './common/searchFilter.component';
import { enableProdMode } from '@angular/core';
import { riskassessmentsComponent } from './Configuration/Riskassessments/riskassessments.component';
import { risktable } from './Configuration/Riskassessments/risktable.component';
import { riskscoretable } from './Configuration/Riskassessments/riskscoretable.component';
import { riskfactortable } from './Configuration/Riskassessments/riskfactortable.component';
import { ExportWizardComponent } from './Configuration/Export/exportWizard.component';
import { ExportTypePartialComponent } from './Configuration/Export/ExportType/exportType.component';
import { objectTypeTable } from './common/objectTypeTable.component';
import { ObjectTypePartialComponent } from './Configuration/Export/ObjectType/objectType.component';
import { UiSwitchModule } from 'angular2-ui-switch';
import { ConfirmExportPartialComponent } from './Configuration/Export/ConfirmExport/confirmExport.component';
import { exportTable } from './common/exportTable.component';
import { ImportWizardComponent } from './Configuration/Import/importWizard.component';
import { importTypeComponent } from './Configuration/Import/ImportType/importType.component';
import { selectImportFileComponent } from './Configuration/Import/SelectFile/selectImportFile.component';
import { ConfirmImportComponent } from './Configuration/Import/ConfirmImport/confirmImport.component';
import { riskDetailsComponent } from './Configuration/Riskassessments/RiskWizard/RiskDetails/riskDetails.component';
import { riskConfirmComponent } from './Configuration/Riskassessments/RiskWizard/Confirm/riskConfirm.component';
import { riskWizardComponent } from './Configuration/Riskassessments/RiskWizard/riskWizard.component';
import { riskConfigurationComponent } from './Configuration/Riskassessments/RiskWizard/RiskConfigurations/riskConfigurations.component';
import { riskConfigModalComponent } from './Configuration/Riskassessments/RiskWizard/RiskConfigurations/riskConfigurations.component';
import { riskConfigurationModal } from './Configuration/Riskassessments/RiskWizard/RiskConfigurations/addRiskConfigurationModal';
import { riskFactorsComponent } from './Configuration/Riskassessments/RiskWizard/RiskFactors/riskFactors.component';
import { riskFactorModalComponent } from './Configuration/Riskassessments/RiskWizard/RiskFactors/riskFactors.component';
import { riskFactorModal } from './Configuration/Riskassessments/RiskWizard/RiskFactors/addRiskFactorModal';
import { riskwiztable } from './common/riskassessmentwiztable.component';
import { opsModel } from './Monitor/OperationsDashboard/opsmodal';
import { DiagnosticsComponent } from './Monitor/Diagnostics/diagnostics.component';
import { diagnosticsTable } from './Monitor/Diagnostics/diagnosticTable.component';
import { diagnosticsActivityTable } from './Monitor/Diagnostics/diagnosticTableActivities.component';
import { diagnosticsRiskTable } from './Monitor/Diagnostics/diagnosticTableRisk.component';
import { diagnosticsFactorTable } from './Monitor/Diagnostics/diagnosticTableRiskfactor.component';
import { OpsWidgetComponent } from './Monitor/OperationsDashboard/opsWidget.coponent';
import { channelTable } from './Configuration/Channels/channeltable.component';
import { channelsComponent } from './Configuration/Channels/channels.component';
import { channelModalComponent } from './Configuration/Channels/channels.component';
import { ChannelModal } from './Configuration/Channels/channel-modal';
import {  flModal } from './Configuration/Factlocators/flModalPopup';
import { riskwizConfigTable } from './Configuration/Riskassessments/RiskWizard/RiskConfigurations/riskWizardConfigTable.component';
import { riskwizFactorsTable } from './Configuration/Riskassessments/RiskWizard/RiskFactors/riskWizardFactorsTable.component';
import { riskConfigEditModalComponent } from './Configuration/Riskassessments/RiskWizard/RiskConfigurations/riskConfigurationsEdit.component';
import { riskFactorEditModalComponent } from './Configuration/Riskassessments/RiskWizard/RiskFactors/riskFactorsEdit.component';
import { ruleconfigurationComponent } from './Configuration/RuleConfiguration/ruleconfiguration.component';
import { rulewizardComponent } from './Configuration/RuleConfiguration/RuleWizard/rulewizard.component';
import { ruleTable } from './Configuration/RuleConfiguration/ruletable.component';
import { RuleIDService } from './Configuration/RuleConfiguration/ruleID.service';
import { OTPComponentModal } from './AuthComponents/otp.component';
import { factlocatorModalComponent } from './Configuration/Factlocators/factlocator.component';
import { factlocatorComponent } from './Configuration/Factlocators/factlocator.component';
import { factlocatorTable } from './Configuration/Factlocators/factlocator-table.component';
//import { FactModal1 } from './Configuration/FactLocators/factLocatorModal';
import { FactLocatorService } from './services/factLocator.service';
import { LimitPipe } from './common/limit.pipe';
//import {DiagnosticsModelData} from './Monitor/Diagnostics/diagnostics-modal';
//import {DiagnosticsModal} from './Monitor/Diagnostics/diagnostics-modal';
enableProdMode();

@NgModule({

    imports: [routing, loginrouting, BrowserModule, FormsModule, MaterialModule, HttpModule, ModalModule.forRoot(),
        BootstrapModalModule, Ng2PaginationModule, SelectModule, ToastyModule.forRoot(),
        ChartsModule, MyDatePickerModule, UiSwitchModule, ReactiveFormsModule],
    declarations: [App,
        Admin,
        DashboardComponent,
        ActivitiesComponent,
        AuthenticatorsComponent,
        ChartCardComponentAT,
        ChartCardComponentRSI,
        ChartCardComponentAF,
        DateTimePickerComponent,
        Footer,
        Header,
        SideBar,
        Card,
        ActivityWizardComponent,
        ActivityWizardPartialComponent,
        AuthenticatorsWizardPartialComponent,
        BalanceRiskTrustWizardPartialComponent,
        ConfirmWizardPartialComponent,
        RiskAssessmentsWizardPartialComponent,
        Tabs,
        Tab,
        Table,
        factlocatorTable,
        DropdownComponent,
        selectComponent,
        multiselectComponent,
        authenticatorModalComponent,
        ActivityModalComponent,
        ChallengeModel,
        ActivityeModel,
        BalanceRiskAuthenticatorsComponent,
        AuthenticatorList,
        Login,
        RiskAlertModelData,
        ConfirmModelData,
        AlertModelData,
        RiskeModel,
        OpsDashboardComponent,
        OrderByPipe,
        SearchPipe,
        riskassessmentsComponent,
        risktable,
        riskscoretable,
        riskfactortable,
        ExportWizardComponent,
        ExportTypePartialComponent,
        objectTypeTable,
        ObjectTypePartialComponent,
        ConfirmExportPartialComponent,
        exportTable,
        ImportWizardComponent,
        importTypeComponent,
        selectImportFileComponent,
        ConfirmImportComponent,
        riskDetailsComponent,
        riskConfirmComponent,
        riskWizardComponent,
        riskConfigurationComponent,
        riskConfigurationModal,
        riskConfigModalComponent,
        riskFactorsComponent,
        riskFactorModalComponent,
        riskFactorModal,
        riskwiztable,
        opsModel,
        DiagnosticsComponent,
        diagnosticsTable,
        diagnosticsActivityTable,
        diagnosticsRiskTable,
        diagnosticsFactorTable,
        channelTable,
        channelModalComponent,
        channelsComponent,
        factlocatorComponent,
        ChannelModal,
        flModal,
        riskwizConfigTable,
        riskwizFactorsTable,
        riskConfigEditModalComponent,
        riskFactorEditModalComponent,
        ruleconfigurationComponent,
        rulewizardComponent,
        ruleTable,
        OTPComponentModal,
        factlocatorModalComponent,
        OpsWidgetComponent,
        LimitPipe
        ],
    bootstrap: [App],
    providers: [{ provide: XSRFStrategy, useValue: new CookieXSRFStrategy('csrfToken', 'x-csrf-token') },
        APIService, MessageService, TabsService, AuthGuard, AuthService, GlobalService,
        RuleIDService,
        SettingsService,FactLocatorService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    entryComponents: [ChallengeModel,
        RiskAlertModelData,
        ActivityeModel,
        ConfirmModelData,
        AlertModelData,
        RiskeModel,
        riskConfigurationModal,
        riskFactorModal,
        opsModel,
        ChannelModal,
        flModal,
        OTPComponentModal,
        ]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);