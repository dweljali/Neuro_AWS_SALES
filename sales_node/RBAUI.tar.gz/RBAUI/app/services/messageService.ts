/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Injectable, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class MessageService {
	private subject = new Subject<any>();
	@Output() openSubmenu: EventEmitter<string> = new EventEmitter();
	sendMessage(message: string) {
		this.subject.next({ text: message });
	}

	clearMessage() {
		this.subject.next();
	}

	getMessage(): Observable<any> {
		return this.subject.asObservable();
	}

	/* Function to highlight the sidebar menus based upon the nabvigation url */
	highlightSidebar(url: string) {
		let objdash = document.getElementById('dashboard');
		let objwiz = document.getElementById('wizard');
		let objact = document.getElementById('activities');
		let objauth = document.getElementById('authenticators');
		let objconf = document.getElementById('configure');
		let objmon = document.getElementById('monitor');
		let opsdash = document.getElementById('opsdash');
		let objriskassessments = document.getElementById('riskassessments');
		let objexport = document.getElementById('export');
		let objimport = document.getElementById('import');
		let objdiagnostics = document.getElementById('diagnostics');
		let objchannels = document.getElementById('channels');
		let objrules = document.getElementById('ruleconfiguration');
		let objfactolocator =  document.getElementById('factlocator');
		if (objdash && objdash.classList) { objdash.classList.remove('active'); }
		if (objwiz && objwiz.classList) { objwiz.classList.remove('active'); }
		if (objconf && objconf.classList) { objconf.classList.remove('active'); }
		if (objact && objact.classList) { objact.classList.remove('active'); }
		if (objauth && objauth.classList) { objauth.classList.remove('active'); }
		if (objmon && objmon.classList) { objmon.classList.remove('active'); }
		if (opsdash && opsdash.classList) { opsdash.classList.remove('active'); }
		if (objexport && objexport.classList) { objexport.classList.remove('active'); }
		if (objimport && objimport.classList) { objimport.classList.remove('active'); }
		if (objdiagnostics && objdiagnostics.classList) { objdiagnostics.classList.remove('active'); }
		if (objriskassessments && objriskassessments.classList) { objriskassessments.classList.remove('active'); }
		if (objchannels && objchannels.classList) { objchannels.classList.remove('active'); }
		if (objrules && objrules.classList) { objrules.classList.remove('active'); }
		if(objfactolocator && objfactolocator.classList) {objfactolocator.classList.remove('active');}
		switch (url) {
			case 'dashboard':
				if (objdash && objdash.classList) {
					objdash.classList.add('active');
				}
				break;

			case 'ActivityWizard':
				if (objwiz && objwiz.classList) {
					objwiz.classList.add('active');

				}
				break;
			case 'activities':
				if (objconf && objconf.classList && objact && objact.classList) {
					objconf.classList.add('active');
					objact.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'authenticators':
				if (objconf && objconf.classList && objauth && objauth.classList) {
					objconf.classList.add('active')
					objauth.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'opsdash':
				if (objmon && objmon.classList && opsdash && opsdash.classList) {
					objmon.classList.add('active');
					opsdash.classList.add('active');
					this.openSubmenu.emit('submenu2')
				}
				break;
			case 'channels':
				if (objconf && objconf.classList && objchannels && objchannels.classList) {
					objconf.classList.add('active');
					objchannels.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'ruleconfiguration':
				if (objconf && objconf.classList && objrules && objrules.classList) {
					objconf.classList.add('active');
					objrules.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'factlocator':
				if (objconf && objconf.classList && objfactolocator && objfactolocator.classList) {
					objconf.classList.add('active');
					objfactolocator.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'riskassessments':
				if (objconf && objconf.classList && objriskassessments && objriskassessments.classList) {
					objconf.classList.add('active');
					objriskassessments.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'export':
				if (objconf && objconf.classList && objexport && objexport.classList) {
					objconf.classList.add('active');
					objexport.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'import':
				if (objconf && objconf.classList && objimport && objimport.classList) {
					objconf.classList.add('active');
					objimport.classList.add('active');
					this.openSubmenu.emit('submenu1')
				}
				break;
			case 'diagnostics':
				if (objmon && objmon.classList && objdiagnostics && objdiagnostics.classList) {
					objmon.classList.add('active');
					objdiagnostics.classList.add('active');
					this.openSubmenu.emit('submenu2')
				}
				break;
			default:
				break;

		}
	}

}
