import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import {APIService} from './APIService.service'
@Injectable()
export class AuthService {
  isLoggedIn: boolean = false;
  firstName: string='';
  lastName: string='';
  data: Object= {};
  authInvalid: boolean = false;
  constructor(private service:APIService){
     
  }

  /* store the URL so we can redirect after logging in */ 
  redirectUrl: string;

  login(data:Object): void {
  }

  /* Function to clear stored user details on logout */ 
  logout(): void {
    this.isLoggedIn = false;
    this.firstName= '';
    this.lastName= '';
  }

  /* Function to store user details on login */ 
  setLoggged(value:boolean, firstName:string, lastName: string){
    this.isLoggedIn=value;
    this.firstName= firstName;
    this.lastName = lastName;
  }

  /* Function to get stored details of loggedin user */ 
  getLoggedDetails(): Object{
      
    this.data['firstName']= this.firstName;
    this.data['lastName']= this.lastName;
    this.data['isLoggedIn']= this.isLoggedIn;
    return this.data;
  }

}
