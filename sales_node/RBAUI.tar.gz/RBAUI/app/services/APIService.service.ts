/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, URLSearchParams, QueryEncoder } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class APIService {

	constructor(private http: Http) { }

	/* Set header details*/

	setHttpHeaders() {
		let headers = new Headers();
		headers.append('Content-Type', 'application/json; charset=utf-8');
		headers.append("Cache-Control", "no-cache");
		headers.append("Cache-Control", "no-store");
		headers.append("If-Modified-Since", "Mon, 26 Jul 1997 05:00:00 GMT");
		return headers;
	}

	/* API call to get total Activity count - Dashboard dispaly */
	getActivitiesCount(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/activities/getActivitiesCount', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get total authenticator count - Dashboard dispaly */
	getAuthenticatorsCount(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/authenticators/getAuthenticatorsCount', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/*API call for activate/de-activate Risk Assessment */
	deleteRiskAssesment(id: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.delete(`/admin/api/riskassessments/deleteRiskAssessment/${id}`).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get AF*/
	getAF(startDate: string, endDate: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get(`/admin/api/opsdashboard/userCards/AF/${encodeURI(startDate)}/${encodeURI(endDate)}`, { headers: headers }).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get AT*/
	getAT(startDate: string, endDate: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get(`/admin/api/opsdashboard/userCards/AT/${encodeURI(startDate)}/${encodeURI(endDate)}`, { headers: headers }).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get RSI*/
	getRSI(startDate: string, endDate: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get(`/admin/api/opsdashboard/userCards/RSI/${encodeURI(startDate)}/${encodeURI(endDate)}`, { headers: headers }).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get Rule Fact Services */
	getRuleFacts(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/rules/getRuleFacts', { headers: headers }).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/*  API call for GET Rule by ID   */
	getRuleByID(id: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/rules/getRule/' + id, { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call for POST rules */
	editRule(id: string, data: Object): Promise<any> {
		return this.http.put('/admin/api/rules/editRule/' + id, data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call for POST rules */
	postRules(data: Object): Promise<any> {
		return this.http.post('/admin/api/rules/postRules', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get rules */
	getRuleConditions(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/rules/getRuleConditions', { headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get rules */
	getRules(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/rules/getRules', { headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get risk assessments */
	getRiskAssesments(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/getRiskAssesment', { headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get risk assessment by ID */
	getRiskAssesmentById(id: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/riskassessments/getRiskAssessmentDetails/' + id, { headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to get authenticator list */
	getAuthenticators(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/authenticators/getAuthenticators', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get Total risk assessments - Dashboard dispaly */
	getRiskCount(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/riskAssessments/getRiskCount', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get Total risk assessments - Dashboard dispaly */
	getRuleCount(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/rules/getRuleCount', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get all risk assessments */
	getRiskAssessments(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/riskAssessments/getRiskAssessments', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to delete authenticator */
	deleteAuthenticators(req: any): Promise<any> {
		return this.http.post('/admin/api/authenticators/deleteAuthenticators', req)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get activities list */
	getActivities(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/activities/getActivities', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get an activity details for edit */
	getWizardActivities(activity: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/wizard/activities/' + activity, { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API get risk assessment details by ID */
	getRiskAssessmentDetails(data: any): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/riskAssessments/getRiskAssessmentDetails/' + data.ID, { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API get Diagnostics data */
	getDiagnostics(data: any): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/diagnostics/getDiagnostics/' + data.userid + '/' + data.channel, { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API get risk assessment details by ID */
	getChannels(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/diagnostics/getChannels', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to GET ALL CHANNELS */
	getAllChannels(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/channels/getChannels', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to add new channel */
	postChannels(data: Object): Promise<any> {
		return this.http.post('/admin/api/channels/channel', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to add new channel */
	putChannels(data: Object): Promise<any> {
		return this.http.put('/admin/api/channels/channel', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to delete authenticator */
	deleteChannel(req: any): Promise<any> {
		return this.http.post('/admin/api/channels/deletechannel', req)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to add a new activity */
	postWizardActivities(data: Object): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.post('/admin/api/wizard/activities', data, options)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get risk assessment tab details */
	getRiskAssesment(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/wizard/riskAssesment/', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to post risk assessment tab details */
	postRiskAssesment(data: Object): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.post('/admin/api/wizard/riskAssesment', data, options)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	editRiskAssessment(id: string, data: Object): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.put('/admin/api/riskAssessments/edirRiskAssessmentDetails/' + id, data, options)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}
	/* API call to post risk assessment with risk factors - Risk assessment Wizard */
	postRiskAssessmentsWithFactors(data: Object): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.post('/admin/api/riskAssessments/postRiskAssessmentsWithFactors', data, options)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to add new authenticator */
	postAuthenticators(data: Object): Promise<any> {
		return this.http.post('/admin/api/authenticators/authenticators', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to import Activities */
	importActivities(data: Object): Promise<any> {
		return this.http.post('/admin/api/import/activities', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get authenticator tab details */
	getAuthenticatorsWizard(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/wizard/authenticators/', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get balance and risk tab details */
	getBalanceRiskAuthenticatorsWizard(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/wizard/balanceRiskAuthenticators/', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to activate/de-activate Activities */
	changeActivityStatus(data: Object): Promise<any> {
		return this.http.put('/admin/api/activities/changeActivityStatus', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to save balance and risk tab details */
	postBalanceRiskWizard(data: Object): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.post('/admin/api/wizard/postbalancerisk', data, options)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to save new activity */
	postActivityWizard(data: Object): Promise<any> {
		return this.http.post('/admin/api/wizard/postActivityWizard', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to edit activity */
	putActivityWizard(data: Object): Promise<any> {
		return this.http.post('/admin/api/wizard/putActivityWizard', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to save authenticator tab details */
	postAuthenticatorsWizard(data: Object): Promise<any> {
		let headers = new Headers();
		return this.http.post('/admin/api/wizard/Authenticators', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to edit authenticator */
	updateAuthenticators(data: Object): Promise<any> {
		return this.http.put('/admin/api/authenticators/updateAuthenticators', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get confirm tab details */
	getConfirm(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/wizard/confirm/', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to check if a user is logged in */
	isLoggedIn(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/login', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to clear activity wizard session  */
	clearWizardSession(): Promise<any> {
		return this.http.put('/admin/api/wizard/clearWizardSession', '')
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to login */
	login(data: Object): Promise<any> {
		return this.http.post('/admin/api/login', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to logout */
	logout(data: Object): Promise<any> {
		return this.http.put('/admin/api/logout', data)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to refresh cache */
	refreshCache(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/login/refreshCache', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get Logged in User Details */
	getLoggedInUserDetails(): Promise<any> {
		let headers = this.setHttpHeaders();
		headers.append('Content-Type', 'application/json; charset=utf-8');
		return this.http.get('/admin/api/login/getLoggedInUserDetails', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to delete an activity */
	deleteActivity(data: Object): Promise<any> {
		return this.http.post('/admin/api/activities/deleteActivity', data).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));;
	}

	/* API call to edit an activity */
	editActivity(data: Object): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.post('/admin/api/activities/editActivity', data, options).toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));;
	}

	/* API call to check if a user is logged in */
	verifyLoggedIn(): Promise<any> {
		let headers = this.setHttpHeaders();
		let options = new RequestOptions({ headers: headers });
		return this.http.get('/admin/api/isLoggedIn', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get chart data for Monitor ops dashboard */
	getChartData(data: any, type: string): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/opsdashboard/getChartData/' + data.duration + '/' + data.startDate + '/' + data.endDate + '/' + data.locale + '/' + type, { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to get Risk Policy Details */
	getRiskScorePolicy(): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/riskAssessments/getRiskScorePolicy', { headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API To Validate Activity Score */
	validateActivityScore(data: any): Promise<any> {
		let headers = this.setHttpHeaders();
		return this.http.get('/admin/api/activities/validateActivityScore/' + data.ID + '/' + data.Channel,
			{ headers: headers })
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to determine Authentication */
	determineAuthentication(req: any): Promise<any> {
		return this.http.post('/admin/api/validate/determine', req)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to determine Authentication */
	sendOTP(req: any): Promise<any> {
		return this.http.post('/admin/api/validate/sendOTP', req)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* API call to determine Authentication */
	validateOTP(req: any): Promise<any> {
		return this.http.post('/admin/api/validate/validateOTP', req)
			.toPromise()
			.then(response => response)
			.catch(error => this.handleError(error));
	}

	/* Handler incase of error */
	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}
}
