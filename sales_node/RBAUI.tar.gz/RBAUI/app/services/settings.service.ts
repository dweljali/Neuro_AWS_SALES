import { Injectable } from '@angular/core';

const DEFAULT_ITEMS_PER_PAGE: number = 10;
export const PAGE_START: number = 10;
@Injectable()
export class SettingsService {
    getPageSize(pages: number, defaultVal: number, localStorageKey: string): number {
        let pageSize = localStorage.getItem(localStorageKey);
        if (pageSize) {
            let pageSizeInt = parseInt(pageSize);
            if ((pages > (pageSizeInt - defaultVal)) && pages <= pageSizeInt) {
                return pageSizeInt;
            } else {
                return defaultVal;
            }

        } else {
            return defaultVal;
        }
    }
    setPageSize(localStorageKey: string, size: number) {
        localStorage.setItem(localStorageKey, size.toString());
    }
    clearPageSize() {
        Object.keys(localStorage)
            .filter((key) => { return /page-size/.test(key) })
            .forEach((key) => {
                localStorage.removeItem(key);
            })
    }
}