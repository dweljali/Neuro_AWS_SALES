/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/
module.exports = function (grunt) {  
    // Project configuration.  
    grunt.initConfig({  
        pkg: grunt.file.readJSON('package.json'),  
        cssmin: {  
            sitecss: {  
                options: {  
                    banner: '/* Minified css file */'  
                },  
                files: {  
					'dist/admin/css/RBA.css': [
                            'assets/plugins/pace/pace-theme-flash.css',
                            'assets/plugins/bootstrapv3/css/bootstrap.min.css',
                            'assets/plugins/font-awesome/css/font-awesome.css',
                            'assets/plugins/jquery-scrollbar/jquery.scrollbar.css',
                            'assets/plugins/select2/css/select2.min.css',
                            'assets/plugins/switchery/css/switchery.min.css',
                            'assets/plugins/nvd3/nv.d3.min.css',
                            'assets/plugins/mapplic/css/mapplic.css',
                            'assets/plugins/rickshaw/rickshaw.min.css',
                            'assets/plugins/bootstrap-datepicker/css/datepicker3.css',
                            'assets/plugins/jquery-metrojs/MetroJs.css',
							'assets/plugins/dropzone/css/dropzone.css',
                            'pages/css/pages-icons.css',
                            'pages/css/pages.css',
                            'node_modules/ng2-toasty/style.css'
                          ]
                }  
            }  
        } 
       ,uglify:
		{
				build: {
					files: {
						'dist/admin/pluginsJS/RBA.js':[
                            'assets/plugins/pace/pace.min.js',
                            'assets/plugins/jquery/jquery-1.11.1.min.js',
                            'assets/plugins/modernizr.custom.js',
                            'assets/plugins/jquery-ui/jquery-ui.min.js',
                            'assets/plugins/bootstrapv3/js/bootstrap.min.js',
                            'assets/plugins/jquery/jquery-easy.js',
                            'assets/plugins/jquery-unveil/jquery.unveil.min.js',
                            'assets/plugins/jquery-bez/jquery.bez.min.js',
                            'assets/plugins/jquery-ios-list/jquery.ioslist.min.js',
                            'assets/plugins/jquery-actual/jquery.actual.min.js',
                            'assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js',
                            'assets/plugins/select2/js/select2.full.min.js',
                            'assets/plugins/classie/classie.js',
                            'assets/plugins/switchery/js/switchery.min.js',
                            'assets/plugins/nvd3/lib/d3.v3.js',
                             'assets/plugins/nvd3/nv.d3.min.js',
                             'assets/plugins/nvd3/src/utils.js',
                             'assets/plugins/nvd3/src/tooltip.js',
                             'assets/plugins/nvd3/src/interactiveLayer.js',
                             'assets/plugins/nvd3/src/models/axis.js',
                             'assets/plugins/nvd3/src/models/line.js',
                             'assets/plugins/nvd3/src/models/lineWithFocusChart.js',
                             'assets/plugins/mapplic/js/hammer.js',
                             'assets/plugins/mapplic/js/jquery.mousewheel.js',
                             'assets/plugins/mapplic/js/mapplic.js',
                             'assets/plugins/rickshaw/rickshaw.min.js',
                             'assets/plugins/jquery-metrojs/MetroJs.min.js',
                             'assets/plugins/jquery-sparkline/jquery.sparkline.min.js',
                             'assets/plugins/skycons/skycons.js',
                             'assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js',
                             'assets/js/dashboard.js',
                             'assets/js/scripts.js',
                             'pages/js/pages.js'
                            ],
					}
				}
		},
        concat: {
            dist: {
              options: {
                // Remove 'use strict'
                process: function(src, filepath) {
                  return '// Source: ' + filepath + '\n' +
                    src.replace(/(^|\n)[ \t]*('use strict'|"use strict");?\s*/g, '$1');
                }
              },
              files: {
                'public/prod/scripts.js': ['public/prod/scripts.js']
              }
            }
          }
    });  
    // Default task.
	grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');	
    grunt.registerTask('default', ['cssmin']);
    grunt.registerTask('minifyJs', ['uglify']);  
};