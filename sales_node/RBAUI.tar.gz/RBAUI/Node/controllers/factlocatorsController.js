/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var logger = require('../lib/logger');
const MESSAGES = require('../lib/messages/factLocatorMsgs').messages;
const VALIDATOR = require('../lib/messages/factLocatorMsgs').validation;

/* GET API call to get all fact locators */
exports.getFactlocators = function* (req, res, next) {
    let data = {};
    data.statusCode = 400;
    data.factLocators = [];
    try {
        let options = common.getHeaderDetails(req);
        logger.info("{GET}" + common.getEndpointURL("factLocator"));
        let apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("factLocator"), '', options);

        if (apiData && apiData.statusCode) {
            data.statusCode = common.checkAPISessionStatus(apiData);
            if (data.statusCode == 401) {
                req.session.Authorization = "";
            }
            else if (apiData.factLocator) {
                for (let i = 0; i < apiData.factLocator.length; i++) {
                    data.factLocators.push({
                        "key": apiData.factLocator[i]["factKey"],
                        "name": apiData.factLocator[i]["name"],
                        "class": apiData.factLocator[i]["factLocatorClass"]
                    });
                }
            }
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.status(data.statusCode).send(data);
}


/* POST API call to create new fact locator */
exports.postFactlocators = function* (req, res, next) {
    let data = {};
    data.statusCode = 400;
    try {
        let options = common.getHeaderDetails(req);
        //POST fact locator payload
        if (validateRequest(req, "POST")) {
            let objBody = {};
            objBody.factLocators = [];
            let objFactLocator = {};
            objFactLocator.factKey = req.body.factKey;
            objFactLocator.name = req.body.factName;
            objFactLocator.factLocatorClass = req.body.factClass;
            objBody.factLocators.push(objFactLocator);

            logger.info("{POST} " + common.getEndpointURL("factLocator"));
            //POST API call
            let apiData = yield proxyAPI.postDataAsync(common.getEndpointURL("factLocator"), objBody, options);
            if (apiData && apiData.statusCode) {
                data.statusCode = common.checkAPISessionStatus(apiData);
                if (data.statusCode == 201) {
                    data.error = 0;
                    data.msg = apiData.message || MESSAGES.POST_SUCCESS;
                } else {
                    if (data.statusCode == 401) { req.session.Authorization = ""; }
                    data.error = 1;
                    data.msg = apiData.message || MESSAGES.POST_FAILURE;
                }
            }
        }
        else {
            data.statusCode = 400;
            data.error = 1;
            data.msg = MESSAGES.INVALID_INCOMPLETE_REQUEST;
        }
    }
    catch (e) {
        logger.error(e);
    }

    res.status(data.statusCode).send(data);
}

/* PUT API call to update fact locator */
exports.putFactlocators = function* (req, res, next) {
    let data = {};
    data.statusCode = 400;
    try {
        let options = common.getHeaderDetails(req);
        //PUT fact locator payload
        if (validateRequest(req, "PUT")) {
            let objBody = {};
            objBody.factKey = req.body.factKey;
            objBody.name = req.body.factName;
            objBody.factLocatorClass = req.body.factClass;

            let putEndpoint = common.getEndpointURL("factLocator") + '/' + req.body.factKey;
            logger.info("{PUT} " + putEndpoint);
            //PUT API call
            let apiData = yield proxyAPI.putDataAsync(putEndpoint, objBody, options);
            if (apiData && apiData.statusCode) {
                data.statusCode = common.checkAPISessionStatus(apiData);
                if (data.statusCode == 200) {
                    data.error = 0;
                    data.msg = apiData.message || MESSAGES.PUT_SUCCESS;
                } else {
                    if (data.statusCode == 401) { req.session.Authorization = ""; }
                    data.error = 1;
                    data.msg = apiData.message || MESSAGES.PUT_FAILURE;
                }
            }
        }
        else {
            data.statusCode = 400;
            data.error = 1;
            data.msg = MESSAGES.INVALID_INCOMPLETE_REQUEST;
        }
    }
    catch (e) {
        logger.error(e);
    }

    res.status(data.statusCode).send(data);
}

function validateRequest(req, type) {
    switch (type) {
        case "PUT":
            if (req.body && req.body.factKey && req.body.factName && req.body.factClass) {
                if (req.body.factName.length <= VALIDATOR.FACT_NAME_MAX_LENGTH &&
                    req.body.factClass.length <= VALIDATOR.FACT_CLASS_MAX_LENGTH) {
                    return true;
                }
            }
            break;

        case "POST":
            if (req.body && req.body.factKey && req.body.factName && req.body.factClass) {
                if (req.body.factKey.length <= VALIDATOR.FACT_KEY_MAX_LENGTH &&
                    req.body.factName.length <= VALIDATOR.FACT_NAME_MAX_LENGTH &&
                    req.body.factClass.length <= VALIDATOR.FACT_CLASS_MAX_LENGTH) {
                    return true;
                }
            }
            break;
    }

    return false;
}