/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var logger = require('../lib/logger');
var messages = require('../lib/messages')();

/* GET API call to get all fact locators */
exports.getFactlocators = function* (req, res, next) {
    let data = {};
    data.statusCode = 400;
    data.factLocators = [];
    try {
        var options = common.getHeaderDetails(req);
        logger.info("{GET}" + common.getEndpointURL("factLocator"));
        var apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("factLocator"), '', options);

        if (apiData && apiData.statusCode) {
            if (common.checkAPISessionStatus(apiData) == 401) {
                req.session.Authorization = "";
                objdata.statusCode = 401;
            }
            else if (apiData.factLocator) {
                for (var i = 0; i < apiData.factLocator.length; i++) {
                    data.factLocators.push({
                        "key": apiData.factLocator[i]["factKey"],
                        "name": apiData.factLocator[i]["name"],
                        "class": apiData.factLocator[i]["factLocatorClass"]
                    });
                }
                data.statusCode = apiData.statusCode;
            }
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.status(data.statusCode).send(data);
}


/* POST API call to create new fact locator */
exports.postFactlocators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        var callbackfunc = function (err, response, statusCode) {
            if (statusCode == 201) {
                res.status(statusCode).send({
                    "error": 0,
                    "msg": response.message ? response.message : message.factLocators.POST_SUCCESS
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                res.status(statusCode).send({
                    "error": 1,
                    "msg": response.message ? response.message : message.factLocators.POST_FAILURE
                });
            }
        }

        //POST fact locator payload
        if (req.body && req.body.factKey && req.body.factName && req.body.factClass) {
            let objBody = {};
            objBody.factLocators = [];

            let objFactLocator = {};
            objFactLocator.factKey = req.body.factKey;
            objFactLocator.name = req.body.factName;
            objFactLocator.factLocatorClass = req.body.factClass;
            objBody.factLocators.push(objFactLocator);
            //API calls
            logger.info("{POST} " + common.getEndpointURL("factLocator"));
            proxyAPI.postData(common.getEndpointURL("factLocator"), objBody, options, callbackfunc);
        }
        else {
            res.status(400).send({
                "error": 1,
                "msg": messages.factLocators.INVALID_INCOMPLETE_REQUEST
            });
        }
    }
    catch (e) {
        logger.error(e);
    }
}

/* PUT API call to update fact locator */
exports.putFactlocators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        var callbackfunc = function (err, response, statusCode) {            
            if (statusCode == 200) {
                res.status(statusCode).send({
                    "error": 0,
                    "msg": response.message ? response.message : message.factLocators.PUT_SUCCESS
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                res.status(statusCode).send({
                    "error": 1,
                    "msg": response.message ? response.message : message.factLocators.PUT_FAILURE
                });
            }
        }

        //PUT fact locator payload
        if (req.body && req.body.factKey && req.body.factName && req.body.factClass) {
            let objBody = {};
            objBody.factKey = req.body.factKey;
            objBody.name = req.body.factName;
            objBody.factLocatorClass = req.body.factClass;
            //API calls
            logger.info("{PUT} " + common.getEndpointURL("factLocator"));
            logger.info(req.body.factKey);
            proxyAPI.putData(common.getEndpointURL("factLocator") + '/' + req.body.factKey, objBody, options, callbackfunc);
        }
        else {
            res.status(400).send({
                "error": 1,
                "msg": messages.factLocators.INVALID_INCOMPLETE_REQUEST
            });
        }
    }
    catch (e) {
        logger.error(e);
    }
}

/* API call - delete fact locator by fact loator key */
exports.deleteFactlocators = function* (req, res, next) {

}


