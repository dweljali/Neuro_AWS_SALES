/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise=require('bluebird');
var proxyAPI=require('../lib/API');
proxyAPI=promise.promisifyAll(proxyAPI);
var common=require('../lib/common');
var logger = require('../lib/logger');

/* GET API call to get all channels */
exports.getChannels=function* (req,res,next){
    var data={};
	var options = common.getHeaderDetails(req);
	var apiDataChannels=yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);
	
    data.channel= [];
	for(var i=0; i<apiDataChannels.channels.length;i++){
		data.channel.push({"id":apiDataChannels.channels[i]["id"], "text": apiDataChannels.channels[i]["description"]});
	}
	res.json(data);
}

/* POST API call to create new channel */
exports.postChannels= function* (req,res,next){
    var options = common.getHeaderDetails(req);
    try{
         var callbackfunc = function(err, response, statusCode) {
            if (statusCode == 201) {
                logger.info("API- "+common.getEndpointURL("channels")+ "--"+ statusCode + ": "+ response.message);
                res.send({
                    "error": 0,
                    "successMsg": response.message,
                    "statusCode":statusCode
                });            
            } else {
                logger.info("API- "+common.getEndpointURL("channels")+ "--"+ statusCode + ": "+ response.message);
                if(statusCode == 401){req.session.Authorization="";}
                var errmsg = (response.message ? (response.message) : ""); 
                res.send({
                    "error": 1,
                    "errorMsg": errmsg,
                    "statusCode":statusCode
                });
            }
        }        
         
        //POST Authenticator payload
        var objBody =  {"channels": [{"id":req.body.channelID,
             "description":req.body.channelDescription
            }]};
		
        //API calls
        proxyAPI.postData(common.getEndpointURL("channels"), objBody, options,callbackfunc);
       
    }
    catch(e){
        logger.error("API- "+common.getEndpointURL("channels")+ "--"+ e);
    }     
}

/* PUT API call to update channel */
exports.putChannels= function* (req,res,next){
    var options = common.getHeaderDetails(req);
    try{
         var callbackfunc = function(err, response, statusCode) {
            if (statusCode == 200) {
                logger.info("API- "+common.getEndpointURL("channels") + '/' + req.body.channelID 
							+ "--"+ statusCode + ": "+ response.message);
                res.send({
                    "error": 0,
                    "successMsg": response.message,
                    "statusCode":statusCode
                });            
            } else {
                logger.info("API- "+common.getEndpointURL("channels")  + '/' + req.body.channelID 
							+ "--"+ statusCode + ": "+ response.message);
                if(statusCode == 401){req.session.Authorization="";}
                var errmsg = (response.message ? (response.message) : ""); 
                res.send({
                    "error": 1,
                    "errorMsg": errmsg,
                    "statusCode":statusCode
                });
            }
        }        
         
        //POST Authenticator payload
        var objBody = {"id":req.body.channelID,
             "description":req.body.channelDescription
            };
		 
        //API calls
        proxyAPI.putData(common.getEndpointURL("channels") + '/' + req.body.channelID, objBody, options,callbackfunc);
       
    }
    catch(e){
        logger.error("API- "+common.getEndpointURL("channels")  + '/' + req.body.channelID + "--"+ e);
    }     
}

/* API call - delete Authencticator by Authenticator ID */
exports.deletechannel = function* (req, res,next){
     var options = common.getHeaderDetails(req);
   
   var callbackfunc = function(err, response, statusCode) {
            if (statusCode == 200) {
                logger.info("API- "+common.getEndpointURL("channels") + '/' + req.body.reqId+ "--"
                            + statusCode + ": "+ response.message);
                res.send({
                    "error": 0,
                    "statusCode":statusCode,
                    "successMsg": response.message
                });            
            } else {
                logger.error("API- "+common.getEndpointURL("channels") + '/' + req.body.reqId+ "--"
                             + statusCode + ": "+ response.message);
                if(statusCode == 401){req.session.Authorization="";}
                var errmsg = (response.message ? (response.message) : "");
                res.send({
                    "error": 1,
                    "statusCode":statusCode,
                    "errorMsg": errmsg
                });
            }
    }
    
    proxyAPI.deleteData(common.getEndpointURL("channels") + '/' + req.body.reqId, '', options,callbackfunc);
}

