/*******************************************************************************
 * Copyright (c) 2017  Persistent Systems Ltd.
 * All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var config = require('../config')();
var logger = require('../lib/logger');
/* Get chart data - API call*/
exports.getChartData = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objdata = {};
    var apiData = {};
    var data = {};

    data.duration = req.params.duration;
    data.startDate = req.params.startDate;
    data.endDate = req.params.endDate;
    data.locale = req.params.locale;
    data.type = req.params.type;

    //options.headers['Authorization'] = 'Bearer'+' '+req.session.Authorization;//config.loginToken;
    var callbackfunc = function (err, response, statusCode) {
        logger.info(common.getEndpointURL("monitorOps"));
        logger.info(statusCode);
        logger.info(response);
        logger.info(err);
        if (statusCode == 200) {
            res.send({
                "data": response.dashboardData,
                "statusCode": response.statusCode,
                "successMsg": response.statusMessage
            });
        } else {
            if (statusCode == 401) {
                req.session.Authorization = "";
            }
            res.send({
                "statusCode": statusCode,
                "errorMsg": response.statusMessage
            });
        }
    }

    try {
        proxyAPI.getDataAsync(common.getEndpointURL("monitorOps") + '/' + data.type,
            data, options, callbackfunc);
    } catch (e) {
        logger.error(common.getEndpointURL("monitorOps"), e);
    }
}

/* Get RSI Call */
exports.getRSIData = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    var apiData = {};
    try {
        let startDate = req.params.startDate;
        let endDate = req.params.endDate;
        //log Endpoint
        logger.info(`${common.getEndpointURL("userCardRSI")}?startDate=${startDate}&endDate=${endDate}`);
        //API call to get user card data
        apiData = yield proxyAPI.getDataAsync(`${common.getEndpointURL("userCardRSI")}?startDate=${startDate}&endDate=${endDate}`, '', options);
        //Log API response
        logger.info(apiData);
        //Process API response
        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.status = apiData.status;
            objData.successMsg = apiData.message;
            objData.userCards = apiData.userCards;

            objData.userCards.forEach((userCard) => {
                userCard.activityTime = common.getFormattedDate(userCard.activityTime)
            })

            objData.userData = apiData.userData;
            //if images are encoded in base64 format
            objData.userData.forEach(common.getFormattedUserImageData);

            objData.error = 0;
            objData.errorMsg = "";
        } else {
            if (apiData.statusCode == 401) {
                req.session.Authorization = "";
            }
            var errmsg = (apiData.message ? (apiData.message) : "");
            objData.error = 1;
            objData.errorMsg = errmsg;
            objData.statusCode = apiData.statusCode;
        }
    } catch (e) {
        console.log(e);
        logger.error(`${common.getEndpointURL("userCardRSI")}?startDate=${startDate}&endDate=${endDate}`, e);
    }

    res.send(objData);
}

/* Get AT Call */
exports.getATData = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    var apiData = {};
    var errmsg = {};
    try {
        let startDate = req.params.startDate;
        let endDate = req.params.endDate;
        //log Endpoint
        logger.info(`${common.getEndpointURL("userCardAT")}?startDate=${startDate}&endDate=${endDate}`);
        //API call to get user card data
        apiData = yield proxyAPI.getDataAsync(`${common.getEndpointURL("userCardAT")}?startDate=${startDate}&endDate=${endDate}`, '', options);

        //Log API response
        logger.info(apiData);
        //Process API response
        if (apiData && apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            objData.userCards = apiData.userCards;

            objData.userCards.forEach((userCard) => {
                userCard.activityTime = common.getFormattedDate(userCard.activityTime)
            })

            objData.userData = apiData.userData;
            //if images are encoded in base64 format
            objData.userData.forEach(common.getFormattedUserImageData);

            objData.error = 0;
            objData.errorMsg = "";
        } else {
            if (apiData && apiData.statusCode == 401) {
                req.session.Authorization = "";
            }
            errmsg = (apiData.message ? (apiData.message) : "");
            objData.error = 1;
            objData.errorMsg = errmsg;
            objData.statusCode = apiData.statusCode;
        }
    } catch (e) {
        console.log(e);
        logger.error(`${common.getEndpointURL("userCardAT")}?startDate=${startDate}&endDate=${endDate}`, e);
    }

    res.send(objData);
}

/* Get AF Call */
exports.getAFData = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    var apiData = {};
    try {
        let startDate = req.params.startDate;
        let endDate = req.params.endDate;
        //log Endpoint
        logger.info(`${common.getEndpointURL("userCardAF")}?startDate=${startDate}&endDate=${endDate}`);
        apiData = yield proxyAPI.getDataAsync(`${common.getEndpointURL("userCardAF")}?startDate=${startDate}&endDate=${endDate}`, '', options);
        //Log API response
        logger.info(apiData);
        //Process API response
        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            objData.userCards = apiData.userCards;
            objData.userData = apiData.userData;

            objData.userCards.forEach((userCard) => {
                userCard.activityTime = common.getFormattedDate(userCard.activityTime)
            })

            objData.userData = apiData.userData;
            //if images are encoded in base64 format
            objData.userData.forEach(common.getFormattedUserImageData);

            objData.error = 0;
            objData.errorMsg = "";

        } else {
            if (apiData.statusCode == 401) {
                req.session.Authorization = "";
            }
            var errmsg = (apiData.message ? (apiData.message) : "");
            objData.error = 1;
            objData.errorMsg = errmsg;
            objData.statusCode = apiData.statusCode;
        }
    } catch (e) {
        console.log(e);
        logger.error(`${common.getEndpointURL("userCardAF")}?startDate=${startDate}&endDate=${endDate}`, e);
    }

    res.send(objData);
}