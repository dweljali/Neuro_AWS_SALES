/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var moment = require('moment');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var config = require('../config')();
var logger = require('../lib/logger');
const MESSAGES = require('../lib/messages/riskassessmentsMsgs');
/* Get riskAssessments score policy - API call*/
exports.getRiskScorePolicy = function* (req, res, next) {
	var options = common.getHeaderDetails(req);
	var objdata = {};
	var apiData = {};
	try {

		apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("riskpolicy"), '', options);
		logger.info("getRiskScorePolicy API- " + common.getEndpointURL("riskpolicy") + "--" + apiData.statusCode);
		objdata.riskScorePolicy = "TOT"; //Default Total
		if (apiData.riskScoreAggregationPolicy && apiData.riskScoreAggregationPolicy.currentValue) {
			objdata.riskScorePolicy = apiData.riskScoreAggregationPolicy.currentValue;
		}

		if (apiData.riskScoreAggregationPolicy && apiData.riskScoreAggregationPolicy.allowedValues) {
			objdata.riskPolicyValues = JSON.parse(JSON.stringify(apiData.riskScoreAggregationPolicy.allowedValues.split(":")));
		}

		objdata.statusCode = apiData.statusCode;
		objdata.status = apiData.status;
		objdata.FromAPI = true;
		if (apiData.c == 401 ||
			(apiData.statusCode == 400 && apiData.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
			req.session.Authorization = "";
			objdata.statusCode = 401;
		}

		/*var allowedValues = "TOT:AVG:MAX";
		var objAllowedValues = allowedValues.split(":");	 	
		objdata.riskScorePolicy = config.RiskScoreCalculator.methodType.toUpperCase().trim();
		objdata.riskPolicyValues = JSON.parse(JSON.stringify(objAllowedValues));
		objdata.status = 200;
		objdata.statusCode = "OK";	*/
	}
	catch (e) {
		logger.error("getRiskScorePolicy API- " + common.getEndpointURL("riskpolicy") + "--" + e);
	}
	res.json(objdata)
}

/* Get Risk assessment count */
exports.getRiskCount = function* (req, res, next) {
	var options = common.getHeaderDetails(req);
	var objdata = {};

	try {

		var data1 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'OS' }, options);
		var data2 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'EA' }, options);
		//Get Risk Policy
		var riskCount = 0;
		logger.info("getRiskCount API- " + common.getEndpointURL("riskAssessment") + "invocationtype:OS" + "--" + data1.statusCode);
		logger.info("getRiskCount API- " + common.getEndpointURL("riskAssessment") + "invocationtype:EA" + "--" + data2.statusCode);
		objdata.statusCode = data1.statusCode;
		if (data1.statusCode == 401 || (data1.statusCode == 400
			&& data1.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
			req.session.Authorization = "";
			data.statusCode = 401;
		}
		else {
			if (data1.riskAssessments) {
				riskCount = data1.riskAssessments.length;
			}
			if (data2.riskAssessments) {
				riskCount = riskCount + data2.riskAssessments.length;
			}
		}
		objdata.noOfRecordsFound = riskCount;
	}
	catch (e) {
		logger.error("getRiskCount API- " + common.getEndpointURL("riskAssessment") + "--" + e);
	}

	res.json(objdata)
}

/* Get all risk Assessments details */
exports.getRiskAssessments = function* (req, res, next) {
	var options = common.getHeaderDetails(req);
	var objdata = {};

	try {

		var data1 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'OS' }, options);
		var data2 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'EA' }, options);

		var policydata = yield proxyAPI.getDataAsync(common.getEndpointURL("riskpolicy"), '', options);
		logger.info("getRiskScorePolicy API- " + common.getEndpointURL("riskpolicy") + "--" + policydata.statusCode);
		objdata.riskScorePolicy = "TOT"; //Default Total
		if (policydata.riskScoreAggregationPolicy && policydata.riskScoreAggregationPolicy.currentValue) {
			objdata.riskScorePolicy = policydata.riskScoreAggregationPolicy.currentValue;
		}

		logger.info("getRiskAssessments API- " + common.getEndpointURL("riskAssessment")
			+ "invocationtype:os" + "--" + data1.statusCode);
		logger.info("getRiskAssessments API- " + common.getEndpointURL("riskAssessment")
			+ "invocationtype:ea" + "--" + data2.statusCode);

		objdata.statusCode = data1.statusCode;
		objdata.riskassessments = [];
		objdata.riskfactorids = [];
		if (data1.statusCode == 401 || (data1.statusCode == 400
			&& data1.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
			req.session.Authorization = "";
			data.statusCode = 401;
		}
		else {
			if (data1.riskAssessments) {
				for (var i = 0; i < data1.riskAssessments.length; i++) {
					objdata.riskassessments.push({
						'id': data1.riskAssessments[i].riskAssessmentCD,
						'name': data1.riskAssessments[i].riskAssessmentName,
						'time': data1.riskAssessments[i].updatedOn
					});

					if (data1.riskAssessments[i].riskFactorVOs) {
						if (data1.riskAssessments[i].riskFactorVOs.length > 0) {
							for (var j = 0; j < data1.riskAssessments[i].riskFactorVOs.length; j++) {
								objdata.riskfactorids.push(data1.riskAssessments[i].riskFactorVOs[j].riskFactorCode);
							}
						}
					}
				}
			}
			if (data2.riskAssessments) {
				for (var i = 0; i < data2.riskAssessments.length; i++) {
					objdata.riskassessments.push({
						'id': data2.riskAssessments[i].riskAssessmentCD,
						'name': data2.riskAssessments[i].riskAssessmentName,
						'time': data2.riskAssessments[i].updatedOn
					});

					if (data2.riskAssessments[i].riskFactorVOs) {
						if (data2.riskAssessments[i].riskFactorVOs.length > 0) {
							for (var j = 0; j < data2.riskAssessments[i].riskFactorVOs.length; j++) {
								objdata.riskfactorids.push(data2.riskAssessments[i].riskFactorVOs[j].riskFactorCode);
							}
						}
					}
				}
			}
		}
	}
	catch (e) {
		logger.error("getRiskAssessments API- " + common.getEndpointURL("riskAssessment") + "--" + e);
	}
	if (objdata && objdata.riskassessments) {
		objdata.riskassessments.sort((ra1, ra2) => {
			let diff = moment(ra1.time).diff(moment(ra2.time), 'seconds');
			return -diff;
		});
	}
	res.json(objdata)
}

exports.getRiskAssessmentDetails = function* (req, res, next) {
	var options = common.getHeaderDetails(req);
	var objdata = {};
	try {
		objdata.riskconfig = [];
		objdata.riskFactors = [];
		if (req.params.ID) {
			var apiRiskDetails = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment") + '/' + req.params.ID
				, '', options);
			objdata.statusCode = apiRiskDetails.statusCode;
			if (apiRiskDetails.statusCode == 401 || (apiRiskDetails.statusCode == 400
				&& apiRiskDetails.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
				req.session.Authorization = "";
				data.statusCode = 401;
			}
			else {
				if (apiRiskDetails.riskAssessmentCD) {
					objdata.riskAssessmentCD = apiRiskDetails.riskAssessmentCD;
				}
				if (apiRiskDetails.riskAssessmentName) {
					objdata.riskAssessmentName = apiRiskDetails.riskAssessmentName;
				}
				if (apiRiskDetails.riskAssessmentInvocationDesc) {
					objdata.riskAssessmentInvocationDesc = apiRiskDetails.riskAssessmentInvocationDesc;
				}
				if (apiRiskDetails.riskAssessmentInvocationCD) {
					objdata.riskAssessmentInvocationCD = apiRiskDetails.riskAssessmentInvocationCD;
				}

				if (apiRiskDetails.config) {
					for (var i = 0; i < apiRiskDetails.config.length; i++) {
						var riskvalue = apiRiskDetails.config[i].value;

						objdata.riskconfig.push({
							'id': apiRiskDetails.config[i].id,
							'name': apiRiskDetails.config[i].name,
							'value': riskvalue,
							'description': apiRiskDetails.config[i].description,
							'type': apiRiskDetails.config[i].type,
							'dataType': apiRiskDetails.config[i].dataType
						});
					}
				}

				if (apiRiskDetails.riskFactors) {
					for (var i = 0; i < apiRiskDetails.riskFactors.length; i++) {
						objdata.riskFactors.push({
							'id': apiRiskDetails.riskFactors[i].id,
							'name': apiRiskDetails.riskFactors[i].name,
							'providedsystem': apiRiskDetails.riskFactors[i].providedBySystem,
							'dataType': apiRiskDetails.riskFactors[i].dataType,
							'risk_asmt_classname': apiRiskDetails.riskFactors[i].risk_asmt_classname,
							'risk_factor_classname': apiRiskDetails.riskFactors[i].risk_factor_classname,
							'risk_factor_locator_classname': apiRiskDetails.riskFactors[i].risk_factor_locator_classname
						});
					}
				}
			}
		}
	}
	catch (e) {
		logger.error("getRiskDetails API- " + common.getEndpointURL("riskpolicy") + "--" + e);
	}
	res.json(objdata)
}

exports.editRiskAssessmentDetails = function* (req, res, next) {
	var data = {}
	data.statusCode = 200;
	data.error = 0;
	data.errmsg = "";
	var options = common.getHeaderDetails(req);
	try {

		if (req.body) {
			//PUT Risk assessements			 
			var reqpayload = {};
			reqpayload = { "riskAssessment": req.body }

			var objresp = yield proxyAPI.putDataAsync(common.getEndpointURL("riskAssessment") + "/" + req.params.ID, reqpayload, options);
			data.statusCode = objresp.statusCode;

			if (objresp.statusCode == 401 || (objresp.statusCode == 400
				&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
				req.session.Authorization = "";
				data.statusCode = 401;
				data.error = 1;
				data.errmsg = (objresp.message ? (objresp.message + ". ") : "");
			}
			else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
				data.error = 1;
				data.errmsg = objresp.message ? (objresp.message) : "Risk assessment edit failed. ";
			}
		}
	} catch (err) {

	}
	res.json(data)
}
exports.postRiskAssessmentsWithFactors = function* (req, res, next) {
	var data = {}
	data.statusCode = 200;
	data.error = 0;
	data.errmsg = "";
	var options = common.getHeaderDetails(req);
	try {

		if (req.body.riskassessments && req.body.riskassessments.length > 0 && req.body.riskassessments[0].riskAssessmentCD) {
			//POST Risk assessements			 
			var reqpayload = {};
			reqpayload = { "riskAssessments": req.body.riskassessments }
			var riskassessmentid = req.body.riskassessments[0].riskAssessmentCD;
			//POST Risk API call

			var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("riskAssessment"), reqpayload, options);
			data.statusCode = objresp.statusCode;

			if (objresp.statusCode == 401 || (objresp.statusCode == 400
				&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
				req.session.Authorization = "";
				data.statusCode = 401;
				data.error = 1;
				data.errmsg = (objresp.message ? (objresp.message + ". ") : "");
			}
			else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
				data.error = 1;
				data.errmsg = "Risk assessment creation failed. " +
					(objresp.message ? (objresp.message) : "");
			}


			//POST Risk Factors
			if (data.statusCode == 200) {


				if (req.body.riskFactors && req.body.riskFactors.length > 0) {

					//form risk factor payload

					var riskfactor = { "riskFactors": req.body.riskFactors };

					//POST risk factor by ID API call

					var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("riskAssessment") + '/' +
						riskassessmentid + '/' +
						'riskfactors', riskfactor, options);
					data.statusCode = objresp.statusCode;

					if (objresp.statusCode == 401 || (objresp.statusCode == 400
						&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
						req.session.Authorization = "";
						data.statusCode = 401;
						data.error = 1;

					}
					else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
						data.error = 1;
						data.errmsg = "Error while creating risk factors. " +
							(objresp.message ? (objresp.message) : "");

					}


				}
			}
		}

	}
	catch (e) {
		logger.error("postRiskWithFactors API- " + common.getEndpointURL("riskAssessment") + "--" + e);
	}

	res.json(data)

}

exports.deleteRisk = function* (req, res, next) {
	let id = req.params.ID;
	if(!id){
	return	res.status(400).send({
			"error": 1,
			"msg": MESSAGES.INVALID_INCOMPLETE_REQUEST
		});
	}

	var options = common.getHeaderDetails(req);
	let objData = {};
	objData.statusCode = 400;
	try {
		logger.info("{DELETE} " + `${common.getEndpointURL("riskAssessment")}/${id}`);
        apiData = yield proxyAPI.deleteDataAsync(`${common.getEndpointURL("riskAssessment")}/${id}`, {}, options);
	   //Process API response
        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.status = apiData.status;
            objData.error = 0;
            objData.msg = apiData.message || MESSAGES.DELETE_SUCCESS;
        } else {
            if (apiData.statusCode == 401) { req.session.Authorization = ""; }
			objData.error = 1;
			objData.msg = apiData.message || MESSAGES.DELETE_FAILURE;
			objData.statusCode = apiData.statusCode;
			objData.resolve = apiData.resolve;		
        }
    } catch (e) {
        console.log(e);
		logger.error(e);
	}

	res.status(objData.statusCode).send(objData);
}