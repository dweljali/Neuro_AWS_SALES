/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var config = require('../config')();
var logger = require('../lib/logger');

/* Get Total Activities Count */
exports.getActivitiesCount = function* (req, res, next) {
    let objResp = {};
    objResp.statusCode = 400;
    objResp.noOfRecordsFound = 0;
    try {
        let options = common.getHeaderDetails(req);
        logger.info("Count : { GET } " + common.getEndpointURL("activities"));
        let apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("activities"), '', options);

        if (apiData && apiData.statusCode) {
            objResp.statusCode = common.checkAPISessionStatus(apiData);
            if (objResp.statusCode == 401) { req.session.Authorization = ""; }
            if (apiData.noOfRecordsFound) {
                objResp.noOfRecordsFound = apiData.noOfRecordsFound;
            }
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.status(objResp.statusCode).send(objResp);
}

/* Get all Activities - API call*/
exports.getActivities = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objdata = {};
    var apiData = {};
    //options.headers['Authorization'] = 'Bearer'+' '+req.session.Authorization;//config.loginToken;
    try {
        logger.info(common.getEndpointURL("activities"));
        apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("activities"), '', options);
        var apiDataChannels = yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);
        var channeldetails = {};
        if (apiDataChannels.channels) {
            for (var i = 0; i < apiDataChannels.channels.length; i++) {
                channeldetails[apiDataChannels.channels[i]["id"]] = apiDataChannels.channels[i]["description"];
            }
        }


        logger.info(apiData.statusCode);
        objdata.activities = apiData.activityRiskAuthenticatorRelations;
        objdata.statusCode = apiData.statusCode;
        objdata.noOfRecordsFound = apiData.noOfRecordsFound;
        objdata.status = apiData.status;
        objdata.channels = channeldetails;

        if (apiData.statusCode == 401 || (apiData.statusCode == 400 && apiData.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
            req.session.Authorization = "";
            objdata.statusCode = 401;
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.json(objdata)
}

/* Activate/De-Activate Activities */
exports.changeActivityStatus = function* (req, res, next) {
    var data = req.body.data;
    var options = common.getHeaderDetails(req);
    try {
        //Call back function will set Activity detials in session to null after success.        
        var callbackfunc = function (err, response, statusCode) {
            logger.info(common.getEndpointURL("activities") + '/' + data.activityId);
            logger.info(statusCode);
            if (statusCode == 200) {
                res.send({
                    "error": 0,
                    "statusCode": statusCode,
                    "msg": response.message
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                var errmsg = (response.message ? (response.message + ". ") : "");
                res.send({
                    "error": 1,
                    "statusCode": statusCode,
                    "msg": errmsg
                });
            }
        }

        /* risk assessment selected */
        var riskAssmnt = [];
        for (var i = 0; i < data.risk.length; i++) {
            riskAssmnt.push({ "riskAssessmentCD": data.risk[i] });
        }


        /* Selected authenticators */
        var challenges = [];

        for (var j = 0; j < data.authList.length; j++) {
            challenges.push({
                "id": data.authList[j].id,
                "score": parseInt(data.authList[j].score),
                "priority": data.authList[j].priority
            });
        }

        //Forming th payload for POST Activity
        var objBody = {
            "activity": {
                "activityID": data.activityId,
                "activityName": data.activityName,
                "description": data.activityDesc,
                "activityAuthLevel": data.authLevel.toUpperCase().replace(/ /g, "_"),
                "requiredScore": parseInt(data.activityscore),
                "activeStatus": data.activeStatus,
                "channel": data.currentSelectedChannel.toUpperCase()
            },
            "riskAssessmentList": riskAssmnt,
            "authenticationChallengeList": challenges
        };


        //PUT Activity API Call
        proxyAPI.putData(common.getEndpointURL("activities") + '/' + data.activityId
            , objBody, options, callbackfunc);

    }
    catch (e) {
        logger.error(e);
    }
}

/* Validate Activity Trust-Risk Score : This API will be called to validate score before re-activating Activity */
exports.validateActivityScore = function* (req, res, next) {
    var objdata = {};
    try {
        if (req.params.ID && req.params.Channel) {
            var options = common.getHeaderDetails(req);

            //Get Risk Policy
            var apiRiskData = yield proxyAPI.getDataAsync(common.getEndpointURL("riskpolicy"), '', options);
            var riskScorePolicy = "TOT"; //Default Total
            if (apiRiskData.riskScoreAggregationPolicy && apiRiskData.riskScoreAggregationPolicy.currentValue) {
                riskScorePolicy = apiRiskData.riskScoreAggregationPolicy.currentValue;
            }

            logger.info(common.getEndpointURL("activities") + '/' + req.params.ID);
            //Get Activity By ID API call
            var apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("activities")
                + '/' + req.params.ID + '?channel=' + req.params.Channel
                , '', options);

            logger.info(apiData.statusCode);

        }

        objdata.statusCode = apiData.statusCode;
        if (apiData.statusCode == 401 || (apiData.statusCode == 400
            && apiData.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
            req.session.Authorization = "";
            objdata.statusCode = 401;
        }

        objdata.activities = apiData.activityRiskAuthenticatorRelations;
        objdata.validated = 0;

        if (apiData.singleActivityRiskAuthenticatorRelations) {
            var apiActivity = apiData.singleActivityRiskAuthenticatorRelations;
            var activityScore = parseInt(apiActivity.activity.requiredScore);
            var totalAutScore = 0;
            var riskScore = 0;

            //Get Sum Of All Authenticator Score(s)
            for (let i = 0; i < apiActivity.authenticationChallengeList.length; i++) {
                //Check If Authenticator Is In An Active Status
                if (apiActivity.authenticationChallengeList[i].activeStatus == 1) {
                    totalAutScore = totalAutScore + parseInt(apiActivity.authenticationChallengeList[i].score);
                }
            }

            //Check if Risk Assessemnts are associated with Activity
            if (apiActivity.riskAssessmentList.length > 0) {
                //Get Policy To Calulate Risk Score
                var riskPolicy = riskScorePolicy;

                var riskpoint = 0;
                //Loop Through All Associated Risk Assessments
                for (let i = 0; i < apiActivity.riskAssessmentList.length; i++) {
                    riskpoint = 0;
                    var riskfactor = apiActivity.riskAssessmentList[i].riskFactors; //Get risk factors data
                    //Loop Through Risk Factors To Get The Maximum Risk Factor
                    for (var key in riskfactor) {
                        var point = parseInt(riskfactor[key]);
                        if (point > riskpoint) {
                            riskpoint = point; //get Max risk factor
                        }
                    }

                    //Use The Risk Policy To Determine Final Risk Score
                    //If Policy Is Not MAX Then Add All Risk Scores
                    if (riskPolicy.toUpperCase().trim() == "MAX") {
                        if (riskpoint > riskScore) {
                            riskScore = riskpoint;
                        }
                    }
                    else {
                        riskScore = riskScore + riskpoint;
                    }
                }

                //If riskPolicy Is AVG, Then Calulate AVG
                if (riskPolicy.toUpperCase().trim() == "AVG") {
                    riskScore = Math.ceil(riskScore / apiActivity.riskAssessmentList.length); //Round UpWard
                }
            }

            //Sum Of All Authenticator Score(s) Should Be Greater Than Or Equal To Risk Score + Activity Scores
            if (totalAutScore >= (activityScore + riskScore)) {
                objdata.validated = 1;
            }
        }
    }
    catch (e) {
        logger.error(e);
    }

    res.json(objdata)
}

/* Edit Activity call - Return data for selected Activity to be displayed on wizard in edit mode */
exports.editActivity = function* (req, res, next) {
    var data = req.body.data;
    /* Set Activity Tab*/
    data.activityName = req.session.activityName;
    req.session.activityDesc = data["Description"];
    req.session.activityId = data["ID"];;
    req.session.activityscore = data["Required Trust Score"];
    req.session.currentSelectedChannel = data["Chnl"];
    req.session.activityName = data["Activity Name"]
    req.session.inclusionRuleId = req.body.inclusionRuleId;
    req.session.exclusionRuleId = req.body.exclusionRuleId;
    if (req.body.authlevel) {
        req.session.currentSelectedAuthType = req.body.authlevel.replace(/ /g, "_");
    }

    /* Set Risk Assesment Tab*/
    req.session.activeRiskOS = [];
    req.session.activeRiskscore = [];
    if (req.body.riskdataos) {
        for (let i = 0; i < req.body.riskdataos.length; i++) {
            req.session.activeRiskOS.push({ id: req.body.riskdataos[i]['code'], text: req.body.riskdataos[i]['name'] })
        }
    }

    req.session.activeRiskEA = [];
    if (req.body.riskdataea) {
        for (let i = 0; i < req.body.riskdataea.length; i++) {
            req.session.activeRiskEA.push({ id: req.body.riskdataea[i]['code'], text: req.body.riskdataea[i]['name'] })

        }
    }
    req.session.activeRiskscore = [];

    var options = common.getHeaderDetails(req);

    var apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("riskpolicy"), '', options);
    var riskScorePolicy = "TOT"; //Default Total
    if (apiData.riskScoreAggregationPolicy && apiData.riskScoreAggregationPolicy.currentValue) {
        riskScorePolicy = apiData.riskScoreAggregationPolicy.currentValue;
    }

    var data1 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'OS' }, options);
    var data2 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'EA' }, options);


    //Risk assessement - once per session
    var objos = [];
    var riskdatapoint = 0;

    for (var i = 0; i < data1.riskAssessments.length; i++) {
        riskpoint = 0;

        var riskfactor = data1.riskAssessments[i].riskFactors; //Get risk factors data

        for (var key in riskfactor) {
            var point = parseInt(riskfactor[key]);
            if (point > riskpoint) {
                riskpoint = point; //get Max risk factor
            }
        }

        objos.push({
            "riskAssessmentCD": data1.riskAssessments[i].riskAssessmentCD,
            "riskAssessmentName": data1.riskAssessments[i].riskAssessmentName,
            "outputPoint": riskpoint,
            "riskfactorcount": 1
        });
    }


    //Risk assessement - every activity
    var objea = [];
    var riskdatapoint = 0;
    for (var i = 0; i < data2.riskAssessments.length; i++) {
        riskpoint = 0;

        var riskfactor = data2.riskAssessments[i].riskFactors; //Get risk factors data

        for (var key in riskfactor) {
            var point = parseInt(riskfactor[key]);
            if (point > riskpoint) {
                riskpoint = point; //get Max risk factor
            }
        }
        objea.push({
            "riskAssessmentCD": data2.riskAssessments[i].riskAssessmentCD,
            "riskAssessmentName": data2.riskAssessments[i].riskAssessmentName,
            "outputPoint": riskpoint,
            "riskfactorcount": 1
        });
    }


    var riskcount = 0, riskpoint = 0;
    var actRiskScore = [];

    //loop through selected every activity risk
    if (req.session.activeRiskEA) {
        for (var i = 0; i < req.session.activeRiskEA.length; i++) {
            for (var j = 0; j < objea.length; j++) {
                if (req.session.activeRiskEA[i].id == objea[j].riskAssessmentCD) {
                    riskcount = riskcount + objea[j].riskfactorcount;
                    if (riskScorePolicy.toUpperCase().trim() == "MAX") {
                        if (objea[j].outputPoint > riskpoint) {
                            riskpoint = objea[j].outputPoint;
                        }
                    }
                    else {
                        riskpoint = riskpoint + objea[j].outputPoint
                    }

                    actRiskScore.push({
                        id: objea[j].riskAssessmentCD,
                        outputpoint: objea[j].outputPoint,
                        riskfactorcount: objea[j].riskfactorcount
                    });

                    break;
                }
            }
        }
    }

    //loop through selected once per session risk
    if (req.session.activeRiskOS) {
        for (var i = 0; i < req.session.activeRiskOS.length; i++) {
            for (var j = 0; j < objos.length; j++) {
                if (req.session.activeRiskOS[i].id == objos[j].riskAssessmentCD) {
                    riskcount = riskcount + objos[j].riskfactorcount;
                    if (riskScorePolicy.toUpperCase().trim() == "MAX") {
                        if (objos[j].outputPoint > riskpoint) {
                            riskpoint = objos[j].outputPoint;
                        }
                    }
                    else {
                        riskpoint = riskpoint + objos[j].outputPoint
                    }

                    actRiskScore.push({
                        id: objos[j].riskAssessmentCD,
                        outputpoint: objos[j].outputPoint,
                        riskfactorcount: objos[j].riskfactorcount
                    });

                    break;
                }
            }
        }
    }

    //If Average risk calculation is selected
    if (riskScorePolicy.toUpperCase().trim() == "AVG") {
        if (riskcount > 0) {
            riskpoint = Math.ceil(riskpoint / riskcount);
        }
    }

    req.session.riskScore = riskpoint;
    req.session.activeRiskscore = actRiskScore;





    /* Set Authenticatros Tab*/
    req.session.activechallenges = [];
    var authlist = req.body.authlist;
    var total = 0;
    var objname = []

    for (let i = 0; i < authlist.length; i++) {
        req.session.activechallenges.push({ id: authlist[i].id, text: authlist[i].desc });

        objname.push({
            'authname': authlist[i].desc,
            'score': authlist[i].score
        });
        total = total + parseInt(authlist[i].score);
    }

    /* Set Balance Tab*/
    req.session.balanceData = {
        totalscore: total,
        name: objname,
        riskScore: 0
    }
    res.send("done!!")
}