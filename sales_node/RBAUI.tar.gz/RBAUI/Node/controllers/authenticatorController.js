/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var config = require('../config')();
var logger = require('../lib/logger');

/* Get Total Authenticators Count */
exports.getAuthenticatorsCount = function* (req, res, next) {
    let objResp = {};
    objResp.statusCode = 400;
    objResp.noOfRecordsFound = 0;
    try {
        let options = common.getHeaderDetails(req);
        logger.info("Count : { GET } " + common.getEndpointURL("authenticators"));
        let apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("authenticators"), '', options);

        if (apiData && apiData.statusCode) {
            objResp.statusCode = common.checkAPISessionStatus(apiData);
            if (objResp.statusCode == 401) { req.session.Authorization = ""; }
            if (apiData.noOfRecordsFound) {
                objResp.noOfRecordsFound = apiData.noOfRecordsFound;
            }
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.status(objResp.statusCode).send(objResp);
}

/* Get all authenticators and fact locators by connecting to rba-admin API */
exports.getAuthenticators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var data = {};

    //options.headers['Authorization'] = 'Bearer'+' '+req.session.Authorization;// config.loginToken;; 
    try {
        var objAuthResp = yield proxyAPI.getDataAsync(common.getEndpointURL("authenticators"), '', options);
        data.authenticatorResponse = objAuthResp.challenges;
        data.noOfRecordsFound = objAuthResp.noOfRecordsFound;
        logger.info(common.getEndpointURL("authenticators"));
        logger.info(objAuthResp.statusCode);
        if (objAuthResp.statusCode == 401 || (objAuthResp.statusCode == 400 && objAuthResp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
            req.session.Authorization = "";
            data.statusCode = 401;
        }
    }
    catch (e) {
        logger.error(e);
    }
    try {

        data.factLocators = yield proxyAPI.getDataAsync(common.getEndpointURL("factlocators"), '', options);
        logger.info(common.getEndpointURL("factlocators"));
        logger.info(data.factLocators.statusCode);
        if (data.factLocators.statusCode == 401) {
            req.session.Authorization = "";
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.json(data);
}

/* POST API call to create new Authenticator */
exports.postAuthenticators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        var callbackfunc = function (err, response, statusCode) {
            logger.info(common.getEndpointURL("authenticators"));
            logger.info(statusCode);
            if (statusCode == 201) {
                res.send({
                    "error": 0,
                    "msg": response.message,
                    "statusCode": statusCode
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                res.send({
                    "error": 1,
                    "msg": response.message ? response.message : "",
                    "statusCode": statusCode
                });
            }
        }

        //POST Authenticator payload
        var objBody = {
            "authenticators": [{
                "id": req.body.AuthenticatorID,
                "description": req.body.AuthenticatorDesc,
                "factKey": req.body.factid,
                "activeStatus": 1
            }]
        };

        //API calls
        proxyAPI.postData(common.getEndpointURL("authenticators"), objBody, options, callbackfunc);

    }
    catch (e) {
        logger.error(e);
    }
}

/* API call to update Authenticator - PUT API Call */
exports.updateAuthenticators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);

    try {
        var callbackfunc = function (err, response, statusCode) {
            logger.info(common.getEndpointURL("authenticators") + '/' + req.body.AuthenticatorID);
            logger.info(statusCode);
            if (statusCode == 200) {
                res.send({
                    "error": 0,
                    "msg": response.message,
                    "statusCode": statusCode
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                res.send({
                    "error": 1,
                    "msg": response.message ? response.message : "",
                    "statusCode": statusCode
                });
            }
        }

        //PUT Authenticator payload
        var objBody = {
            "id": req.body.AuthenticatorID,
            "description": req.body.AuthenticatorDesc,
            "factKey": req.body.factid,
            "activeStatus": req.body.activeStatus
        };

        //API call PUT Authenticator API
        proxyAPI.putData(common.getEndpointURL("authenticators") + '/' + req.body.AuthenticatorID
            , objBody, options, callbackfunc);

    }
    catch (e) {
        logger.error(e);
    }
}