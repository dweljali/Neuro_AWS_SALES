/*******************************************************************************
 * Copyright (c) 2017  Persistent Systems Ltd.
 * All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var moment = require('moment');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var logger = require('../lib/logger');

exports.getChannels = function* (req, res, next) {
	var data = {};
	var options = common.getHeaderDetails(req);
	var apiDataChannels = yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);

	data.channel = [];
	for (var i = 0; i < apiDataChannels.channels.length; i++) {
		data.channel.push({
			"id": apiDataChannels.channels[i]["id"],
			"text": apiDataChannels.channels[i]["description"]
		});
	}
	res.json(data);
}

exports.getDiagnostics = function* (req, res, next) {
	var options = common.getHeaderDetails(req);
	var objdata = {};
	try {
		objdata.user = "";
		objdata.sessions = [];
		var channelid = "DEFAULT";
		if (req.params.userid && req.params.channel) {
			if (req.params.channel == "DEFAULT") {
				req.params.channel = "WEB";
				var apiresp = yield proxyAPI.getDataAsync(common.getEndpointURL("diagnostics") +
					'?userId=' +
					req.params.userid +
					'&channel=MOBILE', '', options)
			}

			var apiResponse = yield proxyAPI.getDataAsync(common.getEndpointURL("diagnostics") +
				'?userId=' +
				req.params.userid +
				'&channel=' +
				req.params.channel, '', options);
			if (apiresp && apiresp.userSessionData && apiresp.userSessionData.userId && apiresp.userSessionData.sessions &&
				apiresp.userSessionData.sessions.length > 0) {
				if (apiResponse && apiResponse.userSessionData && apiResponse.userSessionData.userId &&
					apiResponse.userSessionData.sessions &&
					apiResponse.userSessionData.sessions.length > 0) {
					if (apiresp.userSessionData.sessions[0].sessionStartTime >
						apiResponse.userSessionData.sessions[0].sessionStartTime) {
						apiResponse = apiresp;
					}
				} else {
					apiResponse = apiresp;
				}
			}
			objdata.statusCode = apiResponse.statusCode;
			if (apiResponse.statusCode == 401 || (apiResponse.statusCode == 400 &&
					apiResponse.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
				req.session.Authorization = "";
				data.statusCode = 401;
			} else {
				if (apiResponse.userSessionData && apiResponse.userSessionData.userId && apiResponse.userSessionData.sessions &&
					apiResponse.userSessionData.sessions.length > 0) {
					var apiDataChannels = yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);
					var channeldetails = {};
					if (apiDataChannels.channels) {
						for (var i = 0; i < apiDataChannels.channels.length; i++) {
							channeldetails[apiDataChannels.channels[i]["id"]] = apiDataChannels.channels[i]["description"];
						}
					}

					objdata.user = apiResponse.userSessionData.userId;
					for (var i = 0; i < apiResponse.userSessionData.sessions.length; i++) {
						var objActivities = [];
						var objAuthenticators = [];
						var objRiskAssessments = [];
						var objRiskFactors = [];

						if (apiResponse.userSessionData.sessions[i].activities) {
							for (var j = 0; j < apiResponse.userSessionData.sessions[i].activities.length; j++) {
								objAuthenticators = [];

								if (apiResponse.userSessionData.sessions[i].activities[j].authenticators) {
									for (var k = 0; k < apiResponse.userSessionData.sessions[i].activities[j].authenticators.length; k++) {
										var auth = apiResponse.userSessionData.sessions[i].activities[j].authenticators[k].name.trim() + ' [';
										//auth = auth + //apiResponse.userSessionData.sessions[i].activities[j].authenticators[k].status + ']';
										auth = auth +
											apiResponse.userSessionData.sessions[i].activities[j].authenticators[k].score + ']';
										var s = apiResponse.userSessionData.sessions[i].activities[j].authenticators[k].status.toUpperCase().trim().indexOf("PASS") > -1 ? 1 : 0;
										objAuthenticators.push([s, auth]);
									}
								}
								var channelinfo = "";
								if (apiResponse.userSessionData.sessions[i].activities[j].channel && channeldetails) {
									channelinfo = apiResponse.userSessionData.sessions[i].activities[j].channel.trim();
									channelid = channelinfo;
									if (channeldetails[channelinfo]) {
										channelinfo = channeldetails[channelinfo]
									}
								}

								objActivities.push({
									'id': apiResponse.userSessionData.sessions[i].activities[j].id,
									'time': common.getFormattedDate(apiResponse.userSessionData.sessions[i].activities[j].time),
									'authenticators': objAuthenticators,
									'channel': channelinfo,
									'trustscore': apiResponse.userSessionData.sessions[i].activities[j].trustScore
								});
							}
						}

						if (apiResponse.userSessionData.sessions[i].riskAssessments) {
							for (var k = 0; k < apiResponse.userSessionData.sessions[i].riskAssessments.length; k++) {
								let actTime = apiResponse.userSessionData.sessions[i].riskAssessments[k].activityTime;
								objRiskAssessments.push({
									'id': apiResponse.userSessionData.sessions[i].riskAssessments[k].id,
									'score': apiResponse.userSessionData.sessions[i].riskAssessments[k].score,
									'description': apiResponse.userSessionData.sessions[i].riskAssessments[k].outcomeDescription,
									'activityid': apiResponse.userSessionData.sessions[i].riskAssessments[k].activityId,
									'activityTime': actTime ? common.getFormattedDate(actTime) : ''
								});
							}
						}

						if (apiResponse.userSessionData.sessions[i].riskFactors) {
							for (l = 0; l < apiResponse.userSessionData.sessions[i].riskFactors.length; l++) {
								// to get activityID associated with the Risk Factor
								// let currRiskAssessment = objRiskAssessments.find((val) => {
								// 	return val.id == apiResponse.userSessionData.sessions[i].riskFactors[l].riskAssessmentId
								// });
								let time = apiResponse.userSessionData.sessions[i].riskFactors[l].executionTime;
								objRiskFactors.push({
									'id': apiResponse.userSessionData.sessions[i].riskFactors[l].id,
									'status': apiResponse.userSessionData.sessions[i].riskFactors[l].status,
									'value': apiResponse.userSessionData.sessions[i].riskFactors[l].value,
									'riskid': apiResponse.userSessionData.sessions[i].riskFactors[l].riskAssessmentId,
									'activityid': apiResponse.userSessionData.sessions[i].riskFactors[l].currentActivity,
									'executionTime': time ? common.getFormattedDate(time) : ''
								});
							}
						}
						objActivities.sort((act1, act2) => {
							let diff = moment(act1.time).diff(moment(act2.time), 'seconds');
							return -diff;
						});
						objRiskAssessments.sort((act1, act2) => {
							let diff = moment(act1.activityTime).diff(moment(act2.activityTime), 'seconds');
							return -diff;
						});
						objRiskFactors.sort((act1, act2) => {
							let diff = moment(act1.executionTime).diff(moment(act2.executionTime), 'seconds');
							return -diff;
						});
						objdata.sessions.push({
							'session id': apiResponse.userSessionData.sessions[i].sessionId,
							'start time': common.getFormattedDate(apiResponse.userSessionData.sessions[i].sessionStartTime),
							'session score': apiResponse.userSessionData.sessions[i].sessionScore,
							'risk score': apiResponse.userSessionData.sessions[i].riskScore,
							'activities': objActivities,
							'riskassessments': objRiskAssessments,
							'riskfactors': objRiskFactors,
							'channel': channelid
						});
					}
				}
			}
		}
	} catch (e) {
		console.log(e);
		logger.error("API- " + common.getEndpointURL("diagnostics") + "--" + e);
	}

	res.json(objdata)
}