/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var nconf = require('nconf');
var FileSys = require('fs');
var path=require('path');

var config = {
	demomode: false,
	port: 3000,
	apiPort:8080,
	apiHost:'http://neurodbinstance.cfekgfnky4ey.us-west-2.rds.amazonaws.com',
	apiBaseUrl:'/rba-admin',
	clientId:'',
    //All rba server(s) to be refreshed will be mentioned here
    rbaServerURLs: [{'host':"http://neurodbinstance.cfekgfnky4ey.us-west-2.rds.amazonaws.com", 'port':"8080"}], 
    rbaServerBaseUrl:'/rba',
    //rba authenticator service base URL
    rbaAuthServiceBaseUrl: '/rba-authenticator-service',
	//Client timeout - Default:20 Mins
    timeout : 1200000,
	logsEnabled: true,
	logsPath:'../logs',
	sslEnabled:false,
    apiHostProtocol:'http', 
    appDateFormat:"YYYY-MM-DD HH:mm:ss",
    /*  appDateFormat is the date format which will be used throughout the app
        examples:
        Format string               value
        YYYY-MM-DD hh:mm:ss         2018-03-09 03:07:41
        YYYY-MM-DD HH:mm:ss         2018-03-09 15:07:41
        DD-MM-YY  HH:mm:ss A        09-03-2018 15:03:05 PM
        MM-DD-YY  HH:mm:ss A        03-09-18 15:03:05 PM
        DD-MMM-YY HH:mm:ss A       09-Mar-18 15:03:05 PM
    */
        authMode:{
        enabled:false,
        authType:"OAM_SSO", //OAM_SSO, OAM_OAUTH_LOGIN, OAM_OAUTH_API
        OAM_SSO:{'userid': "",
                 'firstname': "",
                 'lastname': "",
				 'userrole': ""
                },
        OAM_OAUTH_LOGIN:{
            redirect_uri: "",
            host:'',
            port:'',
            userProfileEndpoint:'',
            credentials: {
                client: {
                    id: '',
                    secret: '',  
                },
                auth: {
                    tokenHost: '',
                    tokenPath: '',
                    authorizePath: ''  
                },
                http: {
                    'Authorization':'',
                    'Content-Type': ''
                }
            }
        },
        OAM_OAUTH_API:{
            redirect_uri: "",
            host:'',
            port:'',
            userProfileEndpoint:'',
            credentials: {
                client: {
                    id: '',
                    secret: '',  
                },
                auth: {
                    tokenHost: '',
                    tokenPath: '',
                    authorizePath: ''  
                },
                http: {
                    'Authorization':'',
                    'Content-Type': ''
                }
            }
        }
    },
    //Auth type values on Activity wizard
    authType:[{'id':"LOW", 'text':"Low"},
            {'id':"NORMAL", 'text':"Normal"},
            {'id':"HIGH", 'text':"High"}],
    //Channel values on Activity Wizard
	ExportActivitySettings : {'FileName': 'Activity_List', 'DatetimeStamp': true},
    refreshCacheActivity: {
        enabled: false, //Protect refresh cache activity - Disabled by default
        activityId: 'REFCACHE', //Activity to be invoked for determine authentication
        sourceType: 'DOTCOM', //Source type for performing challenge
        channel: 'WEB', //Channel for determine authentication
        userType: 'USER', //User type for determine authentication        
        authenticators: {
            //Mapping of authenticators supported for refresh cache activity
            //E.g. OTP is supported authenticator, 
            //the configured authenticator ID for OTP needs to be mapped against keyword "OTPAuthenticatorID"
            "OTPAuthenticatorID": "OTP"
        }
    }
}
 
var config_to_return;
config_to_return=config;

module.exports = function() {
	 return config_to_return;
}
