/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var wizardController=require('../controllers/wizardController');
var loginController=require('../controllers/loginController');

router.get('/activities/:activity',loginController.authenticate,function(req,res,next){
    runner(wizardController.getActivities(req,res,next));
});

router.post('/activities',loginController.authenticate,function(req,res,next){
    runner(wizardController.postActivities(req,res,next));
});

router.get('/riskAssesment/',loginController.authenticate,function(req,res,next){
    runner(wizardController.getRisk(req,res,next));
});

router.post('/riskAssesment/',loginController.authenticate,function(req,res,next){
    runner(wizardController.postRisk(req,res,next));
});

router.get('/authenticators/',loginController.authenticate,function(req,res,next){
    runner(wizardController.getAuthenticators(req,res,next));
});

router.post('/authenticators/',loginController.authenticate,function(req,res,next){
    runner(wizardController.postAuthenticators(req,res,next));
});

router.get('/balanceRiskAuthenticators/',loginController.authenticate,function(req,res,next){
    runner(wizardController.getBalanceRiskAuthenticators(req,res,next));
});

router.get('/confirm/',loginController.authenticate,function(req,res,next){
    runner(wizardController.getConfirm(req,res,next));
});

router.post('/postbalancerisk/',loginController.authenticate,function(req,res,next){    
    runner(wizardController.postBalanceRiskWizard(req,res,next));
});

router.post('/postActivityWizard/',loginController.authenticate,function(req,res,next){    
    runner(wizardController.postActivityWizard(req,res,next));
});

router.post('/putActivityWizard/',loginController.authenticate,function(req,res,next){    
    runner(wizardController.putActivityWizard(req,res,next));
});

router.put('/clearWizardSession/',loginController.authenticate,function(req,res,next){    
    runner(wizardController.clearWizardSession(req,res,next));
});

module.exports=router;