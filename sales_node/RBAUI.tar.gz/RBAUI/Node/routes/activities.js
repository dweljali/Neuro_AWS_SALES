/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var activitiesController=require('../controllers/activitiesController');
var loginController=require('../controllers/loginController');

router.get('/getActivitiesCount',loginController.authenticate, function(req,res,next){
    runner(activitiesController.getActivitiesCount(req,res,next));
});

router.get('/getActivities',loginController.authenticate, function(req,res,next){
    runner(activitiesController.getActivities(req,res,next));
});
router.post('/deleteActivity',loginController.authenticate, function (req,res,next) {
	runner(activitiesController.deleteActivity(req,res,next));
});

router.post('/editActivity',loginController.authenticate, function (req,res,next) {
	runner(activitiesController.editActivity(req,res,next));
});
router.put('/changeActivityStatus',loginController.authenticate, function (req,res,next) {
	runner(activitiesController.changeActivityStatus(req,res,next));
});
router.get('/validateActivityScore/:ID/:Channel',loginController.authenticate, function(req,res,next){
    runner(activitiesController.validateActivityScore(req,res,next));
});
module.exports=router;