/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express = require('express');
var router = express.Router();
var runner = require('../../runner.js');
var validateController = require('../controllers/validationController');
var loginController=require('../controllers/loginController');

router.post('/determine', loginController.authenticate, function (req, res, next) {
    runner(validateController.determine(req, res, next));
});

router.post('/sendOTP', loginController.authenticate, function (req, res, next) {
    runner(validateController.sendOTP(req, res, next));
});

router.post('/validateOTP', loginController.authenticate, function (req, res, next) {
    runner(validateController.validateOTP(req, res, next));
});
module.exports = router;