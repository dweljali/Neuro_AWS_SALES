/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var objChannel=require('../controllers/channelsController');
var loginController=require('../controllers/loginController');

router.get('/getChannels', loginController.authenticateAuthorzation, function(req,res,next){
    runner(objChannel.getChannels(req,res,next));
});

router.post('/channel',loginController.authenticate, function(req,res,next){
    runner(objChannel.postChannels(req,res,next));
});

router.put('/channel',loginController.authenticate, function(req,res,next){
    runner(objChannel.putChannels(req,res,next));
});

router.post('/deletechannel',loginController.authenticate, function(req,res,next){
    runner(objChannel.deletechannel(req,res,next));
});


module.exports=router;