/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var authenticatorController=require('../controllers/authenticatorController');
var loginController=require('../controllers/loginController');

router.get('/getAuthenticatorsCount',loginController.authenticate,function(req,res,next){
    runner(authenticatorController.getAuthenticatorsCount(req,res,next));
});
router.get('/getAuthenticators',loginController.authenticate,function(req,res,next){
    runner(authenticatorController.getAuthenticators(req,res,next));
});
router.post('/deleteAuthenticators',loginController.authenticate,function(req,res,next){
    runner(authenticatorController.deleteAuthenticators(req,res,next));
});
router.post('/Authenticators',loginController.authenticate, function(req,res,next){
    runner(authenticatorController.postAuthenticators(req,res,next));
});
router.put('/updateAuthenticators',loginController.authenticate, function(req,res,next){
    runner(authenticatorController.updateAuthenticators(req,res,next));
});
module.exports=router;