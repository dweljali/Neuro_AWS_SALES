/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var objfactlocator=require('../controllers/factlocatorsController');
var loginController=require('../controllers/loginController');

router.get('/factlocators', loginController.authenticate, function(req,res,next){
    runner(objfactlocator.getFactlocators(req,res,next));
});

router.post('/factlocators',loginController.authenticate, function(req,res,next){
    runner(objfactlocator.postFactlocators(req,res,next));
});

router.put('/factlocators',loginController.authenticate, function(req,res,next){
    runner(objfactlocator.putFactlocators(req,res,next));
});

router.post('/deletefactlocators',loginController.authenticate, function(req,res,next){
    runner(objfactlocator.deleteFactlocators(req,res,next));
});


module.exports=router;