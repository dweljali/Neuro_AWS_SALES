/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express = require('express');
var router = express.Router();
var runner = require('../../runner.js');
var wizardRoutes = require('./wizard');
var activities = require('./activities');
var rules = require('./rules');
var authenticators = require('./authenticators');
var login = require('./login');
var logout = require('./logout');
var risk = require('./riskassessments');
var opsdashboard = require('./monitorOps');
var objimport = require('./import');
var objdiagnostics = require('./diagnostics');
var objchannels = require('./channels');
var objvalidate = require('./validation');
var objfactlocator = require('./factlocators');

router.use('/admin/api/wizard', wizardRoutes)
router.use('/admin/api/activities', activities)
router.use('/admin/api/rules', rules)
router.use('/admin/api/authenticators', authenticators)
router.use('/admin/api/login', login);
router.use('/admin/api/logout', logout);
router.use('/admin/api/opsdashboard', opsdashboard);
router.use('/admin/api/riskAssessments', risk);
router.use('/admin/api/import', objimport);
router.use('/admin/api/diagnostics', objdiagnostics);
router.use('/admin/api/channels', objchannels);
router.use('/admin/api/validate', objvalidate);
router.use('/admin/api/factlocator', objfactlocator);
router.get('/admin/api/isLoggedIn', function (req, res, next) {
      if (req.session.Authorization) {
            res.json({ data: true, authMode: ((config.authMode.enabled == true) ? true : false) })
      }
      else {
            res.json({ data: false, authMode: ((config.authMode.enabled == true) ? true : false) })
      }
});
router.get('/admin/ActivityWizard/new', function (req, res, next) {
      req.session.balanceData = null;
      req.session.challengeData = null;
      req.session.activechallenges = null;
      req.session.activeRiskOS = null;
      req.session.activeRiskEA = null;
      next();
});

module.exports = router;