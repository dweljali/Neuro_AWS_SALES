/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express = require('express');
var router = express.Router();
var runner = require('../../runner.js');
var rulesController = require('../controllers/rulesController');
var loginController = require('../controllers/loginController');


router.get('/getRules', loginController.authenticate, function (req, res, next) {
    runner(rulesController.getRules(req,res,next));
});
router.get('/getRule/:ID', loginController.authenticate, function (req, res, next) {
    runner(rulesController.getRuleById(req,res,next));
});
router.get('/getRuleConditions', loginController.authenticate, function (req, res, next) {
    runner(rulesController.getRuleConditions(req,res,next));
});
router.get('/getRuleCount', loginController.authenticate, function (req, res, next) {
    runner(rulesController.getRuleCount(req,res,next));
});
router.post('/postRules', loginController.authenticate, function (req, res, next) {
    runner(rulesController.postRules(req,res,next));
});
router.put('/editRule/:ID', loginController.authenticate, function (req, res, next) {
    runner(rulesController.putRule(req,res,next));
});
router.get('/getRuleFacts', loginController.authenticate, function (req, res, next) {
    runner(rulesController.getRuleFacts(req,res,next));
});
module.exports = router;