/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var app=express();
var config=require('./Node/config')()
var routes=require('./Node/routes');
var path=require('path')
var bodyParser=require('body-parser');
var compression = require('compression');
var sessionexpress = require('express-session');
var cookieParser = require('cookie-parser');
var csrf = require('csurf');
var proxyAPI = require('./Node/lib/API');
    app.use(compression());
	app.use(cookieParser());

  app.use(sessionexpress({ secret: require('crypto').randomBytes(32).toString('hex'), 
							 saveUninitialized: true, resave: true, 
							 cookie: { maxAge: config.timeout,secure:config.sslEnabled} , 
							 rolling:true,
                            unset: 'destroy' }));

	app.use(bodyParser.urlencoded({ extended: true }));
	app.use(bodyParser.json({ limit: '5mb' }));
	app.use(bodyParser.raw({ limit: '5mb' }));
	app.use(bodyParser.text({ limit: '5mb' }));

if (config.authMode.enabled && 
    (config.authMode.authType == "OAM_OAUTH_LOGIN" || config.authMode.authType == "OAM_OAUTH_API")){
    var isLogin = (config.authMode.authType == "OAM_OAUTH_LOGIN") ? true : false;
    const credentialOAM = isLogin ? config.authMode.OAM_OAUTH_LOGIN.credentials :  
                            config.authMode.OAM_OAUTH_API.credentials;
    
    const redirectURL = isLogin ? config.authMode.OAM_OAUTH_LOGIN.redirect_uri :
                            config.authMode.OAM_OAUTH_API.redirect_uri;
    
    // Initialize the OAuth2 Library 
    const oauth2 = require('simple-oauth2').create(credentialOAM);

    // Authorization oauth2 URI 
    const authorizationUri = oauth2.authorizationCode.authorizeURL({
        redirect_uri: redirectURL,
        scope: 'UserProfile.me UserProfile.groups'
        //,state: '<state>'
    });
     
    // Redirect
    app.get('/auth', function (req, res) {
        res.redirect(authorizationUri);
    });
    
    //Handle callback
    app.get('/oauth2/login/callback', function(req, res,next) {
        var code = req.query.code;
        var token,accessToken,refreshToken,expires_in;
        var tokenConfig = {
          code: code,
          redirect_uri: redirectURL,
        };

        oauth2.authorizationCode.getToken(tokenConfig, function saveToken(error, result) {
            if (error) { console.log('Access Token Error', error.message);return; }
             accessToken = result.access_token;
            refreshToken = result.refresh_token;

            var objLoginController = require('./Node/controllers/loginController');
            var runner=require('./runner.js');
            var encryptr = require('./Node/lib/encryptr');
            
            
            runner(objLoginController.getOAMDetails(accessToken, req, res, function(objReq, objRes){
                if(objReq.session.OAMUserProfile){

                    var encryptedtext = encryptr.encryptUser(objReq.session.OAMUserProfile.uid);                    
                    req.body.username = encryptedtext;
                    req.body.SSOMODE = isLogin ? "PROTECT_LOGIN" : "PROTECT_API";
                    req.body.AccessToken = accessToken;
                    
                    if(isLogin){
                        runner(objLoginController.validateOauthToken(req,res,function(request,response){
                               if(request.session.Authorization){
                                   res.redirect('/admin/dashboard');
                                }
                        }));
                    }
                    else{
                        req.session.Authorization = accessToken;
                        req.session.userName = objReq.session.OAMUserProfile.uid;
                        res.redirect('/admin/dashboard');
                    }                    
                }
            }));
            
        });
    });
}

//Handle login
//Check for session / Auth type
app.get('/login', function(req,res,next){
    if(req.session.Authorization){
        return res.redirect('/admin/dashboard');
    }
    else if (config.authMode.enabled){
        if(config.authMode.authType == "OAM_SSO"){            
            if(req.headers[config.authMode.OAM_SSO.userid]){
				var objLoginController = require('./Node/controllers/loginController');
				var encryptr = require('./Node/lib/encryptr');
				var runner=require('./runner.js');

				if(req.headers[config.authMode.OAM_SSO.firstname]){
					req.body.firstName = req.headers[config.authMode.OAM_SSO.firstname];
					if(req.body.firstName == "NOT_FOUND"){
						req.body.firstName = "";
					}
				}
				if(req.headers[config.authMode.OAM_SSO.lastname]){
					req.body.lastName = req.headers[config.authMode.OAM_SSO.lastname];
				}
				
				if(req.headers[config.authMode.OAM_SSO.userrole]){
					console.log("got the role");
					console.log(req.headers[config.authMode.OAM_SSO.userrole]);
				}
				var encryptedtext = "";
				encryptedtext=  encryptr.encryptUser(req.headers[config.authMode.OAM_SSO.userid]);                   

				//var data = {};
				//data.body = {}
				req.body.username = encryptedtext;
				req.body.SSOMODE = "SSO";
				runner(objLoginController.getToken(req,res,function(request,response){                         
					return response.redirect("/admin/dashboard");
				}));
            }
        }
        else if(config.authMode.authType == "OAM_OAUTH_LOGIN" || config.authMode.authType == "OAM_OAUTH_API"){
            return res.redirect("/auth");
        }
    }
    else{
        return next();
    }
});


app.use(csrf({cookie:{maxAge: config.timeout,secure:config.sslEnabled},saltLength:16,secretLength:32}));
app.use(function(req,res,next){
      
	  app.locals.token=req.csrfToken();
	  res.cookie("csrfToken",app.locals.token, { secure: config.sslEnabled });
	  next();
	});


    app.use('/',routes)
    app.use(express.static(__dirname+'/dist'));
    app.use(function(req,res,next){
        console.log("serving index.html file ")
        res.sendFile(path.join(__dirname,'dist','index.html'))
    });
    
    if(!config.sslEnabled){
       
        var httpServer = require('http').createServer(app);
        httpServer.listen(config.port);
    }
    else{
        var fs = require("fs");
        var https = require('https');
        var privateKey  = fs.readFileSync('sslcert/server.key');
        var certificate = fs.readFileSync('sslcert/server.crt');
        
        var credentials = {key: privateKey, cert: certificate};
        var httpsServer = https.createServer(credentials, app);
        httpsServer.listen(config.port);
    }
        
    module.exports = { app: httpServer }
    console.log("listenting on "+config.port)
