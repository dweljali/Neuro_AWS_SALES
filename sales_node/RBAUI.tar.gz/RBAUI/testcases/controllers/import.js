describe('Import Routes.', (done) => {
    it('Case: Import Activities (SUCCESS)...', (done) => {
        request
            .post('/admin/api/import/activities')
            .send({
                "activities": {
                    "risk": [
                        {
                            "riskAssessmentCD": "DEVICE1",
                            "riskAssessmentName": "DEVICE1",
                            "riskAssessmentInvocationCD": "EA",
                            "riskAssessmentConfigurations": [
                                {
                                    "riskAssessmentConfigID": "DVAL1",
                                    "riskAssessmentConfigName": "DVAL1",
                                    "riskAssessmentConfigDesc": "DVAL1",
                                    "riskAssessmentConfigType": "INPUT_THRESHOLD",
                                    "riskAssessmentConfigDatatype": "STRING",
                                    "riskAssessmentConfigValue": "NOT_REGISTERED"
                                }
                            ]
                        }
                    ],
                    "riskFactorsVO": [
                        {
                            "id": "DEVICE1",
                            "riskFactors": [
                                {
                                    "riskFactorCode": "DFCODE",
                                    "riskFactorName": "DFCODE",
                                    "riskFactorDataTypeName": "STRING",
                                    "riskFactorInvocationCode": "EVERY_ACTIVITY_START",
                                    "providedBySourceSystemName": "RBA_INTERNAL",
                                    "retryCollectionOnFailureIndicator": false
                                }
                            ]
                        }
                    ],
                    "authenticators": [
                        {
                            "id": "OTP1",
                            "description": "OTP1",
                            "factKey": "UserInfo",
                            "activeStatus": 1
                        }
                    ],
                    "activity": [
                        {
                            "activity": {
                                "activityID": "CHNGID5",
                                "description": "Change Web ID5",
                                "activityAuthLevel": "NORMAL",
                                "requiredScore": 2,
                                "channel": "MOBILE",
                                "activeStatus": 1
                            },
                            "riskAssessmentList": [
                                {
                                    "riskAssessmentCD": "DEVICE",
                                    "description": "Device Risk Assessment"
                                }
                            ],
                            "authenticationChallengeList": [
                                {
                                    "id": "ZIP",
                                    "score": 60,
                                    "priority": 1,
                                    "description": "Zip Code"
                                }
                            ]
                        }
                    ]
                }
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });


     it('Case: Import Activities (FAILURE)...', (done) => {
        request
            .post('/admin/api/import/activities')
            .send({
                "activities": {
                    "risk": [
                        {
                            "riskAssessmentCD": "DEVICE",
                            "riskAssessmentName": "Device Risk Assessment",
                            "riskAssessmentInvocationCD": "EA",
                            "riskAssessmentConfigurations": [
                                {
                                    "riskAssessmentConfigID": "DEVTREFVAL",
                                    "riskAssessmentConfigName": "High risk device status",
                                    "riskAssessmentConfigDesc": "High risk device status",
                                    "riskAssessmentConfigType": "INPUT_THRESHOLD",
                                    "riskAssessmentConfigDatatype": "STRING",
                                    "riskAssessmentConfigValue": "NOT_REGISTERED,BLACK_LISTED,JAILBROKEN,REVOKED,UNREGISTERED, UNSAFE"
                                },
                                {
                                    "riskAssessmentConfigID": "DEVRSKPTS",
                                    "riskAssessmentConfigName": "High risk device risk points",
                                    "riskAssessmentConfigDesc": "Number of points to add to the required trust score for high risk device.",
                                    "riskAssessmentConfigType": "OUTPUT_POINTS",
                                    "riskAssessmentConfigDatatype": "INTEGER",
                                    "riskAssessmentConfigValue": "25"
                                },
                                {
                                    "riskAssessmentConfigID": "DEVRSKMSG",
                                    "riskAssessmentConfigName": "Unknown/unsafe Device Risk Message",
                                    "riskAssessmentConfigDesc": "Outcome description for unknown/unsafe device",
                                    "riskAssessmentConfigType": "OUTCOME_DESC",
                                    "riskAssessmentConfigDatatype": "STRING",
                                    "riskAssessmentConfigValue": "Device bears high risk. Derived status of device is ($(deviceStatus))."
                                },
                                {
                                    "riskAssessmentConfigID": "DEVVLDMSG",
                                    "riskAssessmentConfigName": "Safe device message",
                                    "riskAssessmentConfigDesc": "Outcome description for no risk",
                                    "riskAssessmentConfigType": "OUTCOME_DESC",
                                    "riskAssessmentConfigDatatype": "STRING",
                                    "riskAssessmentConfigValue": "No risk related to the device. Derived status of device is ($(deviceStatus))."
                                },
                                {
                                    "riskAssessmentConfigID": "DEVNAMSG",
                                    "riskAssessmentConfigName": "Device details unavailable",
                                    "riskAssessmentConfigDesc": "Outcome description for device details unavailable",
                                    "riskAssessmentConfigType": "OUTCOME_DESC",
                                    "riskAssessmentConfigDatatype": "STRING",
                                    "riskAssessmentConfigValue": "Could not identity device for fingerprint."
                                }
                            ]
                        }
                    ],
                    "riskFactorsVO": [
                        {
                            "id": "DEVICE",
                            "riskFactors": [
                                {
                                    "riskFactorCode": "DEVICE",
                                    "riskFactorName": "Unknown/Unsafe Device Risk",
                                    "riskFactorDataTypeName": "STRING",
                                    "riskFactorInvocationCode": "EVERY_ACTIVITY_START",
                                    "providedBySourceSystemName": "RBA_INTERNAL",
                                    "retryCollectionOnFailureIndicator": false
                                }
                            ]
                        }
                    ],
                    "authenticators": [
                        {
                            "id": "ZIP",
                            "description": "Zip Code",
                            "factKey": "UserInfo",
                            "activeStatus": 1
                        }
                    ],
                    "activity": [
                        {
                            "activity": {
                                "activityID": "CHNGID4",
                                "description": "Change Web ID",
                                "activityAuthLevel": "NORMAL",
                                "requiredScore": 2,
                                "channel": "MOBILE",
                                "activeStatus": 1
                            },
                            "riskAssessmentList": [
                                {
                                    "riskAssessmentCD": "DEVICE",
                                    "description": "Device Risk Assessment"
                                }
                            ],
                            "authenticationChallengeList": [
                                {
                                    "id": "ZIP",
                                    "score": 60,
                                    "priority": 1,
                                    "description": "Zip Code"
                                }
                            ]
                        }
                    ]
                }
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
});