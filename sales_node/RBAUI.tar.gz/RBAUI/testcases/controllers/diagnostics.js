describe('Testing Diagnostics Routes.', (done) => {
    it('Case: Get Channels For Diagnostics...', (done) => {
        request
            .get('/admin/api/diagnostics/getChannels')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

      it('Case: Get Diagnostics Details (DEFAULT CHANNEL)...', (done) => {
        request
            .get('/admin/api/diagnostics/getDiagnostics/john/DEFAULT')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
})