describe('Testing Activity Wizard Routes.', (done) => {
    it('Case: Edit Activity Wizard...', (done) => {
        request
            .get(`/admin/api/wizard/activities/edit`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: New Activity Wizard...', (done) => {
        request
            .get(`/admin/api/wizard/activities/new`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Clear Activity Wizard Session...', (done) => {
        request
            .put(`/admin/api/wizard/clearWizardSession`)
            .send({})
            .expect(200)
            .expect((res) => {
                //console.log('Res', res.body);
            })
            .end(done);
    });

    it('Case: Post Activity Wizard Tab...', (done) => {
        request
            .post(`/admin/api/wizard/activities/`)
            .send({
                "activityName": "",
                "activityDesc": "Change Web ID",
                "activityId": "CHNGID",
                "activityscore": 1,
                "currentSelectedChannel": "WEB",
                "currentSelectedAuthType": "NORMAL"
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Post Activity Wizard Risk Tab...', (done) => {
        request
            .post(`/admin/api/wizard/riskAssesment`)
            .send({
                "activeRiskOS": [],
                "activeRiskEA": [
                    {
                        "id": "DEVICE",
                        "text": "Device Risk Assessment"
                    }
                ],
                "activeRiskscore": [
                    {
                        "id": "DEVICE",
                        "outputpoint": 25,
                        "riskfactorcount": 1
                    }
                ],
                "riskScore": 25,
                "inclusionRuleId": "ALL",
                "inclusionRulename": "All Users",
                "exclusionRuleId": "NA",
                "exclusionRulename": "None"
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Post Activity Wizard Authenticators Tab...', (done) => {
        request
            .post(`/admin/api/wizard/Authenticators`)
            .send({
                "activechallenges": [
                    {
                        "id": "ZIP",
                        "text": "Zip Code"
                    }
                ]
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

   it('Case: Post Activity Wizard Balance&Trust Tab...', (done) => {
        request
            .post(`/admin/api/wizard/postbalancerisk`)
            .send({
                "balanceData": {
                    "totalscore": 60,
                    "name": [
                        {
                            "authname": "Zip Code",
                            "score": 60
                        }
                    ]
                },
                "riskScore": 25
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Get Risk Details For Wizard...', (done) => {
        request
            .get(`/admin/api/wizard/riskAssesment/`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Get Authenticator Details For Wizard...', (done) => {
        request
            .get(`/admin/api/wizard/authenticators/`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Get Balance&Trust For Wizard...', (done) => {
        request
            .get(`/admin/api/wizard/balanceRiskAuthenticators/`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Get Confrim Tab Details For Wizard...', (done) => {
        request
            .get(`/admin/api/wizard/confirm/`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: POST - Add Activity (SUCCESS)...', (done) => {
        request
            .post(`/admin/api/wizard/postActivityWizard`)
            .send({})
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

     

    it('Case: POST - Add Activity (FAILURE)...', (done) => {
        request
            .post(`/admin/api/wizard/postActivityWizard`)
            .send({})
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

     it('Case: Post Activity Wizard Tab...', (done) => {
        request
            .post(`/admin/api/wizard/activities/`)
            .send({
                "activityName": "",
                "activityDesc": "Change Web ID",
                "activityId": "CHNGID",
                "activityscore": 2,
                "currentSelectedChannel": "WEB",
                "currentSelectedAuthType": "NORMAL"
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Post Activity Wizard Risk Tab...', (done) => {
        request
            .post(`/admin/api/wizard/riskAssesment`)
            .send({
                "activeRiskOS": [],
                "activeRiskEA": [
                    {
                        "id": "DEVICE",
                        "text": "Device Risk Assessment"
                    }
                ],
                "activeRiskscore": [
                    {
                        "id": "DEVICE",
                        "outputpoint": 25,
                        "riskfactorcount": 1
                    }
                ],
                "riskScore": 25,
                "inclusionRuleId": "ALL",
                "inclusionRulename": "All Users",
                "exclusionRuleId": "NA",
                "exclusionRulename": "None"
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Post Activity Wizard Authenticators Tab...', (done) => {
        request
            .post(`/admin/api/wizard/Authenticators`)
            .send({
                "activechallenges": [
                    {
                        "id": "ZIP",
                        "text": "Zip Code"
                    }
                ]
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

   it('Case: Post Activity Wizard Balance&Trust Tab...', (done) => {
        request
            .post(`/admin/api/wizard/postbalancerisk`)
            .send({
                "balanceData": {
                    "totalscore": 60,
                    "name": [
                        {
                            "authname": "Zip Code",
                            "score": 60
                        }
                    ]
                },
                "riskScore": 25
            })
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });


    it('Case: PUT - Update Activity (SUCESS)...', (done) => {
        request
            .post('/admin/api/wizard/putActivityWizard')
            .send({})
            .expect(200)
            .expect((res) => {

            })
            .end(done)
    });

});