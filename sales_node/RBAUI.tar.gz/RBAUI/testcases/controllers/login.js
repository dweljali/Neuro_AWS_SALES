var common = require('./common.js');
request = common.request;

describe('Testing Login Route.', () => {
    it('Case: Login Route...', (done) => {
        request
            .get(`/admin/api/login`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Valid Login...', (done) => {
        let loginCreds = {
            username: "rbaadmin",
            password: "Welcome1"
        }
        request
            .post(`/admin/api/login`)
            .send(loginCreds)
            .expect(200)
            .expect((res) => {
                console.log('Res', res.body);
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Invalid Login...', (done) => {
        let loginCreds = {
            username: "rbaadmin",
            password: "1234"
        }
        request
            .post(`/admin/api/login`)
            .send(loginCreds)
            .expect(401)
            .expect((res) => {
                console.log('Res', res.body);
            })
            .end(done);
    });

    it('Case: Validate Login...', (done) => {
        request
            .get(`/admin/api/isLoggedIn`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Get Logged In User Data...', (done) => {
        request
            .get(`/admin/api/login/getLoggedInUserDetails`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });

    it('Case: Refresh Cache...', (done) => {
        request
            .get(`/admin/api/login/refreshCache`)
            .expect(200)
            .expect((res) => {
                // expect(res.body.token)
            })
            .end(done);
    });
});