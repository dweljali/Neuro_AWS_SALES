describe('Testing factlocators Routes.', (done) => {
    it('Case: Get All factlocators...', (done) => {

        request
            .get('/admin/api/factlocator/factlocators')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

   it('Case: POST factlocator (Success)...', (done) => {

        request
            .post('/admin/api/factlocator/factlocators')
            .send({
                "factLocators" : [{   
                        "factKey": "fctky2",
                         "name": "fctky2",
                        "factLocatorClass": "fctky.class2"
                    }
                ]})
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: POST factlocator (Failure)...', (done) => {

        request
            .post('/admin/api/factlocator/factlocators')
            .send({
                "factLocators" : [
                    {
                        "factKey": "fctky",
                        "name": "fctky",
                        "factLocatorClass": "fctky.class"
                    }
                ]                 
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: PUT factlocator (SUCCESS)...', (done) => {

        request
            .put('/admin/api/factlocator/factlocators')
            .send( {
                        "factKey": "fctky",
                        "name": "fctky",
                        "factLocatorClass": "fctky.class"
                    })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: PUT factlocator (Failure)...', (done) => {

        request
            .put('/admin/api/factlocator/factlocators')
            .send( {
                        "factKey": "fctkyn",
                        "name": "fctky",
                        "factLocatorClass": "fctky.class"
                    })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
})