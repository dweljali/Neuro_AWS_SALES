describe('Risk Assessments Routes.', (done) => {
    it('Case: Get All Risk Assessments...', (done) => {
        request
            .get('/admin/api/riskAssessments/getRiskAssessments')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: Get Risk Count...', (done) => {
        request
            .get('/admin/api/riskAssessments/getRiskCount')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: Get All Risk Assessment Details(SUCCESS)...', (done) => {
        request
            .get('/admin/api/riskAssessments/getRiskAssessmentDetails/TRAVEL')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: Get All Risk Assessment Details(FAILURE)...', (done) => {
        request
            .get('/admin/api/riskAssessments/getRiskAssessmentDetails/NOTEXISTS')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case:POST Risk Assessment Details(SUCCESS)...', (done) => {
        request
            .post('/admin/api/riskAssessments/postRiskAssessmentsWithFactors')
            .send({
                "riskassessments": [
                    {
                        "riskAssessmentCD": "TEST1",
                        "riskAssessmentName": "TESTRSK1",
                        "riskAssessmentInvocationCD": "EA",
                        "riskAssessmentConfigurations": [
                            {
                                "riskAssessmentConfigID": "TESTCON1",
                                "riskAssessmentConfigName": "TEST CONFIG1",
                                "riskAssessmentConfigDesc": "TEST",
                                "riskAssessmentConfigType": "INPUT_THRESHOLD",
                                "riskAssessmentConfigDatatype": "STRING",
                                "riskAssessmentConfigValue": "01"
                            }
                        ]
                    }
                ],
                "riskFactors": [
                    {
                        "riskFactorCode": "TESTRF1",
                        "riskFactorName": "RF TEST1",
                        "riskFactorDataTypeName": "STRING",
                        "providedBySourceSystemName": "EXTERNAL",
                        "retryCollectionOnFailureIndicator": false,
                        "rerunOnFactorChange": false,
                        "riskFactorInvocationCode": "EVERY_ACTIVITY_START"
                    }
                ]
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case:POST Risk Assessment Details(FAILURE)...', (done) => {
        request
            .post('/admin/api/riskAssessments/postRiskAssessmentsWithFactors')
            .send({
                "riskassessments": [
                    {
                        "riskAssessmentCD": "TEST1",
                        "riskAssessmentName": "TESTRSK1",
                        "riskAssessmentInvocationCD": "EA",
                        "riskAssessmentConfigurations": [
                            {
                                "riskAssessmentConfigID": "TESTCON1",
                                "riskAssessmentConfigName": "TEST CONFIG1",
                                "riskAssessmentConfigDesc": "TEST",
                                "riskAssessmentConfigType": "INPUT_THRESHOLD",
                                "riskAssessmentConfigDatatype": "STRING",
                                "riskAssessmentConfigValue": "01"
                            }
                        ]
                    }
                ],
                "riskFactors": [
                    {
                        "riskFactorCode": "TESTRF1",
                        "riskFactorName": "RF TEST1",
                        "riskFactorDataTypeName": "STRING",
                        "providedBySourceSystemName": "EXTERNAL",
                        "retryCollectionOnFailureIndicator": false,
                        "rerunOnFactorChange": false,
                        "riskFactorInvocationCode": "EVERY_ACTIVITY_START"
                    }
                ]
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });


    it('Case:PUT Risk Assessment Details(SUCCESS)...', (done) => {
        request
            .put('/admin/api/riskAssessments/edirRiskAssessmentDetails/TEST1')
            .send({
                "riskAssessmentCD": "TEST1",
                "riskAssessmentName": "TESTRSK1",
                "riskAssessmentInvocationCD": "EA",
                "rerunAssessmentOnFailure": false,
                "riskAssessmentConfigurations": [
                    {
                        "assessmentCode": "TEST1",
                        "riskAssessmentConfigID": "TESTCON1",
                        "riskAssessmentConfigName": "TEST CONFIG",
                        "riskAssessmentConfigDesc": "TEST",
                        "riskAssessmentConfigType": "INPUT_THRESHOLD",
                        "riskAssessmentConfigDatatype": "STRING",
                        "riskAssessmentConfigValue": "01"
                    }
                ],
                "riskFactorVOs": [
                    {
                        "riskFactorCode": "TESTRF1",
                        "riskFactorName": "RF TEST1",
                        "riskFactorDataTypeName": "STRING",
                        "providedBySourceSystemName": "EXTERNAL",
                        "retryCollectionOnFailureIndicator": false,
                        "rerunOnFactorChange": false,
                        "riskFactorInvocationCode": "EVERY_ACTIVITY_START"
                    }
                ]
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case:PUT Risk Assessment Details(SUCCESS)...', (done) => {
        request
            .put('/admin/api/riskAssessments/edirRiskAssessmentDetails/NOTEXISTS')
            .send({
                "riskAssessmentCD": "TEST1",
                "riskAssessmentName": "TESTRSK1",
                "riskAssessmentInvocationCD": "EA",
                "rerunAssessmentOnFailure": false,
                "riskAssessmentConfigurations": [
                    {
                        "assessmentCode": "TEST1",
                        "riskAssessmentConfigID": "TESTCON1",
                        "riskAssessmentConfigName": "TEST CONFIG",
                        "riskAssessmentConfigDesc": "TEST",
                        "riskAssessmentConfigType": "INPUT_THRESHOLD",
                        "riskAssessmentConfigDatatype": "STRING",
                        "riskAssessmentConfigValue": "01"
                    }
                ],
                "riskFactorVOs": [
                    {
                        "riskFactorCode": "TESTRF1",
                        "riskFactorName": "RF TEST1",
                        "riskFactorDataTypeName": "STRING",
                        "providedBySourceSystemName": "EXTERNAL",
                        "retryCollectionOnFailureIndicator": false,
                        "rerunOnFactorChange": false,
                        "riskFactorInvocationCode": "EVERY_ACTIVITY_START"
                    }
                ]
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });



})