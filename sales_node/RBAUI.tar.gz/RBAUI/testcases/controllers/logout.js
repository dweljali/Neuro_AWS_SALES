describe('Testing Login Route(Logout Method).', () => {
    it('Case: Logout(Success)...', (done) => {

        request
            .put(`/admin/api/logout`)
            .send({})
            .expect(200)
            .expect((res) => {
                console.log('Res', res.body);
            })
            .end(done);
    });

    it('Case: Logout(Failure)...', (done) => {

        request
            .put(`/admin/api/logout`)
            .send({})
            .expect(200)
            .expect((res) => {
                console.log('Res', res.body);
            })
            .end(done);
    });
});