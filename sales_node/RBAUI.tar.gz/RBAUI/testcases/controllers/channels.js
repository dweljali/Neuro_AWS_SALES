describe('Testing Channel Routes.', (done) => {
    it('Case: Get All Channels...', (done) => {

        request
            .get('/admin/api/channels/getChannels')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: POST Channel (Success)...', (done) => {

        request
            .post('/admin/api/channels/channel')
            .send({
                "channelID": "ABC",
                "channelDescription": "ABC"
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: POST Channel (Failure)...', (done) => {

        request
            .post('/admin/api/channels/channel')
            .send({
                "channelID": "ABC",
                "channelDescription": "ABC"
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: PUT Channel (SUCCESS)...', (done) => {

        request
            .put('/admin/api/channels/channel')
            .send({
                "channelID": "ABC",
                "channelDescription": "ABC"
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: PUT Channel (Failure)...', (done) => {

        request
            .put('/admin/api/channels/channel')
            .send({
                "channelID": "ABCD",
                "channelDescription": "ABC"
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: DELETE Channel (Success)...', (done) => {

        request
            .post('/admin/api/channels/deletechannel')
            .send({
                "reqId": "ABC"
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: DELETE Channel (Failure)...', (done) => {

        request
            .post('/admin/api/channels/deletechannel')
            .send({
                "reqId": "ABC"
            })
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
})