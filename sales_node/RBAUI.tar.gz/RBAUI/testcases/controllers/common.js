const {
    app
} = require('./../../server');

const expect = require('expect');
const request = require('supertest').agent(app);

module.exports.request = request;
module.exports.expect = expect;