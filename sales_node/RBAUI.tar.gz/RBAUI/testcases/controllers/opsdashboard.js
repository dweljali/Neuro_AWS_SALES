describe('Ops Dashboard Routes.', (done) => {
    it('Case: Get Ops Dasbhoard (SUCCESS)...', (done) => {
        request
            .get('/admin/api/opsdashboard/getChartData/1M/2017-12-11T00:00:00.000Z-330/2018-01-10T23:59:59.999Z-330/en-US/AT')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: Get Ops Dasbhoard (SUCCESS)...', (done) => {
        request
            .get('/admin/api/opsdashboard/getChartData/1C/2017-12-11T00:00:00.000Z-330/2018-01-10T23:59:59.999Z-330/en-US/AT')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
})

describe('Ops Dashboard User Cards', (done) => {
    it('Case: Get RISK SCORE INDEX (SUCCESS)...', (done) => {
        request
            .get('/admin/api/opsdashboard/userCards/RSI/2018-02-14T00:00:00.000Z-330/2018-03-16T23:59:59.999Z-330')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
    it('Case: Get AUTHENTICATOR TREND  (SUCCESS)...', (done) => {
        request
            .get('/admin/api/opsdashboard/userCards/AT/2018-02-14T00:00:00.000Z-330/2018-03-16T23:59:59.999Z-330')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
    it('Case: Get AUTHENTICATOR FAILURE  (SUCCESS)...', (done) => {
        request
            .get('/admin/api/opsdashboard/userCards/AF/2018-02-14T00:00:00.000Z-330/2018-03-16T23:59:59.999Z-330')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });
});