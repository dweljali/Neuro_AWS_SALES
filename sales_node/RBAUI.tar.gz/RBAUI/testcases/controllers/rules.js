describe('Rule Routes', () => {
    it('Case: Get All Rules...', (done) => {
        request
            .get('/admin/api/rules/getRules')
            .expect(200)
            .expect((res) => {
                console.log('getRules', res.body);
            })
            .end(done);
    })

    it('Case: Get Rules By ID (SUCCESS)...', (done) => {
        request
            .get('/admin/api/rules/getRule/cfe18d21-9cdd-4716-8b67-cc5e393164aa')
            .expect(200)
            .expect((res) => {
                console.log('getRule', res.body);
            })
            .end(done);
    })

    it('Case: Get Rules By ID (FAILURE)...', (done) => {
        request
            .get('/admin/api/rules/getRule/59ebf876-d27c-4312-87ab-02e2346ac830')
            .expect(200)
            .expect((res) => {
                console.log('getRule', res.body);
            })
            .end(done);
    })

    it('Case: Get Rule Conditions...', (done) => {
        request
            .get('/admin/api/rules/getRuleConditions')
            .expect(200)
            .expect((res) => {
                console.log('getRuleConditions', res.body);
            })
            .end(done);
    })
    it('Case: Get Rule Facts...', (done) => {
        request
            .get('/admin/api/rules/getRuleFacts')
            .expect(200)
            .expect((res) => {
                console.log('getRuleFacts', res.body);
            })
            .end(done);
    })
    it('Case: Get Rule Count...', (done) => {
        request
            .get('/admin/api/rules/getRuleCount')
            .expect(200)
            .expect((res) => {
                console.log('getRuleCount', res.body);
            })
            .end(done);
    })

    it('Case: POST Rule (Success)...', (done) => {
        request
            .post('/admin/api/rules/postRules')
            .send({
                "name": "RuleT1",
                "description": "RuleT1",
                "factServcie": {
                    "id": "UserInfo",
                    "text": "UserInfo"
                },
                "factServcieKey": "$userId",
                "ruleConditions": [
                    {
                        "attribute": {
                            "id": "zipCode",
                            "text": "zipCode"
                        },
                        "condition_operator": {
                            "id": "SW",
                            "text": "Starts With"
                        },
                        "value": "1",
                        "rule_operator": {
                            "id": "OR",
                            "text": "OR"
                        },
                        "operator": [
                            {
                                "text": "AND"
                            }
                        ]
                    },
                    {
                        "attribute": {
                            "id": "favoriteBook",
                            "text": "favoriteBook"
                        },
                        "condition_operator": {
                            "id": "ET",
                            "text": "Equals To"
                        },
                        "value": "ret",
                        "rule_operator": {
                            "id": "AND",
                            "text": "AND"
                        },
                        "operator": [
                            {
                                "text": "AND"
                            }
                        ]
                    }
                ]
            })
            .expect(200)
            .expect((res) => {

            })
            .end(done);
    })

    it('Case: POST Rule (Failure)...', (done) => {
        request
            .post('/admin/api/rules/postRules')
            .send({
                "name": "RuleTNew",
                "description": "RuleTNew",
                "factServcie": {
                    "id": "UserInfo",
                    "text": "UserInfo"
                },
                "factServcieKey": "$userId",
                "ruleConditions": [
                    {
                        "attribute": {
                            "id": "favoriteBook",
                            "text": "favoriteBook"
                        },
                        "condition_operator": {
                            "id": "ET",
                            "text": "Equals To"
                        },
                        "value": "ret",
                        "rule_operator": {
                            "id": "AND",
                            "text": "AND"
                        },
                        "operator": [
                            {
                                "text": "AND"
                            }
                        ]
                    }
                ]
            })
            .expect(200)
            .expect((res) => {

            })
            .end(done);
    })


    it('Case: PUT Rule (Success)...', (done) => {
        request
            .put('/admin/api/rules/editRule/bd210fec-297c-4cb3-92ad-01539a47fd13')
            .send({
                "name": "Test New 6",
                "description": "Test New 6",
                "factServcie": {
                    "id": "UserInfo",
                    "text": "UserInfo"
                },
                "factServcieKey": "$userId",
                "ruleConditions": [
                    {
                        "attribute": {
                            "id": "socialSecurityNumber",
                            "text": "socialSecurityNumber"
                        },
                        "condition_operator": {
                            "text": "Starts With",
                            "id": "SW"
                        },
                        "value": "1",
                        "rule_operator": {
                            "id": "AND",
                            "text": "AND"
                        },
                        "operator": [
                            {
                                "text": "AND"
                            }
                        ]
                    }
                ]
            })
            .expect(200)
            .expect((res) => {

            })
            .end(done);
    })

    it('Case: PUT Rule (Failure)...', (done) => {
        request
            .put('/admin/api/rules/editRule/NotExists')
            .send({
                "name": "RuleT",
                "description": "RuleT",
                "factServcie": {
                    "id": "UserInfo",
                    "text": "UserInfo"
                },
                "factServcieKey": "$userId",
                "ruleConditions": [
                    {
                        "attribute": {
                            "id": "zipCode",
                            "text": "zipCode"
                        },
                        "condition_operator": {
                            "text": "Starts With",
                            "id": "SW"
                        },
                        "value": "1",
                        "rule_operator": {
                            "id": "OR",
                            "text": "OR"
                        },
                        "operator": [
                            {
                                "text": "OR"
                            }
                        ]
                    },
                    {
                        "attribute": {
                            "id": "favoriteBook",
                            "text": "favoriteBook"
                        },
                        "condition_operator": {
                            "text": "Equals To",
                            "id": "ET"
                        },
                        "value": "ret",
                        "rule_operator": {
                            "id": "AND",
                            "text": "AND"
                        },
                        "operator": [
                            {
                                "text": "AND"
                            }
                        ]
                    }
                ]
            })
            .expect(200)
            .expect((res) => {

            })
            .end(done);
    })


});