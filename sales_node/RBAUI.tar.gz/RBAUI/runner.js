/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var runner=function (gen,val){
	var promise;
	var result=gen.next(val);

	if (!result.done) {
		//code
		promise=result.value;
		promise.then(function(data){
			runner(gen,data)
			},function(err){
				console.log(err)
				/*gen.throw(err)*/
                runner(gen);
				})
	}
}

module.exports=runner;
