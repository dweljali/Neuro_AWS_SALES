/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var riskController=require('../controllers/riskassessmentsController');
var loginController=require('../controllers/loginController');

router.get('/getRiskScorePolicy',loginController.authenticate, function(req,res,next){
    runner(riskController.getRiskScorePolicy(req,res,next));
});

router.get('/getRiskCount',loginController.authenticate, function(req,res,next){
    runner(riskController.getRiskCount(req,res,next));
});

router.get('/getRiskAssessments',loginController.authenticate, function(req,res,next){
    runner(riskController.getRiskAssessments(req,res,next));
});

router.get('/getRiskAssessmentDetails/:ID',loginController.authenticate, function(req,res,next){
    runner(riskController.getRiskAssessmentDetails(req,res,next));
});

router.put('/edirRiskAssessmentDetails/:ID', loginController.authenticate, function(req, res, next){
    runner(riskController.editRiskAssessmentDetails(req, res, next));
});

router.post('/postRiskAssessmentsWithFactors',loginController.authenticate, function (req,res,next) {
	runner(riskController.postRiskAssessmentsWithFactors(req,res,next));
});

module.exports=router;