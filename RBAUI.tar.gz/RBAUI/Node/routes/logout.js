/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var loginController=require('../controllers/loginController');

router.put('/',function(req,res,next){
    runner(loginController.logout(req,res,next));
});

module.exports=router;