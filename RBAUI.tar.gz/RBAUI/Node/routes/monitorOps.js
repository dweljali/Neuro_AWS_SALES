/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var express=require('express');
var router = express.Router();
var runner=require('../../runner.js');
var monitorOpsController=require('../controllers/monitorOpsController');
var loginController=require('../controllers/loginController');

router.get('/getChartData/:duration/:startDate/:endDate/:locale/:type',loginController.authenticateAuthorzation, function(req,res,next){
    runner(monitorOpsController.getChartData(req,res,next));
});
router.get('/userCards/RSI/:startDate/:endDate',loginController.authenticateAuthorzation, function(req,res,next){
    runner(monitorOpsController.getRSIData(req,res,next));
});
router.get('/userCards/AT/:startDate/:endDate',loginController.authenticateAuthorzation, function(req,res,next){
    runner(monitorOpsController.getATData(req,res,next));
});
router.get('/userCards/AF/:startDate/:endDate',loginController.authenticateAuthorzation, function(req,res,next){
    runner(monitorOpsController.getAFData(req,res,next));
});
module.exports=router;