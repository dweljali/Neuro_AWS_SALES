/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise=require('bluebird');
var proxyAPI=require('../lib/API');
proxyAPI=promise.promisifyAll(proxyAPI);
var common=require('../lib/common');
var config = require('../config')();
var async = require('async');
var logger = require('../lib/logger');

/* This function wil verify login by checking Authorization token in session, returns boolean variable */
exports.verifyLogin = function* (req,res,next){
    if(req.session.Authorization){
        res.json({"login":true,"userole":req.session.userrole})
    }
    else{
        res.json({"login":false})
	}
}

/* This function wil verify login by checking Authorization token in session, returns status code*/
exports.authenticate = function (req,res,next){
	if(req.session.Authorization && req.session.userrole == "fraudinvestigator"){
		var apiData={statusCode: 402, message: "Access Denied/Forbidden"};
        return res.send(apiData);
	}
    else if(req.session.Authorization){
        next();
    }
    else{
        var apiData={statusCode: 401};
        return res.send(apiData);
    }   
}


exports.authenticateAuthorzation = function (req,res,next){
	if(req.session.Authorization){
        next();
    }
    else{
        var apiData={statusCode: 401};
        return res.send(apiData);
    }   
}

/* This function returns the logged in user's first and lastname stored in session */
exports.getLoggedInUserDetails = function* (req,res,next){
    var data={};
    if(req.session.fname){
        data.firstName = req.session.fname;
    }
    if(req.session.lname){
        data.lastName = req.session.lname;
    }
	
	data.userrole = "neuroadmin";
	data.userroleDisplayName = "Neuro Admin";
	if(req.session.userrole){
		if(req.session.userrole == "fraudinvestigator"){
			data.userrole = "fraudinvestigator";
			data.userroleDisplayName = "Fraud Investigator";
		}
	}
	data.ActivityExportFileName = config.ExportActivitySettings.FileName;
	data.AppendTimeStamp = config.ExportActivitySettings.DatetimeStamp;
    data.authMode = (config.authMode.enabled == true) ? true : false;
	data.RoleAccessCode = 1;
	
	data.mode = config.demomode == true ? "demo" : "";
    return res.json(data)
}

/* Login function will connect to rba-admin login API which validates username/password and returns
   Authorization token for successful login */
exports.login = function* (req,res,next){
    var options= {}
    options.headers={};
    var data={};
    data.userName=req.body.username;
    data.password=req.body.password;
    options.headers['SSOMode'] = "DEFAULT";
    try{
        var data1=yield proxyAPI.postDataAsync(common.getEndpointURL("login"),data, options);
       
        if(data1 && data1.statusCode){
            if(data1.statusCode == 200 || data1.statusCode == 201){
                    req.session.Authorization=data1.tokenInformation.token;            
                    req.session.fname = data1.userInformation.firstName;
                    req.session.lname = data1.userInformation.lastName;
                    req.session.userid = req.body.username;
                    req.session.userrole = "neuroadmin";
                    data1.userrole = "neuroadmin";
                    data1.login = 1;
                    if(data1.tokenInformation.role){
                        if(data1.tokenInformation.role == "FRAUD_INVESTIGATOR"){
                            req.session.userrole = "fraudinvestigator";
                            data1.userrole = "fraudinvestigator";
                        }
                    }				
                    logger.info("Login Successfull- "+ data.userName);
                    return res.json(data1)
            }
            else{
                logger.error("Login Failed- "+ data.userName);
                    data1.login = 0;
                    return res.json(data1)
            }
        }
        else{
            logger.error("Login Failed- "+ data1);
            return res.json({'login':0, 'message':'System error : Unable to communicate.'});
        }
    }
    catch(e){
        console.log(e);
        logger.error("Login Failed- "+ data.userName+ "--" + e);
        return res.json({'login':0, 'message':'System error : Unable to communicate.'});
    }
}

/* logout API is called to invalidate authorization token */
exports.logout = function* (req,res,next){
     var options = common.getHeaderDetails(req);
    try{
         var callbackfunc = function(err, response, statusCode) {
            req.session.Authorization="";
            req.session = null;
            if (statusCode == 200) {
                logger.info("Logout Successfull- "+ response.message);
                res.send({
                    "error": 0,
                    "successMsg": response.message
                });            
            } else {
                logger.error("Logout Failed- "+ response.message);
                res.send({
                    "error": 1,
                    "errorMsg": response.message
                });
            }
        }
        var objBody = {"token": req.session.Authorization}
        proxyAPI.putData(common.getEndpointURL("logout"), objBody, options,callbackfunc);
    }
    catch(e){
        logger.error("Logout Failed- "+ e);
    }     
}

/* This function will connect to rba server(s) and invoke refresh cache API to update metadata after
   user has done any important changes in the admin UI and those changes needs to reflect
   in other appications */
exports.refreshCache = function* (req,res,next){
    var options= {};
    var objURLs = [];  
    var objResponse = [];    
 
    try{
            //Send final response
            var sendResponse = function(){
                res.send(objResponse);
            }
        
            //Process final response
            var completed = function(err, results){
                setTimeout(sendResponse, 0);
            }
            
            //Process each URL
            var processURL = function(url, callback){
                proxyAPI.getCacheData(url, '', options, function(err, response, statusCode) {
                    if (statusCode == 200) {
                        objResponse.push({"url": url + common.getEndpointURL("refreshCache") , "error": 0});       
                    } else {
                        objResponse.push({"url": url + common.getEndpointURL("refreshCache"), "error": 1});
                    }
                    callback(null, objResponse);
                });          
            }

            //Read all Rba url setup
            if(config.rbaServerURLs){
                for(var i=0;i<config.rbaServerURLs.length;i++){
                    objURLs.push(config.rbaServerURLs[i].host + ":" + config.rbaServerURLs[i].port);
                }
                 
                //Call refresh cache method for all Rba server urls  
                async.map(objURLs, processURL, completed);        
            }
    }
    catch(e){
        logger.error("Logout Failed- "+ e);
    }
}

/* This function will connect to rba-admin login API which validates encrypted username from SSO
    and returns Authorization token for successful user validation */
exports.getToken = function* (req,res,next){
    var options= {}
    options.headers={};
    var data={};
    options.headers['userName'] = req.body.username;
    options.headers['SSOMode'] = req.body.SSOMODE;
    //options.headers['Content-Type']= 'application/json';
   options.headers['Accept']= 'application/json';
   
   
    try{
          
        var data1= yield proxyAPI.postDataAsync(common.getEndpointURL("getToken"),data, options);
          
        
        if(data1.statusMessage!="Unauthorized"){
                req.session.Authorization=data1.tokenInformation.token;
                if(req.body.firstName){
                    req.session.fname = req.body.firstName;
                }
             
                if(req.body.lastName){
                    req.session.lname = req.body.lastName;
                }
                logger.info("Login Successfull- "+ req.body.username);
                //res.json(data1);
                next(req,res);
        }
        else{
               logger.error("Get token Failed- "+ req.body.username);
              // res.status(401);//.send("login failed");
                next(req,res);
        }
    }
 
    catch(e){
 
        logger.error("Get token Failed- "+ req.body.username+ "--" + e);
        //res.status(401);//.send("login failed");
        next(req,res);
    }
}

/* This function will connect to rba-admin login API which validates encrypted username and OAM Access token
    and sets Authorization token for successful user validation */
exports.validateOauthToken = function* (req,res,next){
    var options= {}
    options.headers={};
    var data={};
    options.headers['accessToken'] = req.body.AccessToken;
    options.headers['SSOMode'] = req.body.SSOMODE;
    options.headers['userName'] = req.body.username;
    //options.headers['Content-Type']= 'application/json';
   options.headers['Accept']= 'application/json';
   
   
    try{
         
        var data1= yield proxyAPI.postDataAsync(common.getEndpointURL("validatetoken"),data, options );
		 
        if(data1.statusMessage!="Unauthorized"){
                req.session.Authorization=data1.tokenInformation.token;                
                logger.info("Login Successfull- "+ req.body.username);
                //res.json(data1)
                next(req,res);
        }
        else{
               logger.error("Get token Failed- "+ req.body.username);
               //res.status(401);//.send("login failed")
               next(req,res);
        }
    }
    catch(e){
        logger.error("Get token Failed- "+ req.body.username+ "--" + e);
        //res.status(401);//.send("login failed")
        next(req,res);
    }
}

exports.getOAMDetails = function* (accesstoken, req, res, next){
    var data = yield proxyAPI.getProfileforOAMAsync(accesstoken);
    req.session.OAMUserProfile = data;
    
    if(req.session.OAMUserProfile.firstname){
        req.session.fname = req.session.OAMUserProfile.firstname;
    }
    if(req.session.OAMUserProfile.lastname){
        req.session.lname  = req.session.OAMUserProfile.lastname;
    }
    
    next(req,res);
}