/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var logger = require('../lib/logger');

/* GET API call to get all fact locators */
exports.getFactlocators = function* (req, res, next) {
    var data = {};
    data.factLocators = [];
    try {
        var options = common.getHeaderDetails(req);
        var apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("factLocator"), '', options);

        if (apiData && apiData.factLocator) {
            data.statusCode = apiData.statusCode;

            for (var i = 0; i < apiData.factLocator.length; i++) {
                data.factLocators.push({
                    "key": apiData.factLocator[i]["factKey"],
                    "name": apiData.factLocator[i]["name"],
                    "class": apiData.factLocator[i]["factLocatorClass"]
                });
            }
        }
    }
    catch (e) {
        logger.error("GET API: " + common.getEndpointURL("factLocator"));
        logger.error(e);
    }
    res.json(data);
}


/* POST API call to create new fact locator */
exports.postFactlocators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        var callbackfunc = function (err, response, statusCode) {
            if (statusCode == 201) {
                logger.info("API- " + common.getEndpointURL("factLocator") + "--" + statusCode + ": " + response.message);
                res.send({
                    "error": 0,
                    "successMsg": response.message,
                    "statusCode": statusCode
                });
            } else {
                logger.info("API- " + common.getEndpointURL("factLocator") + "--" + statusCode + ": " + response.message);
                if (statusCode == 401) { req.session.Authorization = ""; }
                var errmsg = (response.message ? (response.message) : "");
                res.send({
                    "error": 1,
                    "errorMsg": errmsg,
                    "statusCode": statusCode
                });
            }
        }

        //POST fact locator payload
        let objBody = {};
        objBody.factLocators = [];

        let objFactLocator = {};
        objFactLocator.factKey = req.body.factKey;
        objFactLocator.name = req.body.factName;
        objFactLocator.factLocatorClass = req.body.factClass;
        objBody.factLocators.push(objFactLocator);
        //API calls
        proxyAPI.postData(common.getEndpointURL("factLocator"), objBody, options, callbackfunc);

    }
    catch (e) {
        logger.error("POST API: " + common.getEndpointURL("factLocator"));
        logger.error(e);
    }
}

/* PUT API call to update fact locator */
exports.putFactlocators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        var callbackfunc = function (err, response, statusCode) {
            if (statusCode == 200) {
                logger.info("API- " + common.getEndpointURL("factLocator") + '/' + req.body.factKey
                    + "--" + statusCode + ": " + response.message);
                res.send({
                    "error": 0,
                    "successMsg": response.message,
                    "statusCode": statusCode
                });
            } else {
                logger.info("API- " + common.getEndpointURL("factLocator") + '/' + req.body.factKey
                    + "--" + statusCode + ": " + response.message);
                if (statusCode == 401) { req.session.Authorization = ""; }
                var errmsg = (response.message ? (response.message) : "");
                res.send({
                    "error": 1,
                    "errorMsg": errmsg,
                    "statusCode": statusCode
                });
            }
        }

        //PUT fact locator payload
        let objBody = {};
        objBody.factKey = req.body.factKey;
        objBody.name = req.body.factName;
        objBody.factLocatorClass = req.body.factClass;        
        //API calls
        proxyAPI.putData(common.getEndpointURL("factLocator") + '/' + req.body.factKey, objBody, options, callbackfunc);

    }
    catch (e) {
        logger.error("PUT API: " + common.getEndpointURL("factLocator"));
        logger.error(req.body.factKey);
        logger.error(e);
    }
}

/* API call - delete fact locator by fact loator key */
exports.deleteFactlocators = function* (req, res, next) {

}


