/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var messages = require('../lib/messages');
var config = require('../config')();
var logger = require('../lib/logger');

/*  Get Activities details for wizard - Activity tab on UI
    For new activity all session activity details are set to null 
    and eidted activity details are set in session for edit activity
*/
exports.getActivities = function* (req, res, next) {
    var data = {};
    var options = common.getHeaderDetails(req);
    var apiDataChannels = yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);

    data.channel = [];
    for (var i = 0; i < apiDataChannels.channels.length; i++) {
        data.channel.push({ "id": apiDataChannels.channels[i]["id"], "text": apiDataChannels.channels[i]["description"] });
    }

    req.session.apiChannelData = data.channel;
    data.authType = config.authType;


    if (req.params.activity === 'new') {
        req.session.balanceData = null;
        req.session.activityId = "";
        req.session.activityName = "";
        req.session.activityDesc = "";
        req.session.currentSelectedAuthType = "";
        req.session.currentSelectedChannel = "";
        req.session.activityscore = "";
        req.session.challengeData = null;
        req.session.activechallenges = null;
        req.session.activeRiskOS = null;
        req.session.activeRiskEA = null;
        req.session.activeRiskscore = null;
        req.session.riskScore = "";
        req.session.exclusionRuleId = "";
        req.session.inclusionRuleId = "";
        req.session.inclusionRulename = "";
        req.session.exclusionRulename = "";
    }
    else {
        data.activityName = req.session.activityName
        data.activityDesc = req.session.activityDesc
        data.activityId = req.session.activityId
        data.activityscore = req.session.activityscore;
        data.currentSelectedChannel = req.session.currentSelectedChannel;
        data.currentSelectedAuthType = req.session.currentSelectedAuthType;
    }
    res.json(data)
}

/* Clear wizard session data when new activity is created */
exports.clearWizardSession = function* (req, res, next) {
    var data = {};
    try {
        req.session.balanceData = null;
        req.session.challengeData = null;
        req.session.activechallenges = null;
        req.session.activeRiskOS = null;
        req.session.activeRiskEA = null;
        req.session.activityId = "";
        req.session.activityName = "";
        req.session.activityDesc = "";
        req.session.currentSelectedAuthType = "";
        req.session.currentSelectedChannel = "";
        req.session.activityscore = "";
        req.session.activeRiskscore = null;
        req.session.riskScore = "";
        req.session.exclusionRuleId = "";
        req.session.inclusionRuleId = "";
        req.session.inclusionRulename = "";
        req.session.exclusionRulename = "";

        data = { "success": true };
    }
    catch (e) {
        logger.error(e);
        data = { "success": false };
    }
    res.send(data);
}

/* Save Activity details. Wizard save call from UI */
exports.postActivityWizard = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        //callback function which will set session variables to null on success
        var callbackfunc = function (err, response, statusCode) {
            logger.info(common.getEndpointURL("activities"));
            logger.info(statusCode);
            if (statusCode == 201) {
                req.session.balanceData = null;
                req.session.activityId = "";
                req.session.activityName = "";
                req.session.activityDesc = "";
                req.session.currentSelectedAuthType = "";
                req.session.currentSelectedChannel = "";
                req.session.activityscore = "";
                req.session.challengeData = null;
                req.session.activechallenges = null;
                req.session.activeRiskOS = null;
                req.session.activeRiskEA = null;
                req.session.activeRiskscore = null;
                req.session.riskScore = "";
                req.session.exclusionRuleId = "";
                req.session.inclusionRuleId = "";
                req.session.inclusionRulename = "";
                req.session.exclusionRulename = "";
                res.send({
                    "error": 0,
                    "statusCode": statusCode,
                    "msg": response.message ? response.message : ""
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                var errmsg = response.message ? response.message : "";
                res.send({
                    "error": 1,
                    "statusCode": statusCode,
                    "msg": errmsg
                });
            }
        }

        /* Once per session risk assessment selected on wizard */
        var riskAssmnt = [];
        if (req.session.activeRiskOS) {
            for (var i = 0; i < req.session.activeRiskOS.length; i++) {
                riskAssmnt.push({ "riskAssessmentCD": req.session.activeRiskOS[i].id });
            }
        }

        /* Early activity risk assessment selected on wizard */
        if (req.session.activeRiskEA) {
            for (var i = 0; i < req.session.activeRiskEA.length; i++) {
                riskAssmnt.push({ "riskAssessmentCD": req.session.activeRiskEA[i].id });
            }
        }

        /* Selected authenticators and risk score added to the selected authenticators on wizard */
        var challenges = [];
        var reqScore = parseInt(req.session.activityscore);
        if (req.session.balanceData && req.session.activechallenges && req.session.activechallenges.length > 0 &&
            reqScore > -1 && reqScore <= 100 && req.session.activityId && req.session.activityDesc) {

            for (var j = 0; j < req.session.activechallenges.length; j++) {
                for (var i = 0; i < req.session.balanceData.name.length; i++) {
                    if (req.session.balanceData.name[i].authname == req.session.activechallenges[j].text) {
                        challenges.push({
                            "id": req.session.activechallenges[j].id,
                            "score": parseInt(req.session.balanceData.name[i].score),
                            "priority": parseInt(j + 1)
                        });
                        break;
                    }
                }
            }
            // console.log("Exclusion ID, Inclusion ID", req.session.exclusionRuleId, req.session.inclusionRuleId)
            //Forming th payload for POST Activity
            let rules = [];
            if (req.session.inclusionRuleId && req.session.inclusionRuleId != 'ALL') {
                rules.push({
                    "ruleId": req.session.inclusionRuleId,
                    "rule_type": "INC"
                })
            }
            if (req.session.exclusionRuleId && req.session.exclusionRuleId != 'NA') {
                rules.push({
                    "ruleId": req.session.exclusionRuleId,
                    "rule_type": "EXC"
                })
            }
            var objBody = {
                "adminVOList": [{
                    "activity": {
                        "activityID": req.session.activityId,
                        "activityName": req.session.activityName,
                        "description": req.session.activityDesc,
                        "activityAuthLevel": req.session.currentSelectedAuthType.toUpperCase().replace(/ /g, "_"),
                        "requiredScore": parseInt(req.session.activityscore),
                        "channel": req.session.currentSelectedChannel,
                        "activeStatus": 1
                    },
                    "riskAssessmentList": riskAssmnt,
                    "authenticationChallengeList": challenges,
                    "rules": rules
                }]
            };
            //API call POST Acitivites
            proxyAPI.postData(common.getEndpointURL("activities"), objBody, options, callbackfunc);
        }
        else {
            res.send({
                "error": 1,
                "msg": "Please review all required fields."
            });
        }
    }
    catch (e) {
        logger.error(e);
    }
}

/* Update Acitivy Wizard - PUT Activity API Call */
exports.putActivityWizard = function* (req, res, next) {
    var options = common.getHeaderDetails(req);

    try {
        //Call back function will set Activity detials in session to null after success.
        var callbackfunc = function (err, response, statusCode) {
            logger.info(common.getEndpointURL("activities") + '/' + req.session.activityId);
            logger.info(statusCode);
            if (statusCode == 200) {
                req.session.balanceData = null;
                req.session.activityId = "";
                req.session.activityName = "";
                req.session.activityDesc = "";
                req.session.currentSelectedAuthType = "";
                req.session.currentSelectedChannel = "";
                req.session.activityscore = "";
                req.session.challengeData = null;
                req.session.activechallenges = null;
                req.session.activeRiskOS = null;
                req.session.activeRiskEA = null;
                req.session.activeRiskscore = null;
                req.session.riskScore = "";
                req.session.exclusionRuleId = "";
                req.session.inclusionRuleId = "";
                res.send({
                    "error": 0,
                    "statusCode": statusCode,
                    "msg": response.message
                });
            } else {
                if (statusCode == 401) { req.session.Authorization = ""; }
                var errmsg = response.message ? response.message : "";
                res.send({
                    "error": 1,
                    "statusCode": statusCode,
                    "msg": errmsg
                });
            }
        }

        /* Once per session activity risk assessment selected on wizard */
        var riskAssmnt = [];
        if (req.session.activeRiskOS) {
            for (var i = 0; i < req.session.activeRiskOS.length; i++) {
                riskAssmnt.push({ "riskAssessmentCD": req.session.activeRiskOS[i].id });
            }
        }

        /* Early activity risk assessment selected on wizard */
        if (req.session.activeRiskEA) {
            for (var i = 0; i < req.session.activeRiskEA.length; i++) {
                riskAssmnt.push({ "riskAssessmentCD": req.session.activeRiskEA[i].id });
            }
        }

        /* Selected authenticators and risk score added to the selected authenticators on wizard */
        var challenges = [];
        var reqScore = parseInt(req.session.activityscore);
        if (req.session.balanceData && req.session.activechallenges && req.session.activechallenges.length > 0 &&
            reqScore > -1 && reqScore <= 100 && req.session.activityId && req.session.activityDesc) {
            for (var j = 0; j < req.session.activechallenges.length; j++) {
                for (var i = 0; i < req.session.balanceData.name.length; i++) {
                    if (req.session.balanceData.name[i].authname == req.session.activechallenges[j].text) {
                        challenges.push({
                            "id": req.session.activechallenges[j].id,
                            "score": parseInt(req.session.balanceData.name[i].score),
                            "priority": parseInt(j + 1)
                        });
                        break;
                    }
                }

            }
            let rules = [];
            if (req.session.inclusionRuleId && req.session.inclusionRuleId != 'ALL') {
                rules.push({
                    "ruleId": req.session.inclusionRuleId,
                    "rule_type": "INC"
                })
            }
            if (req.session.exclusionRuleId && req.session.exclusionRuleId != 'NA') {
                rules.push({
                    "ruleId": req.session.exclusionRuleId,
                    "rule_type": "EXC"
                })
            }
            //Forming th payload for POST Activity
            var objBody = {
                "activity": {
                    "activityID": req.session.activityId,
                    "activityName": req.session.activityName,
                    "description": req.session.activityDesc,
                    "activityAuthLevel": req.session.currentSelectedAuthType.toUpperCase().replace(/ /g, "_"),
                    "requiredScore": parseInt(req.session.activityscore),
                    "channel": req.session.currentSelectedChannel.toUpperCase(),
                    "activeStatus": 1
                },
                "riskAssessmentList": riskAssmnt,
                "authenticationChallengeList": challenges,
                "rules": rules
            };
            //PUT Activity API Call
            proxyAPI.putData(common.getEndpointURL("activities") + '/' + req.session.activityId
                , objBody, options, callbackfunc);
        }
        else {
            res.send({
                "error": 1,
                "msg": "Please review all required fields."
            });
        }
    }
    catch (e) {
        logger.error(e);

    }
}

/* Save details on Activity tab in session */
exports.postActivities = function* (req, res, next) {
    req.session.activityName = req.body.activityName;
    req.session.activityDesc = req.body.activityDesc;
    req.session.activityId = req.body.activityId;
    req.session.activityscore = req.body.activityscore;
    req.session.currentSelectedChannel = req.body.currentSelectedChannel;
    req.session.currentSelectedAuthType = req.body.currentSelectedAuthType;
    res.json({ "messages": "acitvities successfully created " })
}

/* Connect to rba-admin API to get risk assessment details */
exports.getRisk = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    try {
        var data1 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'OS' }, options);
        var data2 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'EA' }, options);
        //Get Risk Policy
        var apiRiskData = yield proxyAPI.getDataAsync(common.getEndpointURL("riskpolicy"), '', options);
        var riskScorePolicy = "TOT"; //Default Total
        if (apiRiskData.riskScoreAggregationPolicy && apiRiskData.riskScoreAggregationPolicy.currentValue) {
            riskScorePolicy = apiRiskData.riskScoreAggregationPolicy.currentValue;
        }
        req.session.riskScorePolicy = riskScorePolicy;
        var data = {}
        logger.info(common.getEndpointURL("riskAssessment") + " (invocationtype:os)");
        logger.info(common.getEndpointURL("riskAssessment") + " (invocationtype:ea)");
        logger.info(data1.statusCode);
        data.statusCode = data1.statusCode;
        if (data1.statusCode == 401 || (data1.statusCode == 400
            && data1.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
            req.session.Authorization = "";
            data.statusCode = 401;
        }

        //Risk assessement - once per session
        var objos = [];
        var riskdatapoint = 0;

        for (var i = 0; i < data1.riskAssessments.length; i++) {
            riskpoint = 0;

            var riskfactor = data1.riskAssessments[i].riskFactors; //Get risk factors data

            for (var key in riskfactor) {
                var point = parseInt(riskfactor[key]);
                if (point > riskpoint) {
                    riskpoint = point; //get Max risk factor
                }
            }

            objos.push({
                "riskAssessmentCD": data1.riskAssessments[i].riskAssessmentCD,
                "riskAssessmentName": data1.riskAssessments[i].riskAssessmentName,
                "outputPoint": riskpoint,
                "riskfactorcount": 1
            });
        }
        data.os = objos;

        //Risk assessement - every activity
        var objea = [];
        var riskdatapoint = 0;
        for (var i = 0; i < data2.riskAssessments.length; i++) {
            riskpoint = 0;

            var riskfactor = data2.riskAssessments[i].riskFactors; //Get risk factors data

            for (var key in riskfactor) {
                var point = parseInt(riskfactor[key]);
                if (point > riskpoint) {
                    riskpoint = point; //get Max risk factor
                }
            }
            objea.push({
                "riskAssessmentCD": data2.riskAssessments[i].riskAssessmentCD,
                "riskAssessmentName": data2.riskAssessments[i].riskAssessmentName,
                "outputPoint": riskpoint,
                "riskfactorcount": 1
            });
        }
        data.ea = objea;


        //data.os=data1.riskAssessments;
        //data.ea=data2.riskAssessments;
        if (req.session.activeRiskEA) {
            data.activeRiskEA = req.session.activeRiskEA
        }
        if (req.session.activeRiskOS) {
            data.activeRiskOS = req.session.activeRiskOS
        }
        if (req.session.inclusionRuleId) {
            data.inclusionRuleId = req.session.inclusionRuleId
        }
        if (req.session.exclusionRuleId) {
            data.exclusionRuleId = req.session.exclusionRuleId
        }
        if (req.session.inclusionRulename) {
            data.inclusionRulename = req.session.inclusionRulename
        }
        if (req.session.exclusionRulename) {
            data.exclusionRulename = req.session.exclusionRulename
        }

        data.activeRiskscore = req.session.activeRiskscore;
        data.riskMethodType = riskScorePolicy;
        req.session.riskScorePolicy = riskScorePolicy;//set risk policy session variable
        let apiDataRules = yield proxyAPI.getDataAsync(common.getEndpointURL("rules"), '', options);
        var rules = [];
        for (let rule of apiDataRules.rules) {
            let tempRule = {};
            tempRule.id = rule.id;
            tempRule.text = rule.name;
            rules.push(tempRule);
        }
        data.riskInclusionExclusion = rules;

    }
    catch (e) {
        logger.error(e);
    }

    res.json(data)
}

/* Save details on Risk assessment tab in session */
exports.postRisk = function* (req, res, next) {
    req.session.activeRiskEA = req.body.activeRiskEA;
    req.session.activeRiskOS = req.body.activeRiskOS;
    req.session.activeRiskscore = req.body.activeRiskscore;
    req.session.riskScore = req.body.riskScore;
    req.session.exclusionRuleId = req.body.exclusionRuleId;
    req.session.inclusionRuleId = req.body.inclusionRuleId;
    req.session.inclusionRulename = req.body.inclusionRulename;
    req.session.exclusionRulename = req.body.exclusionRulename;
    res.json({ "messages": "risks added succefully" })
}

/* Get Authenticator details existing in the session variables to load Authenticator tab */
exports.getAuthenticators = function* (req, res, next) {
    var options = common.getHeaderDetails(req);

    try {
        var data1 = yield proxyAPI.getDataAsync(common.getEndpointURL("authenticators"), '', options);
        logger.info(common.getEndpointURL("authenticators"));
        var data = {}
        data.challengeData = data1.challenges;

        if (req.session.activechallenges) {
            data.activechallenges = req.session.activechallenges;
        }

        if (data1.statusCode == 401 || (data1.statusCode == 400 && data1.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
            req.session.Authorization = "";
            data.statusCode = 401;
        }
    }
    catch (e) {
        logger.error(e);
    }
    res.json(data)
}

/* Save details on Authenticators tab in session */
exports.postAuthenticators = function* (req, res, next) {
    req.session.activechallenges = req.body.activechallenges
    res.json({ "messages": "risks added succefully" })
}

/* Get balance details existing in the session variables to load balance & risk tab */
exports.getBalanceRiskAuthenticators = function* (req, res, next) {
    try {
        var data = {}

        if (req.session.activechallenges) {
            data.activechallenges = req.session.activechallenges;
        }
        if (req.session.activityscore)//Activity Score
        {
            data.activityscore = req.session.activityscore;
        }

        if (req.session.balanceData) {
            data.balanceData = req.session.balanceData;
        }

        data.activeRiskscore = req.session.activeRiskscore;


        data.riskScore = req.session.riskScore;

        data.riskMethodType = req.session.riskScorePolicy;

    }
    catch (e) {
    }

    res.json(data)
}

/* Save details on balance & trust score tab in session */
exports.postBalanceRiskWizard = function* (req, res, next) {

    req.session.balanceData = req.body.balanceData;
    // req.session.riskScore =req.body.riskScore;

    res.json({ "messages": "balance added succefully" })
}


/* Get details existing in the session variables to load Confirm tab */
exports.getConfirm = function* (req, res, next) {
    var data = {};
    data.activityName = req.session.activityName;
    data.activityDesc = req.session.activityDesc;
    data.activityId = req.session.activityId;
    data.activityscore = req.session.activityscore;
    data.currentSelectedChannel = req.session.currentSelectedChannel;
    var options = common.getHeaderDetails(req);
    var apiDataChannels = yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);
    if (req.session.currentSelectedChannel && apiDataChannels.channels) {
        for (let i = 0; i < apiDataChannels.channels.length; i++) {
            if (apiDataChannels.channels[i]["id"] == req.session.currentSelectedChannel) {
                data.currentSelectedChannelName = apiDataChannels.channels[i]["description"];
                break;
            }
        }
    }
    else {
        data.currentSelectedChannelName = "";
    }
    data.currentSelectedAuthType = req.session.currentSelectedAuthType;
    data.activeRiskOS = req.session.activeRiskOS;
    data.activeRiskEA = req.session.activeRiskEA;
    data.activechallenges = req.session.activechallenges;
    data.balanceData = req.session.balanceData;
    data.riskScore = req.session.riskScore;
    data.exclusionRuleId = req.session.exclusionRuleId;
    data.inclusionRuleId = req.session.inclusionRuleId;
    data.inclusionRulename = req.session.inclusionRulename;
    data.exclusionRulename = req.session.exclusionRulename;
    res.json(data)

}
