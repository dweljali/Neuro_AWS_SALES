/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var messages = require('../lib/messages');
var config = require('../config')();
var logger = require('../lib/logger');

/*  Get Activities details for wizard - Activity tab on UI
    For new activity all session activity details are set to null 
    and eidted activity details are set in session for edit activity
*/
exports.importData = function* (req, res, next) {
	var data = {}
	data.statusCode = 200;
	data.error = 0;
	data.errmsg = "";
	var options = common.getHeaderDetails(req);
	try {

		if (req.body.activities && req.body.activities.activity && req.body.activities.activity.length > 0) {
			//GET All activities
			var existingACT = [];
			var objPOSTActivityArray = [];
			var activitiesExists = true;
			var addActivity = true;
			var objActResponse = yield proxyAPI.getDataAsync(common.getEndpointURL("activities"), '', options);
			if (objActResponse && objActResponse.activityRiskAuthenticatorRelations) {
				for (var i = 0; i < objActResponse.activityRiskAuthenticatorRelations.length; i++) {
					if (objActResponse.activityRiskAuthenticatorRelations[i].activity) {
						existingACT.push({
							'id': objActResponse.activityRiskAuthenticatorRelations[i].activity.activityID.value,
							'channel': objActResponse.activityRiskAuthenticatorRelations[i].activity.channel
						}
						);
					}
				}
			}

			for (var i = 0; i < req.body.activities.activity.length; i++) {
				addActivity = true;
				if (existingACT && existingACT.length > 0) {
					for (j = 0; j < existingACT.length; j++) {
						if (existingACT[j].id == req.body.activities.activity[i].activity.activityID.toUpperCase().trim() &&
							existingACT[j].channel == req.body.activities.activity[i].activity.channel) {
							addActivity = false;
							break;
						}
					}
				}

				if (addActivity == true) {
					activitiesExists = false;
					objPOSTActivityArray.push(req.body.activities.activity[i]);
				}
			}

			if (activitiesExists == false) {
				var existingRISK = [];
				//POST Risk assessements
				if (req.body.activities.risk && req.body.activities.risk.length > 0) {
					var data1 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'OS' }, options);
					var data2 = yield proxyAPI.getDataAsync(common.getEndpointURL("riskAssessment"), { 'invocationtype': 'EA' }, options);

					if (data1.riskAssessments) {
						for (var i = 0; i < data1.riskAssessments.length; i++) {
							existingRISK.push(data1.riskAssessments[i].riskAssessmentCD);
						}
					}

					if (data2.riskAssessments) {
						for (var i = 0; i < data2.riskAssessments.length; i++) {
							existingRISK.push(data2.riskAssessments[i].riskAssessmentCD);
						}
					}

					var reqpayload = {};
					var objPOSTRiskArray = []
					for (var i = 0; i < req.body.activities.risk.length; i++) {
						//Check if risk assessment with code already exists
						if (existingRISK.indexOf(req.body.activities.risk[i].riskAssessmentCD) <= -1) {
							objPOSTRiskArray.push(req.body.activities.risk[i]);
						}
					}

					if (objPOSTRiskArray && objPOSTRiskArray.length > 0) {
						reqpayload = { "riskAssessments": objPOSTRiskArray }
						//POST Risk API call

						var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("riskAssessment"), reqpayload, options);
						data.statusCode = objresp.statusCode;

						if (objresp.statusCode == 401 || (objresp.statusCode == 400
							&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
							req.session.Authorization = "";
							data.statusCode = 401;
							data.error = 1;
							data.errmsg = (objresp.message ? (objresp.message + ". ") : "");
						}
						else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
							data.error = 1;
							data.errmsg = "Import process failed. Error encountered while importing Risk assessment(s).";
							//(objresp.message ? (objresp.message + ". ") : ""); 
						}
					}
				}

				//POST Risk Factors
				if (data.statusCode == 200 || data.statusCode == 201) {
					var riskfactor = {};
					if (req.body.activities.riskFactorsVO && req.body.activities.riskFactorsVO.length > 0) {
						for (let i = 0; i < req.body.activities.riskFactorsVO.length; i++) {
							if (req.body.activities.riskFactorsVO[i].id) {
								//Check if risk factors belong to already existsing risk assessments
								if (existingRISK.indexOf(req.body.activities.riskFactorsVO[i].id) <= -1) {
									//form risk factor payload
									riskfactor = {};
									riskfactor = { "riskFactors": req.body.activities.riskFactorsVO[i].riskFactors };

									//POST risk factor by ID API call
									var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("riskAssessment") + '/' +
										req.body.activities.riskFactorsVO[i].id + '/' +
										'riskfactors', riskfactor, options);
									data.statusCode = objresp.statusCode;

									if (objresp.statusCode == 401 || (objresp.statusCode == 400
										&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
										req.session.Authorization = "";
										data.statusCode = 401;
										data.error = 1;
										break;
									}
									else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
										data.error = 1;
										data.errmsg =
											"Import process failed. Error encountered while importing Risk factor(s).";
										//data.errmsg = (objresp.message ? (objresp.message + ". ") : "");
										break;
									}
								}
							}
						}
					}
				}

				//POST Channels
				if (data.statusCode == 200 || data.statusCode == 201) {
					if (req.body.activities.channels && req.body.activities.channels.length > 0) {
						var objCnlResp = yield proxyAPI.getDataAsync(common.getEndpointURL("channels"), '', options);
						 

						for (var i = 0; i < req.body.activities.channels.length; i++) {
							var objAddChannel = true;
							for (var j = 0; j < objCnlResp.channels.length; j++) {
								if (req.body.activities.channels[i]['id'] == objCnlResp.channels[j]['id']) {
									objAddChannel = false;
									break;
								}
							}
							if (objAddChannel == true) {
								//POST Authenticator payload
								var cnlpayload = {
									"channels": [{
										"id": req.body.activities.channels[i]['id'],
										"description": req.body.activities.channels[i]['text']
									}]
								};
								 
								//API call
								var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("channels"), cnlpayload,
									options);
								data.statusCode = objresp.statusCode;
								if (objresp.statusCode == 401 || (objresp.statusCode == 400
									&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
									req.session.Authorization = "";
									data.statusCode = 401;
									data.error = 1;
								}
								else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
									data.error = 1;
									data.errmsg = "Import process failed. Error encountered while importing Authenticator(s).";
									//data.errmsg = (objresp.message ? (objresp.message + ". ") : ""); 
								}
							}
						}

					}
				}

				//POST Authenticators
				if (data.statusCode == 200 || data.statusCode == 201) {
					if (req.body.activities.authenticators && req.body.activities.authenticators.length > 0) {
						var existingAUTH = [];
						var objAuthResp = yield proxyAPI.getDataAsync(common.getEndpointURL("authenticators"), '', options);
						if (objAuthResp && objAuthResp.challenges) {
							for (var i = 0; i < objAuthResp.challenges.length; i++) {
								existingAUTH.push(objAuthResp.challenges[i].id.value);
							}
						}

						var reqpayload = {};
						var objPOSTAuthArray = []

						for (var i = 0; i < req.body.activities.authenticators.length; i++) {
							if (existingAUTH.indexOf(req.body.activities.authenticators[i].id) <= -1) {
								objPOSTAuthArray.push(req.body.activities.authenticators[i]);
							}
						}

						if (objPOSTAuthArray && objPOSTAuthArray.length > 0) {
							reqpayload = { "authenticators": objPOSTAuthArray }
							//POST Authenticators API call

							var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("authenticators"), reqpayload,
								options);

							data.statusCode = objresp.statusCode;
							if (objresp.statusCode == 401 || (objresp.statusCode == 400
								&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
								req.session.Authorization = "";
								data.statusCode = 401;
								data.error = 1;
							}
							else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
								data.error = 1;
								data.errmsg = "Import process failed. Error encountered while importing Authenticator(s).";
								//data.errmsg = (objresp.message ? (objresp.message + ". ") : ""); 
							}
						}
					}
				}

				//POST Activities
				if (data.statusCode == 200 || data.statusCode == 201) {
					if (req.body.activities.activity && req.body.activities.activity.length > 0) {
						var reqpayload = {};

						if (objPOSTActivityArray && objPOSTActivityArray.length > 0) {
							reqpayload = { "adminVOList": objPOSTActivityArray }
							//POST Activities API call
							 
							var objresp = yield proxyAPI.postDataAsync(common.getEndpointURL("activities"), reqpayload, options);
							 
							data.statusCode = objresp.statusCode;

							if (objresp.statusCode == 401 || (objresp.statusCode == 400
								&& objresp.message.toUpperCase() === 'Token Expired'.toUpperCase())) {
								req.session.Authorization = "";
								data.statusCode = 401;
								data.error = 1;
							}
							else if (objresp.statusCode != 200 && objresp.statusCode != 201) {
								data.error = 1;
								data.errmsg = "Import process failed. Error encountered while importing Activities.";
								//data.errmsg = (objresp.message ? (objresp.message + ". ") : ""); 
							}
						}
					}
				}
			}
			else {
				data.error = 1;
				data.errmsg = "Activities to be imported already exists.";
			}
		}
	}
	catch (e) {

		logger.error("API- IMPORT DATA" + "--" + e);
	}

	res.json(data)

}