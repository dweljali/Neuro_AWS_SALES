/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var messages = require('../lib/messages');
var config = require('../config')();
var async = require('async');
var logger = require('../lib/logger');

/* Determin Authentication */
exports.determine = function* (req, res, next) {
    var options = {}
    options.headers = {};
    var data = {};
    if (!config.refreshCacheActivity.enabled) {
        return res.json({ "statusCode": 200, "status": "APPROVE", "auth": "" });
    }
    else if(config.refreshCacheActivity.authenticators.OTPAuthenticatorID){        
        if (req.session.communicationID && req.session.communicationSessionID) {
            data.communicationSessionId = req.session.communicationID;
            data.communicationSessionTimestampMillis = req.session.communicationSessionID;
        }

        let ipaddress = "ClientIP=0.0.0.0", iaddress = "0.0.0.0", machinename = "";
        try {
            var os = require('os');
            machinename = os.hostname();
        }
        catch (e) {
            machinename = "";
        }

        try {
            var ip = require('ip');
            ipaddress = "ClientIP=" + ip.address();
            iaddress = ip.address();
        }
        catch (e) {
            ipaddress = "ClientIP=0.0.0.0";
            iaddress = "0.0.0.0";
        }

        data.activity = config.refreshCacheActivity.activityId;
        var userJSON = { "userID": req.session.userid, "userType": config.refreshCacheActivity.userType };
        data.actionedUser = userJSON;
        data.initiatedUser = userJSON;
        data.principalUser = userJSON;
        data.ipAddress = ipaddress;
        data.channel = config.refreshCacheActivity.channel;

        try {
            var data1 = yield proxyAPI.postDataAsync(common.getEndpointURL("determineAuthentication"), data, options);
            if (data1 && data1.statusCode && data1.statusCode == 200 && data1.status) {
                if (data1.communicationSessionId) {
                    req.session.communicationID = data1.communicationSessionId;
                }
                if (data1.communicationSessionTimestampMillis) {
                    req.session.communicationSessionID = data1.communicationSessionTimestampMillis;
                }
                if (data1.responseReasonCode == "CHALLENGE") {
                    if (data1.challenges && data1.challenges.length > 0) {
                        for (let challenge of data1.challenges) {
                            if (challenge.challengeType == "VERIFIER" && challenge.challengeId == config.refreshCacheActivity.authenticators.OTPAuthenticatorID) {
                                var otpData = {};
                                otpData.communicationId = data1.communicationSessionId;
                                otpData.userId = req.session.userid;
                                var extension = {};
                                extension.communicationSessionTimestampMillis = data1.communicationSessionTimestampMillis;
                                extension.activity = config.refreshCacheActivity.activityId;
                                extension.channel = config.refreshCacheActivity.channel;
                                extension.challengeId = config.refreshCacheActivity.authenticators.OTPAuthenticatorID;
                                extension.sourceIdentifier = iaddress;
                                extension.serverName = machinename;
                                extension.sourceType = config.refreshCacheActivity.sourceType;
                                otpData.extension = extension;
                                var objResp = yield proxyAPI.postDataAsync(common.getEndpointURL("sendOTP"), otpData, options);
                                if (objResp && objResp.statusCode && objResp.statusCode == 200 && objResp.status == "SUCCESS") {
                                    return res.json({ "statusCode": 200, "status": "CHALLENGE", "auth": "OTP" });
                                }
                            }
                        }
                    }
                }
                else if (data1.responseReasonCode == "APPROVE") {
                    return res.json({ "statusCode": 200, "status": "APPROVE", "auth": "" });
                }
            }
            return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
        }
        catch (e) {
            logger.error(e);
            return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
        }
    }
    else{
         return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
    }
}

/* Determin Authentication */
exports.sendOTP = function* (req, res, next) {
    var options = {}
    options.headers = {};
    var data = {};
    try {
        if (req.session.communicationID && req.session.communicationSessionID) {
            let ipaddress = "0.0.0.0";
            let machinename = "";
            try {
                var os = require('os');
                machinename = os.hostname();
            }
            catch (e) {
                machinename = "";
            }

            try {
                var ip = require('ip');
                ipaddress = ip.address();
            }
            catch (e) {
                ipaddress = "0.0.0.0";
            }

            data.communicationId = req.session.communicationID;
            data.userId = req.session.userid;
            var extension = {};
            extension.communicationSessionTimestampMillis = req.session.communicationSessionID;
            extension.activity = config.refreshCacheActivity.activityId;
            extension.channel = config.refreshCacheActivity.channel;
            extension.challengeId = config.refreshCacheActivity.authenticators.OTPAuthenticatorID;
            extension.sourceIdentifier = ipaddress;
            extension.serverName = machinename;
            extension.sourceType = config.refreshCacheActivity.sourceType;
            data.extension = extension;

            var objResp = yield proxyAPI.postDataAsync(common.getEndpointURL("sendOTP"), data, options);
            if (objResp && objResp.statusCode && objResp.statusCode == 200 && objResp.status == "SUCCESS") {
                return res.json({ "statusCode": 200, "status": "CHALLENGE", "auth": "OTP" });
            }
        }
    }
    catch (e) {
        logger.error(e);
        return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
    }
    return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
}


/* Determin Authentication */
exports.validateOTP = function* (req, res, next) {
    var options = {}
    options.headers = {};
    var data = {};
    try {
        if (req.body.otp && req.session.communicationID && req.session.communicationSessionID) {
            let ipaddress = "0.0.0.0";
            let machinename = "";
            try {
                var os = require('os');
                machinename = os.hostname();
            }
            catch (e) {
                machinename = "";
            }

            try {
                var ip = require('ip');
                ipaddress = ip.address();
            }
            catch (e) {
                ipaddress = "0.0.0.0";
            }

            data.communicationId = req.session.communicationID;
            data.userId = req.session.userid;
            var extension = {};
            extension.communicationSessionTimestampMillis = req.session.communicationSessionID;
            extension.activity = config.refreshCacheActivity.activityId;
            extension.channel = config.refreshCacheActivity.channel;
            extension.challengeId = config.refreshCacheActivity.authenticators.OTPAuthenticatorID;
            extension.sourceIdentifier = ipaddress;
            extension.serverName = machinename;
            extension.sourceType = config.refreshCacheActivity.sourceType;
            data.extension = extension;
            data.otp = req.body.otp;

            var objResp = yield proxyAPI.postDataAsync(common.getEndpointURL("validateOTP"), data, options);
            if (objResp && objResp.statusCode && objResp.statusCode == 200 && objResp.status == "SUCCESS") {
                return res.json({ "statusCode": 200, "status": "SUCCESS", "auth": "OTP" });
            }
        }
    }
    catch (e) {
        logger.error(e);
        return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
    }
    return res.json({ "statusCode": 500, "status": "FAILURE", "auth": "" });
}