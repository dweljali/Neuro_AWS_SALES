/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
var promise = require('bluebird');
var proxyAPI = require('../lib/API');
proxyAPI = promise.promisifyAll(proxyAPI);
var common = require('../lib/common');
var messages = require('../lib/messages');
var config = require('../config')();
var logger = require('../lib/logger');

/* API call to get all the rules */
exports.getRules = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    var apiData = {};
    try {
        apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("rules"), '', options);
        var rules = [];
        for (let rule of apiData.rules) {
            let tempRule = {};
            tempRule.id = rule.id;
            tempRule.Name = rule.name;
            tempRule.Description = rule.description;
            rules.push(tempRule);
        }

        logger.info("API- " + common.getEndpointURL("rules") + "--" + apiData.statusCode);

        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.noOfRecordsFound = apiData.noOfRecordsFound;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            objData.rules = rules;
            res.send(objData);
        } else {
            logger.info("API- " + common.getEndpointURL("rules") + "--" + apiData.statusCode + ": " + apiData.message);
            if (apiData.statusCode == 401) { req.session.Authorization = ""; }
            var errmsg = (apiData.message ? (apiData.message) : "");
            res.send({
                "error": 1,
                "errorMsg": errmsg,
                "statusCode": apiData.statusCode
            });
        }
    } catch (e) {
        console.log(e);
        logger.error("API- " + common.getEndpointURL("rules") + "--" + e);
    }
}


/* Get Total Rule count */
exports.getRuleCount= function* (req,res,next){	
	var options = common.getHeaderDetails(req);
	var objdata = {};
	 
    try{
        
		var data1=yield proxyAPI.getDataAsync(common.getEndpointURL("rules"), '', options);
		//Get Risk Policy
		var ruleCount = 0;
        objdata.statusCode = data1.statusCode;
        if(data1.statusCode == 401 || (data1.statusCode == 400 
                                       && data1.message.toUpperCase() === 'Token Expired'.toUpperCase())){
            req.session.Authorization="";
            data.statusCode= 401;
        }
		else{
			if(data1.rules){
				ruleCount = data1.rules.length;
			}
		}
        objdata.noOfRecordsFound = ruleCount;
    }
    catch(e){
        logger.error("getRuleCount API- "+common.getEndpointURL("rules")+ "--"+ e);
    }
	 
    res.json(objdata)     
}


exports.getRuleById = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    let id = req.params.ID;
    var apiData = {};
    try {

        apiData = yield proxyAPI.getDataAsync(`${common.getEndpointURL("rules")}/${id}`, '', options);
        logger.info("API- " + `${common.getEndpointURL("rules")}/${id}` + "--" + apiData.statusCode);
        if (apiData.statusCode == 200) {
            objData.status = apiData.status;
            objData.rule = apiData.rule;
            objData.error = 0;
            objData.successMsg = apiData.message;
            res.send(objData);
        } else {
            res.send({
                "error": 1,
                "errorMsg": errmsg,
                "statusCode": apiData.statusCode
            });
        }

    } catch (e) {
        logger.error("API- " + `${common.getEndpointURL("rules")}/${id}` + "--" + e);
    }

}
exports.getRuleConditions = function* (req, res, next) {
    var objData = {};
    var options = common.getHeaderDetails(req);
    var apiData = {};
    try {
        apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("ruleConditons"), '', options);

        var ruleConditions = [];
        for (let ruleOperator of apiData.conditionOperators) {
            let rule = {};
            rule.text = ruleOperator.name;
            rule.id = ruleOperator.code;
            ruleConditions.push(rule);
        }
        logger.info("API- " + common.getEndpointURL("ruleConditons") + "--" + apiData.statusCode);

        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.noOfRecordsFound = apiData.noOfRecordsFound;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            objData.ruleConditions = ruleConditions;
            res.json(objData);
        } else {
            logger.info("API- " + common.getEndpointURL("ruleConditons") + "--" + apiData.statusCode + ": " + apiData.message);
            if (apiData.statusCode == 401) { req.session.Authorization = ""; }
            var errmsg = (apiData.message ? (apiData.message) : "");
            res.send({
                "error": 1,
                "errorMsg": errmsg,
                "statusCode": apiData.statusCode
            });
        }
    } catch (e) {
        logger.error("API- " + common.getEndpointURL("ruleConditons") + "--" + e);
    }

}

exports.postRules = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    let apiData = {};
    let postData = {};
    let ruleConditions = [];

    const ruleConditionsFromUI = req.body.ruleConditions;

    for (let condIndex in ruleConditionsFromUI) {
        let ruleCond = {};
        ruleCond['attribute'] = ruleConditionsFromUI[condIndex].attribute.id;
        ruleCond['condition_operator'] = ruleConditionsFromUI[condIndex]['condition_operator'].id;
        ruleCond['value'] = ruleConditionsFromUI[condIndex].value;
        ruleCond['cond_order'] = parseInt(condIndex) + 1;
        condIndex != (ruleConditionsFromUI.length - 1) ? ruleCond['rule_operator'] = ruleConditionsFromUI[condIndex]['rule_operator'].id : '';
        ruleConditions.push(ruleCond);
    }

    postData = {
        rules: [{
            "name": req.body.name.trim(),
            "description": req.body.description,
            "factService": req.body.factServcie.id,
            "factServiceLookupKey": req.body.factServcieKey,
            "ruleConditions": ruleConditions
        }]
    }

    try {
        apiData = yield proxyAPI.postDataAsync(common.getEndpointURL("rules"), postData, options);
        logger.info("API- " + common.getEndpointURL("rules") + "--" + apiData.statusCode);
        if (apiData.statusCode == 201) {
            objData.statusCode = apiData.statusCode;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            res.json(objData);
        } else {
            logger.info("API- " + common.getEndpointURL("rules") + "--" + apiData.statusCode + ": " + apiData.message);
            if (apiData.statusCode == 401) { req.session.Authorization = ""; }
            var errmsg = (apiData.message ? (apiData.message) : "");
            res.send({
                "error": 1,
                "errorMsg": errmsg,
                "statusCode": apiData.statusCode
            });
        }
    } catch (e) {
        console.log(e);
        logger.error("API- " + common.getEndpointURL("rules") + "--" + e);
        var errmsg = (apiData.message ? (apiData.message) : "");
        res.send({
            "error": 1,
            "errorMsg": errmsg,
            "statusCode": apiData.statusCode
        });
    }
    // res.json(objData);
}

exports.putRule = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    let apiData = {};
    let putData = {};
    let ruleConditions = [];
    let id = req.params.ID;

    const ruleConditionsFromUI = req.body.ruleConditions;

    for (let condIndex in ruleConditionsFromUI) {
        let ruleCond = {};
        ruleCond['attribute'] = ruleConditionsFromUI[condIndex].attribute.id;
        ruleCond['condition_operator'] = ruleConditionsFromUI[condIndex]['condition_operator'].id;
        ruleCond['value'] = ruleConditionsFromUI[condIndex].value;
        ruleCond['cond_order'] = parseInt(condIndex) + 1;
        condIndex != (ruleConditionsFromUI.length - 1) ? ruleCond['rule_operator'] = ruleConditionsFromUI[condIndex]['rule_operator'].id : '';
        ruleConditions.push(ruleCond);
    }

    putData = {

        "name": req.body.name.trim(),
        "description": req.body.description,
        "factService": req.body.factServcie.id,
        "factServiceLookupKey": req.body.factServcieKey,
        "ruleConditions": ruleConditions

    }

    try {
        apiData = yield proxyAPI.putDataAsync(`${common.getEndpointURL("rules")}/${id}`, putData, options);
        logger.info("API- " + `${common.getEndpointURL("rules")}/${id}` + "--" + apiData.statusCode);
        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            res.json(objData);
        } else {
            logger.info("API- " + common.getEndpointURL("rules") + "--" + apiData.statusCode + ": " + apiData.message);
            if (apiData.statusCode == 401) { req.session.Authorization = ""; }
            var errmsg = (apiData.message ? (apiData.message) : "");
            res.send({
                "error": 1,
                "errorMsg": errmsg,
                "statusCode": apiData.statusCode
            });
        }
    } catch (e) {
        console.log(e);
        logger.error("API- " + `${common.getEndpointURL("rules")}/${id}` + "--" + e);
        var errmsg = (apiData.message ? (apiData.message) : "");
        res.send({
            "error": 1,
            "errorMsg": errmsg,
            "statusCode": apiData.statusCode
        });
    }
    // res.json(objData);
}

exports.getRuleFacts = function* (req, res, next) {
    var options = common.getHeaderDetails(req);
    var objData = {};
    var apiData = {};
    try {
        apiData = yield proxyAPI.getDataAsync(common.getEndpointURL("ruleFacts"), '', options);

        var facts = apiData.facts;
        logger.info("API- " + common.getEndpointURL("ruleFacts") + "--" + apiData.statusCode);

        if (apiData.statusCode == 200) {
            objData.statusCode = apiData.statusCode;
            // objData.noOfRecordsFound = apiData.noOfRecordsFound;
            objData.status = apiData.status;
            objData.error = 0;
            objData.successMsg = apiData.message;
            objData.facts = facts;
            res.send(objData);
        } else {
            logger.info("API- " + common.getEndpointURL("ruleFacts") + "--" + apiData.statusCode + ": " + apiData.message);
            if (apiData.statusCode == 401) { req.session.Authorization = ""; }
            var errmsg = (apiData.message ? (apiData.message) : "");
            res.send({
                "error": 1,
                "errorMsg": errmsg,
                "statusCode": apiData.statusCode
            });
        }
    } catch (e) {
        console.log(e);
        logger.error("API- " + common.getEndpointURL("ruleFacts") + "--" + e);
    }
}