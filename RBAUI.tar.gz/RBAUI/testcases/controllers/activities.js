describe('Testing Activities Routes.', (done) => {
    it('Case: Get All Activities...', (done) => {

        request
            .get('/admin/api/activities/getActivities')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: Deactivate Activity(Success)..', (done) => {
        let data = {
            "data": {
                "activityId": "CHNGID",
                "activityName": "Change Web ID",
                "activityDesc": "Change Web ID",
                "currentSelectedChannel": "WEB",
                "activityscore": 1,
                "authLevel": "NORMAL",
                "activeStatus": 1,
                "authList": [{
                    "id": "ZIP",
                    "desc": "ZIP",
                    "score": 50,
                    "priority": 1
                }],
                "risk": [
                    "TRAVEL"
                ]
            }
        }
        request
            .put('/admin/api/activities/changeActivityStatus')
            .send(data)
            .expect(200)
            .expect((res) => {

            })
            .end(done)
    });

    it('Case: Deactivate Activity(Failure)..', (done) => {
        let data = {
            "data": {
                "activityId": "TRNSONL2",
                "activityName": "Online Transfer",
                "activityDesc": "Online Transfer",
                "currentSelectedChannel": "WEB",
                "activityscore": 1,
                "authLevel": "NORMAL",
                "activeStatus": 0,
                "authList": [{
                    "id": "ZIP",
                    "desc": "ZIP",
                    "score": 50,
                    "priority": 1
                }],
                "risk": [
                    "TRAVEL"
                ]
            }
        }
        request
            .put('/admin/api/activities/changeActivityStatus')
            .send(data)
            .expect(200)
            .expect((res) => {

            })
            .end(done)
    });

    it('Case: Validate Activity Score...', (done) => {

        request
            .get('/admin/api/activities/validateActivityScore/CHNGID/WEB')
            .expect(200)
            .expect((res) => {
                // console.log(res.body);
            })
            .end(done);
    });

    it('Case: Edit Activity..', (done) => {
        let data = {
            "data": {
                "ID": "TRNSONL",
                "Description": "Online Transfer",
                "Channel": "Internet Banking",
                "Required Trust Score": 1,
                "Risk Assessments": [
                    "Travel Speed"
                ],
                "Authenticators": [
                    "Zip Code"
                ],
                "activekey": "De-Activate",
                "editkey": 1,
                "authL": "NORMAL",
                "Chnl": "WEB"
            },
            "index": {
                "activity": {
                    "activityID": {
                        "value": "TRNSONL"
                    },
                    "description": "Online Transfer",
                    "activityName": "Online Transfer",
                    "activityAuthLevel": "NORMAL",
                    "requiredScore": 1,
                    "channel": "WEB",
                    "partyType": "USER",
                    "activeStatus": 1,
                    "supportedMethodList": [
                        {
                            "id": 30,
                            "value": "METHOD TRNSONL WEB"
                        }
                    ]
                },
                "riskAssessmentList": [
                    {
                        "riskAssessmentCD": "TRAVEL",
                        "riskAssessmentName": "Travel Speed",
                        "riskAssessmentInvocationCD": "EA",
                        "riskAssessmentInvocationDesc": "EVERY_ACTIVITY_START",
                        "rerunAssessmentOnFailure": false,
                        "riskAssessmentOperationModeCD": "A",
                        "riskAssessmentOperationModeDesc": "ACTIVE",
                        "riskFactorVOs": [
                            {
                                "riskFactorCode": "VELOCITY",
                                "riskFactorName": "Travel Speed Indicator",
                                "riskFactorDataTypeName": "STRING",
                                "riskFactorInvocationCode": "EVERY_ACTIVITY_START",
                                "providedBySourceSystemName": "RBA_INTERNAL",
                                "retryCollectionOnFailureIndicator": false
                            }
                        ],
                        "riskFactors": {
                            "VLCTRSKPTS": 25
                        },
                        "riskAssessmentConfigurations": [
                            {
                                "riskAssessmentConfigID": "VLCTRSKPTS",
                                "riskAssessmentConfigName": "Velocity Risk Score Points",
                                "riskAssessmentConfigDesc": "Number of points to add to the required trust score for high velocity case.",
                                "riskAssessmentConfigType": "OUTPUT_POINTS",
                                "riskAssessmentConfigDatatype": "INTEGER",
                                "riskAssessmentConfigValue": "25"
                            },
                            {
                                "riskAssessmentConfigID": "VLCTRSKMSG",
                                "riskAssessmentConfigName": "High Velicty Risk Message",
                                "riskAssessmentConfigDesc": "Outcome description for high velocity",
                                "riskAssessmentConfigType": "OUTCOME_DESC",
                                "riskAssessmentConfigDatatype": "STRING",
                                "riskAssessmentConfigValue": "Velocity ($(velocity)) is high. Risk score will be topped up."
                            },
                            {
                                "riskAssessmentConfigID": "VLCTREFVAL",
                                "riskAssessmentConfigName": "Allowed maximum velocity",
                                "riskAssessmentConfigDesc": "Velocity in KM per hour",
                                "riskAssessmentConfigType": "INPUT_THRESHOLD",
                                "riskAssessmentConfigDatatype": "STRING",
                                "riskAssessmentConfigValue": "1000"
                            },
                            {
                                "riskAssessmentConfigID": "VLCTNAMSG",
                                "riskAssessmentConfigName": "Velocity unavailable Message",
                                "riskAssessmentConfigDesc": "Outcome description for velocity unavailable",
                                "riskAssessmentConfigType": "OUTCOME_DESC",
                                "riskAssessmentConfigDatatype": "STRING",
                                "riskAssessmentConfigValue": "Could not determine velocity for  ($(geolocationprev)) and ($(geolocationcurr))"
                            },
                            {
                                "riskAssessmentConfigID": "VLCTVLDMSG",
                                "riskAssessmentConfigName": "Acceptable velocity Message",
                                "riskAssessmentConfigDesc": "Outcome description for no risk",
                                "riskAssessmentConfigType": "OUTCOME_DESC",
                                "riskAssessmentConfigDatatype": "STRING",
                                "riskAssessmentConfigValue": "No risk for velocity ($(velocity))"
                            }
                        ]
                    }
                ],
                "authenticationChallengeList": [
                    {
                        "id": {
                            "value": "ZIP"
                        },
                        "score": 50,
                        "priority": 1,
                        "authMethod": {
                            "id": 30,
                            "value": "METHOD TRNSONL WEB"
                        },
                        "description": "Zip Code",
                        "activeStatus": 1,
                        "factKey": "UserInfo"
                    }
                ],
                "rules": []
            },
            "authlist": [
                {
                    "id": "ZIP",
                    "desc": "Zip Code",
                    "score": 50,
                    "priority": 1
                }
            ],
            "authlevel": "NORMAL",
            "riskdataea": [
                {
                    "code": "TRAVEL",
                    "name": "Travel Speed"
                }
            ],
            "riskdataos": [],
            "riskscore": [
                {
                    "code": "TRAVEL"
                }
            ],
            "inclusionRuleId": "ALL",
            "exclusionRuleId": "NA"
        }
        request
            .post('/admin/api/activities/editActivity')
            .send(data)
            .expect(200)
            .expect((res) => {

            })
            .end(done)
    });
})