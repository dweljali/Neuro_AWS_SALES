/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent }  from '../Dashboard/dashboard.component';
import { ActivityWizardComponent}  from '../ActivityWizard/activityWizard.component';
import { ActivitiesComponent } from '../Configuration/Activities/activities.component';
import { AuthenticatorsComponent } from '../Configuration/Authenticators/authenticators.component';
import { Admin } from '../admin.component';
import {Login} from '../Login/login.component'
// Route Configuration
export const routes: Routes = [
	{ 
		path:'login',
		component:Login
	}
];



export const loginrouting: ModuleWithProviders = RouterModule.forRoot(routes);