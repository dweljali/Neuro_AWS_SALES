import { Component, OnInit,ViewContainerRef,ViewChildren } from '@angular/core';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from '../../services/auth.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from '../../services/tabsService'
import { multiselectComponent } from './../../common/multiselect.component';
import { AlertModelData } from './../../common/alertModal.component';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Subject } from 'rxjs/Subject'
import * as myGlobals from './../../common/appMessages';

@Component({
    selector: 'authenticators-partial',
    template: require('./AuthenticatorsWiz.html'),
    providers: [APIService,Modal]
})
export class AuthenticatorsWizardPartialComponent{
  private ngUnsubscribe: Subject<void> = new Subject<void>();
  challengeData:Object[]=[];

  private tabContent: string = myGlobals.ACTIVITY_WIZ_AUTH_CONTENT;
  public challenge:Object[]=[];
  public pcholder:string;
  public activeChallenge:Object[]=[];
  public disablegrid:boolean = false;
  @ViewChildren('auth') vcAuth:any;

  ngOnDestroy(){
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  constructor(private service:APIService,  private route: ActivatedRoute,
              private tabs:TabsService,vcRef: ViewContainerRef, 
              public modal: Modal, private auth: AuthService,private globalService:GlobalService){
    modal.overlay.defaultViewContainer = vcRef;
    this.loadData();

    this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {   
      window.scrollTo(0, 0);
		 
      if(message.text=="postAuthenticator"){
        if(message.next == "confirm"||message.next == "balance")
          {this.postChallenges(message.next);}
        else
          {this.postChallenges(null);}

      }
      else if(message.text=="authenticator"){		  
        this.loadDefault();
      }
    })     
  }

  /* Function to load data incase of edit*/
  loadData() {        
    this.service.getAuthenticatorsWizard().then(response=>{

      var data=response._body;
      data=JSON.parse(data);

      if(data.challengeData){                
        this.challengeData=data.challengeData;
        this.pcholder = "Select Authenticators";

        this.challenge =[];
        for(let i=0;i<this.challengeData.length;i++){
          if(this.challengeData[i]["id"] && this.challengeData[i]["activeStatus"] == 1){
            this.challenge.push({id: this.challengeData[i]["id"].value.toString(),
            text:this.challengeData[i]["description"].toString() });  
          }
        }
      }

      if(data.activechallenges){
        this.activeChallenge = data.activechallenges;
      }
    }).catch(error => {console.log(error)});
  }

  /* Function to save authenticator details*/
  postChallenges(msg:string){

    if(!this.activeChallenge){
      this.activeChallenge = [];
    }


    this.service.postAuthenticatorsWizard({
      activechallenges:this.activeChallenge
    }).then(response=>{
        var data=response._body;
        data=JSON.parse(data);
        if(data.statusCode == 401){
            this.auth.authInvalid= true;
            this.globalService.redirectServerOrClient();
        }
      if(msg){
        this.tabs.sendMessage(msg,"")  
      }
    }).catch(error => {console.log(error)});
  }

  /* Function to save multiselected authenticators to an array*/
  selectedvaluelist(arg:any){

    this.activeChallenge.push(arg);       
  }

  /* Function to remove delselected authenticators from the array*/
  removelist(arg:any){

    for(let i=0;i<this.activeChallenge.length;i++){
      if(this.activeChallenge[i]["id"] == arg.id){
        delete this.activeChallenge.splice(i,1);
        break;
      }
    }

  }

  loadDefault(){
	  
    if( this.activeChallenge.length <=0){
      if(this.vcAuth){this.vcAuth.first.nativeElement.classList.add('focused');}
    }
  }  

  /* Function that displays modal upon validation error on authenticators tab*/
  openModal(){
    const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
      {
      isBlocking: true,
      message: myGlobals.AUTHENTICATOR_REVIEW,
      headtext: "Validation error"
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {                    
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
        this.loadDefault();
      });
    });
  }

  /* Function triggered onclick of save button in authenticators tab*/
  save(){
    if(this.activeChallenge && this.activeChallenge.length >0){
      this.postChallenges("balance");
    }
    else{
      this.openModal();
    }     
  }

  /* Function to navigate to previous tab*/
  previous(){
	this.postChallenges(null);
    this.tabs.sendMessage("risk","");
  }
}