/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import {AuthenticatorList} from './inputcomp.component'
@Component({
    selector: 'balance-risk-authenticators',
    template: `<div class="row row-sm-height">
                    <div class="col-sm-9 padding-20  col-sm-height col-top"><span class="icon-thumbnail bg-primary pull-left" style="color:white;">A</span><p class="font-montserrat bold">SELECTED AUTHENTICATORS IN ORDER OF PRIORITY</p><p class="small hint-text">Every Authenticator contributes Trust Points to the user’s session which is shown below:</p>
                        <form role="form">
                            <div class="form-group form-group-default required" *ngFor="let subItem of data">

                                <listauthn [authname]="subItem.name" [authscore] ="subItem.score" (callparent)="calculateTotal($event)"></listauthn>
                            </div>  
                        </form>                             

                    </div>
                    <div class="col-sm-3 col-sm-height col-middle bg-master-lighter">
                        <p class="text-center small hint-text no-margin">Sum of Authenticator Trust Points</p><h4 class="text-center text-primary no-margin">
                        {{total}}
                        </h4>
                    </div>

                </div>`
})
export class BalanceRiskAuthenticatorsComponent{

    @Input() data: Object[];
    @Input() total: number;
    count:number=0;
    authList:AuthenticatorList[]=[];
    @Output() notifyscore:EventEmitter<any> = new EventEmitter<any>();

    constructor() {

    }

    ngOnInit(): void {        

    }

    ngOnChanges(changes: SimpleChanges){
        if(changes["data"]){
            this.clear();
        }
    }

    public clear(){
        this.authList = [];
    }

    /* Function to calculate selected authenticators total score*/
    calculateTotal(arg:any)
    { 

        var list=this.authList; var count=0;
        for(var i=0; i<list.length; i++){
            if(list[i].authname==arg.name){ 
                if(arg.score){
                    list[i].authscore=!isNaN(parseInt(arg.score)) ? parseInt(arg.score) : 0;                
                }
                else{
                    list[i].authscore= 0;
                }
            }
            count=count+list[i].authscore;         
        }

        this.total= !isNaN(count) ? count : 0;

        var args = {};
        args["name"]=this.authList;
        args["score"]=count;
        this.notifyscore.emit(args);
    }

    addToList(list:AuthenticatorList){

        this.authList.push(list);
    }

}