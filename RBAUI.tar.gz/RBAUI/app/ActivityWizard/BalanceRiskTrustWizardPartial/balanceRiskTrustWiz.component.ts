/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef } from '@angular/core';
import{ BalanceRiskAuthenticatorsComponent} from './balanceRiskAuthenticators.component';

import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from '../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { RiskAlertModelData } from './riskAlertModal.component';
import * as myGlobals from './../../common/appMessages';
import { Subject } from 'rxjs/Subject';

@Component({
    selector: 'balance-risk-partial',
    template: require('./BalanceRiskTrustWiz.html'),
    providers: [APIService,Modal]
})
export class BalanceRiskTrustWizardPartialComponent{
    public balanceData:any;
    public objData:Object[]=[];
    public trustScore:any;
    public riskScore:any=0;
    public totalScore:any=0;
    public objName:Object[]=[];
    public activechallenges:Object[]=[];
    private ngUnsubscribe: Subject<void> = new Subject<void>();
    private tabContent: string = myGlobals.ACTIVITY_WIZ_BAL_CONTENT;
    ngOnDestroy(){
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    constructor(private service:APIService,  private route: ActivatedRoute,
                private tabs:TabsService,vcRef: ViewContainerRef, 
                public modal: Modal, private auth: AuthService,private globalService:GlobalService) {
        
        modal.overlay.defaultViewContainer = vcRef;
        this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => { 
            window.scrollTo(0, 0);
            if(message.text=="balance"){
                this.loadData();}
            else if(message.text=="postBalance"){
                if(message.next == "confirm"){
                    this.postBalance("confirm");}
                else{
                    this.postBalance(null);}
            }

        })
     }
    
    ngOnInit(): void {
       
    }

    /* Function to save balance risk & trust details*/
    postBalance(msg:string){
         
         this.service.postBalanceRiskWizard({
                     balanceData:this.balanceData,
                     riskScore:this.riskScore
             }).then(response=>{
                var data=response._body;
                data=JSON.parse(data);
                if(data.statusCode == 401){
                    this.auth.authInvalid= true;
                    this.globalService.redirectServerOrClient();
                }
                if(msg){
                    this.tabs.sendMessage(msg,"")
                }
         }).catch(error => {console.log(error)});
    }

    /* Function to load data incase of edit*/
    loadData(){
        this.service.getBalanceRiskAuthenticatorsWizard().then(response=>{

            var data=response._body;
            data=JSON.parse(data);
            this.objName = [];
            this.totalScore = 0;
            this.riskScore = 0;
            var objscore:any;
            if(data.riskScore){
                this.riskScore=  data.riskScore;
            }
            /*else if(data.activeRiskscore){
                for(let i=0;i<data.activeRiskscore.length;i++){                
                      objscore= parseInt(data.activeRiskscore[i]["outputpoint"]);
                      if(data.riskMethodType.toUpperCase().trim() == "MAX"){
                            if(this.riskScore < objscore){
                                this.riskScore = objscore;
                            }
                        }
                        else{
                            
                            //Total by default
                            this.riskScore = this.riskScore + objscore;
                        }
                    }

                       //Calculate Average risk score
                    if (data.riskMethodType.toUpperCase().trim() == "AVG"){
                        if(data.activeRiskscore.length > 0){
                            this.riskScore = Math.ceil(this.riskScore / data.activeRiskscore.length);
                        }        
                    }
            }*/
            this.objData = [];
            if(data.activechallenges){ 
                this.activechallenges = data.activechallenges;
                var localscore:any;
                for(var i = 0; i < data.activechallenges.length; i++){ 
                    localscore = 0;

                    if(data.balanceData)
                    {                         
                        for(var j=0; j<data.balanceData.name.length; j++){

                            if(data.balanceData.name[j].authname==data.activechallenges[i]["text"]){
                                this.objName.push(data.balanceData.name[j]);
                                localscore =parseInt(data.balanceData.name[j].score);
                                this.totalScore = this.totalScore + localscore;
                                break;
                            }
                        }
                    }

                    this.objData.push({'name':data.activechallenges[i]["text"], 'score':localscore});
                    this.balanceData = { 
                        "totalscore" : this.totalScore,
                        "name" :  this.objName                                        
                    }
                }
            }

            this.trustScore = 0
            if(data.activityscore)
            {
                this.trustScore = data.activityscore;
            }
        }).catch(error => {console.log(error)});
    }
       
    getScore(objdata:any){

        this.balanceData = {};
        var authKeyValue:Object[]=[];

        for(var i=0; i <objdata["name"].length; i ++)
        {
            authKeyValue.push({
            'authname': objdata["name"][i].authname, 
            'score': objdata["name"][i].authscore
            });
        }

        this.balanceData = {
            "totalscore" : objdata["score"],
            "name" :  authKeyValue                                
        }
        this.totalScore =  objdata["score"];
    }

    /* Function that validates the total score with the trust and risk score*/
    validateScore(showmodal:boolean){
        var a = parseInt(this.totalScore);
        var b = parseInt(this.trustScore);
        var c = parseInt(this.riskScore)

        if(b < 0){         
            this.openModal(2);
            return false;
        }
        else if(a  >=  b + c){
            if(showmodal){
                this.openModal(1);}
                return true;
        }
        else{         
            this.openModal(2);
            return false;
        }
    }

    /* Function that displays modal upon validation error in balance risk and trust tab*/
    openModal(pass:number){
        var msg = "";
        switch(pass){
            case 1:
                msg = myGlobals.AUTH_SCORE_VALIDATE;
                break;

            case 2:
                msg = myGlobals.AUTH_SCORE_INVALIDATE;
                break;

            case 3:
                msg = myGlobals.AUTH_TRUST_SCORE_VALIDATE;
                break;
        }
        const dialog = this.modal.open(RiskAlertModelData, overlayConfigFactory(
        {
            isBlocking: true,
            message: msg
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {                    
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    /* Function triggered onclick of save button in balance risk and trust tab*/
    save(){
        if(this.validateScore(false)){
            if(this.validateAuthenticatorScore()){
                this.postBalance("confirm");
            }
            else{
                this.openModal(3);
            }
        }
    }

    /* Function to validate before saving the details of balance risk and trust tab*/
    validateAuthenticatorScore(){
        var objSuccess = true;
        if(this.activechallenges.length != this.balanceData.name.length){
            objSuccess = false;
        }
        else{
            for(var i=0;i<this.balanceData.name.length;i++){
                if(parseInt(this.balanceData.name[i]["score"]) <= 0){
                    objSuccess = false;
                    break;
                }
            }
        }
        return objSuccess;
    }
             
    /* Function to validate score on keypress*/            
    _keyPress(event: any) {
    const pattern = /[0-9]/;
       let inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
          // invalid character, prevent input
         event.preventDefault();
        }
    }

    /* Function to navigate to previous tab*/
    previous(){
		this.postBalance(null);
        this.tabs.sendMessage("authenticator","");
    }
}