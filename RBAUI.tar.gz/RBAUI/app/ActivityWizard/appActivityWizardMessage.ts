/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

// placeholders
export const ACTIVITY_ID_PC : string= "Alphanumeric only, max length 10";
export const ACTIVITY_DESCRIPTION_PC: string ="Describe your activity, max length 50";
export const RULES_MSG: string = "Rules are applicable only if risk assessment(s) exist."