/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewEncapsulation,ContentChild } from '@angular/core';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {AuthenticatorsWizardPartialComponent} from './AuthenticatorsWizardPartial/authenticatorsWiz.component'
import {BalanceRiskTrustWizardPartialComponent} from './BalanceRiskTrustWizardPartial/balanceriskTrustWiz.component'
import {ConfirmWizardPartialComponent} from './ConfirmWizardPartial/confirmWiz.component'
import {RiskAssessmentsWizardPartialComponent} from './RiskAssessmentsWizardPartial/riskAssessmentsWiz.component'
import {TabsService} from '../services/tabsService'
import { GlobalService } from '../services/globalFunctions.service';
import { MessageService } from '../services/MessageService';
import { APIService } from '../services/APIService.service';
@Component({
  
        template: require('./ActivityWizard.html')
})
export class ActivityWizardComponent{

    constructor(private tabservice:TabsService, private globalService:GlobalService, private messageService:MessageService,
				private router:Router,private apiService: APIService) {
        if(this.globalService.userRole != "neuroadmin"){
			this.redir();
		}
		else{
			this.validateAccess();
		}
    }
    save(){

    }

	validateAccess(){
		this.apiService.getLoggedInUserDetails().then(response=>{
			var data=response._body;
			var data=JSON.parse(data);
			if(data.userrole){
				this.globalService.userRole = data.userrole;
				if(data.userrole != "neuroadmin"){
					this.redir();
				}
			}
		}).catch(error => {
			console.log(error);
		});
	}
	
	redir(){
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}
	
    clear(){
    }

    changeTabs(arg:any){
      
    }
     
    tabclicked(arg:any){
       
       switch(arg){
                
       }
    }
}

