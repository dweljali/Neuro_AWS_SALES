/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input } from '@angular/core';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {TabsService} from '../../../../services/tabsService';
import {AuthService} from '../../../../services/auth.service';
import { Subject } from 'rxjs/Subject';
import * as myGlobals from './../../../../common/appMessages';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { riskConfigurationModal, riskConfigurationModalData  } from './addRiskConfigurationModal';
import {ConfirmModelData} from './../../../../common/confirmModal.component'
import { AlertModelData } from './../../../../common/alertModal.component';
import { SimpleChange } from '@angular/core';

@Component({
  selector: 'edit-risk-configuration',
  template: `<span defaultOverlayTarget></span>  
`,
  providers: [Modal]
})

export class riskConfigEditModalComponent {
    @Output() custevent:EventEmitter<any> = new EventEmitter<any>();
	 public datatypeobj:Object[]=[];
     public configtypedata:Object[]=[];
	 @Input() iddata:Object[]=[];
    constructor( public modal: Modal) {
			   this.datatypeobj.push({'id':"STRING",'text':"STRING"});
		this.datatypeobj.push({'id':"INTEGER",'text':"INTEGER"});
		
		this.configtypedata.push({'id':"INPUT_THRESHOLD",'text':"Input threshold or value"});
		this.configtypedata.push({'id':"OUTPUT_POINTS",'text':"Output in points"});
		this.configtypedata.push({'id':"OUTCOME_DESC",'text':"Outcome description"});
    }
    openCustom(data: any) {
    let active: string ;

    for(let config of this.configtypedata){
        if(config['id'] == data['Type']){
            active = config['text'];
        }
    }
      
    const dialog = this.modal.open(riskConfigurationModal, overlayConfigFactory(
        {
            isBlocking: true,
            configID: data['id'], 
            configName: data['Name'],
            configDescription: data['Desc'],
            configValue: data['Value'],
            configEdit:true,
            Add:"Edit", 
            activedatatype:[{'text': active}], 
            selectedConfType: data['Type']   ,    
            selecteddatatype: active == "Output in points" ? "INTEGER" : "STRING",
            datatype:this.datatypeobj,
			configtypedata:this.configtypedata,
            formData: data,
            authHeadermsg:"Edit risk configuration using this form"
        }, BSModalContext));
         
        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                this.custevent.emit(result);
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });   
    }
}

