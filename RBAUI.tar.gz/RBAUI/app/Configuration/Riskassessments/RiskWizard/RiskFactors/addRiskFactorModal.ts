import { Component, Input, AfterViewInit, ViewChildren } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { APIService } from '../../../../services/APIService.service';
import { GlobalService } from '../../../../services/globalFunctions.service';
import { selectComponent } from './../../../../common/select.component';
import * as myGlobals from './../../../../common/appMessages';
import {
  RISK_FACTOR_ID_PC, RISK_FACTOR_NAME_PC, RISK_CLASS_NAME_PC,
  RISK_FACTOR_CLASS_NAME_PC, RISK_FACTOR_LOCATOR_CLASS_NAME_PC
} from './addRiskFactorModalMessages';

export class riskFactorModalData extends BSModalContext {
  public factorID: string;
  public factorName: string;
  public riskClass: string;
  public factorClass: string;
  public factorLocator: string;

  public factorEdit: boolean;
  public Add: string;
  public datatype: Object[];
  public activedatatype: Object[];
  public selecteddatatype: string;
  public selectedps: string;
  public iddata: any;
  public ediddata: any;
  public providedsystems: Object[];
  public authHeadermsg: string;
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-content',
  template: `<style>
    .ui-select-choices {
        left: auto;
        position: fixed;
        top: auto;
        width: 88% !important;
    }

    .small-text-red {
        font-size: 14px !important;
        color: red;
        text-align: center;
    }

    .hide-text {
        display: none;
    }
</style>
<div class="modal-dialog" [class.customfade]="isFade">
    <div class="modal-header clearfix ">
        <button type="button" (click)='closebox()' class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                  </button>
        <h4 class="p-b-5"><span class="semi-bold">{{context.Add}}</span> Risk Factor</h4>
    </div>
    <div class="modal-body">
        <p class="small-text-red" [class.hide-text]="hideerrormsg">{{errormessage}}</p>
        <p class="small-text">{{context.authHeadermsg}}</p>
        <form role="form">
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default required">
                        <label>Risk Factor ID</label>
                        <input maxlength="10" id="appID" #appID (focus)="oninputfocus()" (input)="factorID = $event.target.value" [disabled]="context.factorEdit"
                            class="form-control" placeholder="{{riskFactorIdPc}}" type="text" value="{{context.factorID}}" (keypress)="_keyPressID($event)">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default required">
                        <label>Risk Factor Name</label>
                        <input maxlength="50" id="appName" #appName (input)="factorName = $event.target.value" (focus)="oninputfocus()" class="form-control"
                            placeholder="{{riskFactorNamePc}}" type="text" value="{{ context.factorName}}">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default required custFormgrp">
                        <label>Provided System</label>
                        <custom-select [dataobject]="context.providedsystems" [placeholder]="pcholder" (selectvaluechange)="selectedvalueps($event)"
                            [activemember]="context.selectedps"></custom-select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 ">
                    <div class="form-group form-group-default custFormgrp">
                        <label>Risk Factor Datatype</label>
                        <custom-select [dataobject]="context.datatype" [placeholder]="pcholder" (selectvaluechange)="selectedvalue($event)" [activemember]="context.activedatatype"></custom-select>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label>Risk Assessment Class</label>
                        <input maxlength="100" id="appRiskClass" #appRiskClass (input)="riskClass = $event.target.value" (focus)="oninputfocus()" class="form-control"
                            placeholder="{{riskClassPc}}" type="text" value="{{ context.riskClass}}">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label>Risk Factor Class</label>
                        <input maxlength="100" id="appFactorClass" #appFactorClass (input)="factorClass = $event.target.value" (focus)="oninputfocus()"
                            class="form-control" placeholder="{{factorClassPc}}" type="text" value="{{ context.factorClass}}">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label>Risk Factor Locator Class</label>
                        <input maxlength="100" id="appFactorLocator" #appFactorLocator (input)="factorLocator = $event.target.value" (focus)="oninputfocus()"
                            class="form-control" placeholder="{{factorLocatorPc}}" type="text" value="{{ context.factorLocator}}">
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <button id="add-app" data-dismiss="modal" type="button" (click)='saveAuthenticators(appID.value, appName.value,  isEdit.value,datattype.value, iddata.value)'
            class="btn btn-primary  btn-cons">Add</button>
        <button type="button" data-dismiss="modal" (click)='closebox()' class="btn btn-cons">Close</button>
        <input type="hidden" #isEdit value="{{context.factorEdit}}">
        <input type="hidden" #datattype value="{{context.selecteddatatype}}">
        <input type="hidden" #iddata value="{{context.iddata}}">
    </div>
</div>`
})
export class riskFactorModal implements CloseGuard, ModalComponent<riskFactorModalData> {
  context: riskFactorModalData;
  @ViewChildren('appID') vcappid: any;


  ngAfterViewInit() {
    try {
      if (this.vcappid) {
        this.vcappid.first.nativeElement.focus();
      }
    }
    catch (e) {
    }

  }

  public isFade = false;
  public factorID: string;
  public factorName: string;
  public riskClass: string;
  public factorClass: string;
  public factorLocator: string;

  public selecteddatatype: string;
  public returndata: any;
  public pcholder: string;
  public authFact: string;
  public selecteddatakey: string;
  public selectedps: string;

  public hideerrormsg = true;
  public errormessage: string;

  public riskFactorIdPc: string = RISK_FACTOR_ID_PC;
  public riskFactorNamePc: string = RISK_FACTOR_NAME_PC;
  public riskClassPc: string = RISK_CLASS_NAME_PC;
  public factorClassPc: string = RISK_FACTOR_CLASS_NAME_PC;
  public factorLocatorPc: string = RISK_FACTOR_LOCATOR_CLASS_NAME_PC;
  oninputfocus() {
    this.errormessage = "";
    this.hideerrormsg = true;
  }

  constructor(private apiService: APIService, public dialog: DialogRef<riskFactorModalData>, private globalService: GlobalService) {
    this.context = dialog.context;
    dialog.setCloseGuard(this);

    let objmodalelement = document.getElementsByClassName('modal fade in');
    if (objmodalelement && objmodalelement[0]) {
      console.log("add stick up class");
      objmodalelement[0].classList.add('stick-up');
    }

    this.pcholder = myGlobals.FACT_LOCATOR_PH;
    this.factorID = this.context.factorID;
    this.factorName = this.context.factorName;
    this.riskClass = this.context.riskClass;
    this.factorClass = this.context.factorClass;
    this.factorLocator = this.context.factorLocator;

    this.selecteddatatype = this.context.selecteddatatype;
    if (this.context.selectedps) {
      this.selectedps = this.context.selectedps[0]['text'];
    }

  }

  closebox() {
    this.isFade = true;
    this.dialog.close(this.returndata);
  }

  selectedvalue(objValue: any) {
    this.selecteddatatype = objValue.id;

  }

  selectedvalueps(val: any) {
    this.selectedps = val.id;
  }

  beforeDismiss(): boolean {
    this.dialog.close(this.returndata);
    this.isFade = true;
    return false;
  }

  /* Function to validate authenticator id */
  _keyPressID(event: any) {
    var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft', 'Home', 'Delete', 'Tab'];
    const pattern = /^[a-zA-Z\d-_]+$/;
    let inputChar = String.fromCharCode(event.charCode);


    if (arrint.indexOf(event.key) != -1) {
      return;
    }
    else if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }

  }

  /* Function to save the new/edited authenticator */
  saveAuthenticators(objAppid: string, objAppname: string,
    objEdit: string, objdatattype: string, idData: any) {


    if (!objAppid || !objAppname || !this.selectedps) {
      this.errormessage = myGlobals.MANDATORY_FIELDS_VALIDATE;
      this.hideerrormsg = false;
      return;
    }

    /*	var validstate = 1;
      if(this.globalService.riskfactorids){
        for(var i=0; i<this.globalService.riskfactorids.length; i++){
          if(this.globalService.riskfactorids[i].toUpperCase().trim() == this.factorID.toUpperCase().trim()){
            validstate = 0;
            break;
          }
        }
      	
        if(validstate == 0){
          this.errormessage = "Risk Factor ID already exists. Please enter some other ID.";
          this.hideerrormsg = false;
          return;
        }
      }*/
    if (idData) {
      var res = idData.split(",");
      if (res && res.length > 0) {
        var validstate = 1;
        for (var i = 0; i < res.length; i++) {
          if (res[i] == this.factorID) {
            validstate = 0;
            break;
          }
        }

        if (validstate == 0) {
          this.errormessage = "Risk configuration ID already exists. Please enter some other ID.";
          this.hideerrormsg = false;
          return;
        }
      }
    }

    if (!this.selecteddatatype) {
      this.selecteddatatype = objdatattype;
    }

    ;
    this.returndata = {
      'id': this.factorID, 'name': this.factorName, 'providedsystem': this.selectedps,
      'datattype': this.selecteddatatype, 'type': 1,
      'risk_asmt_classname': this.riskClass,
      'risk_factor_classname': this.factorClass,
      'risk_factor_locator_classname': this.factorLocator
    };
    this.closebox();
  }


}
