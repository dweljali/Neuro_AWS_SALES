import { Component, OnInit, Output, EventEmitter, ViewContainerRef, AfterViewInit, ViewChildren, Input } from '@angular/core';
import { APIService } from './../../../services/APIService.service';
import { GlobalService } from './../../../services/globalFunctions.service';
import { AuthService } from './../../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TabsService } from './../../../services/tabsService'

import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AlertModelData } from './../../../common/alertModal.component';
import * as myGlobals from './../../../common/appMessages';
import { Subject } from 'rxjs/Subject'
import { objectTypeTable } from './../../../common/objectTypeTable.component'

@Component({
    selector: 'object-type-wizard',
    template: require('./ObjectType.html'),
    providers: [APIService, Modal]
})
export class ObjectTypePartialComponent {
    private ngUnsubscribe: Subject<void> = new Subject<void>();
    @Input() objecttype: number; //1 - Activity, 2 - Risk, 3 - Authenticators
    @Input() activitylist: any;
    @Input() authlist: any;
    @Input() risklist: any;
    @Input() activeactivity: any;
    @Input() activeauth: any;
    @Input() activerisk: any;

    public cnls: any = {
        "INTERNET": "Internet", "ATM": "ATM Kiosk", "WEB": "Internet Banking",
        "RETAIL": "Retail Banking",
        "COMMERCIAL": "Commercial Banking",
        "MOBILE": "Mobile Banking",
        "CHAT": "Chat",
        "FACEBOOK": "Facebook", "MWALLET": "Mobile Wallet"
        , "CALLCENTER": "Call Center"
    };

    public displayobjtype: string = "ACTIVITIES";
    private tabTextContent: string = myGlobals.EXPORT_OBJECT_TAB_CONTENT;

    public showswitch: Boolean = false;
    public data: Object[] = [];
    @Output() fillactivitylist: EventEmitter<any> = new EventEmitter<any>();
    @Output() fillauthlist: EventEmitter<any> = new EventEmitter<any>();
    @Output() fillrisklist: EventEmitter<any> = new EventEmitter<any>();
    @Output() updateactiveitem: EventEmitter<any> = new EventEmitter<any>();
    @Output() updatechannels: EventEmitter<any> = new EventEmitter<any>();

    tableTitles: Object[] = [];
    maxpagesize: number;
    itemsperpage: number;

    ngAfterViewInit() {

    }

    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    constructor(private service: APIService, private route: ActivatedRoute,
        private router: Router, private tabs: TabsService, vcRef: ViewContainerRef,
        public modal: Modal, private auth: AuthService, private globalService: GlobalService) {
        modal.overlay.defaultViewContainer = vcRef;
        window.scrollTo(0, 0);
        this.tableTitles = [['id', 1], ['description', 1], ['channel', 1]];
        this.maxpagesize = myGlobals.EXPORT_MAX_PAGE_SIZE;
        this.itemsperpage = myGlobals.EXPORT_ITEMS_PER_PAGE;
        this.loadData();

        this.tabs.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {
            if (message.text.toUpperCase().trim() == "OBJECTTYPE") {
                window.scrollTo(0, 0);
                this.loadData();
            }
        });
    }

    /* Function that displays modal upon validation error on activity & channel tab*/
    openModal() {
        const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
            {
                isBlocking: true,
                message: myGlobals.SELECT_EXPORT_TYPE,
                headtext: "Validation error"
            }, BSModalContext));

        dialog.then((resultPromise) => {
            resultPromise.result.then((result) => {
                let objbody = document.getElementsByTagName('body')[0];
                objbody.classList.remove("modal-open");
            });
        });
    }

    validate() {
        if (this.objecttype == 0) {
            return false;
        }
        return true;
    }

    /* Function to navigate to the previous tab*/
    previous() {
        this.tabs.sendMessage("exportType", "");
    }

    /* Function to navigate to the next tab*/
    next() {
        if (this.validate()) {
            this.tabs.sendMessage("confirmExport", "");
        }
        else {
            this.openModal();
            this.tabs.sendMessage("exportType", "");
        }
    }

    updateallitem(value: any) {
        for (var i = 0; i < this.data.length; i++) {
            this.data[i]['status'] = value;
        }
        this.updateactiveitem.emit(this.data);
    }

    updateitemlist(value: any) {
        for (var i = 0; i < this.data.length; i++) {
            if (value.id == this.data[i]['id'] && value.channel == this.data[i]['channel']) {
                this.data[i]['status'] = value.status;
                break;
            }
        }
        this.updateactiveitem.emit(this.data);
    }

    /* Function to load data incase of edit*/
    loadData() {

        if (this.objecttype == 1) {
            this.displayobjtype = "ACTIVITIES";

            if (!this.activitylist || this.activitylist.length == 0) {
                this.fillauthlist.emit(null);
                this.fillrisklist.emit(null);
                this.updateactiveitem.emit(null);
                this.updatechannels.emit(null);
                this.data.splice(0, this.data.length);
                this.service.getActivities().then((response) => {
                    var objdata = JSON.parse(response._body);
                    var APIdata = objdata.activities;
                    this.cnls = objdata.channels;
                    this.updatechannels.emit(objdata.channels);
                    if (objdata.statusCode == 401) {
                        this.auth.authInvalid = true;
                        this.globalService.redirectServerOrClient();
                    }
                    else {
                        this.fillactivitylist.emit(APIdata);//emit output fill act list

                        for (var i = 0; i < APIdata.length; i++) {
                            this.data.push({
                                'id': APIdata[i].activity.activityID.value,
                                'description': APIdata[i].activity.description,
                                'channel': this.cnls[APIdata[i].activity.channel],
                                'channelid': APIdata[i].activity.channel,
                                'status': false
                            });
                        }
                    }
                }).catch(error => {
                    console.log(error);
                });
            }

        }
        else if (this.objecttype == 2) {
            this.displayobjtype = "RISK ASSESSMENTS";
            if (!this.risklist || ((!this.risklist.os || this.risklist.os.length == 0)
                || (!this.risklist.ea || this.risklist.ea.length == 0))
            ) {

                this.fillactivitylist.emit(null);
                this.fillauthlist.emit(null);
                this.updateactiveitem.emit(null);

                this.data.splice(0, this.data.length);
                this.service.getRiskAssesment().then(response => {
                    var data = response._body;
                    data = JSON.parse(data);

                    if (data.statusCode == 401) {
                        this.auth.authInvalid = true;
                        this.globalService.redirectServerOrClient();
                    }
                    else {
                        this.fillrisklist.emit(data);//emit output fill auth list
                        if (data.os) {
                            for (let i = 0; i < data.os.length; i++) {

                                this.data.push({
                                    'id': data.os[i].riskAssessmentCD.toString(),
                                    'description': data.os[i].riskAssessmentName.toString(),
                                    'status': false
                                });
                            }
                        }
                        if (data.ea) {
                            for (let i = 0; i < data.ea.length; i++) {
                                this.data.push({
                                    'id': data.ea[i].riskAssessmentCD.toString(),
                                    'description': data.ea[i].riskAssessmentName.toString(),
                                    'status': false
                                });
                            }
                        }
                    }
                }).catch(error => { console.log(error) });
            }
        }
        else if (this.objecttype == 3) {
            this.displayobjtype = "AUTHENTICATORS";
            if (!this.authlist || this.authlist.length == 0) {
                let AuthenticatorsList: any;
                this.fillactivitylist.emit(null);
                this.fillrisklist.emit(null);
                this.updateactiveitem.emit(null);
                this.data.splice(0, this.data.length);
                this.service.getAuthenticators().then((response: any) => {
                    var objBody = JSON.parse(response._body);
                    if (objBody.factLocators && objBody.factLocators.statusCode
                        && objBody.factLocators.statusCode == 401 || objBody.statusCode == 401) {
                        this.auth.authInvalid = true;
                        this.globalService.redirectServerOrClient();
                    }
                    else {
                        AuthenticatorsList = objBody.authenticatorResponse;
                        this.fillauthlist.emit(AuthenticatorsList);//emit output fill auth list
                        for (var i = 0; i < AuthenticatorsList.length; i++) {
                            if (AuthenticatorsList[i].id) {
                                this.data.push({
                                    'id': AuthenticatorsList[i].id.value,
                                    'description': AuthenticatorsList[i].description,
                                    'status': false
                                });
                            }
                        }
                    }
                }).catch(error => {
                    console.log(error);
                });
            }
        }
        if (this.data && this.data.length > 0) {
            console.log(this.data.length);
            this.showswitch = true;
        }
    }
}