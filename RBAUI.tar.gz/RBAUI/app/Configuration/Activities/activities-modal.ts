import { Component,Input } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';

/* Component to display all authenticators and risk assessments for a row in activity table. */ 
export class ActivityModelData extends BSModalContext {
  public actArr:string[];
  public Add:string;
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-content',
  template: `
   <div class="custModal">
        <div class="modal-dialog" [class.customfade]="isFade">
             
                <div class="modal-header clearfix ">

                  <h4 class="p-b-5"><span class="semi-bold">{{context.Add}}</span></h4>
                </div>
                <div class="modal-body">
                  <form role="form">
                    <div class="row">
                      <div class="col-sm-12">
                      	<table class="table table-hover demo-table-search table-responsive-block" id="tableWithSearch">
                      		 <tbody> 
                      		 	<tr>
                      		 		<td><a *ngFor="let temp of context.actArr;" href="javascript:void(0)" class="btn btn-tag">{{temp}}</a></td>
                      		 	</tr>
                      		 </tbody>
                      	</table>
					   </div>
                    </div>
                                     
                  </form>
                </div>
                <div class="modal-footer"><button type="button" data-dismiss="modal" (click)='closebox()' class="btn btn-cons">Close</button>
                </div>
            </div>
            </div>`
})

export class ActivityeModel implements CloseGuard, ModalComponent<ActivityModelData> {
  context: ActivityModelData;
  public isFade = false;
  public returndata:any;
   
	constructor(public dialog: DialogRef<ActivityModelData>) { 
		this.context = dialog.context;
		dialog.setCloseGuard(this);
	}

	closebox(){
    this.isFade = true;
    this.dialog.close(this.isFade);
	}

}