/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

export const FACT_LOCATOR_REDIRECT_PAGE_NAME: string = "Dashboard";
export const FACT_LOCATOR_HEADER_TEXT: string = "Configure Fact Locators";
export const FACT_LOCATOR_ITEMS_PER_PAGE: number = 10;
export const FACT_LOCATOR_MAX_PAGE_SIZE: number = 5;
export const DELETE_FACT_LOCATOR_CONFIRM: string = "Are you sure you want to delete this fact locator?";
export const ADD_FACT_LOCATOR_SUCCESS: string = "Fact locator successfully added.";
export const UPDATE_FACT_LOCATOR_SUCCESS: string = "Fact locator successfully edited.";
export const FACT_LOCATOR_TABLE_SORT_INFO: any = {'key': 1,'name': 1};
export const FACT_LOCATOR_TABLE_DISPLAY_NAME: any = {'key': 'Fact Key','name': 'Name'};
export const FACT_LOCATOR_TITLE_TEXT: string = "Fact Locators";
export const FACT_LOCATOR_BTN_ADD_TEXT: string = " Add a Fact Locator";
export const FACT_LOCATOR_ADD_TEXT: string = "Add";
export const FACT_LOCATOR_ADD_HEADER_TEXT: string = "Create a new fact locator using this form";
export const FACT_LOCATOR_EDIT_TEXT: string = "Edit";
export const FACT_LOCATOR_EDIT_HEADER_TEXT: string = "Edit fact locator using this form";
export const FACT_LOCATOR_DELETE_ERROR_MSG: string = "There was an error while deleting this fact locator.";
export const FACT_LOCATOR_ADD_TITLE_TEXT: string = "Fact Locator";
export const FACT_LOCATOR_LOCALSTORAGE_KEY:string = "fact-locator-records";
export const FACT_LOCATOR_LBL_FACT_KEY: string = "Fact Key";
export const FACT_LOCATOR_LBL_FACT_NAME: string = "Fact Locator Name";
export const FACT_LOCATOR_LBL_FACT_CLASS: string = "Fact Locator Class Name";
export const FACT_PC_KEY: string = "Alphanumeric only, max length 100";
export const FACT_PC_NAME: string = "Alphanumeric only,  max length 200";
export const FACT_PC_CLASS: string = "Alphanumeric only,  max length 500";
export const FACT_KEY_MAX_LENGTH: number = 100;
export const FACT_NAME_MAX_LENGTH: number = 200;
export const FACT_CLASS_MAX_LENGTH: number = 500;
export const FACT_BTN_CLOSE: string = "Close";
export const FACT_BTN_SAVE: string = "Save";
export const MANDATORY_FIELDS_VALIDATION: string = "Please fill in all mandatory fields.";
export const FACT_UPDATE_ERROR_MSG: string = "There was an error while updating fact locator.";
export const FACT_ADD_ERROR_MSG: string = "There was an error while adding a new fact locator."