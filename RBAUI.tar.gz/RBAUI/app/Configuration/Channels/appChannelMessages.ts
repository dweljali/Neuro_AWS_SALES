/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

export const CHANNEL_REDIRECT_PAGE_NAME: string = "Dashboard";
export const CHANNEL_HEADER_TEXT: string = "Configure Channels";
export const CHANNEL_ITEMS_PER_PAGE: number = 10;
export const CHANNEL_MAX_PAGE_SIZE: number = 5;
export const DELETE_CHANNEL_CONFIRM: string = "Are you sure you want to delete this channel?";
export const ADD_CHANNEL_SUCCESS: string = "Channel is successfully added.";
export const UPDATE_CHANNEL_SUCCESS: string = "Channel is successfully edited.";
export const CHANNEL_TABLE_SORT_INFO: any = {'id': 1,'description': 1};
export const CHANNEL_TABLE_DISPLAY_NAME: any = {'id': 'id','description': 'description'};
export const CHANNEL_TITLE_TEXT: string = "Channels";
export const CHANNEL_BTN_ADD_TEXT: string = "Add a Channel";
export const CHANNEL_ADD_TEXT: string = "Add";
export const CHANNEL_ADD_HEADER_TEXT: string = "Create a new channel using this form";
export const CHANNEL_EDIT_TEXT: string = "Edit";
export const CHANNEL_EDIT_HEADER_TEXT: string = "Edit channel using this form";
export const CHANNEL_DELETE_ERROR_MSG: string = "There was an error while deleting this channel.";
export const CHANNEL_ADD_TITLE_TEXT: string = "Channel";
export const CHANNEL_BTN_ID: string = "Channel ID";
export const CHANNEL_BTN_DESC: string = "Channel Description";
export const CHANNEL_ID_MAX_LENGTH: number = 10;
export const CHANNEL_DESC_MAX_LENGTH: number = 50;
export const CHANNEL_PC_ID: string = "Alphanumeric only, max length 10";
export const CHANNEL_PC_DESC: string = "Describe the channel,  max length 50";
export const CHANNEL_BTN_CLOSE: string = "Close";
export const CHANNEL_BTN_SAVE: string = "Save";
export const MANDATORY_FIELDS_VALIDATE: string = "Please fill in all mandatory fields.";
export const CHANNEL_UPDATE_ERROR_MSG: string = "There was an error while updating channel.";
export const CHANNEL_ADD_ERROR_MSG: string = "There was an error while adding a new channel.";
//-----------------

export const RISK_BTN_ADD_TEXT: string = "Add a Risk Assessment";
export const RISK_POLICY_DETAILS_TEXT: string = "Select Risk Aggregation Method:";
export const RISK_OPT_TOTAL_TEXT: string = "Total";
export const RISK_OPT_MAX_TEXT: string = "Max";
export const RISK_OPT_AVG_TEXT: string = "Average";
export const RISK_TABLE_DISPLAY_NAME: any = {'id': 'id','name': 'name'};


export const RISK_BTN_DISPLAY_DETAILS: string = "Details";

export const RISK_SEARCH_TEXT_PC: string = "Search Assessment ID, NAME";
export const RISK_CONFIG_HEADER_TEXT: string = "CONFIGURATION";
export const RISK_CONFIG_TABLE_DISPLAY_NAME: any = {'id': 'id','name': 'name', 'value': 'value', 'type': 'type'};
export const RISK_CONFIG_TABLE_SORT_INFO: any = {'id': 1,'name': 1, 'value': 1, 'type': 1};
export const RISK_CONFIG_ITEMS_PER_PAGE: number = 6;
export const RISK_CONFIG_MAX_PAGE_SIZE: number = 4;

export const RISK_FACTOR_HEADER_TEXT: string = "RISK FACTORS";
export const RISK_FACTOR_TABLE_DISPLAY_NAME: any = {'id': 'id','name': 'name', 'provided_system': 'provided system'};
export const RISK_FACTOR_TABLE_SORT_INFO: any = {'id': 1,'name': 1, 'provided_system': 1};
export const RISK_FACTOR_ITEMS_PER_PAGE: number = 4;
export const RISK_FACTOR_MAX_PAGE_SIZE: number = 4;
export const RISK_MODAL_CLOSE_TEXT: string = "Close";