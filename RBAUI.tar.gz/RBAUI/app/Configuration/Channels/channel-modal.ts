import { Component,Input,AfterViewInit, ViewChildren } from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import * as myGlobals from './appChannelMessages';

export class channelModalData extends BSModalContext {
	public channelID: string; 
	public channelDescription: string;
	public channelEdit: boolean;
	public Add:string;
	public channelHeadermsg:string;
}

/**
 * Create channel modal popup
 */
@Component({
  selector: 'modal-content', 
  template: `
    <style>.ui-select-choices {left: auto; position: fixed;    top: auto;    width: 88% !important;} .small-text-red {font-size: 14px !important;color: red;text-align: center;} .hide-text{display: none;}</style>
        <div class="modal-dialog" [class.customfade]="isFade">
             
                <div class="modal-header clearfix ">
        <button type="button" (click)='closebox()' class="close" data-dismiss="modal" aria-hidden="true">
<i class="pg-close fs-14"></i>
                  </button>
                  <h4 class="p-b-5"><span class="semi-bold">{{context.Add}}</span> {{titleText}}</h4>
                </div>
                <div class="modal-body">
                  <p class="small-text-red" [class.hide-text]="hideerrormsg">{{errormessage}}</p>
                  <p class="small-text">{{context.channelHeadermsg}}</p>                   
                  <form role="form">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>{{lblChannelID}}</label>
                          <input maxlength="10" id="appName" #appName (focus)="oninputfocus()"
							[disabled]="context.channelEdit" 
							class="form-control" placeholder="{{pcChannelID}}" 
							type="text" value="{{context.channelID}}" 
							(keypress)="_keyPressID($event)" (paste)="false">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group form-group-default required">
                          <label>{{lblChannelDesc}}</label>
                          <input maxlength="50" id="appDescription" #appDesc 
							(focus)="oninputfocus()" class="form-control" 
							placeholder="{{pcChannelDesc}}" value="{{context.channelDescription}}">
                        </div>
                      </div>
                    </div>                  
                  </form>
                </div>
				<div class="modal-footer">
					<button id="add-app" data-dismiss="modal" type="button" 
						(click)='saveChannels(appName.value, appDesc.value, isEdit.value)' 
						class="btn btn-primary  btn-cons">{{btnSaveText}}</button>
					<button type="button" data-dismiss="modal" (click)='closebox()' 
						class="btn btn-cons">{{btnCloseText}}</button>
					<input type="hidden" #isEdit value="{{context.channelEdit}}" >
				</div>
            </div>`
})
export class ChannelModal implements CloseGuard, ModalComponent<channelModalData> {
	context: channelModalData;

	@ViewChildren('appName') vcappname:any;
	@ViewChildren('appDesc') vcappdesc:any;

	ngAfterViewInit() {
		if(this.vcappname.first.nativeElement.value){
			this.vcappdesc.first.nativeElement.focus();
		}
		else{
			this.vcappname.first.nativeElement.focus();
		}
	}

	public isFade = false;
	public returndata:any;
	public pcholder:string;
	public hideerrormsg = true;
	public errormessage:string;
	titleText:string = myGlobals.CHANNEL_ADD_TITLE_TEXT;
	lblChannelID:string = myGlobals.CHANNEL_BTN_ID;
	lblChannelDesc:string = myGlobals.CHANNEL_BTN_DESC;
	btnCloseText:string = myGlobals.CHANNEL_BTN_CLOSE;
	btnSaveText:string = myGlobals.CHANNEL_BTN_SAVE;
	channelIDMaxLength:number = myGlobals.CHANNEL_ID_MAX_LENGTH;
	channelDescMaxLength:number = myGlobals.CHANNEL_DESC_MAX_LENGTH;
	pcChannelID:string = myGlobals.CHANNEL_PC_ID;
	pcChannelDesc:string = myGlobals.CHANNEL_PC_DESC;

	oninputfocus(){
		this.errormessage = "";
		this.hideerrormsg = true;
	}

	constructor(private apiService: APIService, public dialog: DialogRef<channelModalData>,
		private globalService: GlobalService) {
		this.context = dialog.context;
		dialog.setCloseGuard(this); 
	}

	closebox(){
		this.isFade = true;
		this.dialog.close(this.returndata);
	}

	beforeDismiss(): boolean {
		this.dialog.close(this.returndata);
		this.isFade = true;
		return false;
	}

	/* Function to validate channel id */ 
	_keyPressID(event: any) {
		var arrint: Array<string> = ['Backspace', 'ArrowLeft', 'ArrowLeft','Home','Delete','Tab'];
		const pattern = /^[a-zA-Z\d-_]+$/;
		let inputChar = String.fromCharCode(event.charCode);

		if(arrint.indexOf(event.key) != -1 ){
			return;
		}
		else if (!pattern.test(inputChar)) {
			// invalid character, prevent input
			event.preventDefault();
		}
	}

	/* Function to save the new/edited channel */ 
	saveChannels(objAppname:string, objAppDesc:string, objEdit:string)
	{  
		if(!objAppname || !objAppDesc){
			this.errormessage = myGlobals.MANDATORY_FIELDS_VALIDATE;
			this.hideerrormsg = false;
			return;   
		}

		if(objEdit == "true"){
			this.apiService.putChannels({
				channelID:objAppname,
				channelDescription:objAppDesc
			}).then(response=>{   
				var resp = JSON.parse(response._body);
				if(resp.statusCode == 401){
					this.closebox();
					this.globalService.redirectServerOrClient();
				}
				else if(resp.error == 0){  
					this.returndata = {'id': objAppname, 'description': objAppDesc,'type':0};
					this.closebox();
				}
				else{
					this.errormessage = resp.errorMsg ? resp.errorMsg : myGlobals.CHANNEL_UPDATE_ERROR_MSG;
					this.hideerrormsg = false;  
				}
			}).catch(error => {
				console.log(error);
			});
		}
		else{
			this.apiService.postChannels({
				channelID:objAppname,
				channelDescription:objAppDesc
			}).then(response=>{   
				var resp = JSON.parse(response._body);
				if(resp.statusCode == 401){
					this.closebox();
					this.globalService.redirectServerOrClient();
				}
				else if(resp.error == 0){  
					this.returndata = {'id': objAppname, 'description': objAppDesc,'type':1};
					this.closebox();
				}
				else{
					this.errormessage = resp.errorMsg ? resp.errorMsg : myGlobals.CHANNEL_ADD_ERROR_MSG;
					this.hideerrormsg = false;  
				}
			}).catch(error => {
				console.log(error);
			});
		}
	}
}