/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
'use strict';

// placeholders
export const AUTHENTICATOR_ID_PC : string = "Alphanumeric only, max length 10"
export const AUTHENTICATOR_DESCRIPTION_PC : string = "Describe the authenticator, max length 50"