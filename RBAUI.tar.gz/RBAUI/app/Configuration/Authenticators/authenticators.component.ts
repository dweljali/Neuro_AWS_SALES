import { Component, OnInit, ViewEncapsulation, ViewContainerRef, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Table } from '../../common/table.component'
import { APIService } from './../../services/APIService.service';
import { GlobalService } from './../../services/globalFunctions.service';
import { AuthService } from './../../services/auth.service';
import { MessageService } from './../../services/MessageService';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ChallengeModel, CustomModelData } from './authenticator-modal';
import { ConfirmModelData } from '../../common/confirmModal.component'
import { AlertModelData } from './../../common/alertModal.component';
import * as myGlobals from './../../common/appMessages';
import { SettingsService } from '../../services/settings.service';
/* Trigger to add new authenticator modal */
@Component({
  selector: 'modal-authenticator',
  template: `<span defaultOverlayTarget></span>  
  <button (click)="openCustom()" id="show-modal" class="btn btn-primary btn-cons"><i class="fa fa-plus"></i> Add an Authenticator</button>
`,
  providers: [Modal]
})

export class authenticatorModalComponent {
  @Output() custevent: EventEmitter<any> = new EventEmitter<any>();
  @Input() factdata: any;
  constructor(public modal: Modal) {

  }
  openCustom() {

    const dialog = this.modal.open(ChallengeModel, overlayConfigFactory(
      {
        isBlocking: true,
        authID: "",
        authDescription: "",
        authEdit: false,
        Add: "Add",
        factLocator: this.factdata,
        activefact: [{ 'text': myGlobals.FACT_LOCATOR_PH }],
        selectedfactkey: "None",
        selectedfactvalue: myGlobals.FACT_LOCATOR_PH,
        authHeadermsg: "Create a new authenticator using this form"
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        this.custevent.emit(result);
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
      });
    });
  }
}

@Component({
  selector: 'authenticators',
  template: require('./Authenticators.html'),
  providers: [Modal]
})
export class AuthenticatorsComponent {

  titles: Object[] = [];
  data: Object[] = [];
  objDelete: Object;
  AuthenticatorsList: any;
  factdata: Object[] = [];
  placeholder: string = myGlobals.AUTHENTICATORS_SEARCH_PH;
  itemsperpage: number;
  maxpagesize: number = myGlobals.AUTHENTICATOR_MAX_PAGE_SIZE;
  defaultitemsperpage: number = myGlobals.AUTHENTICATOR_ITEMS_PER_PAGE;
  localstoragekey: string = myGlobals.AUTHENTICATOR_LOCALSTORAGE_KEY;
  pagesizes: Object[];
  @ViewChild(Table)
  private objtblcmp: Table;

  constructor(
    private apiService: APIService,
    public objmodal: Modal,
    vcRef: ViewContainerRef,
    private router: Router,
    private messageService: MessageService,
    private auth: AuthService,
    private globalService: GlobalService,
    private settings: SettingsService
  ) {

    objmodal.overlay.defaultViewContainer = vcRef;
    if (this.globalService.userRole != "neuroadmin") {
      this.redir();
    }
    else {
      this.titles = [['id', 1], ['name', 1], ['fact locator', 1]];
      this.InitiateChallenge();
    }
  }

  modifytable(objData: any) {

    if (objData) {
      if (objData.type == 1) {
        this.openModalError(objData.msg ? objData.msg : myGlobals.ADD_AUTHENTICATOR_SUCCESS, "Success");
        this.InitiateChallenge();
      }
      else {
        this.openModalError(objData.msg ? objData.msg : myGlobals.UPDATE_AUTHENTICATOR_SUCCESS, "Success");
        this.InitiateChallenge();
      }

    }
  }

  /* Function to redirect to dashboard on click of breadcrumb */
  redir() {
    this.messageService.highlightSidebar('dashboard');
    this.messageService.sendMessage('admin/dashboard');
    this.router.navigate(['admin/dashboard']);
  }


  InitiateChallenge(): void {
    var factLocators: any;
    this.data = [];
    this.factdata = [];
    this.apiService.getAuthenticators().then((response: any) => {
      var objBody = JSON.parse(response._body);
      if (objBody.statusCode == 402) {
        this.redir();
      }
      else if (objBody.factLocators && objBody.factLocators.statusCode
        && objBody.factLocators.statusCode == 401 || objBody.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalService.redirectServerOrClient();
      }
      else {
        this.AuthenticatorsList = objBody.authenticatorResponse;

        factLocators = objBody.factLocators.factLocators;
        this.factdata = [];
        this.data.splice(0, this.data.length);
        for (let i = 0; i < factLocators.length; i++) {
          if (factLocators[i].factKey) {
            this.factdata.push({ 'id': factLocators[i].factKey, 'text': factLocators[i].displayName });
          }
        }

        for (var i = 0; i < this.AuthenticatorsList.length; i++) {
          if (this.AuthenticatorsList[i].id) {

            var oedit = this.filterFactData(this.AuthenticatorsList[i].factKey, 0);
            var pointer: string = this.factdata.indexOf(oedit).toString();
            var factdsc = this.factdata[pointer]["text"];
            var factdscid = this.factdata[pointer]["id"];
            this.data.push({
              'id': this.AuthenticatorsList[i].id.value,
              'name': this.AuthenticatorsList[i].description,
              'fact locator': factdsc,
              'factid': factdscid
              //,'activekey': (factdsc == myGlobals.FACT_LOCATOR_PH; ? "De-Activate" : "Activate")
              // ,'editkey': (factdsc == myGlobals.FACT_LOCATOR_PH; ? 1 : 0)
              , 'activekey': (this.AuthenticatorsList[i].activeStatus == 1 ? "De-Activate" : "Activate")
              , 'editkey': (this.AuthenticatorsList[i].activeStatus)
            });
          }
        }
        let totalItems = this.data.length;

        this.pagesizes = [];
        let page = myGlobals.AUTHENTICATOR_ITEMS_PER_PAGE;
        while (page <= totalItems) {
          this.pagesizes.push({
            id: page.toString(),
            text: page.toString()
          })
          page += myGlobals.AUTHENTICATOR_ITEMS_PER_PAGE;
        }
        if ((page - myGlobals.AUTHENTICATOR_ITEMS_PER_PAGE) < totalItems || !this.pagesizes.length) {
          this.pagesizes.push({
            id: page.toString(),
            text: page.toString()
          });
        }
        this.itemsperpage = this.settings.getPageSize(this.data.length, myGlobals.AUTHENTICATOR_ITEMS_PER_PAGE, myGlobals.AUTHENTICATOR_LOCALSTORAGE_KEY);
        this.objtblcmp.checkText();
      }
    }).catch(error => {
      console.log(error);
    });
  }

  /* Confirmation modal for remove authenticator */
  openModal(displaymsg: string) {
    const dialog = this.objmodal.open(ConfirmModelData, overlayConfigFactory(
      {
        size: 'md',
        isBlocking: false,
        message: displaymsg
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");

        if (result == "1") {

          this.deleteRow();
        }
      });
    });
  }

  /* Function triggered on click of remove button in authenticator list */
  remove(obj: Object) {
    this.objDelete = obj;
    let displaymsg: string = "";
    if (obj["editkey"] && obj["editkey"] == 1) {
      displaymsg = myGlobals.DEACTIVATE_AUTHENTICATOR_CONFIRM;
    }
    else {
      displaymsg = myGlobals.ACTIVATE_AUTHENTICATOR_CONFIRM;
    }
    this.openModal(displaymsg);
  }

  /* Modal displayed incase of error in deleting authenticator */
  openModalError(msg: string, headtext: string) {
    const dialog = this.objmodal.open(AlertModelData, overlayConfigFactory(
      {
        isBlocking: true,
        message: msg,
        headtext: headtext
      }, BSModalContext));

    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
      });
    });
  }

  /* Function that deletes the row from authenticator table */
  deleteRow() {

    var toDelete = this.filterByID(this.objDelete);
    var index: string = this.data.indexOf(toDelete).toString();
    var objReqId = this.data[index].id;

    var activeStatusId = 0;
    if (this.data[index]["editkey"] == 0) {
      activeStatusId = 1;
    }


    this.apiService.updateAuthenticators({
      AuthenticatorID: this.data[index]["id"],
      AuthenticatorDesc: this.data[index]["name"],
      factid: this.data[index]["factid"],
      activeStatus: activeStatusId
    }).then(response => {
      var resp = JSON.parse(response._body);
      if (resp.statusCode == 401) {
        this.globalService.redirectServerOrClient();
      }
      else if (resp.error == 0) {
        this.InitiateChallenge();//Refresh the grid
      }
      else {
        var objError = resp.msg;
        this.openModalError(objError, "Error");
      }
    }).catch(error => {
      console.log(error);
    });

    /*  this.apiService.deleteAuthenticators({reqId:objReqId} ).then((response:any) => {       
        var resp = JSON.parse(response._body);m
        if(resp.statusCode == 401){
          this.auth.authInvalid= true;
          this.globalService.redirectServerOrClient();
        }
        else if(resp.error == 0){
          this.data.splice(parseInt(index), 1);
        }
        else{this.openModalError(resp.msg, "Error");}
      }); */
  }

  /* Return authenticator object based on id */
  filterByID(d: Object): Object {
    var match = this.data.filter(function (el) {
      return el['id'] === d['id'];
    });
    return match[0];
  }

  /* Return authenticator object based on fact locator */
  filterFactData(d: string, i: number): Object {
    if (i == 0) {
      var match = this.factdata.filter(function (el) {
        return el['id'] === d;
      });
    }
    else {
      var match = this.factdata.filter(function (el) {
        return el['text'] === d;
      });
    }

    return match[0];
  }

  /* Function triggered on click of edit authenticator */
  edit(obj: Object) {
    var toEdit = this.filterByID(obj);
    var index: string = this.data.indexOf(toEdit).toString();

    var oedit = this.filterFactData(this.data[index]["fact locator"], 1);
    var pointer: string = this.factdata.indexOf(oedit).toString();
    var factid = this.factdata[pointer]["id"];
    const dialog = this.objmodal.open(ChallengeModel, overlayConfigFactory(
      {
        isBlocking: true,
        authID: this.data[index].id,
        authDescription: this.data[index].name,
        activefact: [{ 'text': this.data[index]["fact locator"] }],
        authEdit: true,
        Add: "Edit",
        factLocator: this.factdata,
        selectedfactkey: factid,
        selectedfactvalue: this.data[index]["fact locator"],
        authHeadermsg: "Edit authenticator using this form"
      }, BSModalContext));



    dialog.then((resultPromise) => {
      resultPromise.result.then((result) => {
        let objbody = document.getElementsByTagName('body')[0];
        objbody.classList.remove("modal-open");
        if (result) {
          this.modifytable(result);
        }
        //this.InitiateChallenge();
      });
    });
  }

}
