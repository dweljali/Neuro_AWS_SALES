/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, Input, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MessageService } from './../../../services/MessageService';
import { Subject } from 'rxjs/Subject'

import { AlertModelData } from '../../../common/alertModal.component';
import { Overlay, overlayConfigFactory } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { GlobalService } from './../../../services/globalFunctions.service';
import { AuthService } from './../../../services/auth.service';
import { APIService } from '../../../services/APIService.service';
import { RuleIDService } from '../ruleID.service';

import { RULE_FACT_SERVICE_PH_TEXT, RULE_FACT_PH_TEXT, RULE_RULE_CONDITION_OPERATOR_PH_TEXT } from '../appRuleMessages'
//list of reserved rule names
const reservedNames = [
	'none',
	'all users'
]
@Component({
	selector: 'rule-wizard',
	template: `<!-- START PAGE CONTENT -->
	<span defaultOverlayTarget></span>
	
	<div class="content ">
	  <!-- MODAL STICK UP  -->
	  <!-- START JUMBOTRON -->
	  <div class="jumbotron" data-pages="parallax">
		<div class="container-fluid container-fixed-lg sm-p-l-20 sm-p-r-20">
		  <div class="inner">
			<!-- START BREADCRUMB -->
			<ul class="breadcrumb">
			  <li>
				<a (click)="redir()" href="javascript:void(0)">Dashboard</a>
			  </li>
			  <li>
				<a class="active">CONFIGURE RULES</a>
			  </li>
			</ul>
			<!-- END BREADCRUMB -->
		  </div>
		</div>
	  </div>
	  <!-- END JUMBOTRON -->
	  <!-- START CONTAINER FLUID -->
	  <div class="container-fluid container-fixed-lg bg-white">
		<!-- START PANEL -->
		<div class="panel panel-transparent">
		  <div class="panel-heading">
			<div class="panel-title">
			</div>
		  </div>
		  <div class="panel-body">
			<div class="row">
			  <div class="col-sm-12">
				<form id="form-work" class="form-horizontal" role="form" autocomplete="off">
				  <div class="form-group">
					<label for="fname" class="col-sm-3 control-label">Rule Name</label>
					<div class="col-sm-9 mandatory">
					  <input type="text" class="form-control" id="rname" maxlength="50" placeholder="Enter Rule Name" name="ruleName" [(ngModel)]="ruleName">
					</div>
				  </div>
				  <div class="form-group">
					<label for="name" class="col-sm-3 control-label">Rule Description</label>
					<div class="col-sm-9 mandatory">
					  <textarea class="form-control" id="rdsc" maxlength="250" rows="4" placeholder="Enter Rule Description" name="description" [(ngModel)]="ruleDescription" style="resize: vertical;">{{rulename}}</textarea>
					</div>
				  </div>
				  <div class="form-group">
					<label for="name" class="col-sm-3 control-label">Rule Fact Service</label>
					<div class="col-sm-9 mandatory">
					  <custom-select [dataobject]="ruleservice" [placeholder]="ruleFactServicePH" [activemember]="activefactService" (selectvaluechange)="selectedvalueRuleFactService($event)">
					  </custom-select>
	
					</div>
				  </div>
				  <div class="form-group">
					<label for="fname" class="col-sm-3 control-label">Fact Service Lookup Key</label>
					<div class="col-sm-9 mandatory">
					  <input type="text" class="form-control" id="rfactServiceKey" maxlength="50" placeholder="Run-time variable to invoke fast-service (e.g.$userid)" name="fname"
						[value]="uid" [(ngModel)]="factServiceKey" [disabled]="true">
					</div>
				  </div>
				  <div class="form-group">
					<label for="fname" class="col-sm-3 control-label">Build Rule Conditions</label>
					<div class="col-sm-9">
					  <div class="row">
						<div class="col-sm-3">
	
						  <custom-select [dataobject]="buildRuleconditionA" [activemember]="activebuildRuleconditionA" [placeholder]="ruleFactPH" (selectvaluechange)="selectedvalueRuleConditionA($event)">
						  </custom-select>
						</div>
						<div class="col-sm-3">
	
						  <custom-select [dataobject]="buildRuleconditionB" [placeholder]="ruleConditonOperatorPH" (selectvaluechange)="selectedvalueRuleConditionB($event)">
						  </custom-select>
						</div>
						<div class="col-sm-3">
						  <input type="text" class="form-control" id="rval" maxlength="30" placeholder="Enter Value" name="subRuleVal" [(ngModel)]="subRuleVal">
						</div>
						<div class="col-sm-2">
						  <button class="btn btn-success" (click)="addSubRule()" [disabled]="(subRuleConditionA && subRuleConditionB && subRuleVal)? false: true">
							<i class="pg-plus"></i> Add</button>
						</div>
					  </div>
	
					  <div class="row">
						<div class="col-sm-9" style="padding-right:10px;">
						  <table class="table table-condensed" style="margin-top:15px;">
							<tbody>
							  <tr class="rule-conditions-row"  *ngFor="let rule of ruleConditions; let i = index; let length= count;">
								<td *ngIf="rule.attribute && rule.condition_operator " class="col-lg-8 col-md-10 col-sm-7">
								  <a class="remove-item" style="margin-left:10px;cursor:pointer;" accesskey="" (click)="removeSubRule(i)">
									<i class="pg-close"></i>
								  </a>
								  <span class="m-l-10 ">Rule {{i + 1}} - {{rule.attribute.text}} {{rule.condition_operator.text}} {{rule.value}}</span>
								</td>
								<div *ngIf="i != (length -1)" class="rule-conditions-connector">
								  <custom-select [dataobject]="ruleConnector" [placeholder]="cdata" [activemember]="rule.operator"(selectvaluechange)="selectedvalueConnector(i,$event)">
								  </custom-select>
								</div>
							  </tr>
							</tbody>
						  </table>
						</div>
					  </div>
					</div>
				  </div>
				  <br>
				  <div class="row">
					<div class="col-sm-3">
					</div>
					<div class="col-sm-9">
					  <button class="btn btn-success pull-right" type="submit" (click)="saveRule()">Save</button>
					  <button class="btn btn-default pull-right" style="margin-right:5px;" routerLink="/admin/ruleconfiguration">Cancel</button>
					</div>
				  </div>
	
				</form>
				<div class="emptyDiv" style="height: 20vh;"></div> 
			  </div>
			</div>
		  </div>
		</div>
		<!-- END PANEL -->
	  </div>
	  <!-- END CONTAINER FLUID -->
	</div>`,
	providers: [APIService, Modal]
})
export class rulewizardComponent {

	public ruleservice: Object[] = [];
	public ruleConditions: Object[] = [];
	ruleConditionsForEachFactService: Object[] = [];
	buildRuleconditionA: Object[] = [];
	attributeOptions: Object[] = [];
	buildRuleconditionB: Object[] = [];
	ruleConnector: Object[] = [];
	subRuleConditionA: Object = null;
	subRuleConditionB: Object = null;

	ruleName: string;
	ruleDescription: string;
	factServiceKey: string;
	activebuildRuleconditionA: Object[];
	selectedFactService: Object;
	activefactService: Object[];
	subRuleVal: string;
	ruleFactServicePH: string = RULE_FACT_SERVICE_PH_TEXT;
	ruleFactPH: string = RULE_FACT_PH_TEXT;
	ruleConditonOperatorPH: string = RULE_RULE_CONDITION_OPERATOR_PH_TEXT
	cdata: string = "AND";
	rulename: string;
	private sub: any;
	cl: Boolean = false;
	cl2: Boolean = false;
	uid: string = "$userid";
	formType: string;
	constructor(
		private route: ActivatedRoute,
		private router: Router,
		private messageService: MessageService,
		private apiService: APIService,
		private globalService: GlobalService,
		private auth: AuthService,
		public modal: Modal,
		vcRef: ViewContainerRef,
		private ruleIdService: RuleIDService
	) {
		modal.overlay.defaultViewContainer = vcRef;
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
		/*	this.ruleservice = [
				{ "id": "Phone Number", "text": "Phone Number" },
				{ "id": "User Information", "text": "User Information" },
				{ "id": "Account Data", "text": "Account Data" },
				{ "id": "User Family Information", "text": "User Family Information" }
			];*/
		this.buildRuleconditionA = [];

		/*this.buildRuleconditionA = [
			{ "id": "Location", "text": "Location" },
			{ "id": "Country", "text": "Country" },
			{ "id": "State", "text": "State" },
			{ "id": "Birthdate", "text": "Birthdate" },
			{ "id": "CustomerType", "text": "CustomerType" },
			{ "id": "CustomerSince", "text": "CustomerSince" },
			{ "id": "PhoneNumber", "text": "PhoneNumber" }
		];*/

		/*this.buildRuleconditionB = [{ "id": "StartsWith", "text": "StartsWith" },
		{ "id": "Contains", "text": "Contains" },
		{ "id": "EqualTo", "text": "EqualTo" },
		{ "id": "NotEqualTo", "text": "NotEqualTo" },
		{ "id": "EndsWith", "text": "EndsWith" }];*/


		this.ruleConnector = [
			{ "id": "AND", "text": "AND" },
			{ "id": "OR", "text": "OR" }
		];
		//	this.selectedFactService = this.ruleservice[0];
	}
	ngOnInit() {
		this.getRuleConditions();

		this.route.params.subscribe(params => {
			this.formType = params['id'];
			this.getRuleFacts();
		});

	}
	getRuleFacts() {
		this.apiService.getRuleFacts().then((response) => {
			var objdata = JSON.parse(response._body);
			if (objdata.statusCode == 401) {
				this.auth.authInvalid = true;
				this.globalService.redirectServerOrClient();
			}
			this.ruleservice = objdata['facts'].map((fact: Object) => {
				return { id: fact['factType'], text: fact['factType'] }
			});
			this.attributeOptions = objdata['facts'].map((fact: Object) => {
				let attributes = fact['attributes'].map((attr: String) => {
					return { id: attr, text: attr }
				});
				return {
					id: fact['factType'],
					attributes,
					factLookupKey: fact['factLookupKey']
				}
			});
			// create an array of Objects, each object has id=ruleFactService and empty ruleConditions array
			this.ruleConditionsForEachFactService = objdata['facts'].map((fact: Object) => {
				let ruleConditions: Object[] = [];
				return {
					id: fact['factType'],
					ruleConditions
				}
			});
			if (this.formType == 'edit') {
				this.getRuleDeails();
			}
		}).catch((err) => {
			console.log(err);
		});
	}
	getRuleDeails() {
		let id = this.ruleIdService.ruleID;
		if (id) {
			this.apiService.getRuleByID(id).then((response) => {
				var objdata = JSON.parse(response._body);
				if (objdata.statusCode == 401) {
					this.auth.authInvalid = true;
					this.globalService.redirectServerOrClient();
				}
				this.ruleName = objdata['rule']['name'];
				this.ruleDescription = objdata['rule']['description'];



				this.selectedFactService = this.ruleservice.find((val) => {
					return val['id'] == objdata['rule']['factService']
				});

				if (this.selectedFactService) {
					this.activefactService = [{ text: objdata['rule']['factService'] }];
					this.factServiceKey = objdata['rule']['factServiceLookupKey'];
				}
				//get corresponding rule facts
				let fact: Object = this.attributeOptions.find((value: Object) => {
					return value['id'] == objdata['rule']['factService'];
				});
				this.buildRuleconditionA = fact['attributes'];

				let ruleConditions = objdata['rule']['ruleConditions'].map((ruleCondition: Object) => {
					return {
						attribute: this.buildRuleconditionA.find((value: Object) => { return value['id'] == ruleCondition['attribute'] }),
						condition_operator: this.buildRuleconditionB.find((value: Object) => { return value['id'] == ruleCondition['condition_operator'] }),
						value: ruleCondition['value'],
						rule_operator: ruleCondition['rule_operator']
							? this.ruleConnector.find((connector: Object) => { return connector['id'] == ruleCondition['rule_operator'] })
							: this.ruleConnector[0],
						operator: ruleCondition['rule_operator']
							? [{ text: ruleCondition['rule_operator'] }]
							: [{ text: this.ruleConnector[0]['id'] }]
					}
				});


				//set corresponding fact subrules
				//get current rule Fact Service
				let ruleConditionsForCurrFactService: Object = this.ruleConditionsForEachFactService.find((ruleCondition: Object) => {
					return ruleCondition['id'] == objdata['rule']['factService'];
				});
				//update it's ruleConditons to whatever is returned by the api
				ruleConditionsForCurrFactService['ruleConditions'] = ruleConditions;
				//point ruleConditions to the current rule Fact service's ruleconditions
				this.ruleConditions = ruleConditionsForCurrFactService['ruleConditions'];
			}).catch((err) => {
				console.log(err);
			})
		} else {
			this.router.navigate(['admin/ruleconfiguration'])
		}

	}
	getRuleConditions() {
		this.apiService.getRuleConditions().then((response) => {

			var objdata = JSON.parse(response._body);


			if (objdata.statusCode == 401) {
				this.auth.authInvalid = true;
				this.globalService.redirectServerOrClient();
			}
			else if (objdata.statusCode == 402) {
				this.redir();
			}
			else {
				this.buildRuleconditionB = objdata['ruleConditions'];
			}
		}).catch((err) => {
			console.log(err);
		});;
	}
	selectedvalueRuleFactService(data: any) {
		this.selectedFactService = data;
		let fact: Object = this.attributeOptions.find((value: Object) => {
			return value['id'] == data['id'];
		});
		this.buildRuleconditionA = fact['attributes'];
		this.factServiceKey = fact['factLookupKey'];

		//set corresponding fact subrules
		let ruleConditionsForCurrFactService: Object = this.ruleConditionsForEachFactService.find((ruleCondition: Object) => {
			return ruleCondition['id'] == data['id'];
		});

		this.ruleConditions = ruleConditionsForCurrFactService['ruleConditions'];
		this.activebuildRuleconditionA = []; //set active member for attribute
		this.subRuleConditionA = null;
	}
	selectedvalueRuleConditionA(data: any) {
		this.subRuleConditionA = data;
	}
	selectedvalueRuleConditionB(data: any) {
		this.subRuleConditionB = data;
	}
	validateSubRule(): boolean {

		let ruleFactService = this.attributeOptions.find((facts) => {
			return facts['id'] == this.selectedFactService['id']
		});
		//check if fact service is valid
		if (ruleFactService && ruleFactService['attributes']) {
			//check if selected attrivute is associated with the given fact service
			let attributeList: string[] = ruleFactService['attributes'].map((attr: Object) => attr['id']);
			return attributeList.indexOf(this.subRuleConditionA['id']) >= 0 ? true : false;
		}
		else {
			return false;
		}
		//	if(ruleFactService[''])
	}
	addSubRule() {
		if (this.validateSubRule()) {
			let rule: Object = {};
			rule['attribute'] = this.subRuleConditionA;
			rule['condition_operator'] = this.subRuleConditionB;
			rule['value'] = this.subRuleVal;
			rule['rule_operator'] = this.ruleConnector[0]; //set it to AND by default
			rule['operator'] = [{ text: this.ruleConnector[0]['id'] }];
			this.subRuleVal = '';
			//this.ruleConditionsForEachFactService[this.selectedFactService['id']]['ruleConditions'].push(rule);
			this.ruleConditions.push(rule);
		}else{
			this.activebuildRuleconditionA = null;
			this.subRuleConditionA = null;
			this.openModal('Please select correct rule fact data.', "Error");
		}
	}
	removeSubRule(index: number) {
		this.ruleConditions.splice(index, 1);
	}
	selectedvalueConnector(index: number, data: any) {
		this.ruleConditions[index]['rule_operator'] = data;
	}
	isRuleNameReserved() {
		return reservedNames.indexOf(this.ruleName.trim().toLowerCase()) != -1 ? true : false;
	}
	saveRule() {
		//validate ruleName first
		if (this.ruleName && this.isRuleNameReserved()) {
			this.openModal(`Rule name cannot be "${this.ruleName}"`, "Error");
			return;
		}
		//validate other fields
		if (this.ruleName &&
			this.ruleDescription &&
			this.selectedFactService &&
			this.factServiceKey) {

			if (!this.ruleConditions.length) {
				this.openModal("Rule must have at least one rule condition.", "Error");
				return;
			}
			let rule = {
				name: this.ruleName,
				description: this.ruleDescription,
				factServcie: this.selectedFactService,
				factServcieKey: this.factServiceKey,
				ruleConditions: this.ruleConditions,
			}
			if (this.ruleIdService.ruleID) { // is an edit 
				this.apiService.editRule(this.ruleIdService.ruleID, rule).then((resp) => {
					var objdata = JSON.parse(resp._body);
					if (objdata.statusCode == 401) {
						this.auth.authInvalid = true;
						this.ruleIdService.ruleID = null;
						this.globalService.redirectServerOrClient();
					}
					else if (objdata.error == 0) {
						this.ruleIdService.ruleID = null;
						this.openModal("Rule edited successfully.", "Success");
					}
					else { this.openModal(objdata.errorMsg, "Error"); }
				}).catch(error => { console.log(error) });

			} else {
				this.apiService.postRules(rule).then((resp) => {
					var objdata = JSON.parse(resp._body);
					if (objdata.statusCode == 401) {
						this.auth.authInvalid = true;
						this.globalService.redirectServerOrClient();
					}
					else if (objdata.error == 0) {
						this.openModal("Rule added successfully.", "Success");
					}
					else { this.openModal(objdata.errorMsg, "Error"); }
				}).catch(error => { console.log(error) });
			}
		} else {
			this.openModal("Please enter all the mandatory fields.", "Error");
		}
	}
	/* Function displays alert incase data is incomplete and navigates to the appropriate tab*/
	openModal(msg: string, headtext: string) {
		const dialog = this.modal.open(AlertModelData, overlayConfigFactory(
			{
				isBlocking: true,
				message: msg,
				headtext: headtext
			}, BSModalContext));

		dialog.then((resultPromise) => {
			resultPromise.result.then((result) => {
				let objbody = document.getElementsByTagName('body')[0];
				objbody.classList.remove("modal-open");
				headtext == "Success" ? this.router.navigate(['admin/ruleconfiguration']) : '';

			});
		});
	}
	redir() {
		this.messageService.highlightSidebar('dashboard');
		this.messageService.sendMessage('admin/dashboard');
		this.router.navigate(['admin/dashboard'])
	}
}