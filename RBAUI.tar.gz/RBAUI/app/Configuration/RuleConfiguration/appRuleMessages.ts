export const RULE_FACT_SERVICE_PH_TEXT = "Select Fact Service"
export const RULE_FACT_PH_TEXT = "Select Fact"
export const RULE_RULE_CONDITION_OPERATOR_PH_TEXT = "Select Operator"
export const RULES_ITEMS_PER_PAGE = 10;
export const RULES_LOCALSTORAGE_KEY: string = "rule-page-size";
export const RULES_MAX_PAGE_SIZE = 5;