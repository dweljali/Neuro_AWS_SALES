/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit, Input, Renderer, ElementRef, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/map';
import { APIService } from '../../services/APIService.service';
import { GlobalService } from '../../services/globalFunctions.service';
import { Subject } from 'rxjs/Subject';
import { AuthService } from '../../services/auth.service';
import { DateRange } from './models/dateRange.model';
import { RISK_SCORE_INDEX_GRAPH_TITLE } from './opsDashboardMessages';

@Component({
  selector: 'chart-card-rsi',
  template: `<div class="col-sm-4 m-b-10">
    <div class="widget-12 panel no-border widget-loader-circle no-margin">
    <div class="row">
    <div class="col-xlg-12">
    <div class="panel-heading pull-up top-right ">
    <div class="panel-controls">

    </div>
    </div>
    </div>
    </div>
    <div class="panel-body" style="height:550px">
    <div class="row">
    <div class="col-xlg-12">
    <div class="p-l-10">
    <h2 class="pull-left">
      <span class="icon-thumbnail bg-master-light pull-left text-master">{{cardcode}}</span>
      <span style="font-size: 24px;"> {{cardname}}</span>
    </h2>
    <div class="clearfix"></div>
    <h2 class="pull-left m-l-50 text-danger">
    <span class="bold">{{totalcount}}</span>
    <span class="text-danger fs-12"></span>
    </h2>
    <div class="clearfix"></div>
    <div class="full-width">
    <ul class="list-inline">
    <li [class.active]="isDay">
    <a href="javascript:void(0)" (click)="dayView()" class="font-montserrat text-master" 
    [class.bg-master-light]="isDay">1D</a>
    </li>
    <li [class.active]="isWeek">
    <a href="javascript:void(0)" (click)="weekView()" class="font-montserrat text-master"
    [class.bg-master-light]="isWeek">7D</a>
    </li>
    <li [class.active]="isMonth">
    <a  href="javascript:void(0)" (click)="monthView()" class="font-montserrat text-master"
    [class.bg-master-light]="isMonth">1M</a>
    </li>                              
    </ul>
    </div>

    <div class="nvd3-line5 line-chart text-center" data-x-grid="false">
    <div style="display: block;">

    <canvas baseChart   class="chart" height="250"
    [datasets]="lineChartData"
    [labels]="lineChartLabels"
    [options]="lineChartOptions"
    [colors]="lineChartColors"
    [legend]="lineChartLegend"
    [chartType]="lineChartType"
    (chartHover)="chartHovered($event)"
    (chartClick)="chartClicked($event)">
    </canvas>
    </div>
    </div>

    </div>
    </div>
    </div>
    </div>
    </div>                  
    </div>`
})
export class ChartCardComponentRSI {
  @Input() changeddatevalues: any;

  private fromDate: string = '';
  private toDate: string = '';
  private fromDateObj: any = {};
  private toDateObj: any = {};
  public isDay: boolean = false;
  public isWeek: boolean = false;
  public isMonth: boolean = false;
  public lineChartData: Array<any> = [];
  public lineChartLabels: any = [];
  public upperLimit: any = [];
  @Output() datechange = new EventEmitter<DateRange>();
  
  ngOnChanges(changes: any) {
    if (changes.changeddatevalues.currentValue) {
      if (changes.changeddatevalues.currentValue.fromDate && changes.changeddatevalues.currentValue.toDate) {
        this.setActiveClass(false, false, false);
        this.fromDate = changes.changeddatevalues.currentValue.fromDate;
        this.toDate = changes.changeddatevalues.currentValue.toDate;
        this.callGraphAPI('NA');
        setTimeout(() => {
          this.changeLabels();
        }, 1000);
      }
    }
  }

  private totalcount: number = 0;
  private cardcode: string = 'RSI';
  private cardname: string = RISK_SCORE_INDEX_GRAPH_TITLE;

  public dynlinedata: any = [];


  public lineChartOptions: any = {
    responsive: true
    // scales : {
    //   yAxes: [{
    //        ticks: {
    //          max : 100
    //         }
    //     }] 
    // }
  };
  public lineChartColors: Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend: boolean = false;
  public lineChartType: string = 'line';

  ngOnInit() {

    this.lineChartData = [
      { data: [], label: 'RSI' }
    ];
    this.lineChartLabels = [];
    this.dynlinedata = [];
    this.upperLimit = [];
  }
  ngAfterViewInit() {

    setTimeout(() => {
      this.changeLabels();
    }, 1000);
  }


  constructor(private apiService: APIService, private renderer: Renderer,
    private globalservice: GlobalService, private auth: AuthService) {
    this.setActiveClass(false, false, true);
    this.toDateObj = new Date();
    // this.toDateObj.setHours(23,59,59,999);
    // console.log(this.toDateObj);
    // console.log(this.toDateObj.toISOString());
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Month');
    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;
    this.callGraphAPI('1M');
  }

  setActiveClass(day: boolean, week: boolean, month: boolean) {
    this.isDay = day;
    this.isWeek = week;
    this.isMonth = month;
  }


  emitDates() {
    this.datechange.emit({
      fromDate: this.fromDate,
      toDate: this.toDate
    })
  }

  dayView() {
    this.setActiveClass(true, false, false);
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Day');

    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, true);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;

    this.callGraphAPI('1D');
    setTimeout(() => {
      this.changeLabels();
    }, 1000);
    this.emitDates();
  }

  weekView() {
    this.setActiveClass(false, true, false);
    // this.calcPastDays();
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Week');

    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;

    this.callGraphAPI('7D');
    setTimeout(() => {
      this.changeLabels();
    }, 1000);
    this.emitDates();
  }

  monthView() {
    this.setActiveClass(false, false, true);
    this.toDateObj = new Date();
    this.fromDateObj = this.globalservice.calcPastDays(this.toDateObj.getFullYear(), this.toDateObj.getMonth(), this.toDateObj.getDate(), 'Month');

    let formattedDates = this.globalservice.constructDateString(this.fromDateObj, this.toDateObj, false);
    this.fromDate = formattedDates.fromDate;
    this.toDate = formattedDates.toDate;

    this.callGraphAPI('1M');
    setTimeout(() => {
      this.changeLabels();
    }, 1000);
    this.emitDates();

  }
  // lineChart

  // events
  public chartClicked(e: any): void {
    //console.log(e);

  }

  public chartHovered(e: any): void {
    // console.log(e);
  }

  callGraphAPI(duration: string) {
    let apiData: any = {};
    let lineChartDataA: Array<any> = [];

    this.dynlinedata = [];
    this.upperLimit = [];
    apiData.startDate = this.fromDate;
    apiData.endDate = this.toDate;
    apiData.locale = window.navigator.language;
    apiData.duration = duration;
    this.apiService.getChartData(apiData, 'RSI').then(res => {
      this.lineChartOptions = {
        responsive: true
      }

      var dataAPI = res._body;
      dataAPI = JSON.parse(dataAPI);

      this.totalcount = 0;
      if (dataAPI.statusCode == 200) {
        let data: any = [];
        if (dataAPI.data) {
          this.totalcount = dataAPI.data.cumulativeValue;

          if (Object.keys(dataAPI.data.graphData).length == 1) {
            this.dynlinedata.push('0');
            data.push(0);
            for (let key in dataAPI.data.graphData) {
              this.dynlinedata.push(key);
              data.push(dataAPI.data.graphData[key]);
            }

          }
          else if (Object.keys(dataAPI.data.graphData).length > 0) {
            for (let key in dataAPI.data.graphData) {
              this.dynlinedata.push(key);
              data.push(dataAPI.data.graphData[key]);
            }
          }

        }
        this.upperLimit[0] = Math.max.apply(Math, data);
        if (this.upperLimit[0] < 30) {
          this.upperLimit[0] = 30;
        }
        // else{
        //   this.upperLimit[0]= this.upperLimit[0]+ ((Math.round(this.upperLimit[0]/10))*2);
        // }
        lineChartDataA.push({ data: data, label: 'RSI' });
        this.lineChartData = lineChartDataA;
        // this.lineChartOptions.scales.yAxes[0].ticks.max=this.upperLimit[0];
      }
      else if (dataAPI.statusCode == 401) {
        this.auth.authInvalid = true;
        this.globalservice.redirectServerOrClient();
      }
    }).catch(error => { console.log(error) });

  }

  changeLabels(): void {
    if (this.upperLimit[0] <= 30) {
      this.lineChartOptions = {
        responsive: true,
        scales: {
          yAxes: [{
            ticks: {
              max: 30
            }
          }]
        }
      };
    }
    // this.lineChartOptions.scales.yAxes[0].ticks.max=this.upperLimit[0];
    this.lineChartLabels = this.dynlinedata;
  }
}