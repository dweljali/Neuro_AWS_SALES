/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component, OnInit } from '@angular/core';
import { PERSISTENT_SYSTEM_HOME_LINK } from './appMessages';
@Component({
    selector: 'footer',
    templateUrl: './footer.html',

})
export class Footer {
    constructor() {

    }

    gotoLink() {
        window.open(PERSISTENT_SYSTEM_HOME_LINK, "_blank");
    }

}