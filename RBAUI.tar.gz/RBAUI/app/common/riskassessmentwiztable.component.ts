import { Component, OnInit,Input } from '@angular/core';
import {OrderByPipe} from './orderBy.component';
 

/* Reusable component for tables */ 
@Component({
    selector:'risk-wiz-table',
    template: `
<table class="table table-hover demo-table-search table-responsive-block" id="tableWithSearch">
               <thead> 
               <tr> 
               <th *ngFor="let heading of headings" 
                        [class.pointer_cursor]="(heading[1] == 1)" 
                        (click)="sort(heading[0])">{{heading[0]}}
                     <i class="fa" [ngClass]="{'fa-sort': column != heading[0], 
                        'fa-sort-asc': (column == heading[0] && isDesc), 
                        'fa-sort-desc': (column == heading[0] && !isDesc),
                        'hide-grid-sort': (heading[1] == 0)}" aria-hidden="true"> 
                    </i>
                </th><th></th></tr>
               </thead>
               <tbody> 
			<tr *ngFor="let item of data | orderBy: {property: column, direction: direction}; let i = index;" >
                <td *ngFor="let heading of headings" class="v-align-middle">
               <p *ngIf='!isArray(item[heading[0]])'>{{item[heading[0]]}}</p> 
               
               </td> 
      
					   <td class="v-align-middle"><p> <button class="btn btn-info"  
					(click)="remove(item['id'])">Delete</button></p> </td> 

               </tr>
               </tbody> 
               </table>`,
})
export class riskwiztable{

    @Input() headings:Object[];
    @Input() data:Object[];
    @Input() edit:Object;
    @Input() remove:Object;
    @Input() showalert: Object;
    @Input() placeholder:string;
    @Input() maxpagesize:number;
    @Input() itemsperpage:number;
    isDesc: boolean = false;
    column: string = '';
    direction: number;
    
    constructor() {
       
        
    }
    
   
    sort(property:any){
        let proceedSorting: boolean = false;
        for(let i=0; i<this.headings.length;i++){
            if(this.headings[i][0] == property){
                if(this.headings[i][1] == 1){
                    proceedSorting = true;
                }
                break;
            }
        }
        
        if(proceedSorting){
            this.isDesc = !this.isDesc; //change the direction    
            this.column = property;
            this.direction = this.isDesc ? 1 : -1;
        }
    };
     
    isArray(val: any) {  return typeof val==='object'; }
}