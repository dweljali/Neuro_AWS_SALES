import {Pipe, PipeTransform} from '@angular/core';
 
@Pipe({name: 'searchcriteria'})
export class SearchPipe implements PipeTransform {
  transform(data: any, searchText: any): any {
      
     if(searchText == null) return data;

    return data.filter(function(obj:any){
         
      console.log(searchText);
       return (
            (obj.id && obj.id.toLowerCase().indexOf(searchText.toLowerCase()) > -1) ||
            (obj.name && obj.name.toLowerCase().indexOf(searchText.toLowerCase()) > -1) ||
           (obj.ID && obj.ID.toLowerCase().indexOf(searchText.toLowerCase()) > -1) ||
           (obj.Description && obj.Description.toLowerCase().indexOf(searchText.toLowerCase()) > -1) ||
           (obj.Channel && obj.Channel.toLowerCase().indexOf(searchText.toLowerCase()) > -1)
      );
    })
  }
}