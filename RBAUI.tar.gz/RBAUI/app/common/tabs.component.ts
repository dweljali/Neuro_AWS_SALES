import { Component, OnInit,Input,Output, EventEmitter } from '@angular/core';
import {Tab} from './tab.component';
import {TabsService} from '../services/tabsService';
import { Subject } from 'rxjs/Subject';

@Component({
    selector:'tabs',
    template: `<div class="content ">
    <div class="container-fluid container-fixed-lg">
    <div class="m-t-50">
        <ul class="nav nav-tabs nav-tabs-linetriangle nav-tabs-separator nav-stack-sm">
            <li *ngFor="let tab of tabs" (click)="selectTab(tab)" [class.active]="tab.active==true">
                 <a data-toggle="tab" > <i class="{{tab.icon}} tab-icon"></i> <span>{{tab.objtitle}}</span></a>
            </li>

        </ul>
        <ng-content></ng-content>
    </div>
  </div>
  </div>`

})
export class Tabs{
    @Output() tablclicked = new EventEmitter<any>();
    tabs:Tab[]=[];
    private ngUnsubscribe: Subject<void> = new Subject<void>();
 
    ngOnDestroy(){
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }

    constructor(private tabservice:TabsService) {
      this.tabservice.getMessage().takeUntil(this.ngUnsubscribe).subscribe(message => {           
         this.tabs.forEach((tab) => {
            tab.active = false;
            if(tab.name==message.text){
                  tab.active = true;
                
            }
        });
      })
    }
 
    addTab(tab:Tab) {
      if (this.tabs.length === 0) {
        tab.active = true;
      }
      this.tabs.push(tab);
    }

    /* Function triggered when a tab is clicked */ 
    selectTab(tab:Tab) {
      for(let i=0; i<this.tabs.length; i++){
        if(this.tabs[i].active == true){
          switch(this.tabs[i].name){
            case "activity":
			  this.tabservice.sendMessage("postActivity",tab.name);
              break;
            case "risk":
              this.tabservice.sendMessage("postRisk",tab.name);
              break;
            case "authenticator":
              this.tabservice.sendMessage("postAuthenticator",tab.name);
              break;
            case "balance":
              this.tabservice.sendMessage("postBalance",tab.name);
              break;
            case "confirm":
              this.tabservice.sendMessage("confirmAction",tab.name);
              break;
		 	case "detailsriskswizard":
			  this.tabservice.sendMessage("updateRiskWizard",tab.name);
              break
			case "riskconfigriskwizard":
			  this.tabservice.sendMessage(tab.name,"");
              break
			case "riskfactorriskwizard":
			  this.tabservice.sendMessage(tab.name,"");
              break
			case "confirmriskwizard":
			  this.tabservice.sendMessage(tab.name,"");
			  break
			case "exportType":
              this.tabservice.sendMessage(tab.name,"");
              break;
            case "objectType":
              this.tabservice.sendMessage(tab.name,"");
              break;
            case "confirmExport":
              this.tabservice.sendMessage(tab.name,"");
              break;
		    case "importType":
              this.tabservice.sendMessage(tab.name,"");
              break;
            case "selectImport":
              this.tabservice.sendMessage(tab.name,"");
              break;
            case "confirmImport":
              this.tabservice.sendMessage(tab.name,"");
              break;
            }
            break;
        }
      }


      this.tabs.forEach((tab) => {
      tab.active = false;
      });
      tab.active = true;
      var emittab:string = tab.name;

      this.tablclicked.emit(emittab);
    }
}