/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Component,Input} from '@angular/core';

import { DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { BSModalContext } from 'angular2-modal/plugins/bootstrap';

export class CustomAlertModelData extends BSModalContext {
  public message: string;
}

/**
 * A Sample of how simple it is to create a new window, with its own injects.
 */
@Component({
  selector: 'modal-alert-content',
  template: `
          <div class="custModal">
            <div class="modal-dialog" [class.customfade]="isFade">             
              <div class="modal-header clearfix "> 
                <button type="button" class="close" (click)='close()' data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                </button>
                <h5>{{context.message}}</h5>      
              </div>
              <div class="modal-body">

              </div>
              <div class="modal-footer">
                <button id="add-app" data-dismiss="modal" type="button" (click)='save()' class="btn btn-primary  btn-cons">Yes</button>
                <button type="button" data-dismiss="modal" (click)='close()' class="btn btn-cons">No</button>
              </div>
            </div>
          </div>`
})
export class ConfirmModelData implements CloseGuard, ModalComponent<CustomAlertModelData> {
  context: CustomAlertModelData;
  public isFade = false;
  public returndata:any; 


  constructor(public dialog: DialogRef<CustomAlertModelData>) {
    this.context = dialog.context;
    dialog.setCloseGuard(this);
  }
  close(){
    this.isFade = true;
    this.dialog.close("0");
  }

  save(){
    this.isFade = true;
    this.dialog.close("1");
  }

  beforeDismiss(): boolean {
    this.isFade = true;
    this.dialog.close(this.returndata);      
    return false;
  }
}
