import { Component, Input, Output, EventEmitter } from '@angular/core';
 
/* Component for select */ 
@Component({
  selector: 'custom-select',
  template: `
    <div>      
      <ng-select [allowClear]="false"
                  [items]="dataobject"
                  [disabled]="disablegrid"
                  [active]="activemember"
                  (data)="refreshValue($event)"
                  (selected)="selected($event)"
                  (removed)="removed($event)"
                  (typed)="typed($event)"
                  placeholder="{{placeholder}}">
      </ng-select>      
    </div>`
})
export class selectComponent { 
  
  @Input() dataobject:Object[];
  @Input() placeholder:string;
  @Input() activemember:string[];
  @Output() selectvaluechange:EventEmitter<any>=new EventEmitter<any>(); 
  @Input() disablegrid:boolean;
  @Input() defaultmember:string[];  

  private value:any = {};
  private _disabledV:string = '0';
  private disabled:boolean = false;
  
  ngOnInit() {

  }
   
  private get disabledV():string {
    return this._disabledV;
  }
 
  private set disabledV(value:string) {
    this._disabledV = value;
    this.disabled = this._disabledV === '1';
  }
 
  public selected(value:any):void {
    this.selectvaluechange.emit(value);
  }
 
  public removed(value:any):void {
     if(this.defaultmember){
         this.activemember = this.defaultmember;
     }
  }
 
  public typed(value:any):void {
  }
 
  public refreshValue(value:any):void {
    this.value = value;
  }
}