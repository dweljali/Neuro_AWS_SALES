/*******************************************************************************
* Copyright (c) 2017  Persistent Systems Ltd.
* All rights reserved.
 *******************************************************************************/
import { Injectable }       from '@angular/core';
import {
	CanActivate, Router,
	ActivatedRouteSnapshot,
	RouterStateSnapshot
}                           from '@angular/router';
import { AuthService }      from './auth.service';
import {APIService} from './APIService.service';
import { GlobalService } from './globalFunctions.service';
@Injectable()
export class AuthGuard implements CanActivate {
	constructor(private authService: AuthService, private router: Router,
				private service:APIService,private globalService:GlobalService) {}

	canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
		let url: string = state.url;

		return this.checkLogin(url);
	}

	checkLogin(url: string):boolean {

		this.authService.redirectUrl = url;
		if(this.authService.isLoggedIn){return true}
			this.checkAuth(url);

	}

	 /* check if the user is logged before redirecting him to any page */ 
	checkAuth(url: string):boolean{
		var check = false;
		this.service.verifyLoggedIn().then(response=>{
			var data=response._body;
			data=JSON.parse(data)
			if(data.data==true){
				this.authService.isLoggedIn=true;
				this.router.navigate([url])
				/* Store the attempted URL for redirecting */ 
    		check= true
  		}
		  else{
		        /* Navigate to the login page with extras */
			      this.authService.isLoggedIn=false;
			      this.authService.authInvalid= true;
			      
			  	  if(data.authMode){ this.globalService.authMode = data.authMode;}
			      this.router.navigate(['/login']);
			      check= false;
		      }
	      }).catch(response=>{
	      	check=  false;
	      })
	      return check;
	  }
}
