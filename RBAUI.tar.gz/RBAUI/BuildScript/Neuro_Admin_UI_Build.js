/*******************************************************************************
* Copyright (c) 2017 Persistent Systems Ltd.
* All rights reserved. 
 *******************************************************************************/

//Commands
//Create build without npm modules [node Neuro_Admin_UI_Build.js None npm-install-skip]
//Create complete build package with npm modules [node Neuro_Admin_UI_Build.js None npm-install]
var shell = require('shelljs');
var Client = require('svn-spawn');
var fs = require('fs');

//SVN repo(Tag) URL for Build
var repo = "https://svn.persistent.co.in/svn/RBAC/trunk/RBAUI";

if (!shell.which('svn')) {
    shell.echo('Sorry, this script requires svn');
    shell.exit(1);
}

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function hidden(query, callback) {
    var stdin = process.openStdin(),
    i = 0;
    process.stdin.on("data", function(char) {
        char = char + "";
        switch (char) {
            case "\n":
            case "\r":
            case "\u0004":
                stdin.pause();
                break;
            default:
                process.stdout.write("\033[2K\033[200D"+query+"["+((i%2==1)?"=-":"-=")+"]");
                i++;
                break;
        }
    });

    rl.question(query, function(value) {
        rl.history = rl.history.slice(1);
        callback(value);
    });
}

rl.question('Please enter your SVN  username ', (username) => {

    hidden('Please enter your SVN  password ', (password) => {
        
        if(shell.exec("svn --no-auth-cache export "+repo+" --username "+username+" --password "+password).code!==0){
            shell.echo('Error: SVN export failed');
            shell.exit(1);
        }

        if(shell.exec("npm install --prod").code!==0){
            shell.echo('Error with npm install');
            shell.exit(1);
        }

        //creating a svn directory to allow commit   
        if(shell.exec("svn --no-auth-cache checkout "+repo+" RBAUIPackage/ --depth empty --username "
                      +username+" --password "+password).code!==0){
            
            shell.echo('Error: SVN checkout package failed');
            shell.exit(1);
        }

        var Client = require('svn-spawn');
        var client = new Client({
            cwd: __dirname+'/RBAUIPackage',
            username: username, // optional if authentication not required or is already saved
            password: password, // optional if authentication not required or is already saved
            noAuthCache: true, // optional, if true, username does not become the logged in user on the machine
        });
        shell.cd('RBAUIPackage');

        if(shell.exec("svn --no-auth-cache update package.json --username "+username+" --password "+password).code!==0){
            shell.echo('Error: SVN update package.json failed');
            shell.exit(1);
        }
        shell.cd('../');

        var file = require('./RBAUI/package.json');
        var version=file.version;
        var versions=version.split('.');
        var main_version=versions[0];
        var minor_version=versions[1];
        var patch_version=versions[2];

        if(process.argv[2]=="major"){
            main_version=parseInt(main_version)+1;
            minor_version=0;
            patch_version=0;
            client_version=0;
        }
        else if(process.argv[2]=="minor"){
            minor_version=parseInt(minor_version)+1;
            patch_version=0;
            client_version=0;
        }
        else if(process.argv[2]=="patch"){
            patch_version=parseInt(patch_version)+1;
            client_version=0;
        }
        versions[0]=main_version;
        versions[1]=minor_version;
        versions[2]=patch_version;
        file.version=versions.join('.');
        version=file.version;
        client.getInfo(function(err, data) {
            console.log('svn commit id is %s', data.commit.$.revision);
            file.revision=data.commit.$.revision;
            fs.writeFile('RBAUIPackage/package.json', JSON.stringify(file,null, 2), function (err) {
                if (err) return console.log(err);

                //copying updated package.json to svn directory
                shell.cp('RBAUIPackage/package.json','RBAUI/');

                shell.cd('RBAUI');

                //remove assets and pages folder  
                console.log("Removing assests folders");
                shell.rm('-rf', 'assets');
                shell.rm('-rf', 'pages');			

                if(process.argv[3]=="npm-install"){
                    console.log("npm install - Begin.......");
                    if(shell.exec("npm install --prod").code!==0){
                        shell.echo('Error with npm install');
                        shell.exit(1);
                    }
                    console.log("npm install was successful");
                }
                else{
                    console.log("Skip npm install and continue.....");
                }

                shell.cd('../');    

                console.log("Compression - tar.gz - Begin....");
                if(shell.exec("tar -zcvf  RBAUI_" + version + "_" + file.revision + ".tar.gz RBAUI").code!==0){
                    shell.echo('Compression failed');
                    shell.exit(1);
                };

                console.log("Build created!!")
                shell.rm('-rf', 'RBAUI'); //Remove RBAUI directory
                shell.rm('-rf', 'RBAUIPackage'); //Remove RBAUIPackage directory
                
                shell.echo('Script executed Successfully...');
                shell.exit(1);
                /*if(process.argv[3]=="no-build"){
                    shell.echo('exting shell');
                    shell.exit(1);
                }*/
            });
        });
    })
})